"""Turning what a session supports into findings someone can record.

This proposes and records nothing, like everything else in this package. The
drafts it returns go to a person, who reads them beside the interpretation and
decides; recording is the application layer's act and the citation check happens
there.

A draft carries the interpretation's limits as its conditions on purpose. A
caveat that stays behind in a report nobody re-reads has stopped travelling with
the finding, and the finding is the thing the next plan will read.
"""

from relab_core.interpretation import SessionInterpretation
from relab_core.memory import MAXIMUM_TAGS, MemoryDraft


def memory_drafts(
    interpretation: SessionInterpretation, scope: str, *, tags: list[str] | None = None,
) -> list[MemoryDraft]:
    """One draft per claim, or none at all from a session that carries nothing.

    The scope is the caller's to state. Nothing here can know where a result is
    believed to hold -- that is the judgement a person makes from the recorded
    facts, and inventing it would produce the generalisation nobody checked.
    """
    if not scope.strip():
        raise ValueError("a finding needs a scope: where it is believed to hold")
    if not interpretation.carries_findings:
        return []
    chosen = list(tags or [])[:MAXIMUM_TAGS]
    return [
        MemoryDraft(
            finding=claim.statement, scope=scope.strip(),
            conditions=list(interpretation.limits), citations=list(claim.citations),
            tags=chosen,
        )
        for claim in interpretation.claims
    ]
