"""What a planner may return, and what it may not.

Research Intelligence proposes; it records nothing and executes nothing. So
everything here is a value a person can read, amend or decline, and none of it
is a side effect that has already happened.

One design decision is worth stating because it came from evidence rather than
taste. The legacy client carries a `loopDetector` whose own comment records a
director that asked the same question for more than twenty turns and created
nothing, while the researcher answered three times. So there is **no way to
return a question instead of a proposal.** A planner that cannot determine
something states the assumption it made and proposes anyway; a person amends or
declines. Uncertainty becomes `assumptions`, never a turn that produced nothing.
"""

import math
import re

from pydantic import Field, model_validator

from relab_core.contracts import Contract
from relab_core.controls import (
    MAXIMUM_CONTROLS,
    MeasurementControl,
    controls_named_once,
)
from relab_core.evaluation import MetricRegistry
from relab_core.generation import ModelIdentity
from relab_core.inspection import InspectionRound
from relab_core.measurement import (
    MAXIMUM_REQUIREMENTS,
    MeasurementRequirement,
    MeasurementSetup,
    requirements_named_once,
)
from relab_core.routing import ModelRoutingPolicy
from relab_core.targets import EditTarget

MAXIMUM_ARMS = 8
MAXIMUM_ASSUMPTIONS = 16
MAXIMUM_PLANNED_FILES = 32
MAXIMUM_PLAN_STEPS = 16
MAXIMUM_RISKS = 8


class ResearchIntent(Contract):
    """What a person said they want to find out, kept as they said it."""

    stated: str = Field(min_length=1, max_length=4000)


class KnownSession(Contract):
    """A session already in the workspace, as the planner is allowed to see it."""

    session_id: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    state: str = Field(min_length=1)
    decision: str | None = None


class KnownFinding(Contract):
    """A finding a person confirmed into research memory, as the planner may see it."""

    memory_id: str = Field(min_length=1)
    finding: str = Field(min_length=1, max_length=2000)
    scope: str = Field(min_length=1, max_length=500)
    conditions: list[str] = Field(default_factory=list, max_length=4)


# Runs per arm a comparison needs when the metric is known to vary between runs of the
# same code (0.2.79): what the repeatability check asks for by default.
REPEATS_WHEN_IT_VARIES = 3
# Sizing them to the difference to tell (0.2.81): two arms compared at a two-sided 5%
# with 80% power need about 2 x (1.96 + 0.84)^2 = 15.7 x (sd / difference)^2 runs each.
POWER_FACTOR = 15.7
# A spread (largest minus smallest of one version's runs) read as a standard deviation:
# the range of two runs is 1.128 standard deviations; the larger estimate of the two.
RANGE_TO_SD = 1.128
MAXIMUM_SIZED_REPEATS = 20
# The difference a request says it wants to tell: "1%p", "1.5 points", "2 퍼센트포인트".
STATED_DIFFERENCE = re.compile(
    r"(\d+(?:\.\d+)?)\s*(?:%\s*p(?![A-Za-z])|퍼센트\s*포인트|포인트|percentage\s+points?|points?(?![A-Za-z])"
    r"|pp(?![A-Za-z]))",
    re.IGNORECASE)


def stated_difference(text: str) -> float | None:
    """The difference, in percentage points, a request says it wants to tell; the last one named."""
    found = [float(match.group(1)) for match in STATED_DIFFERENCE.finditer(text)]
    found = [value for value in found if value > 0]
    return found[-1] if found else None


def repeats_for(spread: float, difference: float) -> int:
    """Runs per arm to tell `difference` apart when one version's runs differ by up to `spread`."""
    if spread <= 0 or difference <= 0:
        return REPEATS_WHEN_IT_VARIES
    needed = math.ceil(POWER_FACTOR * (spread / RANGE_TO_SD / difference) ** 2)
    return max(REPEATS_WHEN_IT_VARIES, min(MAXIMUM_SIZED_REPEATS, needed))


def metric_key(name: str) -> str:
    """A metric's name as compared across records: `pass_rate`, `Pass rate`, `pass-rate` are one."""
    return " ".join(name.casefold().replace("_", " ").replace("-", " ").replace(".", " ").split())


class MeasuredSeries(Contract):
    """One evaluation's scores here, oldest first, as the coding loops' runs printed them (P5).

    One variable measured across versions of the code: what a study here sets
    its baseline from, rather than measuring again what is already known.
    """

    command: str = Field(min_length=1, max_length=300)
    metric: str = Field(min_length=1, max_length=80)
    # As printed ("66.7%", "0.812"), the newest last.
    shown: list[str] = Field(min_length=1, max_length=12)
    runs: int = Field(ge=1)
    tasks: int = Field(ge=1)
    latest_at: str = Field(default="", max_length=40)
    # How far runs of one version of the code differed, at most, as printed, and
    # how many runs were such repeats (0.2.77); empty when none was measured twice.
    spread: str = Field(default="", max_length=40)
    repeats: int = Field(default=0, ge=0)
    # The spread as a number, in the unit printed: percentage points when the scores
    # were percentages (0.2.81). Absent for records kept before it was.
    spread_value: float | None = Field(default=None, ge=0)

    def varies(self) -> bool:
        """Whether runs of one version were seen to differ at all."""
        return self.spread_number() > 0

    def spread_number(self) -> float:
        if self.spread_value is not None:
            return self.spread_value
        try:
            return float(self.spread.split()[0])
        except (IndexError, ValueError):
            return 0.0

    def in_points(self) -> bool:
        """Whether its scores were percentages, so a spread and a difference are in points."""
        return self.spread.endswith("points")

    def as_mine(self, points: float) -> float:
        """A difference in percentage points, in the unit of these scores."""
        if self.in_points():
            return points
        latest = 0.0
        for shown in reversed(self.shown):
            try:
                latest = float(shown.rstrip("%"))
                break
            except ValueError:
                continue
        # Scores printed as shares (0.66) take points as hundredths; scores printed
        # as numbers past 1 (66.0) are already in points.
        return points / 100 if latest <= 1 else points


class DeclaredCheck(Contract):
    """A command the project itself declares to check it, and what declares it (P4)."""

    argv: list[str] = Field(min_length=1, max_length=32)
    why: str = Field(min_length=1, max_length=300)


class ResearchContext(Contract):
    """What the application layer gathered for the planner to reason over.

    The planner is handed this rather than being given a workspace to read,
    because a planner that can read can eventually write. Everything it knows
    arrives here, which also makes what it knew at the time recordable.
    """

    workspace: str = Field(min_length=1)
    sessions: list[KnownSession] = Field(default_factory=list)
    # Paths the repository inspection offered, as candidate edit targets.
    candidate_paths: list[str] = Field(default_factory=list, max_length=64)
    # How many of those were chosen because they relate to the stated goal;
    # the rest are simply what else is in the workspace. A planner told only
    # "here are sixty-four files" has been told nothing in particular.
    related_path_count: int = Field(default=0, ge=0)
    # Measurement artifacts earlier sessions of this workspace built. A planner
    # cannot tell a project's own verifier from a previous experiment's leftover
    # by looking at the tree -- the file looks the same either way -- so it is
    # told, and can then say which of the two it means. Without this the
    # distinction would be one only the refusal knew about.
    recorded_artifacts: list[str] = Field(default_factory=list, max_length=64)
    # The command that starts Python on this host, found by trying the usual
    # names before asking for a design. Planners kept writing `python3`, which
    # on a Windows host is an installer stub; told what works, they need not
    # guess. Absent when none of the usual names starts Python here.
    python_command: str | None = Field(default=None, min_length=1, max_length=64)
    # The directories at the top of the workspace, empty ones included. A person
    # made `a-test` and asked for the project there; the planner, shown only
    # files, could not see it and invented `a_test_project` beside it.
    directories: list[str] = Field(default_factory=list, max_length=64)
    # What earlier studies here established, confirmed by a person, that bears
    # on this goal (M6.4): a planner that never read memory designed again the
    # comparison an earlier session had already answered.
    findings: list[KnownFinding] = Field(default_factory=list, max_length=12)
    # The checks the project declares -- its tests folder or pytest settings,
    # package.json scripts, go.mod, Cargo.toml -- found by the `find_checks`
    # skill the coding loop uses too (P4). A planner adopting a verifier the
    # project owns ("use_existing") guessed it from file names before.
    declared_checks: list[DeclaredCheck] = Field(default_factory=list, max_length=16)
    # What evaluations here already scored, across the code's versions (P5,
    # 0.2.74): kept by the coding loops, read here as measurements, so a design
    # starts from the latest score instead of measuring it again.
    measured_before: list[MeasuredSeries] = Field(default_factory=list, max_length=8)


class ProposedArm(Contract):
    """One arm of a proposed design, in the shape an arm task needs."""

    arm: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    # Each target says what will be done to it. A live run showed why a bare path
    # is not enough: a design proposed files it intended to create, said so in its
    # assumptions, and was refused at execution because every target was read as
    # a file to edit. Intent belongs in the type, where the schema carries it to
    # the planner, rather than in prose nothing reads.
    targets: list[EditTarget] = Field(default_factory=list, max_length=8)
    verify_argv: list[str] = Field(default_factory=list)
    # How this arm means to meet the objective, in more than one sentence:
    # which files hold what, the algorithm, the edge cases it handles. Given
    # to the arm's coding model with its objective, and shown to the person
    # deciding. Two arms that differ only in a word of their objective are a
    # comparison nobody can read the difference of.
    approach: str | None = Field(default=None, min_length=1, max_length=2000)

    @model_validator(mode="after")
    def executable_intent(self) -> "ProposedArm":
        named = [target.path for target in self.targets]
        if len(named) != len({path.casefold() for path in named}):
            raise ValueError("an arm names each target once")
        if any(not item.strip() for item in self.verify_argv):
            raise ValueError("a proposed verification argument must not be blank")
        return self


class PlannedFile(Contract):
    """One file of the project a design builds, and what it is for."""

    path: str = Field(min_length=1, max_length=260)
    purpose: str = Field(min_length=1, max_length=400)


class ImplementationPlan(Contract):
    """The project as a coding agent would plan it, before any of it is written.

    A design said what would be compared and how it would be measured, and
    little about what would be built: one target file and a sentence. People
    used to coding agents asked for the rest -- the folder layout, the order of
    work, what could go wrong -- and the arms' coding models are better for it
    too, since they see the layout with their objective.

    It does not execute. What is created, edited and measured is still exactly
    the arms' targets and the measurement's artifacts; this explains them.
    """

    # Every file the project will hold -- arm targets, measurement artifacts
    # and anything else it is organised around -- with its purpose.
    layout: list[PlannedFile] = Field(min_length=1, max_length=MAXIMUM_PLANNED_FILES)
    # The work in order, one step a line.
    steps: list[str] = Field(default_factory=list, max_length=MAXIMUM_PLAN_STEPS)
    # What could make the result wrong or the study uninformative.
    risks: list[str] = Field(default_factory=list, max_length=MAXIMUM_RISKS)

    @model_validator(mode="after")
    def readable(self) -> "ImplementationPlan":
        paths = [item.path.casefold() for item in self.layout]
        if len(paths) != len(set(paths)):
            raise ValueError("the implementation plan names each file once")
        if any(not item.strip() for item in [*self.steps, *self.risks]):
            raise ValueError("a plan step or risk must not be blank")
        return self


class PlannerProposal(Contract):
    """Exactly the design a planner proposes, and nothing a caller owns.

    Split out because these eight fields are the ones a model may fill in, and
    the rest -- the intent, what the planner was shown, which model it was -- are
    written by the layer that knows them and would be claims if a model supplied
    them.

    Having the boundary as a type rather than a convention means the schema a
    model is asked to satisfy is `PlannerProposal.model_json_schema()`, taken from
    the contract itself. No projection utility trims a larger type down to it, and
    there is no second copy of the shape to drift from the first.
    """

    # The session objective this design would be recorded under.
    objective: str = Field(min_length=1, max_length=500)
    # Why this design answers that intent. A proposal nobody can argue with is
    # one nobody can decline for a reason.
    rationale: str = Field(min_length=1, max_length=4000)
    registry: MetricRegistry
    arms: list[ProposedArm] = Field(min_length=1, max_length=MAXIMUM_ARMS)
    repeats_per_arm: int = Field(default=1, strict=True, ge=1, le=100)
    candidate_arm: str | None = None
    baseline_arm: str | None = None
    # What the planner could not determine and assumed instead, so a person can
    # correct it. This is where uncertainty goes; there is nowhere else for it.
    assumptions: list[str] = Field(default_factory=list, max_length=MAXIMUM_ASSUMPTIONS)
    # The project as it will be built. See `ImplementationPlan`.
    implementation_plan: ImplementationPlan | None = None
    # How this design will be measured, and what has to exist for it to be. Owned
    # by the plan rather than by an arm: a verifier an arm could write is a verifier
    # the arm can pass by rewriting, and two arms with their own verifiers are not
    # being compared at all. Absent means the workspace already holds whatever the
    # arms' `verify_argv` runs, which is the only shape that worked before this.
    measurement: MeasurementSetup | None = None
    # What this design asks its measurement to check, in the planner's own words
    # with an identifier each.
    #
    # Required here while it stays optional on `ResearchPlan`, and the asymmetry
    # is the point. A plan recorded before this existed cannot be judged against
    # a contract nobody wrote, so it reads as undeclared. A design proposed from
    # now on can be: leaving it optional here would let every new study go on
    # declaring nothing, and a check only the conscientious opt into is one the
    # case it was built for will not be opted into.
    #
    # A statement is what a person reads and argues with. The identifier is the
    # only part anything matches on, and matching a claim is all it supports --
    # never that the requirement was well checked.
    measurement_requirements: list[MeasurementRequirement] = Field(
        min_length=1, max_length=MAXIMUM_REQUIREMENTS)
    # How to find out whether that measurement can tell a broken implementation
    # from a working one: two versions of one file and the difference the ruler
    # must show between them.
    #
    # Optional here, unlike the requirements, and the asymmetry is deliberate.
    # A requirement is a sentence; a control is two working files and a claim
    # about how they should measure, which is a much larger thing to ask of a
    # design and a much easier one to fake. A design that offers none says so,
    # and a study whose sensitivity was never tested reads as untested rather
    # than as calibrated.
    #
    # What a model may not do alone is establish the *expectation*: see
    # `ExpectationAuthority`. It may draft the files and say which it thinks is
    # better; that draft earns no demonstration until somebody agrees or the
    # broken subject follows from a named, mechanical change.
    measurement_controls: list[MeasurementControl] | None = Field(
        default=None, max_length=MAXIMUM_CONTROLS)

    @model_validator(mode="after")
    def coherent_design(self) -> "PlannerProposal":
        requirements_named_once(self.measurement_requirements)
        controls_named_once(self.measurement_controls)
        declared = {item.requirement_id for item in self.measurement_requirements}
        aimless = sorted({item.requirement_id for item in self.measurement_controls or []}
                         - declared)
        if aimless:
            raise ValueError(
                "a measurement control names a requirement this design does not "
                f"declare: {', '.join(aimless)}")
        names = [arm.arm for arm in self.arms]
        if len(names) != len(set(names)):
            raise ValueError("proposed arm names must be unique")
        designated = [self.candidate_arm, self.baseline_arm]
        if any(arm is not None and arm not in names for arm in designated):
            raise ValueError("a designated comparison arm must also be proposed")
        if (self.candidate_arm is None) != (self.baseline_arm is None):
            raise ValueError("a designated comparison needs both candidate and baseline arms")
        if self.candidate_arm is not None and self.candidate_arm == self.baseline_arm:
            raise ValueError("candidate and baseline arms must differ")
        if any(not item.strip() for item in self.assumptions):
            raise ValueError("a stated assumption must not be blank")
        return self


class ProposedPlan(PlannerProposal):
    """A design a person can read, amend or decline. Recording it is a separate act.

    The planner's fields plus the ones only a caller can fill. Inheritance rather
    than nesting, so the document a person opens and edits keeps the flat shape it
    has always had: this split is about who may write a field, not about how the
    document looks.
    """

    proposal_version: str = "research-proposal-v1"
    intent: ResearchIntent
    # What the planner was shown, so a person reading the document can see what it
    # had to go on, and so the accepted plan can record why it looks like this.
    # Set by the layer that gathered it; a planner does not report its own inputs.
    context: ResearchContext | None = None
    # Which model proposed it, when one did. Read from the gateway rather than
    # from the reply: a model naming itself is a claim, not a fact.
    proposed_by: ModelIdentity | None = None
    # Smaller models on the person's ladder whose replies could not be used,
    # each with why, before `proposed_by` answered (`relab_app.escalation`).
    passed_over: list[str] = Field(default_factory=list, max_length=6)
    # What the planner looked at before designing this, in the order it looked.
    # Written by the layer that performed the looking, for the same reason
    # `context` is: a model's account of what it read is a claim about what it
    # read, and the two must stay distinguishable.
    inspected: list[InspectionRound] = Field(default_factory=list, max_length=4)
    # Which model each role is to call, when the caller declared any. Travels on
    # the proposal because the planner runs before a session exists: what routed
    # the design is pinned to the session that accepts it, so one declaration
    # covers the model that designed a study and the models that carry it out.
    #
    # Caller-owned like `context`. A model that could write this would be
    # choosing which model runs next, and the budget that pays for it.
    routing_policy: ModelRoutingPolicy | None = None
