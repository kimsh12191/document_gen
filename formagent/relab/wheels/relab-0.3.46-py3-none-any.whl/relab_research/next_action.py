"""Proposing what the declared policy should become, given what was observed.

This proposes and performs nothing. It also proposes, for now, only changes that
**raise** the bar: asking for more repeats, or requiring the compared runs to have
started from the same conditions. Both demand more evidence than the recorded
policy did, so neither can move a goalpost, and a session amended this way can
still be accepted on its merits.

That restraint is the point of doing the deterministic advisor first. A change
that lowers the bar is exactly the change a tempted researcher -- or a model
optimising for a passing result -- would propose after seeing the numbers, and the
path such a proposal has to travel is the one worth building before anything is
allowed to walk down it.
"""

from typing import Protocol

from relab_core.interpretation import SessionInterpretation
from relab_core.next_action import ProposedAmendment
from relab_core.research import ResearchPlan

# What the repeatability check already treats as enough runs to see a spread.
REPLICATION_REPEATS = 3
UNREPLICATED = "no observable spread"
INCOMPARABLE = "did not start from the same conditions"


def propose_amendment(
    interpretation: SessionInterpretation, plan: ResearchPlan | None,
) -> ProposedAmendment | None:
    """The one policy change these records argue for, or none.

    A refused session gets no amendment. Its policy cannot honestly be changed
    into one that would accept it, and proposing a change would suggest otherwise.
    """
    if plan is None or interpretation.refused or not interpretation.carries_findings:
        return None
    limits = " ".join(interpretation.limits)
    grounds = []
    changes: dict[str, object] = {}
    if UNREPLICATED in limits and plan.repeats_per_arm < REPLICATION_REPEATS:
        changes["repeats_per_arm"] = REPLICATION_REPEATS
        grounds.append(
            f"each arm ran {plan.repeats_per_arm} time(s), so nothing here says the "
            f"numbers repeat; {REPLICATION_REPEATS} repeats per arm would show the spread")
    if INCOMPARABLE in limits and not plan.require_comparable_conditions:
        changes["require_comparable_conditions"] = True
        grounds.append(
            "the compared runs did not start from the same conditions, and the policy "
            "did not require that they had, so the difference is not attributable "
            "to the design")
    if not changes:
        return None
    return ProposedAmendment(rationale="; ".join(grounds), **changes)  # type: ignore[arg-type]


class AmendmentAdvisor(Protocol):
    """Anything that can say what a policy should become, having judged nothing else.

    An advisor sees an interpretation and the plan. It sees no workspace, no store
    and no service: it proposes, and the application layer decides whether to
    record. `LLMAmendmentAdvisor` and `DeterministicAdvisor` are the two so far.
    """

    def advise(
        self, interpretation: SessionInterpretation, plan: ResearchPlan | None,
    ) -> ProposedAmendment | None: ...


class DeterministicAdvisor:
    """The rules above, behind the same interface a model-backed advisor uses.

    Having one interface is what keeps the recording path from being able to tell
    where a proposal came from -- which is exactly the property that makes it safe
    to let a model propose one.
    """

    def advise(
        self, interpretation: SessionInterpretation, plan: ResearchPlan | None,
    ) -> ProposedAmendment | None:
        return propose_amendment(interpretation, plan)
