"""Turning a contract into the schema a provider will enforce.

Derived from the contract, never written beside it. A second copy of a shape is a
copy that drifts, and the whole reason this exists is that shapes drift.

## What this adjusts, and why

A structured-output schema is enforced strictly or not at all, and strict has two
requirements Pydantic's output does not meet on its own:

**Every property must be required.** Pydantic marks a field with a default as
optional, which is right for validation -- `verify_argv` may legitimately be absent
from a hand-written document -- and wrong for a model. An optional field is one a
model may omit, and the field it omitted is the one nobody checked the type of. Ten
live calls produced three replies where `verify_argv` arrived as a shell string
rather than an argv list, and it was optional in the schema every time.

The optional fields here are already nullable or have sensible empties, so
requiring them asks a model to be explicit rather than asking it for more.

**`default` is not part of the strict subset**, so it is removed. A default is
what *we* do when a field is missing, and under this schema it cannot be missing.

Nothing else is touched. In particular no field is added, removed or renamed: if
this needed to reshape a contract to make it expressible, the contract would be
the thing to fix.
"""

from typing import Any

from pydantic import BaseModel


def strict_schema(model: type[BaseModel]) -> dict[str, object]:
    """The model's own schema, in the form a provider will enforce strictly."""
    adjusted = _strict(model.model_json_schema())
    assert isinstance(adjusted, dict)
    return adjusted


def _strict(node: Any) -> Any:
    if isinstance(node, list):
        return [_strict(item) for item in node]
    if not isinstance(node, dict):
        return node
    adjusted = {key: _strict(value) for key, value in node.items() if key != "default"}
    properties = adjusted.get("properties")
    if isinstance(properties, dict):
        # Every property, in the order the contract declares them, so two runs of
        # this produce the same schema and a diff of it means something changed.
        adjusted["required"] = list(properties)
        adjusted["additionalProperties"] = False
    return adjusted


# The validation keywords a provider's structured-output mode may not carry.
#
# A fixed list, decided before it was needed and written down in
# `docs/architecture/PROPOSALS.md` -- not "whatever the provider complained
# about", which is how a remedy becomes a habit of removing whatever is in the
# way. These seven are the ones this contract actually uses.
LOWERED_KEYWORDS = frozenset({
    "pattern", "minLength", "maxLength", "minimum", "maximum", "minItems", "maxItems",
})


def provider_schema(model: type[BaseModel]) -> dict[str, object]:
    """The contract in the dialect a provider's structured-output mode speaks.

    Named for what it does. This is a transport conversion, not a second, laxer
    contract, and calling it `strict_schema` would invite exactly the reading it
    must not have.

    ## Why it exists, which is not the reason it was written

    It was written for a provider that *refuses* an unsupported keyword -- a 4xx
    before any reply, which the live harness records as NOT RUN. What actually
    happened was quieter and worse. The provider accepted the schema and the
    model never finished: it consumed whatever budget it was given, 4096 then
    16384 then 65536 tokens, at about a hundred tokens a second, and stopped only
    when the budget or the clock ran out.

    One probe separated the cause from its neighbour. The same workspace and the
    same goal converged in 63 seconds with no schema sent, and timed out at 600
    seconds with this one. Constrained decoding has to keep every token inside
    the schema, and `pattern` in particular makes that a regex the decoder must
    satisfy while still finding a way to end -- this contract carries three.

    So the observable differs from the one anticipated and the mechanism is the
    same: a keyword the provider's structured-output mode cannot really carry.
    The pre-registered remedy applies unchanged, which is the point of deciding
    it in advance.

    ## What it does and does not touch

    Structure survives: objects, arrays, types, `required`, and
    `additionalProperties: false`. Only the seven validation keywords go, and
    only from the copy that travels.

    The authority stays in the domain type. Dropping `minLength` for transport
    means the provider still enforces "a string" while ReLab still enforces "a
    string of at least one character" -- a model returning `""` may satisfy the
    provider and is refused here regardless. Not one domain validator is removed,
    weakened, or made conditional, and `read_proposal` is not told about any of
    this.
    """
    lowered = _lower(strict_schema(model))
    assert isinstance(lowered, dict)
    return lowered


def _lower(node: Any) -> Any:
    if isinstance(node, list):
        return [_lower(item) for item in node]
    if not isinstance(node, dict):
        return node
    return {key: _lower(value) for key, value in node.items()
            if key not in LOWERED_KEYWORDS}
