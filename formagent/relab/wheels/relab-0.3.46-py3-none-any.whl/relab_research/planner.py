"""Who may propose a design, and how a proposal becomes something recordable.

The compilation below is the join this whole layer exists for: a proposal is
only useful if it turns into a `ResearchPlan` the existing validator accepts,
unchanged. Nothing here relaxes that validator, and the compilation is a pure
function so the join can be tested without recording anything.
"""

from typing import Protocol

from relab_core.research import ArmTask, DesignProvenance
from relab_research.proposals import ProposedArm, ProposedPlan, ResearchContext, ResearchIntent


class ResearchPlanner(Protocol):
    """Proposes a design. It is handed everything it knows and returns a value.

    It has no workspace, no services and no way to record: a planner that could
    read could eventually write, and the boundary is cheaper to hold here than
    to police later.
    """

    def propose(self, intent: ResearchIntent, context: ResearchContext) -> ProposedPlan:
        ...


class ScriptedPlanner:
    """A planner that returns what a caller prepared. No provider is contacted.

    Proving the join without a model is deliberate: the contracts, the
    compilation and the accept path can all be wrong on their own, and finding
    that out should not cost a model call.
    """

    def __init__(self, *proposals: ProposedPlan) -> None:
        self.proposals = list(proposals)
        self.seen: list[tuple[ResearchIntent, ResearchContext]] = []

    def propose(self, intent: ResearchIntent, context: ResearchContext) -> ProposedPlan:
        self.seen.append((intent, context))
        if not self.proposals:
            raise AssertionError("the planner was asked for more proposals than it was given")
        return self.proposals.pop(0)


def arm_tasks(proposal: ProposedPlan) -> list[ArmTask]:
    """The proposal's arms as the tasks a session dispatches.

    `ArmTask` validates its own contents, so a proposal that would not make an
    executable task is refused here -- before a session exists, rather than
    after one has been created and left half-formed.
    """
    return [
        ArmTask(
            # The operation travels with the path. A proposal that said "create"
            # and a plan that recorded only a path would have lost the one fact
            # execution needs to know what kind of write it is making.
            arm=arm.arm, objective=_objective(arm, proposal), targets=list(arm.targets),
            verify_argv=list(arm.verify_argv),
        )
        for arm in proposal.arms
    ]


def _objective(arm: ProposedArm, proposal: ProposedPlan) -> str:
    """The arm's objective, with how it means to meet it and the project it sits in.

    The coding model sees an arm's objective and its target files and nothing
    else, so a plan a person read and accepted reached it as one sentence. The
    approach and the layout go with the objective, so what is built is what was
    planned.
    """
    said = arm.objective
    if arm.approach:
        said += f"\nApproach: {arm.approach}"
    plan = proposal.implementation_plan
    if plan is not None:
        said += "\nProject layout:\n" + "\n".join(
            f"- {item.path}: {item.purpose}" for item in plan.layout)
    return said


def plan_arguments(proposal: ProposedPlan) -> dict[str, object]:
    """Exactly what `record_plan` needs, and nothing it does not.

    Returned as arguments rather than as a `ResearchPlan` so the application
    layer stays the only thing that builds one. A proposal cannot smuggle in a
    plan field the recording path did not mean to expose.
    """
    return {
        "arms": [arm.arm for arm in proposal.arms],
        "repeats_per_arm": proposal.repeats_per_arm,
        "candidate_arm": proposal.candidate_arm,
        "baseline_arm": proposal.baseline_arm,
        "arm_tasks": arm_tasks(proposal),
        "measurement": proposal.measurement,
        # Beside the instrument, not inside it. What the study asks of its
        # measurement travels with the design a person accepted, and changing
        # it later is a plan revision rather than a new ruler.
        "measurement_requirements": list(proposal.measurement_requirements),
        "measurement_controls": (None if proposal.measurement_controls is None
                                 else list(proposal.measurement_controls)),
        "provenance": provenance(proposal),
    }


def provenance(proposal: ProposedPlan) -> DesignProvenance:
    """Why the policy looks like this, in terms the plan can hold.

    The rationale and the assumptions do not execute, so they are not policy --
    but a policy nobody can explain later is a policy nobody can argue with, and
    the whole point of pre-registration is that it can be argued with.
    """
    context = proposal.context
    return DesignProvenance(
        intent=proposal.intent.stated,
        rationale=proposal.rationale,
        assumptions=list(proposal.assumptions),
        known_session_ids=[] if context is None else [
            item.session_id for item in context.sessions],
        candidate_paths=[] if context is None else list(context.candidate_paths),
        proposed_by=proposal.proposed_by,
        inspected=list(proposal.inspected),
        # What the design said it would build and how, so the record can still
        # be read as the plan a person accepted.
        layout=[] if proposal.implementation_plan is None else [
            f"{item.path}: {item.purpose}" for item in proposal.implementation_plan.layout],
        steps=[] if proposal.implementation_plan is None
        else list(proposal.implementation_plan.steps),
        risks=[] if proposal.implementation_plan is None
        else list(proposal.implementation_plan.risks),
    )
