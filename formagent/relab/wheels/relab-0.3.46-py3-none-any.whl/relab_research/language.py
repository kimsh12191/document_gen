"""Which language a model writes a person's sentences in.

A person who states a goal in Korean was answered in English throughout: the
design's objective, its rationale, the requirement statements and the arm
objectives were all written in English, because nothing asked for anything
else. The words a person reads should be in the language they wrote in.

What must not follow them is everything a machine reads: identifiers, paths,
code, commands, metric and rule names, requirement and control ids, enum values
and JSON keys keep the exact form their format specifies, whatever language the
sentences around them are in. A metric renamed into Korean would break the rule
that reads it, and so would a translated enum value.
"""

# For the planner, which is given the person's own words as the goal.
PLANNER_LANGUAGE = (
    "Write every sentence meant for a person to read -- the objective, the "
    "rationale, requirement statements, assumptions, arm objectives and "
    "derivations -- in the language the goal is written in. Keep identifiers, "
    "file paths, code, commands, metric and rule names, requirement and control "
    "ids, enum values and JSON keys exactly as this format specifies them.\n"
)

# For every later step, which is given the study rather than the person's words.
# The planner set the language; the rest keep it.
FOLLOW_LANGUAGE = (
    "Write every sentence meant for a person to read in the language the study's "
    "goal or objective below is written in, and in English when neither is "
    "given. Keep identifiers, file paths, code, commands, metric and rule names, "
    "requirement and control ids, enum values and JSON keys exactly as this "
    "format specifies them.\n"
)

# For a step that is given the person's own words as a request -- the coding
# loop, understanding a request, exploring the workspace -- whose sentences are
# read in the conversation the person is having.
REQUEST_LANGUAGE = (
    "Write every sentence meant for a person to read -- thoughts, questions and "
    "their choices, plan purposes and steps, summaries, rationales -- in the "
    "language the request is written in: Korean for a Korean request, English "
    "for an English one. Keep identifiers, file paths, code, commands, JSON keys, "
    "enum values and the summary's line labels exactly as this format specifies "
    "them; code and its comments follow the project's own convention.\n"
)
