"""One bounded, non-authoritative interpretation of conversational text."""

import json

from pydantic import Field

from relab_core.contracts import Contract
from relab_core.conversation_intent import ConversationIntent
from relab_core.generation import ModelGateway
from relab_research.language import REQUEST_LANGUAGE
from relab_research.schema import provider_schema

# Room for the reply, not its size: the reply is one enum value and a short
# rationale, bounded by the schema. A reasoning model spends its reasoning from
# the same budget, and at 128 a live `gpt-5-mini` call used all of it thinking
# and returned nothing ("128 completion tokens of 128 allowed"). Billing is for
# what is used, so a generous ceiling costs nothing a small reply does not.
INTENT_REPLY_TOKENS = 4096


class InterpretedIntent(Contract):
    """The only thing an intent model may return.

    It cannot name a path, plan field, run, gate or action. The caller checks its
    one enum value against the lifecycle-derived affordances before showing it.
    """

    intent: ConversationIntent
    rationale: str = Field(min_length=1, max_length=400)


def interpret_intent(
    gateway: ModelGateway, said: str, allowed: list[ConversationIntent], *,
    timeout_seconds: float,
) -> InterpretedIntent:
    """Classify a request into one offered intent without performing anything."""
    if not allowed:
        raise ValueError("there is no conversation intent available to interpret")
    vocabulary = [item.value for item in allowed]
    prompt = (
        "Classify the user's request into exactly one offered ReLab conversation intent. "
        "This is categorization only: do not propose an action, command, path, plan edit, "
        "gate decision, or execution. Choose only from the offered intent values. "
        + REQUEST_LANGUAGE
        + f"Offered intents: {json.dumps(vocabulary)}\n"
        f"User request: {said}"
    )
    reply = gateway.complete(
        prompt, timeout_seconds=timeout_seconds,
        response_contract=provider_schema(InterpretedIntent),
        reply_tokens=INTENT_REPLY_TOKENS,
    )
    interpreted = InterpretedIntent.model_validate_json(str(reply))
    if interpreted.intent not in allowed:
        raise ValueError(
            f"the intent model returned {interpreted.intent.value}, which was not offered")
    return interpreted
