"""Only consecutive independent observations may cross a parallel boundary."""
from dataclasses import dataclass

from relab_core.coding_loop import LoopAction, LoopActionKind

READ_ONLY_PARALLEL = frozenset({LoopActionKind.READ_FILE, LoopActionKind.READ_FILES,
                               LoopActionKind.SEARCH, LoopActionKind.SEARCH_CODEBASE,
                               LoopActionKind.LIST_FILES, LoopActionKind.OUTLINE})


@dataclass(frozen=True)
class ActionGroup:
    actions: tuple[LoopAction, ...]
    parallel: bool


def schedule(actions: list[LoopAction]) -> list[ActionGroup]:
    groups: list[ActionGroup] = []
    reads: list[LoopAction] = []
    for action in actions:
        if action.action in READ_ONLY_PARALLEL:
            reads.append(action)
            continue
        if reads:
            groups.append(ActionGroup(tuple(reads), len(reads) > 1))
            reads = []
        groups.append(ActionGroup((action,), False))
    if reads:
        groups.append(ActionGroup(tuple(reads), len(reads) > 1))
    return groups
