"""What a coding loop is held to before it may finish, and the record it leaves.

A live OCR request -- "develop an OCR agent, record every step in process.md"
-- ended with a planned README never written, a process.md that still said
"planned" for every step, an agent guessing six names for the backend module it
had written two steps before, `except Exception: pass` hiding why it failed,
and tests that built the agent with `__new__` and checked `hasattr`. Each was
something the instruction already asked for; these are the checks that hold
whatever the model writes. Each is read from the files (`ast`), never run.

    plan        every file an approved plan named exists, and defines the
                names its interface promised
    log         a log the request asked for was written, and after the code
    tests       the tests the loop wrote go through the code, not around it
    review      after building a plan, the loop's own diff, to read once
                before finishing
    swallowed   `except Exception: pass` and its kin, said after a write
    record      the loop's steps as Markdown, from its record, appended to the
                log the request named -- what happened, not what was recalled
"""

import ast
import difflib
import re
from collections.abc import Callable
from pathlib import Path

from relab_core.coding_loop import CodingLoop, LoopActionKind, LoopStep
from relab_core.targets import unusable_path
from relab_workspace.snapshot_store import SnapshotStore

REVIEW_CHARACTERS = 8000
# A word that says the request wants a running log kept, in either language.
LOG_WORDS = re.compile(r"기록|로그|일지|\blog\b|\brecord\b|\bjournal\b", re.IGNORECASE)
# ASCII on both sides: "process.md에" names process.md, and a Korean particle
# is a word character to `\w`.
MARKDOWN_NAME = re.compile(r"(?<![A-Za-z0-9_./-])([A-Za-z0-9_./-]*[A-Za-z0-9_-]\.md)(?![A-Za-z0-9_])",
                           re.IGNORECASE)
NOT_LOGS = {"readme.md", "relab.md", "changelog.md", "license.md"}


# --- the plan ----------------------------------------------------------------------------------

def unbuilt_plan(workspace: Path, loop: CodingLoop) -> list[str]:
    """What an approved plan named that is not there: files, and promised names."""
    if loop.plan is None or not loop.plan_approved:
        return []
    found: list[str] = []
    missing = [item.path for item in loop.plan.files
               if unusable_path(item.path) is None
               and not workspace.joinpath(*item.path.split("/")).is_file()]
    if missing:
        found.append(f"the approved plan names files that were not written: {', '.join(missing)}")
    for item in loop.plan.files:
        target = workspace.joinpath(*item.path.split("/"))
        if not item.interface or not item.path.endswith(".py") or not target.is_file():
            continue
        defined = defined_names(target.read_bytes())
        promised = [name for name in (_promised(entry) for entry in item.interface)
                    if name is not None]
        absent = [name for name in promised if name not in defined]
        if absent:
            found.append(f"{item.path} does not define what the plan's interface promised: "
                         f"{', '.join(absent)}")
    return found


def _promised(entry: str) -> str | None:
    """The name an interface entry promises: `def run(...)`, `class Agent: ...`, `run(...)`."""
    found = re.match(r"\s*(?:async\s+def|def|class)?\s*([A-Za-z_]\w*)", entry)
    return found[1] if found else None


def defined_names(content: bytes | None) -> set[str]:
    """Every function, class and assigned name a module defines at its top level."""
    if content is None:
        return set()
    try:
        tree = ast.parse(content.decode("utf-8"))
    except (SyntaxError, UnicodeDecodeError):
        return set()
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Assign):
            names.update(target.id for target in node.targets if isinstance(target, ast.Name))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
    return names


# --- the log the request asked for -------------------------------------------------------------

def requested_log(request: str, scope: str | None) -> str | None:
    """The Markdown file the request asks to keep a record in, as a workspace path, or None.

    Named as a file (`process.md`) by a request that also says to record or
    log; a README, RELAB.md or a changelog is a document, not this.
    """
    if not LOG_WORDS.search(request):
        return None
    for name in (str(found) for found in MARKDOWN_NAME.findall(request)):
        path = name.replace("\\", "/").lstrip("./")
        if path.rsplit("/", 1)[-1].lower() in NOT_LOGS or unusable_path(path) is not None:
            continue
        if scope is not None and not path.startswith(f"{scope}/"):
            path = f"{scope}/{path}"
        return path
    return None


def stale_log(loop: CodingLoop, log: str) -> str | None:
    """Why the requested log does not yet record the work, or None."""
    wrote = [step.index for step in loop.steps if _writes(step, log)]
    code = [step.index for step in loop.steps
            if step.action.action in (LoopActionKind.WRITE_FILE, LoopActionKind.EDIT_FILE)
            and step.succeeded and step.action.path not in (None, log)]
    if not wrote:
        return (f"the request asked for a record in {log}, and it was not written: write it "
                f"-- the plan, what was built, what ran and how it ended, what is left")
    if code and max(code) > max(wrote):
        return (f"{log} was last written before the code it should record; bring it up to "
                f"date with what was built, what ran and how it ended, and what is left")
    return None


def _writes(step: LoopStep, path: str) -> bool:
    return (step.action.action in (LoopActionKind.WRITE_FILE, LoopActionKind.EDIT_FILE)
            and step.action.path == path and step.succeeded)


# --- the tests it wrote ------------------------------------------------------------------------

def hollow_tests(workspace: Path, loop: CodingLoop,
                 is_test: Callable[[str], bool]) -> list[str]:
    """Tests this loop wrote that go around the code instead of through it."""
    found: list[str] = []
    for item in loop.written:
        if not item.path.endswith(".py") or not is_test(item.path):
            continue
        target = workspace.joinpath(*item.path.split("/"))
        try:
            tree = ast.parse(target.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, SyntaxError):
            continue
        said: list[str] = []
        if any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
               and node.func.attr == "__new__" for node in ast.walk(tree)):
            said.append("build objects with __new__, skipping their constructor")
        only_names = [node.name for node in ast.walk(tree)
                      if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                      and node.name.startswith("test") and _only_hasattr(node)]
        if only_names:
            said.append(f"{', '.join(only_names)} only check that names exist")
        if said:
            found.append(f"the tests in {item.path} {' and '.join(said)}")
    if not found:
        return []
    return [*found, ("test through the public constructor and the real code path, with a "
                     "stand-in only for what cannot run here (a missing program or service)")]


def _only_hasattr(function: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    asserts = [node for node in ast.walk(function) if isinstance(node, ast.Assert)]
    if not asserts:
        return False
    calls = [node for node in ast.walk(function) if isinstance(node, ast.Call)]
    return all(isinstance(call.func, ast.Name) and call.func.id in {"hasattr", "callable"}
               for call in calls)


# --- reading its own diff ----------------------------------------------------------------------

def review(loop: CodingLoop, snapshots: SnapshotStore) -> str:
    """What the loop changed, as one bounded unified diff, for it to read before finishing."""
    parts: list[str] = []
    for item in loop.written:
        before = snapshots.get(item.before_digest) if item.before_digest else b""
        after = snapshots.get(item.after_digest)
        try:
            old = (before or b"").decode("utf-8").splitlines()
            new = (after or b"").decode("utf-8").splitlines()
        except UnicodeDecodeError:
            parts.append(f"--- {item.path}: not text")
            continue
        parts.extend(difflib.unified_diff(
            old, new, fromfile=f"a/{item.path}" if item.before_digest else "/dev/null",
            tofile=f"b/{item.path}", lineterm="", n=1))
    text = "\n".join(parts)
    if len(text) > REVIEW_CHARACTERS:
        text = text[:REVIEW_CHARACTERS] + "\n[the rest of the diff is cut; read the files]"
    return text


# --- errors swallowed --------------------------------------------------------------------------

def swallowed_errors(source: str) -> list[int]:
    """Lines of handlers that catch everything and do nothing with it."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []
    found: list[int] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.ExceptHandler):
            continue
        broad = node.type is None or (isinstance(node.type, ast.Name)
                                      and node.type.id in {"Exception", "BaseException"})
        if broad and all(_does_nothing(statement) for statement in node.body):
            found.append(node.lineno)
    return found


def _does_nothing(statement: ast.stmt) -> bool:
    if isinstance(statement, (ast.Pass, ast.Continue)):
        return True
    if isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Constant):
        return True  # `...` or a docstring-like string
    if isinstance(statement, ast.Return):
        return statement.value is None or (isinstance(statement.value, ast.Constant)
                                           and statement.value.value is None)
    if isinstance(statement, ast.Assign) and isinstance(statement.value, ast.Constant):
        return statement.value.value is None
    return False


# --- the record, as Markdown -------------------------------------------------------------------

KO = {"title": "ReLab 실행 기록", "request": "요청", "outcome": "결과", "steps": "단계",
      "checks": "실행한 검사 (프로젝트 자체 테스트)", "changed": "변경된 파일", "summary": "요약",
      "none": "없음", "processes": "백그라운드 프로세스", "note": "이 절은 ReLab이 실행 기록에서 "
      "자동으로 작성합니다."}
EN = {"title": "ReLab run record", "request": "Request", "outcome": "Outcome", "steps": "Steps",
      "checks": "Checks run (the project's own tests)", "changed": "Changed files",
      "summary": "Summary", "none": "none", "processes": "Background processes",
      "note": "This section is written by ReLab from its record of the run."}


def record_markdown(loop: CodingLoop) -> str:
    """The loop as it happened, in the language of its request."""
    words = KO if re.search(r"[가-힣]", loop.request) else EN
    lines = [f"<!-- relab:{loop.loop_id} -->", f"## {words['title']} — {loop.loop_id}", "",
             f"_{words['note']}_", "",
             f"- {words['request']}: {_one_line(loop.request, 300)}",
             (f"- {words['outcome']}: {loop.outcome.value} · {len(loop.steps)} {words['steps']} · "
              f"{loop.started_at.strftime('%Y-%m-%d %H:%M UTC')}"), "", f"### {words['steps']}"]
    lines += [f"{step.index}. {_step_line(step)}" for step in loop.steps]
    lines += ["", f"### {words['checks']}"]
    lines += [f"- `{check}`" for check in loop.checks] or [f"- {words['none']}"]
    lines += ["", f"### {words['changed']}"]
    lines += [f"- `{item.path}`" + (f" (+{item.added} −{item.removed})"
                                    if item.added is not None and item.removed is not None else "")
              for item in loop.written] or [f"- {words['none']}"]
    if loop.processes:
        lines += ["", f"### {words['processes']}"]
        lines += [f"- {item.name}: `{' '.join(item.argv)}` — {item.state.value}"
                  + (f" ({item.exit_code})" if item.exit_code is not None else "")
                  for item in loop.processes]
    if loop.summary:
        lines += ["", f"### {words['summary']}", "", loop.summary]
    if loop.report:
        lines += ["", loop.report.strip()]
    lines += ["", f"<!-- /relab:{loop.loop_id} -->"]
    return "\n".join(lines) + "\n"


def merged_log(existing: str, loop_id: str, section: str) -> str:
    """`existing` with this loop's section replaced, or appended when it has none."""
    start, end = f"<!-- relab:{loop_id} -->", f"<!-- /relab:{loop_id} -->"
    if start in existing and end in existing:
        head, rest = existing.split(start, 1)
        _, tail = rest.split(end, 1)
        return head + section.rstrip("\n") + tail
    joined = existing.rstrip("\n")
    return (joined + "\n\n" if joined else "") + section


def _step_line(step: LoopStep) -> str:
    did = step.action
    kind = did.action
    if kind in (LoopActionKind.READ_FILE, LoopActionKind.WRITE_FILE, LoopActionKind.EDIT_FILE):
        target = f"`{did.path}`"
    elif kind is LoopActionKind.SEARCH:
        target = f'"{did.query}"'
    elif kind in (LoopActionKind.RUN, LoopActionKind.START_PROCESS):
        target = f"`{' '.join(did.argv or [])}`"
    elif kind in (LoopActionKind.READ_PROCESS, LoopActionKind.STOP_PROCESS):
        target = did.process or ""
    elif kind is LoopActionKind.PLAN and did.plan is not None:
        target = f"{len(did.plan.files)} files"
    else:
        target = ""
    mark = "✓" if step.succeeded else "✗"
    first = _one_line(step.observation, 140)
    return f"{kind.value} {target} {mark}".replace("  ", " ") + (
        f" — {first}" if not step.succeeded or kind is LoopActionKind.RUN else "")


def _one_line(text: str, limit: int) -> str:
    line = " ".join(text.split())
    return line if len(line) <= limit else line[:limit] + "…"
