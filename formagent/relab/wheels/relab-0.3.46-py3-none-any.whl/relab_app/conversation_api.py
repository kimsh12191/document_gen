"""The single entry point a conversation goes through.

One box, one call. What a person typed and which session they typed it about is
all a client sends; everything the routing depends on is read here, from records.

    ConversationInput  -> read the session -> ConversationRouteContext
                                                   |
                                                   v
                                          deterministic router
                                                   |
                                                   v
                                          one capability, answered
                                                   |
                                                   v
                                          ConversationResponse

This layer exists so the boundary has somewhere to live. A client cannot send a
turn state -- `ConversationInput` has no field for one -- and this is the only
place a `ConversationRouteContext` is built. A client that believed a finished
session was still running, by mistake or on purpose, changes nothing about which
branch runs.
"""

import json
from collections.abc import Sequence
from pathlib import Path

from relab_app.conversation import Conversation
from relab_app.inspection import WorkspaceInspection
from relab_app.keep import ResultKeeper
from relab_app.next_action import NextActions
from relab_app.proposals import ResearchProposals
from relab_app.repair import RepairMemory
from relab_app.routing import routed_component
from relab_app.runs import CodingRunService
from relab_app.sessions import ResearchSessionService
from relab_core.alternatives import Alternative, AlternativeAction
from relab_core.changes import RunChange
from relab_core.coding.dependency import DependencyDecision, DependencyInstallDecision
from relab_core.conversation import ConversationTurn
from relab_core.conversation_actions import ConversationActionRequest
from relab_core.conversation_intent import (
    ConversationCapability,
    ConversationInput,
    ConversationIntent,
    ConversationRouteContext,
    ConversationWorkflow,
    WorkflowUnavailable,
    available_intents,
    capability_for,
    route,
    workflow_for,
)
from relab_core.conversation_response import (
    MAXIMUM_CHANGES,
    ArmResult,
    ConversationAction,
    ConversationResponse,
    ConversationResults,
    ResultCheck,
    ResultCheckKind,
)
from relab_core.explanation import FailureExplanation
from relab_core.gateways import GatewayResolver
from relab_core.generation import ModelGateway
from relab_core.inspection import InspectionContext, InspectionRequest
from relab_core.lifecycle import LifecycleAction
from relab_core.next_action import (
    NextAction,
    NextActionKind,
    ProposedAmendment,
    ProposedConclusion,
)
from relab_core.operations import (
    AMENDMENT_ROLE,
    CONVERSATION_INTENT_ROLE,
    REPLAN_ROLE,
    narrated,
)
from relab_core.research import PendingAmendment, ResearchSessionAssessment
from relab_core.routing import ModelRole
from relab_evaluation.changes import describe_change
from relab_research.amendment import build_prompt as amendment_prompt
from relab_research.amendment import read_amendment
from relab_research.conversation_intent import interpret_intent
from relab_research.planner import ResearchPlanner
from relab_research.proposals import ProposedPlan
from relab_research.replan import LLMReplanAdvisor
from relab_workspace.inspection_context_store import InspectionContextStore
from relab_workspace.operation_recorder import OperationRecorder

# What each step is, in a sentence. The prose repeats what the typed fields
# already say, for whoever is reading rather than parsing; a surface acts on
# `workflow` and `workflow_unavailable` and never on this.
_STEPS = {
    ConversationWorkflow.EXPLORE_WORKSPACE:
        "Looking at the workspace is the step for that, and it changes nothing.",
    ConversationWorkflow.DRAFT_PLAN_CHANGE:
        "Drafting a plan change is the step for that; approving one stays separate.",
    ConversationWorkflow.TAKE_TURN:
        "Taking a turn is the step for that, and this session offers one.",
    ConversationWorkflow.REVIEW_SESSION:
        "This answer is that: what the records currently say.",
    ConversationWorkflow.START_NEW_SESSION:
        "Starting a new study is the step for that.",
}
_WITHDRAWN = {
    WorkflowUnavailable.SESSION_MOVED:
        "The session moved while that was being read, so there is no step to offer "
        "against the state described here.",
    WorkflowUnavailable.NOT_AVAILABLE_NOW:
        "There is no step for that here.",
}


def _signpost(
    workflow: ConversationWorkflow | None, unavailable: WorkflowUnavailable | None,
) -> str:
    """One sentence naming the step, or saying why there is not one."""
    if workflow is not None:
        return _STEPS[workflow]
    assert unavailable is not None
    return _WITHDRAWN[unavailable]


class StaleConversationAction(ValueError):
    """An action offered for a session that has since moved on.

    Its own type, because a surface must be able to tell "this was refused
    because the world changed" from "this was refused because it was never
    allowed". The first is answered by showing where the session stands now; the
    second is a bug in whoever offered it.
    """


# What may be done in each branch. Data, so no surface has to work it out, and a
# closed set, so nothing can offer an action nobody implemented.
OFFERED: dict[ConversationCapability, list[ConversationAction]] = {
    ConversationCapability.PROPOSE_RESEARCH: [ConversationAction.ACCEPT_PROPOSAL],
    ConversationCapability.ANSWER_GATE: [ConversationAction.ANSWER_GATE],
    ConversationCapability.DISCUSS_BLOCKER: [
        ConversationAction.ANSWER_AMENDMENT, ConversationAction.SELECT_ALTERNATIVE,
        ConversationAction.CONFIRM_STOP, ConversationAction.EVALUATE_HOLDOUT,
        ConversationAction.CONCLUDE,
    ],
    ConversationCapability.CONTINUE_SESSION: [ConversationAction.TAKE_TURN],
    ConversationCapability.ASK_ABOUT_SESSION: [],
    ConversationCapability.EXPLAIN_RESULT: [
        ConversationAction.KEEP_RESULT, ConversationAction.START_NEW_SESSION],
    ConversationCapability.START_NEW_RESEARCH: [ConversationAction.START_NEW_SESSION],
}

# What a conversation can carry out itself, today. Named here rather than left to
# be discovered by clicking, and deliberately not the same set as `OFFERED`:
# what a session affords is a fact about the session, and what this surface can
# do about it is a fact about how much of the surface is built. Conflating them
# would mean either hiding real affordances or promising what nothing performs.
EXECUTABLE: frozenset[ConversationAction] = frozenset({
    ConversationAction.ACCEPT_PROPOSAL, ConversationAction.TAKE_TURN,
    ConversationAction.ANSWER_AMENDMENT, ConversationAction.CONCLUDE,
    ConversationAction.ANSWER_GATE, ConversationAction.CONFIRM_STOP,
    ConversationAction.SELECT_ALTERNATIVE, ConversationAction.KEEP_RESULT,
})

# Where the rest are answered meanwhile, so a refusal points somewhere instead of
# stopping at "not yet".
ELSEWHERE: dict[ConversationAction, str] = {
    ConversationAction.EVALUATE_HOLDOUT: "relab session holdout SESSION_ID",
    ConversationAction.START_NEW_SESSION: "say a new goal with no session selected",
}


# Where an alternative this surface does not perform is answered instead, so a
# refusal points somewhere rather than stopping at "not here".
ELSEWHERE_ALTERNATIVE: dict[AlternativeAction, str] = {
    AlternativeAction.CHANGE_MODEL:
        "chosen per role when model routing is declared, which this surface does not do yet",
}

# How long an advisor may take. The same ceiling the planner uses; a question
# asked at the point somebody is deciding whether to give up should not be the
# thing that keeps them waiting.
MODEL_SECONDS = 300.0


def _chose(chosen: "Alternative") -> str:
    """What was selected, said the same way wherever it is recorded or shown.

    One sentence, so the message a person reads and the rationale that reaches
    the record cannot drift into two accounts of one choice.
    """
    return f"Chosen from the alternatives offered at event {chosen.source_event_sequence}: "            f"{chosen.alternative_id}."


def _with_amendment(standing: ConversationResponse) -> list[ConversationAction]:
    """The actions this answer already offered, plus answering what it now carries."""
    offered = list(standing.available_actions)
    if ConversationAction.ANSWER_AMENDMENT not in offered:
        offered.append(ConversationAction.ANSWER_AMENDMENT)
    return offered


class ConversationAPI:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        # Every provider call a conversation can reach goes out through a
        # wrapped gateway, so a person watching sees the planner being asked as
        # readily as they see a coding model being asked. Append-only, and
        # nothing here or anywhere else reads it back.
        self.observe = OperationRecorder.open(self.workspace)
        self.actions = NextActions(self.workspace)
        self.sessions = ResearchSessionService(self.workspace)
        self.proposals = ResearchProposals(self.workspace)
        self.repairs = RepairMemory(self.workspace)
        self.runs = CodingRunService(self.workspace)
        self.keeper = ResultKeeper(self.workspace, self.sessions, self.runs)

    def _narrated(
        self, gateway: ModelGateway, role: str, session_id: str | None,
    ) -> ModelGateway:
        """The same gateway, saying which piece of work is asking."""
        return narrated(gateway, self.observe, role=role, session_id=session_id)

    def context(self, session_id: str) -> ConversationRouteContext:
        """Where this session stands, read from its records and nowhere else."""
        action = self.actions.decide(session_id)
        interpretation = self.actions.interpreter.interpret(session_id)
        return ConversationRouteContext(
            turn_state=action.turn_state,
            # A gate is a specific thing to answer. An amendment is a judgement,
            # and so is a conclusion; those are a different conversation.
            awaiting_gate=action.lifecycle is LifecycleAction.RESOLVE_GATE,
            refused=interpretation.refused,
            event_sequence=action.event_sequence,
            plan_revision=action.plan_revision,
        )

    def answer(
        self, said: ConversationInput, *, planner: ResearchPlanner | None = None,
    ) -> ConversationResponse:
        """Route this turn and answer it. The text never chooses the branch."""
        context = None if said.session_id is None else self.context(said.session_id)
        capability = route(said, context)
        if capability is ConversationCapability.PROPOSE_RESEARCH:
            return self._propose(said, planner)
        assert said.session_id is not None and context is not None
        return self._about(said.session_id, capability, context)

    def describe(self, session_id: str) -> ConversationResponse:
        """Where this session stands, with nobody having said anything.

        What a surface shows when it is reopened, and what an action that did
        nothing is answered with. There is no text in either case, and inventing
        one would put words in a person's mouth on the record they are reading.

        It is the same answer `answer` gives, minus the routing on a session id,
        because what a session affords was never a function of what was typed.
        """
        standing = self.context(session_id)
        return self._about(session_id, capability_for(standing), standing)

    def explore(self, session_id: str, request: InspectionRequest) -> ConversationResponse:
        """Look at the workspace without changing the session or its evidence."""
        standing = self.describe(session_id)
        found = WorkspaceInspection(self.workspace).inspect(request)
        context = InspectionContextStore(self.workspace).add(InspectionContext(
            session_id=session_id, event_sequence=standing.event_sequence or 1,
            plan_revision=standing.plan_revision or 0, request=request, result=found))
        return ConversationResponse.model_validate({
            **standing.model_dump(mode="json"),
            "intent": ConversationIntent.EXPLORE_WORKSPACE.value,
            "message": "Read-only workspace inspection. The session and plan are unchanged.",
            "inspection": found.model_dump(mode="json"),
            "inspection_context": context.model_dump(mode="json"),
        })

    def interpret(
        self, said: ConversationInput, gateway: ModelGateway, *, timeout_seconds: float,
    ) -> ConversationResponse:
        """Classify a request, and say which bounded step it corresponds to.

        Interpretation writes nothing and performs nothing. What it adds is the
        signpost: a classified intent used to be a label with nowhere to go, and
        whoever typed "run it" was told their request was an `execute` and left
        to find the door themselves.

        The offer is derived, deterministically, from the records read *after*
        the provider call. A model call takes long enough for another client to
        move the session, and an offer computed against the state before it
        would point at a session this answer never described -- the same
        staleness every other execution boundary here already refuses. The
        interpreter reaches that derivation as one enum value, so at most it
        picks among steps the records had already opened.
        """
        context = None if said.session_id is None else self.context(said.session_id)
        allowed = available_intents(context)
        if context is None:
            # There is only one possible kind of request before a session exists;
            # do not spend a model call to rediscover it.
            return ConversationResponse(
                capability=ConversationCapability.PROPOSE_RESEARCH,
                intent=ConversationIntent.NEW_GOAL,
                available_intents=allowed,
                workflow=workflow_for(ConversationIntent.NEW_GOAL, None),
                message="This is a new-goal request. No session or plan was changed.",
            )
        assert said.session_id is not None
        selected = interpret_intent(narrated(gateway, self.observe, role=CONVERSATION_INTENT_ROLE,
                      session_id=said.session_id),
            said.said, allowed, timeout_seconds=timeout_seconds)
        current = self.context(said.session_id)
        answered = self._about(said.session_id, capability_for(current), current)
        workflow = workflow_for(
            selected.intent, current,
            # From the answer's own authority list, so a signpost cannot point
            # at a door the records have not opened.
            may_take_turn=ConversationAction.TAKE_TURN in answered.available_actions,
            may_start_new=ConversationAction.START_NEW_SESSION
            in answered.available_actions)
        unavailable = None if workflow is not None else (
            WorkflowUnavailable.SESSION_MOVED
            if selected.intent not in available_intents(current)
            else WorkflowUnavailable.NOT_AVAILABLE_NOW)
        return answered.model_copy(update={
            "intent": selected.intent,
            "workflow": workflow,
            "workflow_unavailable": unavailable,
            "message": (
                f"Interpreted as {selected.intent.value}: {selected.rationale}. "
                f"{_signpost(workflow, unavailable)} "
                "No action, plan or session state was changed."
            ),
        })

    def draft_plan_change(self, session_id: str, context_id: str, request: str,
                          gateway: ModelGateway, *, timeout_seconds: float) -> ConversationResponse:
        """Propose one held amendment from an immutable exploration context."""
        standing = self.context(session_id)
        context = InspectionContextStore(self.workspace).load(context_id)
        if context.session_id != session_id or context.event_sequence != standing.event_sequence \
                or context.plan_revision != standing.plan_revision:
            raise ValueError("inspection context is stale; explore again before proposing a plan change")
        session = self.sessions.store.latest(session_id).snapshot
        if session.plan is None:
            raise ValueError("no recorded plan to change")
        prompt = amendment_prompt(self.actions.interpreter.interpret(session_id), session.plan)
        reply = narrated(
            gateway, self.observe, role=AMENDMENT_ROLE, session_id=session_id,
        ).complete(prompt + "\n" + json.dumps({
            "user_request": request, "inspection_context": context.model_dump(mode="json")}),
            timeout_seconds=timeout_seconds)
        # A provider call takes long enough for another client to revise the
        # session. Recheck after it returns; a draft read against the old plan
        # must never become the pending proposal for the new one.
        current = self.context(session_id)
        if current.event_sequence != context.event_sequence or current.plan_revision != context.plan_revision:
            raise ValueError("session changed while drafting; explore again before proposing a plan change")
        proposed = read_amendment(str(reply))
        if proposed is None:
            return self.describe(session_id).model_copy(update={
                "message": "No plan change was proposed. The session and plan are unchanged."})
        checked = self.actions.checked(session.plan, proposed)
        self.sessions.propose_amendment(session_id, checked)
        return self.describe(session_id).model_copy(update={
            "message": "A plan change was proposed from the recorded exploration context. Read it before approving."})

    def act(
        self, request: ConversationActionRequest, *,
        gateway: ModelGateway | None = None,
        resolver: GatewayResolver | None = None,
    ) -> ConversationResponse:
        """Do one of the things an answer offered, and answer again from what is now true.

        The action is checked against the session as it stands, not as the answer
        described it. An answer a person acted on may be seconds or hours old, and
        in between a worker can record a result or another client can answer a
        gate. Applying an action to a session that has moved on would be acting on
        a state nobody ever saw.

        What comes back is a fresh answer rather than a receipt, so the surface
        never has to work out what the action changed -- it is told.
        """
        if request.action is ConversationAction.ACCEPT_PROPOSAL:
            return self._accept(request)
        assert request.session_id is not None
        self._still_current(request)
        if request.action not in EXECUTABLE:
            raise ValueError(
                f"{request.action.value} cannot be done from a conversation yet; "
                f"it is offered because the session affords it, and it is answered "
                f"today by {ELSEWHERE[request.action]}")
        if request.action is ConversationAction.ANSWER_GATE:
            return self._answer_gate(request)
        if request.action is ConversationAction.ANSWER_AMENDMENT:
            return self._answer_amendment(request)
        if request.action is ConversationAction.CONFIRM_STOP:
            return self._confirm_stop(request)
        if request.action is ConversationAction.SELECT_ALTERNATIVE:
            return self._select_alternative(request, gateway, resolver)
        if request.action is ConversationAction.CONCLUDE:
            return self._conclude(request)
        if request.action is ConversationAction.KEEP_RESULT:
            return self._keep_result(request)
        # The only executable action left: accepting returned above, and every
        # other one was refused by the check just made.
        assert request.action is ConversationAction.TAKE_TURN
        if gateway is None:
            raise ValueError("taking a turn needs a model to take it with")
        # A review copy written when the arms were complete is not the tree the
        # next attempt was designed to start from; it goes before any does.
        self.keeper.withdraw_preview(request.session_id)
        taken = Conversation(self.workspace).turn(request.session_id, gateway)
        return self._after(taken)

    def _answer_gate(self, request: ConversationActionRequest) -> ConversationResponse:
        """Approve or refuse the install one attached run is waiting on.

        The client names which run, from the gates the answer listed. Everything
        the decision *binds* to comes from the records: the gate id, and through
        it the request id the installer checks. So a surface can choose among
        what it was shown and cannot name a gate nobody offered -- and a stale or
        misdirected approval still fails the installer's own check rather than
        silently attaching to the wrong install.
        """
        assert request.session_id is not None and request.approved is not None
        assert request.run_id is not None
        waiting = {gate.run_id: gate
                   for gate in self.actions.reader.status(request.session_id).gates}
        gate = waiting.get(request.run_id)
        if gate is None:
            raise ValueError(
                f"{request.run_id} is not a run this session is waiting on")
        self.runs.decide_dependency(gate.run_id, DependencyInstallDecision(
            request_id=gate.gate_id,
            decision=(DependencyDecision.APPROVE if request.approved
                      else DependencyDecision.REJECT),
            decided_by=request.decided_by))
        return self.describe(request.session_id)

    def _answer_amendment(self, request: ConversationActionRequest) -> ConversationResponse:
        """Record the proposed change, or decline it and record nothing.

        The amendment comes from the records, not from the request. A client that
        could send the policy it wanted applied would be a client that proposes
        amendments, and what a person approves has to be the thing they were
        shown -- which is the amendment this session's own answer carried.

        Declining writes nothing. That is the honest outcome and it is said
        plainly, rather than dressed up as a decision that was taken: an
        amendment nobody accepted simply is not part of the plan.
        """
        assert request.session_id is not None and request.approved is not None
        held = self.sessions.store.latest(request.session_id).snapshot.pending_amendment
        if held is not None:
            # Read back rather than asked for again. A model wrote this one, and
            # a second advisor call could answer differently -- so what reaches
            # the plan is the object that was shown, not a fresh one that
            # resembles it.
            if not request.approved:
                self.actions.decline_pending(request.session_id)
                return self.describe(request.session_id).model_copy(update={
                    "message": "The proposed change was declined. The recorded plan is "
                               "unchanged, and nothing is waiting on you.",
                })
            self.actions.approve_pending(request.session_id)
            return self.describe(request.session_id)
        standing = self.actions.decide(request.session_id)
        if standing.amendment is None:
            raise ValueError("there is no amendment to answer on this session")
        if not request.approved:
            declined = self.describe(request.session_id)
            return declined.model_copy(update={
                "message": "The proposed change was declined. The recorded plan is unchanged.",
            })
        self.actions.amend(request.session_id, standing.amendment,
                           expected_revision=request.plan_revision or 0)
        return self.describe(request.session_id)

    def _select_alternative(
        self, request: ConversationActionRequest, gateway: ModelGateway | None,
        resolver: GatewayResolver | None = None,
    ) -> ConversationResponse:
        """Ask for one of the alternatives this session offered, and show the change.

        Choosing is not doing. What comes back is a `ProposedAmendment` a person
        then reads and approves through the path that already exists -- so
        nothing reaches a recorded plan without having been read, and this action
        adds no way to change one that was not already there.

        The alternatives are derived again from the session as it stands now,
        and the chosen id is matched against that derivation rather than trusted
        from the request. A client can therefore choose among what it was shown
        and cannot name an option nobody offered; and one whose situation has
        changed is refused with what is actually available, which is the same
        rule the pin on every action follows for the same reason.
        """
        assert request.session_id is not None and request.alternative_id is not None
        standing = self.actions.decide(request.session_id)
        available = {} if standing.conclusion is None else {
            item.alternative_id: item for item in standing.conclusion.alternatives}
        chosen = available.get(request.alternative_id)
        if chosen is None:
            raise ValueError(
                f"{request.alternative_id} is not among the alternatives this session "
                f"offers now: {sorted(available) or 'none'}")
        if not chosen.performable:
            raise ValueError(
                f"{chosen.alternative_id} is a real option and not one this "
                f"conversation performs; it is {ELSEWHERE_ALTERNATIVE[chosen.action]}")
        if chosen.action is AlternativeAction.RETASK_ARM:
            if request.approved is not None:
                # The invariant both halves of this action serve:
                #
                #     whatever is approved must be exactly what was shown
                #
                # A deterministic change keeps it by being derived again from the
                # same recorded plan by the same rule. A model-written one cannot:
                # two advisor calls do not have to agree, so asking again at the
                # moment of approval could record an objective nobody read. Until
                # such a proposal is held between the press that shows it and the
                # press that takes it, this one is shown here and approved as the
                # amendment it resolved to -- which is the object that holds what
                # is being agreed to.
                #
                # What a person approves is not the abstract "retask this arm".
                # It is `candidate: <old objective> -> <new objective>`.
                raise ValueError(
                    "a retask is approved as the amendment it resolved to, not as the "
                    "alternative that asked for it; answer the amendment instead")
            return self._retask_from(request.session_id, chosen, gateway, resolver)
        # The only other performable one, and the deterministic one: no model is
        # asked what "more evidence" means, so the change a person saw and the
        # change that is recorded are derived by the same rule from the same plan.
        return self._more_repeats_from(request.session_id, chosen,
                                       approved=request.approved)

    def _retask_from(
        self, session_id: str, chosen: Alternative, gateway: ModelGateway | None,
        resolver: GatewayResolver | None = None,
    ) -> ConversationResponse:
        """Ask an advisor what this arm should attempt instead, and show the answer.

        The retask is not on the record to be read back -- it is what an advisor
        proposes when asked -- so this asks, and what comes back is offered for
        approval rather than applied. A session with no model to ask says so
        instead of inventing an objective, which is the same refusal the design
        path makes.
        """
        session = self.sessions.store.latest(session_id).snapshot
        advising, route = routed_component(
            session.routing_policy, ModelRole.REPLAN, resolver=resolver,
            # Wrapped before the advisor is built, not after: the advisor is
            # what calls the provider, and the gateway is the one thing every
            # one of its calls goes through.
            given=None if gateway is None else LLMReplanAdvisor(
                self._narrated(gateway, REPLAN_ROLE, session_id),
                timeout_seconds=MODEL_SECONDS),
            build=lambda resolved, declared: LLMReplanAdvisor(
                self._narrated(resolved, REPLAN_ROLE, session_id),
                timeout_seconds=MODEL_SECONDS, declared_route=declared),
            what="a replan advisor")
        if advising is None:
            raise ValueError("asking what an arm should attempt instead needs a model")
        del route  # recorded on the retask itself, from the advisor that made it
        asked = self.actions.decide(session_id, replanner=advising)
        if asked.amendment is None:
            return self.describe(session_id).model_copy(update={
                "message": f"Nothing different was proposed for {chosen.arm}. "
                           f"The recorded plan is unchanged.",
            })
        # Held, because a model wrote it. The advisor is called once, here; what
        # a person approves is read back from the record rather than asked for a
        # second time, so the objective that reaches the plan is the one that was
        # on the screen.
        self.sessions.propose_amendment(
            session_id, asked.amendment, source_alternative_id=chosen.alternative_id)
        standing = self.describe(session_id)
        return standing.model_copy(update={
            "message": f"{_chose(chosen)} Read it before approving; the plan is "
                       f"unchanged until you do.",
        })

    def _more_repeats_from(
        self, session_id: str, chosen: Alternative, *, approved: bool | None,
    ) -> ConversationResponse:
        """Turn "ask for more evidence" into the amendment that says so.

        Raising `repeats_per_arm` asks the design for more usable runs, and the
        attempts to get them follow from it. It is not a way of buying attempts
        quietly: what a person approves says the design now wants more evidence,
        which is what it will mean afterwards.
        """
        plan = self.sessions.store.latest(session_id).snapshot.plan
        if plan is None:
            raise ValueError("a session with no recorded plan has no repeats to raise")
        # As many as telling its difference needs (P5, 0.2.87), when the spread
        # says; one more when it does not. Derived the same way for the preview
        # and the approval, so what is recorded is what was read.
        try:
            needed = int(self.sessions.repeat_shortfall(session_id)["needed"])  # type: ignore[call-overload]
        except (ValueError, LookupError):
            needed = 0
        proposed = self.actions.checked(plan, ProposedAmendment(
            repeats_per_arm=max(plan.repeats_per_arm + 1, needed),
            rationale=f"{_chose(chosen)} {chosen.rationale}"))
        if approved is True:
            # Derived from the recorded plan by the same rule that produced the
            # preview, so what is recorded is what was read.
            self.actions.amend(session_id, proposed, expected_revision=plan.revision)
            return self.describe(session_id)
        if approved is False:
            # A no. Nothing was held, so nothing has to be released -- but the
            # answer has to stop showing a change nobody is going to take, or the
            # surface would keep offering a decision that was already made.
            return self.describe(session_id).model_copy(update={
                "message": "The proposed change was declined. The recorded plan is "
                           "unchanged, and nothing is waiting on you.",
            })
        standing = self.describe(session_id)
        return standing.model_copy(update={
            "amendment": proposed,
            "message": f"{_chose(chosen)} Read it before choosing it again to record "
                       f"it; nothing has been recorded yet.",
        })

    def _confirm_stop(self, request: ConversationActionRequest) -> ConversationResponse:
        """Record the decision to stop that this session's records support.

        The decision and its rationale come from the records, exactly as an
        amendment does. A client that could send the decision it wanted recorded
        would be a client that decides how a session ended -- and what a person
        confirms has to be the thing they were shown, which is the conclusion
        this session's own answer carried.

        Declining writes nothing, and says so. A session somebody chose not to
        stop is not a session that was stopped, and it is not a session that was
        continued either: it is one still waiting on them.
        """
        assert request.session_id is not None and request.approved is not None
        standing = self.actions.decide(request.session_id)
        if standing.conclusion is None:
            raise ValueError("there is no proposed conclusion to confirm on this session")
        if not request.approved:
            declined = self.describe(request.session_id)
            return declined.model_copy(update={
                "message": "Stopping was declined. Nothing was recorded and the "
                           "session is still waiting on you.",
            })
        self.sessions.conclude(request.session_id, standing.conclusion.decision,
                               standing.conclusion.rationale)
        return self.describe(request.session_id)

    def _keepable(self, session_id: str) -> bool:
        """Whether a finished study has an attempt to keep that is not kept yet."""
        session = self.sessions.store.latest(session_id).snapshot
        if session.conclusion is None:
            return False
        return (self.keeper.chosen(session_id) is not None
                and not self.keeper.kept(session_id))

    def _keep_result(self, request: ConversationActionRequest) -> ConversationResponse:
        """Write the chosen attempt's recorded files back, and say which they were."""
        assert request.session_id is not None
        kept = self.keeper.keep(request.session_id)
        scored = ("" if kept.metric is None or kept.value is None
                  else f", which measured {kept.metric}={kept.value:g}")
        return self.describe(request.session_id).model_copy(update={
            "message": (f"Kept the {kept.arm} arm's attempt {kept.run_id}{scored}: "
                        f"wrote {', '.join(kept.paths)}. The study's records are unchanged."),
        })

    def _conclude(self, request: ConversationActionRequest) -> ConversationResponse:
        """Bind one terminal decision to the evidence pinned now.

        Nothing here softens what acceptance requires. A conclusion of ACCEPTED
        on evidence that does not support it is refused by the service, and an
        amendment that moved the deciding rules still bars it however it was
        approved -- including from this surface.
        """
        assert request.session_id is not None and request.decision is not None
        assert request.rationale is not None
        self.sessions.conclude(request.session_id, request.decision, request.rationale)
        answer = self.describe(request.session_id)
        chosen = self.keeper.chosen(request.session_id)
        if chosen is not None and self.keeper.kept(request.session_id):
            # The copy written for review is the one this decision keeps.
            return answer.model_copy(update={"message": (
                f"{answer.message} The code you reviewed stays: the {chosen.arm} arm's "
                f"attempt in {', '.join(chosen.paths)}.")})
        return answer

    def _after(self, taken: ConversationTurn) -> ConversationResponse:
        """What the turn did, and where that leaves the session.

        Where it stands is read again rather than predicted, so the two halves
        cannot disagree: the account comes from the turn, the state comes from the
        records the turn wrote.

        The message becomes the turn's own detail, which is an account of what
        happened -- "performed 2 operation(s); next: ..." -- rather than a
        restatement of where things now stand. A person who pressed something is
        owed what it did, and the state is in the fields beside it.
        """
        # The arms complete, the best attempt is written for review before
        # anyone is asked to decide: a person choosing from a report alone was
        # choosing without the code it described.
        reviewed = self.keeper.preview(taken.session_id)
        standing = self.context(taken.session_id)
        answer = self._about(taken.session_id, capability_for(standing), standing)
        detail = taken.detail if reviewed is None else (
            f"{taken.detail} The best attempt -- the {reviewed.arm} arm's {reviewed.run_id}"
            + ("" if reviewed.metric is None or reviewed.value is None
               else f", {reviewed.metric}={reviewed.value:g}")
            + f" -- is written to {', '.join(reviewed.paths)} for you to read before deciding.")
        return answer.model_copy(update={
            "message": detail,
            "performed": list(taken.performed),
            # A refused operation is why this did nothing. The turn's own state is
            # not copied over: `turn_state` is where the *session* stands, read
            # from its records, and a turn that failed did not necessarily leave
            # the session failed.
            "refusal": taken.refusal,
        })

    def _still_current(self, request: ConversationActionRequest) -> None:
        """Refuse an action offered for a session that has since moved on."""
        assert request.session_id is not None
        standing = self.context(request.session_id)
        if (request.event_sequence != standing.event_sequence
                or request.plan_revision != standing.plan_revision):
            raise StaleConversationAction(
                f"this was offered for event {request.event_sequence} and plan revision "
                f"{request.plan_revision}; the session is now at event "
                f"{standing.event_sequence} and revision {standing.plan_revision}. "
                f"Nothing was done. Ask again to see where it stands.")
        # The held proposal counts as something this session affords: it is the
        # thing a person was shown and is being asked about.
        held = self.sessions.store.latest(request.session_id).snapshot.pending_amendment
        offered = _offered(capability_for(standing), self.actions.decide(request.session_id),
                           pending=held, keepable=self._keepable(request.session_id))
        if request.action not in offered:
            raise StaleConversationAction(
                f"{request.action.value} is not something this session affords now. "
                f"Nothing was done.")

    def _accept(self, request: ConversationActionRequest) -> ConversationResponse:
        """Record the proposal a person accepted: the one act here that writes.

        Validated as a `ProposedPlan` on the way in. It travelled to a surface and
        back, and a person may have edited it there -- which is what reading a
        proposal before accepting it is for -- so what returns is checked exactly
        as anything else entering the application is.
        """
        assert request.proposal is not None
        session = self.proposals.accept(ProposedPlan.model_validate(request.proposal))
        return self.describe(session.session_id)

    def _failures(self, session_id: str, arms: Sequence[str]) -> list[FailureExplanation]:
        """Why each holding arm has no usable evidence.

        The arms come from `blocked_arms`, which is data; no arm name is ever read
        out of a blocker sentence. An arm with nothing to explain is left out
        rather than carried as an empty story -- "not checked" and "checked and
        found nothing" stay different answers here as everywhere else.
        """
        explained = []
        for arm in dict.fromkeys(arms):
            explanation = self.repairs.explain(session_id, arm)
            if explanation.explains_anything:
                explained.append(explanation)
        return explained

    def _changes(self, session_id: str) -> list[RunChange]:
        """What each attached attempt wrote, newest last, bounded.

        Every attached run, not only the arms holding things up: a session a
        person is reading has already changed their files, and which attempt did
        it is exactly what they are looking for. A run that never wrote anything
        is left out rather than carried as a change of nothing -- "it never ran"
        and "it ran and changed nothing" are different answers.
        """
        session = self.actions.research.store.latest(session_id).snapshot
        described = []
        for reference in session.runs[-MAXIMUM_CHANGES:]:
            change = describe_change(self.actions.research.runs.load(reference.run_id),
                                     arm=reference.role)
            if change is not None:
                described.append(change)
        return described

    def _propose(
        self, said: ConversationInput, planner: ResearchPlanner | None,
    ) -> ConversationResponse:
        """Design from a stated goal. Nothing is recorded until someone accepts."""
        if planner is None:
            # Said plainly rather than answered with something invented: there is
            # no design without something to design with.
            return ConversationResponse(
                capability=ConversationCapability.PROPOSE_RESEARCH,
                message="Choose a model to design with, and say the goal again.",
            )
        from relab_research.proposals import ResearchIntent

        proposed = self.proposals.propose(ResearchIntent(stated=said.said), planner)
        return ConversationResponse(
            capability=ConversationCapability.PROPOSE_RESEARCH,
            intent=ConversationIntent.NEW_GOAL,
            available_intents=available_intents(None),
            message=f"Proposed: {proposed.objective}. Nothing is recorded until you accept it.",
            proposal=proposed.model_dump(mode="json"),
            available_actions=OFFERED[ConversationCapability.PROPOSE_RESEARCH],
        )

    def _about(
        self, session_id: str, capability: ConversationCapability,
        context: ConversationRouteContext,
    ) -> ConversationResponse:
        """Answer about a session that exists, from what its records say."""
        action = self.actions.decide(session_id)
        session = self.sessions.store.latest(session_id).snapshot
        status = self.actions.reader.status(session_id)
        return ConversationResponse(
            capability=capability,
            intent=ConversationIntent.QUESTION,
            available_intents=available_intents(context),
            message=_message(capability, action),
            session_id=session_id,
            turn_state=context.turn_state,
            blockers=list(action.blockers),
            blocked_arms=list(action.blocked_arms),
            # When the instrument is the problem, say so here rather than
            # leaving a person to read it out of a sentence about budgets.
            measurement_blocker=action.measurement_blocker,
            measurement_claim_blocker=action.measurement_claim_blocker,
            measurement_sensitivity=action.measurement_sensitivity,
            # The numbers a conclusion is decided on, beside the request for one.
            results=_results(status.assessment),
            failures=self._failures(session_id, action.blocked_arms),
            # What a person is being asked to approve, so they can read it before
            # they are asked. It carries its own `moves_deciding_rules`, written
            # against the plan on record rather than by whoever proposed it.
            # A change held for a decision is what a person is being asked about;
            # one derived for this answer is what the session would propose if
            # nobody had been asked yet. The held one wins, because it is the one
            # that was shown.
            amendment=(session.pending_amendment.proposal
                       if session.pending_amendment is not None else action.amendment),
            # And the decision to stop, when the records support one. It carries
            # its own alternatives, so what stopping is instead of stays visible.
            conclusion=action.conclusion,
            # The runs waiting on a person, as data rather than as the sentences
            # the lifecycle renders them into for `blockers`.
            gates=list(status.gates),
            # What the attempts wrote, so "patch applied and verified" is not the
            # whole account a person gets of a change to their own code.
            changes=self._changes(session_id),
            available_actions=_offered(capability, action,
                                       pending=session.pending_amendment,
                                       keepable=self._keepable(session_id)),
            evidence=list(action.grounds),
            event_sequence=context.event_sequence,
            plan_revision=context.plan_revision,
        )


def _offered(
    capability: ConversationCapability, action: NextAction, *,
    pending: PendingAmendment | None = None, keepable: bool = False,
) -> list[ConversationAction]:
    """What may be done here, narrowed to what this session actually has."""
    offered = list(OFFERED[capability])
    if ConversationAction.KEEP_RESULT in offered and not keepable:
        # Nothing to keep, or it is already on disk.
        offered.remove(ConversationAction.KEEP_RESULT)
    if (ConversationAction.ANSWER_AMENDMENT in offered
            and action.amendment is None and pending is None):
        # With no amendment there is nothing to answer, which is a fact about the
        # record rather than a policy this layer is deciding.
        offered.remove(ConversationAction.ANSWER_AMENDMENT)
    if (ConversationAction.SELECT_ALTERNATIVE in offered
            and not _choosable(action.conclusion)):
        # Nothing to choose. An alternative that is real but answered elsewhere
        # is still shown; what is withdrawn here is the offer to act on one,
        # which is a fact about how much of this surface is built.
        offered.remove(ConversationAction.SELECT_ALTERNATIVE)
    if ConversationAction.CONFIRM_STOP in offered and action.conclusion is None:
        # Nothing to confirm. The same rule the amendment follows, and for the
        # same reason: a session that cannot be stopped as proposed has no
        # proposal, which is a fact about the record and not a policy here.
        offered.remove(ConversationAction.CONFIRM_STOP)
    if (ConversationAction.EVALUATE_HOLDOUT in offered
            and action.lifecycle is not LifecycleAction.EVALUATE_HOLDOUT):
        # The same rule, applied to the other conditional action in this branch.
        # A session that declares no holdout was still offered one, and a person
        # clicking it was told the conversation cannot do it yet -- which is a
        # true sentence about an action that was never theirs to take. The
        # lifecycle already decides when a holdout is open and unevaluated; that
        # decision is read here rather than made a second time.
        offered.remove(ConversationAction.EVALUATE_HOLDOUT)
    return offered


def _choosable(conclusion: ProposedConclusion | None) -> bool:
    """Whether any alternative on this answer is one this surface can act on."""
    return conclusion is not None and any(item.performable for item in conclusion.alternatives)


def _message(capability: ConversationCapability, action: NextAction) -> str:
    """One line, assembled from what the backend already said.

    Deliberately not a model's sentence. A message that a model wrote and a
    surface then read for instructions is how the control plane gets back into
    prose; this one restates the answer that is already in the fields.
    """
    detail = _sentence(action.detail)
    if capability is ConversationCapability.ANSWER_GATE:
        return f"A run is waiting on you. {detail}"
    if capability is ConversationCapability.DISCUSS_BLOCKER:
        if action.kind is NextActionKind.AMENDMENT and action.amendment is not None:
            return f"A change to the declared policy is proposed: {action.amendment.rationale}"
        return f"This is waiting on you. {detail}"
    if capability is ConversationCapability.CONTINUE_SESSION:
        return f"ReLab can continue this on its own. {detail}"
    if capability is ConversationCapability.EXPLAIN_RESULT:
        return f"This session is finished. {detail}"
    if capability is ConversationCapability.START_NEW_RESEARCH:
        return f"This session can carry nothing forward. {detail}"
    return f"Nothing here is ours to move. {detail}"


def _sentence(detail: str) -> str:
    """A lifecycle detail, made to read as the second sentence it becomes.

    The details are written as clauses -- "the declared design still lacks
    usable evidence" -- and were appended after a full stop as they stood. Only
    a plain lowercase word is capitalised: a detail that opens with a path, an
    identifier or a name stays exactly as written, because `calculator.py` is
    not a word that starts a sentence.
    """
    text = detail.strip()
    if not text:
        return text
    first = text.split(" ", 1)[0]
    if first.isalpha() and first.islower():
        text = text[0].upper() + text[1:]
    if text[-1] not in ".!?:":
        text += "."
    return text


def _results(assessment: ResearchSessionAssessment | None) -> ConversationResults | None:
    """The assessment, as the numbers a person decides a conclusion on.

    Read, never recomputed: the checks are the assessment's own items with
    their own reasons, so what this shows and what the lifecycle decided are
    the same judgement.
    """
    if assessment is None:
        return None
    arms, checks = [], []
    for arm in assessment.arms:
        report = arm.repeatability
        samples = [] if report is None else report.samples
        values: dict[str, list[float]] = {}
        for sample in samples:
            for name, value in sample.metrics.items():
                values.setdefault(name, []).append(value)
        arms.append(ArmResult(arm=arm.arm, runs=len(arm.run_ids), values=values))
        for item in [] if report is None else report.items:
            span = (None if item.minimum is None or item.maximum is None
                    else f"{item.minimum:g} to {item.maximum:g}"
                    + ("" if item.spread is None else f" (spread {_short(item.spread)})"))
            checks.append(ResultCheck(
                kind=ResultCheckKind.REPEATABILITY, subject=arm.arm, metric=item.name,
                passed=item.passed, reason=item.reason, detail=span))
    for index, comparison in enumerate(assessment.comparisons, start=1):
        for rule in comparison.items:
            said = (None if rule.candidate_value is None or rule.baseline_value is None
                    else f"candidate {rule.candidate_value:g}, baseline {rule.baseline_value:g}")
            checks.append(ResultCheck(
                kind=ResultCheckKind.COMPARISON, subject=f"candidate vs baseline, pair {index}",
                metric=rule.name, passed=rule.passed, reason=rule.reason, detail=said))
    return ConversationResults(
        passed=assessment.passed, reason=assessment.reason,
        support=assessment.decision_support.value,
        support_reason=assessment.support_reason,
        arms=arms[:16], checks=checks[:64])


def _short(number: str) -> str:
    """A decimal the assessment wrote exactly, at the precision a person reads."""
    try:
        return f"{float(number):g}"
    except ValueError:
        return number
