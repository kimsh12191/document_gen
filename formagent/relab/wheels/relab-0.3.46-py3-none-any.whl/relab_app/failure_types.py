"""Failures a loop could not see, by kind, as lessons for other tasks (P3, 0.3.24).

RL-10 read again: of the first repeat's twelve failures with only the loops'
own lessons carried, eleven finished believing they had succeeded. What failed
was what the hidden check compared exactly -- a message's words, the shape of
what is returned, a unit -- and a test the loop wrote from its own reading
passed its own reading. A loop writes no lesson about a failure it never saw,
so its own lessons cannot help the next attempt; and the check's own words, as
an `evaluation` lesson, help only the same task again.

What does carry to another task is the kind of failure. A verified failure
statement (pytest's `E` line: a hidden check, or later a person's or CI's
test) is sorted by rule into a kind; a kind met in at least two tasks becomes a
lesson with what to do about it and one task's failure as its example. Given to
loops on other tasks, whose own checks are never read, whether it helps is a
measure of memory without the check's feedback (`bench --given-lessons`).
Rule-made, with no model call.
"""

from __future__ import annotations

import re
from collections.abc import Iterable

from pydantic import Field

from relab_app.lessons import failure_statements
from relab_core.contracts import Contract

# A kind is a lesson only once met in this many tasks: one task's failure is that task's.
MINIMUM_TASKS = 2
MAXIMUM_EXAMPLE = 200
EXAMPLES = 2

# What to do about each kind, said once for every task. The order is the order
# a statement is tried in: the first kind it fits is its kind.
GUIDANCE = {
    "not_raised": "Where the task says an input is invalid, raise the exception it names, with its "
                  "message: tests check that it is raised, and code that returns or prints instead fails them.",
    "missing_name": "Use the names the task's stub and description give -- functions, classes, "
                    "attributes, constants -- exactly: tests import and read them by those names.",
    "return_shape": "Return what the description and examples show in the shape they show it -- a "
                    "list of lines or one string, a string or a list, a number or a string: tests "
                    "compare the value as it is, not as it prints.",
    "exact_text": "Messages and text the task gives are compared character for character: take error "
                  "messages, wording, separators, blank lines and trailing newlines verbatim from the "
                  "description and its examples, not paraphrased.",
    "value": "Work out each of the description's examples by hand and check your code gives that "
             "exact value, in the units and scale the examples use (cents, not dollars; counts, not "
             "sizes): a test you wrote from your own reading passes your own reading.",
}

QUOTED = r"""(?:'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*")"""
NUMBER = r"-?\d+(?:\.\d+)?"


def failure_kind(statement: str) -> str | None:
    """The kind of a verified failure, from pytest's `E` line; None when none fits."""
    text = re.sub(r"^E\s+", "", statement.strip())
    if re.search(r"\bnot raised\b|DID NOT RAISE", text):
        return "not_raised"
    if re.match(r"(?:ImportError: cannot import name|NameError: name)\b", text) or \
            re.match(r"AttributeError: (?:module|type object) .* has no attribute", text):
        return "missing_name"
    if re.search(r"is not an instance of", text) or \
            re.match(rf"AssertionError: {QUOTED} != \[", text) or \
            re.match(rf"AssertionError: \[.*\] != {QUOTED}$", text) or \
            re.match(r"AssertionError: Lists differ: \['[^\]]*\\n", text):
        return "return_shape"
    compared = re.match(rf"AssertionError: ({QUOTED}) != ({QUOTED})$", text)
    if compared is not None:
        # Two pieces of text, each of words: wording. A word against a word
        # ('!msicrexe' != 'exercism!') is a wrong value that happens to be text.
        return "exact_text" if all(" " in side for side in compared.groups()) else "value"
    if re.match(r"AssertionError: Lists differ: \[", text):
        return "exact_text"
    if re.match(rf"AssertionError: {NUMBER} != {NUMBER}$", text):
        return "value"
    return None


class KindLesson(Contract):
    """A kind of failure met in more than one task, and what to do about it."""

    kind: str = Field(min_length=1, max_length=40)
    text: str = Field(min_length=1, max_length=700)
    tasks: list[str] = Field(min_length=1)
    example: str = Field(min_length=1, max_length=MAXIMUM_EXAMPLE + 80)


def kind_lessons(failures: Iterable[tuple[str, str]], minimum: int = MINIMUM_TASKS) -> list[KindLesson]:
    """From (task, check output) of failed runs: each kind met in `minimum` or more tasks, most met first."""
    met: dict[str, dict[str, str]] = {}
    for task, output in failures:
        for _, statement in failure_statements(output, limit=3):
            kind = failure_kind(statement)
            if kind is not None:
                said = re.sub(r"^E\s+", "", statement.strip())
                kept = met.setdefault(kind, {})
                if task not in kept or len(said) < len(kept[task]):
                    kept[task] = said
    lessons = []
    for kind, where in met.items():
        if len(where) < minimum:
            continue
        # The shortest statements say the kind most plainly ('EDGE malformed' != 'Edge is malformed'),
        # two tasks' so neither reads as the rule.
        shown = sorted(sorted(where.items()), key=lambda item: len(item[1]))[:EXAMPLES]
        example = "; ".join(f"{task}: {_clip(said, MAXIMUM_EXAMPLE // EXAMPLES)}" for task, said in shown)
        lessons.append(KindLesson(kind=kind, tasks=sorted(where), example=example,
                                  text=f"{GUIDANCE[kind]} (Failed this way in {len(where)} other tasks' "
                                       f"hidden tests, e.g. {example})"[:700]))
    order = list(GUIDANCE)
    lessons.sort(key=lambda item: (-len(item.tasks), order.index(item.kind)))
    return lessons


def _clip(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[:limit - 3] + "..."
