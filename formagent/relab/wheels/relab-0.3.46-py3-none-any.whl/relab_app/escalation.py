"""A research model call that moves up a ladder when a model's reply cannot be used.

The coding loop moves up when its record says the model is stuck
(`coding_loop.ModelLadder`). A research role -- the planner proposing a design,
the replan advisor -- is one call, so it moves up on one thing only: the model
answered, and what it answered could not be used. Its JSON did not read, its
proposal broke the contract, it refused, or it called a tool. Not a timeout, a
lost connection, a rate limit or a content filter -- a provider's failure is
not the model's (`relab_core.provider.KIND`), and the doctrine there is no
automatic retry for those. Each model on the ladder is asked once: the ladder
is the budget. A session whose roles were declared (`--route`) uses its
declared route and nothing else; a ladder applies to calls nobody routed.

Nothing here is written by a model: the person names the ladder.
"""

from collections.abc import Callable
from typing import Any, TypeVar

from relab_core.generation import ModelGateway
from relab_core.provider import KIND, IncidentKind, ProviderIncident

R = TypeVar("R")
MAXIMUM_SAID = 300


class Witness:
    """A gateway, unchanged, that remembers whether the model replied.

    An error raised after a reply came back is about the reply: what the
    model said could not be read. One raised before is about something else.
    """

    def __new__(cls, inner: ModelGateway) -> "Witness":  # noqa: PYI034 -- typing.Self requires Python 3.11.
        # Declared when the inner gateway has an identity: Python 3.12's
        # protocol checks do not see one reached through `__getattr__`.
        identified = cls is Witness and getattr(inner, "identity", None) is not None
        return super().__new__(_IdentifiedWitness if identified else cls)

    def __init__(self, inner: ModelGateway) -> None:
        self.inner = inner
        self.replied = False

    def complete(self, prompt: str, **options: Any) -> str:
        reply = self.inner.complete(prompt, **options)
        self.replied = True
        return reply

    def complete_chat(self, messages: list[dict[str, object]], **options: Any) -> str:
        reply: str = self.inner.complete_chat(messages, **options)  # type: ignore[attr-defined]
        self.replied = True
        return reply

    def __getattr__(self, name: str) -> Any:
        # Its identity, and anything else a caller reads off the gateway.
        return getattr(self.inner, name)



class _IdentifiedWitness(Witness):
    """A witness whose inner gateway has an identity, declared (Python 3.12+)."""

    @property
    def identity(self) -> Any:
        return self.inner.identity  # type: ignore[attr-defined]

def unusable(error: BaseException, replied: bool) -> str | None:
    """Why a model's reply could not be used, when that is what went wrong; else None."""
    incident = getattr(error, "incident", None)
    if isinstance(incident, ProviderIncident):
        if KIND.get(incident) is IncidentKind.MODEL_OUTCOME:
            return incident.value.replace("_", " ")
        return None
    if replied and isinstance(error, ValueError):
        first = (str(error).strip().splitlines() or [type(error).__name__])[0]
        return f"its reply could not be used: {first}"
    return None


def climb(models: list[str | None],
          attempt: Callable[[str | None, Callable[[ModelGateway], ModelGateway]], R], *,
          said: Callable[[str], object] | None = None) -> tuple[R, list[str]]:
    """`attempt` with each model in turn until one's reply is usable.

    `attempt(model, wrap)` builds its gateway for `model` and passes it
    through `wrap`, so a reply can be told from no reply. What was passed
    over -- each model and why -- is returned beside the result. Any other
    failure, and the last model's, is raised as it was.
    """
    passed: list[str] = []
    for place, model in enumerate(models):
        watched: list[Witness] = []

        def wrap(gateway: ModelGateway, watched: list[Witness] = watched) -> ModelGateway:
            witness = Witness(gateway)
            watched.append(witness)
            return witness

        try:
            return attempt(model, wrap), passed
        except Exception as error:
            why = unusable(error, any(witness.replied for witness in watched))
            if why is None or place == len(models) - 1 or model is None:
                raise
            passed.append(f"{model}: {why}"[:MAXIMUM_SAID])
            if said is not None:
                said(f"{model}'s reply could not be used ({why}); asking {models[place + 1]}")
    raise AssertionError("climb was given no models")
