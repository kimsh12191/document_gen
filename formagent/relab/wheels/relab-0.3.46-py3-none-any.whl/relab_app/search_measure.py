"""How long ReLab's code search takes on this machine, at 10,000 and 30,000 files (P1).

`relab code measure-search` runs it where ReLab is installed: only the VSIX
goes onto a server, so the repository's benchmark scripts never reached Linux
(RL-03 was measured on Windows alone). Nothing of the workspace is read: the
files are made in a temporary folder -- flat, and nested 25 x 10 folders deep
-- and removed after. Each case runs in a process of its own, with ripgrep
when one is found and without it, so both paths are measured; the medians and
95th percentiles of the samples are returned, with the platform they came from.
"""

from __future__ import annotations

import json
import os
import platform
import shutil
import statistics
import subprocess
import sys
import tempfile
from collections.abc import Callable
from pathlib import Path

# What each worker measures, by case: one search, a regex, five at once, one
# from a fresh service (no index yet), and rebuilding the index.
CASES = ("literal_1", "regex_1", "literal_5", "cold_literal_1", "index_refresh")


def make_files(root: Path, files: int) -> None:
    """`files` small Python files, flat and nested, each holding one findable line."""
    body = "# filler\n" * 100
    for tree in ("flat", "nested"):
        for index in range(files):
            folder = root / tree if tree == "flat" else (
                root / tree / f"pkg{index % 25:02}" / f"mod{(index // 25) % 10}")
            folder.mkdir(parents=True, exist_ok=True)
            (folder / f"f{index:05}.py").write_text(
                f"value = 'needle_{index:04}_end'\n{body}", encoding="utf-8")


def worker(root: Path, repeats: int) -> dict[str, list[float]]:
    """Each case's samples in milliseconds, for both trees under `root`."""
    import time

    from relab_workspace.code_search import CodeSearchQuery, CodeSearchService
    from relab_workspace.file_index import WorkspaceFileIndex

    literal = [CodeSearchQuery(query="needle_0042_end")]
    regex = [CodeSearchQuery(query="needle_0042_e.d", regex=True)]
    five = [CodeSearchQuery(query=f"needle_{index:04}_end") for index in range(5)]

    def cases(folder: Path) -> dict[str, Callable[[], object]]:
        service = CodeSearchService(folder)
        service.index.files()
        return {
            "literal_1": lambda: service.search_many(literal),
            "regex_1": lambda: service.search_many(regex),
            "literal_5": lambda: service.search_many(five),
            "cold_literal_1": lambda: CodeSearchService(folder).search_many(literal),
            "index_refresh": lambda: WorkspaceFileIndex(folder).refresh(),
        }

    out: dict[str, list[float]] = {}
    for tree in ("flat", "nested"):
        for name, case in cases((root / tree).resolve()).items():
            samples = []
            for _ in range(repeats):
                started = time.perf_counter()
                case()
                samples.append((time.perf_counter() - started) * 1000)
            out[f"{tree}/{name}"] = samples
    return out


def _p95(values: list[float]) -> float:
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, max(0, round(0.95 * len(ordered)) - 1))]


def _without_ripgrep(environment: dict[str, str]) -> dict[str, str]:
    """The environment with no ripgrep to be found: the fallback some servers take."""
    changed = dict(environment)
    changed.pop("RELAB_RG", None)
    name = "rg.exe" if os.name == "nt" else "rg"
    changed["PATH"] = os.pathsep.join(part for part in changed.get("PATH", "").split(os.pathsep)
                                      if part and not (Path(part) / name).exists())
    return changed


def measure(counts: list[int], repeats: int = 5) -> dict[str, object]:
    """The search timings at each file count, with and without ripgrep, as one report."""
    found = os.environ.get("RELAB_RG", "").strip() or shutil.which("rg")
    modes = [("with_rg", dict(os.environ)), ("without_rg", _without_ripgrep(dict(os.environ)))] \
        if found else [("without_rg", _without_ripgrep(dict(os.environ)))]
    report: dict[str, object] = {
        "python": platform.python_version(), "platform": platform.platform(),
        "machine": platform.machine(), "cpus": os.cpu_count(), "ripgrep": found,
        "repeats": repeats, "results": {}}
    results: dict[str, dict[str, float]] = report["results"]  # type: ignore[assignment]
    for count in counts:
        with tempfile.TemporaryDirectory(prefix="relab-measure-search-") as folder:
            root = Path(folder)
            make_files(root, count)
            for mode, environment in modes:
                done = subprocess.run(
                    [sys.executable, "-m", "relab_app.search_measure", "--worker", str(root),
                     str(repeats)], capture_output=True, text=True, env=environment, check=True)
                for case, samples in json.loads(done.stdout).items():
                    results[f"{count}/{mode}/{case}"] = {
                        "p50_ms": round(statistics.median(samples), 1),
                        "p95_ms": round(_p95(samples), 1), "samples": len(samples)}
    return report


def shown(report: dict[str, object]) -> str:
    """The report as lines a person reads: one per case."""
    results: dict[str, dict[str, float]] = report["results"]  # type: ignore[assignment]
    lines = [(f"{report['platform']} · Python {report['python']} · {report['cpus']} CPUs · "
              f"ripgrep {report['ripgrep'] or 'not found'}")]
    lines += [f"{case:44} p50 {value['p50_ms']:>9} ms   p95 {value['p95_ms']:>9} ms"
              for case, value in results.items()]
    return "\n".join(lines)


if __name__ == "__main__":
    if sys.argv[1:2] == ["--worker"]:
        print(json.dumps(worker(Path(sys.argv[2]), int(sys.argv[3]))))
