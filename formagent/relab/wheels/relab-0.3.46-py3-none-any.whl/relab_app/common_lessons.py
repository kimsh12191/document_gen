"""Lessons common to a person's projects: the same failure met in more than one (0.3.17).

Each workspace keeps its own lessons (`lessons.py`), with its own file names in
them; a lesson about `text2sql/scripts/generate_datasets.py` means nothing in
another project. What does carry over is the failure itself: the same error,
once its names, numbers and paths are left out (`signature`) -- an
`UnboundLocalError` on a variable set only in a branch, a sqlite name that
needs quoting -- and the change that fixed it.

A failure met in two or more of the person's workspaces is offered as a common
lesson (`candidates`), with the fixes each found. Nothing is kept for every
project unseen: the person confirms one (`relab code common-lessons --confirm`),
writing its text or taking the one offered, or dismisses it. Confirmed, it is
kept in the person's folder and given to a loop in any workspace when a
command there fails with that error -- counted, as a workspace's lessons are,
as given and as missed when the loop met the error again. Rule-made, with no
model call. Not given where records are kept in the workspace (the test suite,
a benchmark's throwaway workspaces): a measurement is not to be changed by
what one person confirmed.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from pydantic import Field

from relab_app.lessons import LESSONS_FILE, Lesson, first_error
from relab_core.coding_loop import CodingLoop, LoopActionKind
from relab_core.contracts import Contract
from relab_workspace.private_state import in_workspace, private_base

COMMON_FILE = "common_lessons.json"
# Met in this many of the person's workspaces, a failure is offered as common.
MINIMUM_WORKSPACES = 2
# The kinds of lesson that name an error and what got past it.
KINDS = ("fixed_failure", "changed_approach")
MAXIMUM_COMMON = 100
MAXIMUM_TEXT = 700
# The fixes an offer shows, and a confirmed lesson's text keeps, at most.
SHOWN_FIXES = 3
# A lesson given this many times or more that did not prevent its failure at
# least half of them is no longer given, as a workspace's are.
MISSED_ENOUGH = 2
# An assertion is a project's own expectation, not a failure that carries over.
NOT_COMMON = re.compile(r"^(?:AssertionError|assert\b)")
# One error, worded by Python versions differently: each said as 3.10 says it, and the
# suggestions 3.10+ add left out (0.3.31). Found by the weekly check on 3.12: a lesson from a
# project on 3.10 was never given to the same UnboundLocalError on 3.11+.
WORDINGS = (
    (re.compile(r"cannot access local variable (\S+) where it is not associated with a value"),
     r"local variable \1 referenced before assignment"),
    (re.compile(r"cannot access free variable (\S+) where it is not associated with a value in enclosing scope"),
     r"free variable \1 referenced before assignment in enclosing scope"),
    (re.compile(r"\.?\s*(?:Did you mean:?|Did you forget to import)\s.*$"), ""),
)


def signature(error: str) -> str | None:
    """A failure's shape: the named error and its message, with names, numbers and paths left out.

    "sqlite3.OperationalError: near "7": syntax error" and the same error near
    "2023" are one shape; so are UnboundLocalError on `table3` and on
    `tables_used`. Only a named error (`...Error`, `...Exception`) has one: an
    exit code or "it failed" says nothing that carries to another project.
    """
    text = re.sub(r"^E\s+", "", error.strip())
    found = re.search(r"\b[\w.]*(?:Error|Exception)\b", text)
    if found is None:
        return None
    text = text[found.start():]
    if NOT_COMMON.match(text):
        return None
    for wording, said in WORDINGS:
        text = wording.sub(said, text)
    text = re.sub(r"'[^']*'|\"[^\"]*\"|`[^`]*`", "<x>", text)
    text = re.sub(r"(?:[A-Za-z]:)?(?:[\w.~-]*[\\/])+[\w.-]+", "<path>", text)
    # A number of its own, not one inside a name (`sqlite3`, `utf8`).
    text = re.sub(r"\b0x[0-9a-fA-F]+\b|(?<![A-Za-z_])\d+(?:\.\d+)?", "<n>", text)
    return " ".join(text.split())[:160] or None


def lesson_error(text: str) -> str | None:
    """The error a fixed-failure or way-through lesson names."""
    found = (re.search(r"failed with: (.+?) -- it passed", text)
             or re.search(r"kept failing with: (.+?) -- sending it again", text))
    return found.group(1).strip() if found else None


def lesson_fix(text: str) -> str | None:
    """What a lesson says fixed it: the change, or the way through."""
    found = (re.search(r"; the change: (.+?)\.?$", text)
             or re.search(r"what worked instead: (.+?)\.?$", text)
             or re.search(r"it passed after (changing .+?)\.?$", text))
    return found.group(1).strip() if found else None


class CommonCandidate(Contract):
    """A failure met in more than one workspace, offered to the person; not kept."""

    candidate_id: str = Field(pattern=r"^common-[0-9a-f]{16}$")
    signature: str = Field(min_length=1, max_length=160)
    workspaces: list[str] = Field(min_length=1)
    lessons: int = Field(ge=1)
    fixes: list[str] = Field(default_factory=list, max_length=SHOWN_FIXES)
    # How the workspaces' own lessons for it fared, summed.
    given: int = Field(default=0, ge=0)
    missed: int = Field(default=0, ge=0)
    offered: str = Field(min_length=1, max_length=MAXIMUM_TEXT)


class CommonLesson(Contract):
    """A failure common to the person's projects, and what fixed it, as the person confirmed it."""

    lesson_id: str = Field(pattern=r"^common-[0-9a-f]{16}$")
    signature: str = Field(min_length=1, max_length=160)
    text: str = Field(min_length=1, max_length=MAXIMUM_TEXT)
    workspaces: int = Field(ge=1)
    confirmed_at: datetime
    given: int = Field(default=0, ge=0)
    missed: int = Field(default=0, ge=0)


def common_id(shape: str) -> str:
    return "common-" + hashlib.sha256(shape.encode("utf-8")).hexdigest()[:16]


def offered_text(shape: str, workspaces: int, fixes: list[str]) -> str:
    """The text a candidate is offered with: the failure, and what fixed it where it was met."""
    said = "; or ".join(fixes[:SHOWN_FIXES])
    return (f"Met in {workspaces} of your projects: {shape}"
            + (f" -- what fixed it there: {said}" if said else ""))[:MAXIMUM_TEXT]


class CommonLessons:
    """The person's common lessons, and the failures their workspaces share, read fresh each time."""

    def __init__(self, base: Path | None = None) -> None:
        self.base = base if base is not None else private_base()
        self.path = self.base / COMMON_FILE

    def _read(self) -> tuple[list[CommonLesson], list[str]]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return [], []
        if not isinstance(data, dict):
            return [], []
        kept: list[CommonLesson] = []
        for item in data.get("confirmed", []) if isinstance(data.get("confirmed"), list) else []:
            try:
                kept.append(CommonLesson.model_validate(item))
            except ValueError:
                continue
        dismissed = [str(item) for item in data.get("dismissed", []) if isinstance(item, str)]
        return kept, dismissed

    def _write(self, kept: list[CommonLesson], dismissed: list[str]) -> None:
        self.base.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps({
            "confirmed": [item.model_dump(mode="json") for item in kept[-MAXIMUM_COMMON:]],
            "dismissed": sorted(set(dismissed))}, ensure_ascii=False, indent=1), encoding="utf-8")
        temporary.replace(self.path)

    def all(self) -> list[CommonLesson]:
        return self._read()[0]

    def _workspace_lessons(self) -> list[tuple[str, Lesson]]:
        """Every workspace's lessons that name an error, with the workspace they are from."""
        found: list[tuple[str, Lesson]] = []
        for folder in sorted((self.base / "workspaces").glob("*")):
            try:
                named = (folder / "workspace.txt").read_text(encoding="utf-8").strip().splitlines()
                data = json.loads((folder / LESSONS_FILE).read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            where = named[0] if named else folder.name
            for item in data if isinstance(data, list) else []:
                try:
                    lesson = Lesson.model_validate(item)
                except ValueError:
                    continue
                if lesson.kind in KINDS:
                    found.append((where, lesson))
        return found

    def candidates(self, minimum: int = MINIMUM_WORKSPACES) -> list[CommonCandidate]:
        """The failures met in `minimum` or more workspaces, not yet confirmed or dismissed, most met first."""
        kept, dismissed = self._read()
        settled = {item.signature for item in kept} | set(dismissed)
        grouped: dict[str, list[tuple[str, Lesson]]] = {}
        for where, lesson in self._workspace_lessons():
            error = lesson_error(lesson.text)
            shape = signature(error) if error is not None else None
            if shape is not None and shape not in settled:
                grouped.setdefault(shape, []).append((where, lesson))
        offers: list[CommonCandidate] = []
        for shape, found in grouped.items():
            places = list(dict.fromkeys(where for where, _ in found))
            if len(places) < minimum:
                continue
            fixes = list(dict.fromkeys(fix for _, lesson in found
                                       for fix in [lesson_fix(lesson.text)] if fix))[:SHOWN_FIXES]
            offers.append(CommonCandidate(
                candidate_id=common_id(shape), signature=shape, workspaces=places, lessons=len(found),
                fixes=fixes, given=sum(lesson.given for _, lesson in found),
                missed=sum(lesson.missed for _, lesson in found),
                offered=offered_text(shape, len(places), fixes)))
        offers.sort(key=lambda item: (len(item.workspaces), item.lessons, item.signature), reverse=True)
        return offers

    def confirm(self, candidate_id: str, text: str | None = None) -> CommonLesson | None:
        """Keep a candidate as a common lesson, with the person's text or the one offered."""
        offer = next((item for item in self.candidates() if item.candidate_id == candidate_id), None)
        if offer is None:
            return None
        kept, dismissed = self._read()
        lesson = CommonLesson(
            lesson_id=offer.candidate_id, signature=offer.signature,
            text=(text.strip() if text and text.strip() else offer.offered)[:MAXIMUM_TEXT],
            workspaces=len(offer.workspaces), confirmed_at=datetime.now(timezone.utc))
        self._write([*kept, lesson], dismissed)
        return lesson

    def dismiss(self, lesson_id: str) -> bool:
        """Take a confirmed lesson out, or set a candidate aside: neither is offered again."""
        kept, dismissed = self._read()
        gone = [item for item in kept if item.lesson_id == lesson_id]
        offer = next((item for item in self.candidates() if item.candidate_id == lesson_id), None)
        if not gone and offer is None:
            return False
        shapes = [item.signature for item in gone] + ([offer.signature] if offer is not None else [])
        self._write([item for item in kept if item.lesson_id != lesson_id], [*dismissed, *shapes])
        return True

    def for_failure(self, observation: str) -> CommonLesson | None:
        """The confirmed lesson for the error a command just failed with, if one is kept and still helps."""
        if in_workspace():
            return None
        shape = signature(first_error(observation))
        if shape is None:
            return None
        return next((item for item in self.all() if item.signature == shape
                     and not (item.missed >= MISSED_ENOUGH and item.missed * 2 >= item.given)), None)

    def record_use(self, loop: CodingLoop) -> None:
        """Count, for the common lessons a finished loop was given, that they were given, and missed.

        Given when a command failed with its error, a lesson missed when a command
        failed with that error again after it: the failure that brought it is
        not one it could have prevented.
        """
        kept, dismissed = self._read()
        mine = [item for item in kept if item.text in loop.lessons]
        if not mine:
            return
        shapes = [signature(first_error(step.observation)) for step in loop.steps
                  if step.action.action is LoopActionKind.RUN and not step.succeeded]
        updated = [item.model_copy(update={"given": item.given + 1,
                                           "missed": item.missed + (1 if shapes.count(item.signature) > 1 else 0)})
                   if item in mine else item for item in kept]
        self._write(updated, dismissed)
