"""Where a loop's turns and time went, in numbers only (`relab code stats LOOP`).

Asked for in use: ReLab and Cline were given the same task; Cline did it in
fewer turns and less time, and what the task held could not be shared. These
are counts and durations read from the loop's record -- no request, no file,
no output -- so they can be shared where the work cannot:

- time: in all, while steps ran (reads, commands), and between them (the model
  answering, and ReLab's own handling);
- calls: model calls, turns that brought steps, summaries;
- steps by kind, and the ones that failed;
- what ReLab itself sent back: steps refused by kind, finishes sent back, plans
  asked for, the same failing step refused, plan B/C notes;
- speed (0.3.38): the calls' time to the first token and in all, by the size of
  their prompt, and the share of the prompt the provider's cache served. Slower
  as the prompt grows -- a long context read again each call -- is a context
  budget's to fix (`--context-budget`); a small cached share, the server's
  prefix cache's.
"""

from collections import Counter
from statistics import median

from relab_core.coding_loop import CallMeasure, CodingLoop, LoopStep

# The prompt sizes calls are grouped by, in tokens: up to each bound, the last for the rest.
PROMPT_SIZES = ((32_000, "under 32k"), (64_000, "32k-64k"), (128_000, "64k-128k"),
                (256_000, "128k-256k"), (None, "256k and over"))
# How many of the slowest calls are named, and how much slower the largest prompts'
# first token must be than the smallest's to be said as growing with the prompt.
SLOWEST = 3
GROWS = 2.0

# What a refusal is about, by words its observation says; the first that matches.
REFUSAL_KINDS = (
    ("the text to replace is not in", "edit quote not found"),
    ("the text to replace was found", "edit quote found more than once"),
    ("changed since it was last read", "edit by lines on a changed file"),
    ("held out for the final evaluation", "held-out path"),
    ("outside the workspace", "outside the workspace"),
    ("outside the project folder", "outside the project folder"),
    ("is not a program on this host", "program not found"),
    ("plan first:", "plan asked for first"),
    ("waiting for the person", "waiting for the person"),
)


def _kind(observation: str) -> str:
    for words, kind in REFUSAL_KINDS:
        if words in observation:
            return kind
    return "other"


SLOWEST_STEPS = 5


def _took(step: LoopStep) -> float:
    """How long one step ran, in seconds."""
    return max(0.0, (step.finished_at - step.started_at).total_seconds())


def _seconds(steps: list[LoopStep]) -> float:
    """How long steps ran, a turn's steps counted as the span they ran in together."""
    turns: dict[object, list[LoopStep]] = {}
    for step in steps:
        turns.setdefault(step.turn if step.turn is not None else ("step", step.index), []).append(step)
    total = 0.0
    for group in turns.values():
        began = min(step.started_at for step in group)
        ended = max(step.finished_at for step in group)
        total += max(0.0, (ended - began).total_seconds())
    return total


def _tokens(call: CallMeasure) -> int:
    """A call's prompt in tokens: as the provider reported it, else as estimated here."""
    return call.prompt_tokens if call.prompt_tokens is not None else call.budget.estimated_tokens


def _size(tokens: int) -> str:
    for bound, name in PROMPT_SIZES:
        if bound is None or tokens < bound:
            return name
    return PROMPT_SIZES[-1][1]


def _thousands(tokens: int) -> str:
    return f"{tokens / 1000:.1f}k"


def _middle(values: list[float]) -> float | None:
    return round(median(values), 1) if values else None


def _first_tokens(calls: list[CallMeasure]) -> float | None:
    """The median time to the first token of the calls streamed."""
    return _middle([call.first_token_seconds for call in calls if call.first_token_seconds is not None])


def speed(loop: CodingLoop) -> dict[str, object]:
    """How fast the loop's measured calls were, by the size of their prompt (0.3.38)."""
    calls = [call for call in loop.calls_measured if call.seconds is not None]
    firsts = [call.first_token_seconds for call in calls if call.first_token_seconds is not None]
    groups: dict[str, list[CallMeasure]] = {}
    for call in sorted(calls, key=_tokens):
        groups.setdefault(_size(_tokens(call)), []).append(call)
    by_size: dict[str, str] = {}
    for name, group in groups.items():
        first = _first_tokens(group)
        whole = _middle([call.seconds for call in group if call.seconds is not None])
        by_size[name] = (f"{len(group)} call(s), first token {first if first is not None else '-'}s, "
                         f"in all {whole}s (medians)")
    slowest = sorted(calls, key=lambda call: call.first_token_seconds or call.seconds or 0.0, reverse=True)
    reported = [call for call in calls if call.prompt_tokens]
    cached = (round(100 * sum(call.cached_tokens or 0 for call in reported)
                    / sum(call.prompt_tokens or 0 for call in reported), 1)
              if reported and any(call.cached_tokens is not None for call in reported) else None)
    said_of: list[str] = []
    ordered = list(groups.values())
    low = _first_tokens(ordered[0]) if ordered else None
    high = _first_tokens(ordered[-1]) if ordered else None
    if len(groups) > 1 and low and high and high >= GROWS * low:
        said_of.append(f"the first token grows with the prompt ({low}s -> {high}s): the long context is read "
                       f"again each call; a context budget (--context-budget) keeps the prompt smaller")
    if cached is not None and cached < 50 and len(reported) > 1:
        said_of.append(f"the provider's cache served {cached}% of the prompt tokens: check the server's "
                       f"prefix cache (vLLM: --enable-prefix-caching and its hit rate in the log)")
    return {
        "calls_timed": len(calls),
        "first_token_seconds": {"median": _middle(firsts), "slowest": round(max(firsts), 1) if firsts else None},
        "call_seconds": {"median": _middle([call.seconds for call in calls if call.seconds is not None])},
        "cached_share_percent": cached,
        "by_prompt_size": by_size,
        "slowest_calls": {f"call {call.call}": (
            f"{_thousands(_tokens(call))} prompt, first token "
            f"{round(call.first_token_seconds, 1) if call.first_token_seconds is not None else '-'}s, "
            f"in all {round(call.seconds or 0.0, 1)}s") for call in slowest[:SLOWEST]},
        "reading": "; ".join(said_of) or None,
    }


def stats(loop: CodingLoop) -> dict[str, object]:
    """The numbers of one loop's record."""
    steps = loop.steps
    observations = [step.observation for step in steps]
    refused = [text for text in observations if text.startswith("refused")]
    running = _seconds(steps)
    runs = [step for step in steps if step.action.action.value == "run"]
    return {
        "loop_id": loop.loop_id,
        "outcome": loop.outcome.value,
        "requests": 1 + len(loop.followups),
        "time": {
            "seconds": round(loop.seconds, 1),
            "steps_running": round(running, 1),
            "between_steps": round(max(0.0, loop.seconds - running), 1),
        },
        "calls": {
            "model_calls": loop.calls,
            "turns_with_steps": len({step.turn for step in steps if step.turn is not None}),
            "summaries": loop.digests,
            "summaries_from_the_record": loop.digest_failures,
            "model_changes": len(loop.model_changes),
        },
        "steps": {
            "in_all": len(steps),
            "failed": sum(1 for step in steps if not step.succeeded),
            "by_kind": dict(Counter(step.action.action.value for step in steps).most_common()),
            "runs": len(runs),
            "runs_failed": sum(1 for step in runs if not step.succeeded),
            # Where the steps' time went (0.3.43): a loop's commands took 58% of ten hours and
            # nothing said which. By its number and kind only, never what it ran.
            "slowest": {f"step {step.index}": f"{step.action.action.value} {_took(step):.1f}s"
                        for step in sorted(steps, key=_took, reverse=True)[:SLOWEST_STEPS]
                        if _took(step) > 0},
        },
        "sent_back_by_relab": {
            "refused_by_kind": dict(Counter(_kind(text) for text in refused).most_common()),
            "same_failing_step_refused": sum(1 for text in observations
                                             if text.startswith("not done again")),
            "finish_sent_back": sum(1 for text in observations if text.startswith("not finished")),
            "plan_sent_back_for_layout": sum(1 for text in observations
                                             if text.startswith("plan sent back")),
            "plan_b_or_c": sum(text.count("[ReLab] Plan ") for text in observations),
            "usage_errors": sum(1 for text in observations
                                if "[ReLab] The program refused its arguments" in text),
        },
        "checklist": {"items": len(loop.todos), "done": sum(1 for item in loop.todos if item.done)},
        "speed": speed(loop),
    }


def said(numbers: dict[str, object]) -> str:
    """The numbers as lines a person reads and can paste."""
    lines = [f"loop {numbers['loop_id']} ({numbers['outcome']}, {numbers['requests']} request(s))"]
    for section in ("time", "calls", "steps", "sent_back_by_relab", "checklist"):
        value = numbers[section]
        assert isinstance(value, dict)
        parts = []
        for key, item in value.items():
            if isinstance(item, dict):
                inner = ", ".join(f"{name} {count}" for name, count in item.items()) or "none"
                parts.append(f"{key}: {inner}")
            else:
                parts.append(f"{key} {item}")
        lines.append(f"{section}: " + "; ".join(parts))
    return "\n".join(lines + _speed_lines(numbers["speed"]))  # type: ignore[arg-type]


def _speed_lines(numbers: dict[str, object]) -> list[str]:
    """The speed section a line a part: groups and slowest calls read down, not across."""
    lines = [f"speed: calls_timed {numbers['calls_timed']}; first_token_seconds "
             + ", ".join(f"{key} {value}" for key, value in numbers["first_token_seconds"].items())  # type: ignore[attr-defined]
             + f"; call_seconds median {numbers['call_seconds']['median']}"  # type: ignore[index]
             + f"; cached_share_percent {numbers['cached_share_percent']}"]
    for heading in ("by_prompt_size", "slowest_calls"):
        for key, value in numbers[heading].items():  # type: ignore[attr-defined]
            lines.append(f"  {heading.replace('_', ' ')}: {key}: {value}")
    if numbers["reading"]:
        lines.append(f"  reading: {numbers['reading']}")
    return lines
