"""Which policy a run works under, apart from where its records are kept (R09, 0.3.0).

Before, keeping records in the workspace (`RELAB_STATE_IN_WORKSPACE`, as the
test suite and the benchmarks do) also turned off the person's own rules,
ReLab's default rules and the documentation check: where records were kept
decided how the work was done. Now a profile decides, named in
`RELAB_PROFILE` (or `--profile`):

- `vscode_default`: the editor's way -- ReLab's defaults (the documentation
  rule, while its setting is on), the person's own rules, the documentation
  check.
- `benchmark_controlled`: a comparison with another agent under control --
  neither ReLab's defaults nor the person's rules, no documentation check.
- `benchmark_usage_equivalent`: the editor's way for a usability measure,
  with the person's own rules left out and said so (a benchmark must not read
  whoever runs it).

With no profile named, records kept in the workspace read as
`benchmark_controlled`, as before, and the record says the profile came from
there (`legacy:RELAB_STATE_IN_WORKSPACE`); else `vscode_default`. Named, the
profile holds wherever the records are. The person's rules are never read
where records are kept in the workspace, whatever the profile: that is what
keeps a test from reading a real home.
"""

import os
from dataclasses import dataclass

from relab_workspace.private_state import in_workspace

PROFILE_ENV = "RELAB_PROFILE"
PROFILES = ("vscode_default", "benchmark_controlled", "benchmark_usage_equivalent")


@dataclass(frozen=True)
class RunPolicy:
    """What a profile resolves to: each part of the policy, and where the profile came from."""

    profile: str
    source: str
    default_rules: bool
    personal_rules: bool
    docs_kept: bool


def resolved(default_rules_setting: bool = True) -> RunPolicy:
    """The policy this process runs under; an unknown profile is refused."""
    named = os.environ.get(PROFILE_ENV, "").strip()
    if named and named not in PROFILES:
        raise ValueError(f"{PROFILE_ENV} is {named!r}; it is one of {', '.join(PROFILES)}")
    if named:
        profile, source = named, f"env:{PROFILE_ENV}"
    elif in_workspace():
        profile, source = "benchmark_controlled", "legacy:RELAB_STATE_IN_WORKSPACE"
    else:
        profile, source = "vscode_default", "default"
    controlled = profile == "benchmark_controlled"
    return RunPolicy(
        profile=profile, source=source,
        default_rules=default_rules_setting and not controlled,
        # Never from a real home where records are in the workspace (RULE-06).
        personal_rules=profile == "vscode_default" and not in_workspace(),
        docs_kept=default_rules_setting and not controlled)
