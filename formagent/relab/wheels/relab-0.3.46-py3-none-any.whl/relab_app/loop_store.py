"""Where a workspace's coding loops are kept: one JSON record each (RL-09).

Split out of `CodingLoopService`, which still decides when a record is saved
and counts the time it takes; this only knows how a record is written so a
reader never sees half of one, and how it is found again.
"""

import re
import time
from pathlib import Path

from relab_core.coding_loop import CodingLoop

# How often a record is tried again when Windows holds it for a moment.
SAVE_ATTEMPTS = 6
# A loop's record, and nothing else kept beside it: `loop-<id>.problems.json`
# (the editor's diagnostics) and `loop-<id>.steer.jsonl` share the folder.
RECORD = re.compile(r"loop-[0-9a-f]{32}\.json")


def records(directory: Path) -> list[Path]:
    """The loop records in a folder: `loop-<32 hex>.json`, nothing beside them."""
    if not directory.is_dir():
        return []
    return sorted(path for path in directory.glob("loop-*.json") if RECORD.fullmatch(path.name))


class LoopStore:
    def __init__(self, directory: Path) -> None:
        self.directory = directory
        # Records `all` could not read, by name: kept out of the list, not the
        # end of it (0.2.22).
        self.unreadable: list[str] = []

    def write(self, loop: CodingLoop) -> None:
        """Replace a loop's record whole: written beside it, then moved over it."""
        self.directory.mkdir(parents=True, exist_ok=True)
        target = self.directory / f"{loop.loop_id}.json"
        temporary = target.with_suffix(".tmp")
        temporary.write_text(loop.model_dump_json(), encoding="utf-8")
        # On Windows a file just written can be held for a moment by something
        # else reading it -- a virus scanner, an indexer -- and the replace is
        # refused; a record saved twice in a row met that. A few short waits,
        # then the error as it is.
        for attempt in range(SAVE_ATTEMPTS):
            try:
                temporary.replace(target)
                return
            except PermissionError:
                if attempt == SAVE_ATTEMPTS - 1:
                    raise
                time.sleep(0.05 * (attempt + 1))

    def load(self, loop_id: str) -> CodingLoop:
        target = self.directory / f"{loop_id}.json"
        if not loop_id.startswith("loop-") or not target.is_file():
            raise LookupError(f"no coding loop {loop_id} in this workspace")
        return CodingLoop.model_validate_json(target.read_text(encoding="utf-8"))

    def latest(self) -> CodingLoop:
        """The loop whose record was written last, helpers left out: the one running, or just ended.

        Read newest first and stopped at the first that will read, rather than
        every record read to choose one (0.3.25).
        """
        def written(path: Path) -> float:
            try:
                return path.stat().st_mtime
            except OSError:
                return 0.0

        for item in sorted(records(self.directory), key=written, reverse=True):
            try:
                loop = CodingLoop.model_validate_json(item.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if loop.helper_of is None:
                return loop
        raise LookupError("no coding loop recorded in this workspace")

    def all(self) -> list[CodingLoop]:
        """Every loop recorded here, oldest first; a record that cannot be read is left out.

        Found on a Linux server (0.2.22): the editor's `loop-<id>.problems.json`
        matched `loop-*.json`, failed to read as a loop, and the whole list failed
        with it -- every conversation was gone from the editor, which said there
        were none. Only `loop-<32 hex>.json` is a record now, and one that will
        not read (another version's, a broken write) costs only itself.
        """
        found, self.unreadable = [], []
        for item in records(self.directory):
            try:
                found.append(CodingLoop.model_validate_json(item.read_text(encoding="utf-8")))
            except (OSError, ValueError):
                self.unreadable.append(item.name)
        return sorted(found, key=lambda item: item.started_at)
