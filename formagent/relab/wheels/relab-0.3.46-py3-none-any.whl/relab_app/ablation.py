"""Turning one of ReLab's checks off, for an experiment that measures what it does (0.2.87).

The paper's experiment plan (docs/validation/PAPER_EXPERIMENT_PLAN.md) compares
ReLab with each of its checks off in turn. Named in `RELAB_WITHOUT`, comma
separated, or with `--without NAME` on a loop's command; an unknown name is an
error rather than a check quietly left on. Every switch off is said in the
loop's record (`performance["without:<name>"]`), so a run can be told apart.
For experiments only: none of them is offered in the editor.
"""

import os

WITHOUT_ENV = "RELAB_WITHOUT"
# A1-A5 of the plan; the finish checks as a whole, and each of the newer ones alone.
SWITCHES = {
    "finish-checks": "every check before finishing (A1)",
    "hollow-outputs": "outputs that are mostly empty values (A2)",
    "unmeasured-shares": "percentages stated with nothing run (A3)",
    "copied-summaries": "summaries that paste their sources",
    "fixed-addresses": "a service's address fixed in code",
    "rule-made-summaries": "a model's summary asked, the model asked only to read",
    "unused-settings": "settings written and read by no code",
    "sequential-calls": "many items, and the model called one at a time",
    "docs-kept": "code written, and its documents in docs/ not there",
    "plan-layout": "a plan sent back for its layout (A4)",
    "plan-requirements": "a plan sent back for a model's summary it does not place",
    "score-spread": "the spread of repeated scores, the repeats it allows and sizes (A5)",
    "goal-holds": "a finish short of the request's goal sent back while room is left",
    "staged-runs": "a run over every item held until a few items ran, and scores of a few said so",
    "probe-files": "a script to check something written in scratch/, a test in tests/, and named",
}


# How the checks that look at how the code is written say what they find (0.2.94):
# "demand" names what to put in; "advise" says what to find out and accepts a
# reason. Advise is the default since 0.2.103, asked in use: rules pressed too
# hard were holding the work back. Safety and the request's own requirements
# are the same in both; "demand" stays for the experiment that compares them.
CHECK_STYLE_ENV = "RELAB_CHECK_STYLE"
CHECK_STYLES = ("demand", "advise")


def advising() -> bool:
    """Whether the checks on how code is written advise rather than demand; another value is refused."""
    style = os.environ.get(CHECK_STYLE_ENV, "").strip() or "advise"
    if style not in CHECK_STYLES:
        raise ValueError(f"{CHECK_STYLE_ENV} is {style!r}; it is one of {', '.join(CHECK_STYLES)}")
    return style == "advise"


def switched_off() -> frozenset[str]:
    """The checks turned off for this process; an unknown name is refused."""
    named = {item.strip() for item in os.environ.get(WITHOUT_ENV, "").split(",") if item.strip()}
    unknown = sorted(named - SWITCHES.keys())
    if unknown:
        raise ValueError(f"{WITHOUT_ENV} names checks ReLab does not have: {', '.join(unknown)}; "
                         f"it has {', '.join(sorted(SWITCHES))}")
    return frozenset(named)


def without(name: str) -> bool:
    """Whether the check `name` is turned off."""
    assert name in SWITCHES, name
    return name in switched_off()
