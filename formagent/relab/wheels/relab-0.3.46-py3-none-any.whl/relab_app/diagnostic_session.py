"""Cheap checks immediately, installed project diagnostics once per turn."""
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from relab_app.diagnostics import (
    JAVASCRIPT,
    TYPESCRIPT,
    _eslint,
    _gofmt,
    _json,
    _node_check,
    _package,
    _toml,
    _tsc,
)
from relab_core.coding.patch import VerificationResult
from relab_workspace.patcher import Patcher


@dataclass
class DiagnosticResult:
    paths: list[str]
    text: str
    broken: bool = False


class DiagnosticSession:
    def __init__(self, workspace: Path, python: str, *,
                 measure: Callable[..., VerificationResult] | None = None) -> None:
        self.workspace = workspace
        self.python = python
        self.measure = measure or Patcher().measure
        self.changed: dict[str, None] = {}
        self.duration_ms = 0.0

    def mark_changed(self, path: str) -> None:
        self.changed[path] = None

    def cheap_check(self, path: str) -> DiagnosticResult:
        suffix = Path(path).suffix.lower()
        try:
            if suffix == ".py":
                compile((self.workspace / path).read_text(encoding="utf-8"), path, "exec")
                return DiagnosticResult([path], "")
            check = {".json": lambda: _json(self.workspace / path),
                     ".toml": lambda: _toml(self.workspace / path),
                     ".go": lambda: _gofmt(self.workspace, path)}
            if suffix in JAVASCRIPT:
                text, broken = _node_check(self.workspace, path)
            elif suffix in check:
                text, broken = check[suffix]()
            else:
                text, broken = "", False
            return DiagnosticResult([path], text, broken)
        except SyntaxError as error:
            return DiagnosticResult([path],
                                    f"syntax error at line {error.lineno}: {error.msg}", True)
        except (OSError, UnicodeDecodeError):
            return DiagnosticResult([path], "")

    def flush(self) -> list[DiagnosticResult]:
        paths = list(self.changed)
        self.changed.clear()
        if not paths:
            return []
        started = time.monotonic()
        results: list[DiagnosticResult] = []
        python = [p for p in paths if p.endswith(".py")]
        if python:
            try:
                measured = self.measure(self.workspace,
                    [self.python, "-m", "ruff", "check", "--output-format", "concise",
                     "--select", "E9,F63,F7,F82,F401,F811,F841", *python], timeout_seconds=60)
                lines = [line for line in measured.stdout.splitlines() if line.strip()
                         and not line.startswith(("Found", "[*]", "No fixes", "All checks"))]
                if lines:
                    results.append(DiagnosticResult(python, "ruff found:\n" + "\n".join(lines[:20])))
            except (OSError, ValueError):
                pass  # Optional tool availability does not block a coding task.
        packages: dict[str, list[str]] = {}
        for path in paths:
            if Path(path).suffix.lower() in JAVASCRIPT | TYPESCRIPT | {".jsx"}:
                package = _package(self.workspace, path)
                if package is not None:
                    packages.setdefault(package, []).append(path)
        for package, files in packages.items():
            try:
                typed = [p for p in files if Path(p).suffix.lower() in TYPESCRIPT]
                if typed:
                    text, broken = _tsc(self.workspace, package, typed)
                    if text:
                        results.append(DiagnosticResult(typed, text, broken))
                text = _eslint(self.workspace, package, files)
                if text:
                    results.append(DiagnosticResult(files, text))
            except (OSError, UnicodeDecodeError):
                continue
        self.duration_ms += (time.monotonic() - started) * 1000
        return results
