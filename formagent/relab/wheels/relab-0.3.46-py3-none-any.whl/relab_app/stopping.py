"""Proposing that a session stop, and saying what stopping would be instead of.

A session that cannot reach a verdict goes quiet today. Its lifecycle says the
budget is spent, or that an arm keeps hitting one failure and somebody should
"change the task, the model, or stop" -- and then nothing happens, because none
of those three is an operation anybody was offered. The records afterwards say
this session was never concluded, which is not the same claim as *we decided to
stop* and cannot be read as one later.

Everything here is derived. The decision follows from whether the design was ever
measured, the rationale is assembled from the lifecycle's own sentences, and the
alternatives are facts about what the records show has not been tried. No model
is asked, because nothing here is a judgement: which decision the evidence
supports is computable, and whether to take it is the part that belongs to a
person.
"""

from pathlib import Path

from relab_app.repair import RepairMemory
from relab_app.sessions import ResearchSessionService
from relab_core.alternatives import (
    MAXIMUM_ALTERNATIVES,
    Alternative,
    AlternativeAction,
    identify,
)
from relab_core.lifecycle import LifecycleAction, SessionLifecycle
from relab_core.next_action import ProposedConclusion
from relab_core.research import ResearchDecision, ResearchSession

# Where the lifecycle has stopped: nothing can advance and a person is owed a
# decision rather than a description. Kept beside `next_action.STOPPED`, which
# reads the same two for the same reason.
STOPPED = frozenset({LifecycleAction.REVIEW_FAILURES, LifecycleAction.REVIEW_BUDGET})


class StopReader:
    """What stopping this session would mean, read from its records."""

    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.research = ResearchSessionService(self.workspace)
        self.repairs = RepairMemory(self.workspace)

    def stop(self, session_id: str, status: SessionLifecycle) -> ProposedConclusion | None:
        """The decision this session's records support, or None while it can still run.

        None is the ordinary answer. A session with work left is not being asked
        to stop, and proposing it anyway would put a terminal decision in front of
        somebody every time they looked at a session that was merely slow.
        """
        if status.action not in STOPPED:
            return None
        session = self.research.store.latest(session_id).snapshot
        if session.conclusion is not None:
            return None
        return ProposedConclusion(
            # Abandoned, not rejected. Rejection is a verdict on a design that was
            # measured; this design was not, and recording the stronger word would
            # put a finding in the record that no evidence supports.
            decision=ResearchDecision.ABANDONED,
            rationale=_rationale(status),
            alternatives=_alternatives(session, status),
        )


def _rationale(status: SessionLifecycle) -> str:
    """Why stopping is what these records support, in the lifecycle's own words.

    Assembled rather than written, so the sentence a person confirms is the same
    one the session has been saying. A second wording of the same fact is a place
    for the two to drift.
    """
    said = [status.detail, *status.blockers]
    return " ".join(item.rstrip(".") + "." for item in said if item.strip())


def _alternatives(
    session: ResearchSession, status: SessionLifecycle,
) -> list[Alternative]:
    """What the records show has not been tried, as things that can be chosen.

    Stopping should be a choice. A person shown only "the budget is spent" is
    being asked to agree; one who can also see that an arm has never been asked
    to do anything different is deciding -- and one who can *choose* that from
    where they are reading it does not have to go and find the command for it.

    Nothing is ranked and nothing is recommended. The order is the order these
    facts are derived in, which carries no claim about which is better.
    """
    at = status.event_sequence
    left = []
    for arm in status.stuck_arms:
        left.append(_alternative(
            AlternativeAction.RETASK_ARM, at, arm=arm,
            rationale=f"{arm} has only ever been asked to do one thing; a different "
                      f"task for it is an amendment a person may record"))
    if status.exhausted_arms:
        repeats = 1 if session.plan is None else session.plan.repeats_per_arm
        left.append(_alternative(
            AlternativeAction.INCREASE_REPEATS, at,
            rationale=f"the declared policy asks for {repeats} usable run(s) per arm "
                      f"and the attempts allowed for them are spent; asking for more "
                      f"evidence is an amendment a person may record"))
    declared = None if session.plan is None else session.plan.expected_model
    if declared is not None:
        left.append(_alternative(
            AlternativeAction.CHANGE_MODEL, at,
            rationale=f"every attempt ran against {declared.provider}/{declared.model}; "
                      f"no other model has been tried"))
    return left[:MAXIMUM_ALTERNATIVES]


def _alternative(
    action: AlternativeAction, at: int, *, rationale: str, arm: str | None = None,
) -> Alternative:
    """One alternative, with the id both sides derive rather than either choosing."""
    return Alternative(alternative_id=identify(action, arm), action=action, arm=arm,
                       rationale=rationale, source_event_sequence=at)
