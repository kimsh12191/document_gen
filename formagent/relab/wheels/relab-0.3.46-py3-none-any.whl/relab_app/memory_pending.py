"""Findings drafted when a session concludes, held until a person confirms them.

Research memory recorded only what a person wrote by hand, so a concluded
study's result -- and above all a negative one, "the candidate did not meet the
declared rules" -- was found again by the next study rather than read. Now
concluding a session drafts one finding per claim its interpretation supports,
negative claims included, with a suggested scope (the session's objective).
They wait here, used by nothing, until a person confirms each -- with the
scope they believe it holds in -- or dismisses it (decided 2026-10-04: research
findings are confirmed by a person; coding lessons are not).

Confirming records through `ResearchMemory`, so the rule that a finding cites
evidence recorded here holds unchanged. Nothing is deleted: a dismissed draft
is kept as dismissed.
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from pydantic import Field

from relab_app.interpretation import SessionInterpreter
from relab_app.memory import ResearchMemory
from relab_app.sessions import ResearchSessionService
from relab_core.contracts import Contract
from relab_core.memory import MAXIMUM_CONDITIONS, MemoryDraft
from relab_research.interpretation import memory_drafts
from relab_workspace.private_state import state_dir

PENDING_FILE = "memory_pending.json"
MAXIMUM_SCOPE = 500


class PendingFinding(Contract):
    draft_id: str = Field(pattern=r"^draft-[0-9a-f]{32}$")
    session_id: str
    evidence_package_id: str | None = None
    draft: MemoryDraft
    status: str = Field(default="pending", pattern=r"^(pending|confirmed|dismissed)$")
    memory_id: str | None = None
    created_at: datetime
    decided_at: datetime | None = None


class PendingFindings:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.path = state_dir(self.workspace) / PENDING_FILE

    def all(self) -> list[PendingFinding]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        found = []
        for item in data if isinstance(data, list) else []:
            try:
                found.append(PendingFinding.model_validate(item))
            except ValueError:
                continue
        return found

    def pending(self) -> list[PendingFinding]:
        return [item for item in self.all() if item.status == "pending"]

    def _write(self, items: list[PendingFinding]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps([item.model_dump(mode="json") for item in items],
                                        ensure_ascii=False, indent=1), encoding="utf-8")
        temporary.replace(self.path)

    def propose(self, session_id: str) -> list[PendingFinding]:
        """Draft what a session's records support; a claim drafted before is not again."""
        read = SessionInterpreter(self.workspace).interpret(session_id)
        scope = (read.objective or session_id).strip()[:MAXIMUM_SCOPE] or session_id
        tags = [str(read.decision)] if read.decision else []
        drafted = memory_drafts(read, scope, tags=tags)
        kept = self.all()
        known = {(item.session_id, item.draft.finding) for item in kept}
        now = datetime.now(timezone.utc)
        # Pin provenance to the interpretation read, even if the study reopens meanwhile.
        events = ResearchSessionService(self.workspace).store.events(session_id)
        snapshot = next(event.snapshot for event in events if event.sequence == read.event_sequence)
        conclusion = snapshot.conclusion
        package_id = (f"{session_id}/evidence-{conclusion.event_sequence}"
                      if conclusion is not None and conclusion.decision.value != "abandoned" else None)
        # What the conclusion could not show goes with each finding drawn from it (P5,
        # 0.2.83): a later task reading "no difference" reads how few runs said so.
        limits = [] if conclusion is None else list(conclusion.limitations)
        if limits:
            drafted = [draft.model_copy(update={"conditions": [
                *draft.conditions, *limits][:MAXIMUM_CONDITIONS]}) for draft in drafted]
        new = [PendingFinding(draft_id=f"draft-{uuid4().hex}", session_id=session_id,
                              draft=draft, created_at=now, evidence_package_id=package_id)
               for draft in drafted if (session_id, draft.finding) not in known]
        if new:
            self._write(kept + new)
        return new

    def confirm(self, draft_id: str, *, scope: str | None = None) -> PendingFinding:
        """Record a draft as a finding, in the scope the person states; its evidence must be here."""
        items = self.all()
        item = next((entry for entry in items if entry.draft_id == draft_id), None)
        if item is None or item.status != "pending":
            raise ValueError(f"{draft_id} is not a pending draft")
        draft = item.draft if scope is None or not scope.strip() else \
            item.draft.model_copy(update={"scope": scope.strip()[:MAXIMUM_SCOPE]})
        recorded = ResearchMemory(self.workspace).remember(draft)
        decided = item.model_copy(update={"status": "confirmed", "draft": draft,
                                          "memory_id": recorded.memory_id,
                                          "decided_at": datetime.now(timezone.utc)})
        self._write([decided if entry.draft_id == draft_id else entry for entry in items])
        return decided

    def dismiss(self, draft_id: str) -> PendingFinding:
        items = self.all()
        item = next((entry for entry in items if entry.draft_id == draft_id), None)
        if item is None or item.status != "pending":
            raise ValueError(f"{draft_id} is not a pending draft")
        decided = item.model_copy(update={"status": "dismissed",
                                          "decided_at": datetime.now(timezone.utc)})
        self._write([decided if entry.draft_id == draft_id else entry for entry in items])
        return decided
