"""Deciding what happens next, and recording an amendment if that is the answer.

Two things live here that cannot live anywhere else. What the driver may take
unattended is the driver's own list, so the turn state is derived from it rather
than from a second copy. And whether an amendment would move what decides a pass
is computed against the plan on record, by the layer that holds it.
"""

from collections.abc import Callable
from pathlib import Path

from relab_app.interpretation import SessionInterpreter
from relab_app.lifecycle import SessionLifecycleReader
from relab_app.orchestration import MECHANICAL
from relab_app.replan import ReplanReader, amendment_for
from relab_app.routing import routed_component
from relab_app.sessions import ResearchSessionService
from relab_app.stopping import StopReader
from relab_core.gateways import GatewayResolver
from relab_core.generation import ModelGateway
from relab_core.interpretation import SessionInterpretation
from relab_core.lifecycle import LifecycleAction
from relab_core.memory import MAXIMUM_CITATIONS, EvidenceCitation
from relab_core.next_action import NextAction, NextActionKind, ProposedAmendment
from relab_core.research import ResearchPlan, ResearchSession
from relab_core.routing import ModelRole, ModelRoute
from relab_core.turns import TurnState
from relab_evaluation.preregistration import moved_goalposts
from relab_research.next_action import AmendmentAdvisor, DeterministicAdvisor
from relab_research.replan import ReplanAdvisor

# Where the lifecycle has stopped and a person is being asked to decide something.
#
# Both, not just `REVIEW_FAILURES`. Execution keeps attempting until the budget is
# gone, so by the time an arm has failed the same way three times it has usually
# spent its attempts as well -- and the budget branch is reported first. Gating a
# retask on `REVIEW_FAILURES` alone would have made it almost unreachable: the
# observed status of a genuinely stuck arm is `REVIEW_BUDGET` with `stuck_arms`
# naming it. What decides whether retasking is the right answer is `stuck_arms`,
# not which of the two sentences the lifecycle chose.
STOPPED = frozenset({LifecycleAction.REVIEW_FAILURES, LifecycleAction.REVIEW_BUDGET})


def turn_state(action: LifecycleAction) -> TurnState:
    """What state a turn ending on this operation is in.

    `MECHANICAL` is the driver's own list, imported rather than restated: a second
    copy would eventually disagree, and the disagreement would decide whether a
    turn claimed to be queued when nothing was going to pick it up.
    """
    if action in MECHANICAL:
        return TurnState.ACTION_QUEUED
    if action is LifecycleAction.WAIT:
        return TurnState.ACTION_RUNNING
    if action is LifecycleAction.NONE:
        return TurnState.COMPLETE
    return TurnState.AWAITING_HUMAN


class NextActions:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.reader = SessionLifecycleReader(self.workspace)
        self.interpreter = SessionInterpreter(self.workspace)
        self.research = ResearchSessionService(self.workspace)
        self.replans = ReplanReader(self.workspace)
        self.stopping = StopReader(self.workspace)

    def decide(
        self, session_id: str, *, attempts_per_slot: int = 1,
        advisor: AmendmentAdvisor | None = None,
        replanner: ReplanAdvisor | None = None,
        resolver: GatewayResolver | None = None,
        advisor_from: "Callable[[ModelGateway, ModelRoute], AmendmentAdvisor] | None" = None,
    ) -> NextAction:
        """One thing to do next. This performs none of it and records nothing.

        The advisors are the only judgement in here, and both are replaceable: the
        rest reads records. A model-backed one reaches the same acceptance check as
        the deterministic default, because nothing downstream can tell them apart.

        There is no default replanner. An amendment advisor has a deterministic
        one because raising a bar is computable; nothing computes a different way
        to write a function, so a session with no replanner is told what its
        lifecycle already said rather than handed an invented answer.
        """
        status = self.reader.status(session_id, attempts_per_slot=attempts_per_slot)
        session = self.research.store.latest(session_id).snapshot
        sequence = status.event_sequence
        revision = None if session.plan is None else session.plan.revision
        if (status.action in STOPPED and status.stuck_arms and replanner is not None
                and session.plan is not None):
            retasked = self._retask(session_id, session.plan, status.stuck_arms, replanner)
            if retasked is not None:
                return NextAction(
                    kind=NextActionKind.AMENDMENT, amendment=retasked,
                    detail=f"a person must approve this change: {retasked.rationale}",
                    turn_state=TurnState.AWAITING_HUMAN, blockers=list(status.blockers),
                    blocked_arms=list(status.blocked_arms), plan_revision=revision,
                    session_id=session_id, event_sequence=sequence)
        if status.action in STOPPED:
            # After the retask, deliberately. Asking an arm to attempt something
            # different is the cheaper answer and the reversible one; stopping is
            # what is proposed when nothing is left to try, not instead of trying.
            stopping = self.stopping.stop(session_id, status)
            if stopping is not None:
                return NextAction(
                    kind=NextActionKind.CONCLUSION, conclusion=stopping,
                    detail=f"a person must confirm this: {stopping.rationale}",
                    turn_state=TurnState.AWAITING_HUMAN, blockers=list(status.blockers),
                    blocked_arms=list(status.blocked_arms), plan_revision=revision,
                    session_id=session_id, event_sequence=sequence)
        if status.action is LifecycleAction.CONCLUDE and session.plan is not None:
            # The one moment an amendment is both possible and useful: the design is
            # covered, nothing is decided yet, and the policy can still be raised.
            # A concluded session cannot be amended at all, so proposing one there
            # would be proposing something nobody could carry out.
            read = self.interpreter.interpret(session_id)
            # A declared policy decides which model advises on a policy, like
            # every other role. The deterministic advisor asks nothing, so it is
            # what a session with no declaration and no advisor still gets.
            advising, _ = routed_component(
                session.routing_policy, ModelRole.AMENDMENT, given=advisor,
                resolver=resolver, build=advisor_from, what="an amendment advisor")
            amendment = (advising or DeterministicAdvisor()).advise(read, session.plan)
            if amendment is not None:
                checked = self.checked(session.plan, amendment)
                return NextAction(
                    kind=NextActionKind.AMENDMENT, amendment=checked,
                    detail=f"a person must approve this change: {checked.rationale}",
                    turn_state=TurnState.AWAITING_HUMAN, blockers=list(status.blockers),
                    blocked_arms=list(status.blocked_arms),
                    grounds=_grounds(read), plan_revision=revision,
                    session_id=session_id, event_sequence=sequence)
        if status.action is not LifecycleAction.NONE:
            # The session names an operation, so that is the answer.
            return NextAction(
                kind=NextActionKind.LIFECYCLE, lifecycle=status.action,
                detail=status.detail, turn_state=turn_state(status.action),
                blockers=list(status.blockers),
                blocked_arms=list(status.blocked_arms), plan_revision=revision,
                # The lifecycle has already worked out whether the instrument is
                # what stopped this. Carrying it here is what lets a surface say
                # so without reading the sentence it wrote about it.
                measurement_blocker=status.measurement_blocker,
                measurement_claim_blocker=status.measurement_claim_blocker,
                measurement_sensitivity=status.measurement_sensitivity,
                session_id=session_id, event_sequence=sequence)
        read = self.interpreter.interpret(session_id)
        if read.refused:
            return NextAction(
                kind=NextActionKind.NEW_SESSION, turn_state=TurnState.AWAITING_HUMAN,
                detail=("this session cannot carry findings and cannot be amended into "
                        f"one that can: {read.reason}. Pre-register a new session."),
                plan_revision=revision, session_id=session_id, event_sequence=sequence)
        return NextAction(
            kind=NextActionKind.NONE, turn_state=TurnState.COMPLETE,
            detail="this session is finished and nothing here needs doing",
            plan_revision=revision, session_id=session_id, event_sequence=sequence)

    def _retask(
        self, session_id: str, plan: ResearchPlan, stuck_arms: list[str],
        replanner: ReplanAdvisor,
    ) -> ProposedAmendment | None:
        """The first stuck arm the replanner has something to say about.

        One arm at a time, on purpose. Two retasks in one amendment would be one
        approval covering two judgements, and a person who agreed with one of
        them would have no way to say so.

        Only once the lifecycle has stopped. While another arm can still run, a
        stuck one is not a reason to halt the session and ask a person a question.
        """
        for arm in stuck_arms:
            case = self.replans.stuck(session_id, arm)
            if case is None:
                continue
            retask = replanner.advise(case, plan)
            if retask is None or retask.arm != arm:
                # An advisor answering about a different arm is answering a
                # question nobody asked, and the records for that arm may not
                # support the change at all.
                continue
            return self.checked(plan, amendment_for(plan, retask))
        return None

    def checked(self, plan: ResearchPlan, amendment: ProposedAmendment) -> ProposedAmendment:
        """Say what this change would move, against the plan actually on record.

        Never taken from the document: whoever wrote it has every reason to say it
        moves nothing, and the recorded plan is the only thing that can say.
        """
        return amendment.model_copy(update={
            "moves_deciding_rules": moved_goalposts(plan, _merged(plan, amendment))})


    def approve_pending(self, session_id: str) -> ResearchSession:
        """Record the change that was held, exactly as it was held.

        No advisor is asked. The proposal a person approved is read back from
        the record and merged into the plan, so the objective that reaches the
        policy is the one that was on the screen -- which is the whole reason it
        was kept.
        """
        session = self.research.store.latest(session_id).snapshot
        pending = session.pending_amendment
        if pending is None:
            raise ValueError("there is no proposed change waiting on a decision")
        self.research.resolve_pending_amendment(
            session_id, accepted=True, expected_revision=pending.plan_revision)
        return self.amend(session_id, pending.proposal,
                          expected_revision=pending.plan_revision)

    def decline_pending(self, session_id: str) -> ResearchSession:
        """Answer the held proposal with a no, and change nothing else.

        The plan is untouched. What is recorded is that the question was
        answered -- without it, the same proposal would still be waiting after a
        restart, asking for a decision somebody had already taken.
        """
        session = self.research.store.latest(session_id).snapshot
        pending = session.pending_amendment
        if pending is None:
            raise ValueError("there is no proposed change waiting on a decision")
        return self.research.resolve_pending_amendment(
            session_id, accepted=False, expected_revision=pending.plan_revision)

    def amend(
        self, session_id: str, amendment: ProposedAmendment, *, expected_revision: int,
    ) -> ResearchSession:
        """Record the change. This does not check whether it moves the goalposts.

        It is recorded whatever it moves, and it is recorded *visibly*: a person may
        legitimately amend a policy and then reject or abandon the session. What a
        moving amendment cannot do is be accepted, and that refusal belongs at
        acceptance, where it applies to every amendment however it was proposed.
        """
        session = self.research.store.latest(session_id).snapshot
        if session.plan is None:
            raise ValueError("no research plan to amend; record one first")
        merged = _merged(session.plan, amendment)
        return self.research.revise_plan(
            session_id, merged.registry, expected_revision=expected_revision,
            rationale=amendment.rationale, arms=merged.arms,
            repeats_per_arm=merged.repeats_per_arm, candidate_arm=merged.candidate_arm,
            baseline_arm=merged.baseline_arm, arm_tasks=merged.arm_tasks,
            expected_model=merged.expected_model,
            expected_reported_model=merged.expected_reported_model,
            data_paths=merged.data_paths,
            require_comparable_conditions=merged.require_comparable_conditions,
            holdout_registry=merged.holdout_registry,
            restore_between_attempts=merged.restore_between_attempts,
            isolate_attempts=merged.isolate_attempts,
            sandbox_backend=merged.sandbox_backend, docker_image=merged.docker_image,
            holdout_data_paths=merged.holdout_data_paths, provenance=merged.provenance,
        )


def _merged(plan: ResearchPlan, amendment: ProposedAmendment) -> ResearchPlan:
    """The plan this amendment describes: the recorded one, with its changes applied.

    Every field it does not mention is carried forward. `revise_plan` takes a whole
    policy and defaults what it is not given, so merging here is what stops an
    amendment about repeats from quietly withdrawing a declared holdout.
    """
    changes = {name: value for name, value in (
        ("registry", amendment.registry),
        ("holdout_registry", amendment.holdout_registry),
        ("arms", amendment.arms),
        ("repeats_per_arm", amendment.repeats_per_arm),
        ("candidate_arm", amendment.candidate_arm),
        ("baseline_arm", amendment.baseline_arm),
        ("arm_tasks", amendment.arm_tasks),
        ("require_comparable_conditions", amendment.require_comparable_conditions),
    ) if value is not None}
    return plan.model_copy(update=changes)


def _grounds(read: SessionInterpretation) -> list[EvidenceCitation]:
    """Every event the claims behind this rest on, once each and in a fixed order."""
    seen: dict[tuple[str, int], EvidenceCitation] = {}
    for claim in read.claims:
        for citation in claim.citations:
            seen.setdefault((citation.run_id, citation.event_sequence), citation)
    return [seen[key] for key in sorted(seen)][:MAXIMUM_CITATIONS]
