"""Advancing a session by one turn, and always ending somewhere actionable.

This composes what already exists rather than adding a second orchestration: the
driver performs the mechanical operations, and the next-action reader says what
is left and who may do it. What this adds is that the two come back as one answer
with a turn state on it, so a conversation never has to infer where it stands.
"""

from collections.abc import Callable
from pathlib import Path

from relab_app.next_action import NextActions
from relab_app.orchestration import SessionDriver
from relab_core.conversation import MAXIMUM_PERFORMED, ConversationTurn
from relab_core.gateways import GatewayResolver
from relab_core.generation import ModelGateway
from relab_core.next_action import NextAction, NextActionKind
from relab_core.orchestration import DriveStep
from relab_core.routing import ModelRoute
from relab_core.turns import TurnState
from relab_research.next_action import AmendmentAdvisor

# What a turn that raised is said to have stopped because of.
REFUSED = "the operation was refused"


class Conversation:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.driver = SessionDriver(self.workspace)
        self.actions = NextActions(self.workspace)

    def turn(
        self, session_id: str, gateway: ModelGateway, *, max_steps: int = 3,
        attempts_per_slot: int = 1, repair_context: bool = False,
        model_timeout_seconds: float = 60, timeout_seconds: float = 300,
        parallel_arms: int = 1, advisor: AmendmentAdvisor | None = None,
        resolver: GatewayResolver | None = None,
        advisor_from: "Callable[[ModelGateway, ModelRoute], AmendmentAdvisor] | None" = None,
    ) -> ConversationTurn:
        """Do what is ours to do, then say where that leaves the session.

        Executing calls a model and costs whatever that provider charges. The step
        budget is the only thing that bounds it, exactly as it bounds the driver.
        """
        # Read the session before anything else, so a session that is not here is
        # an error the caller sees rather than a turn reporting a failure about
        # something that never existed.
        self.actions.research.store.latest(session_id)
        performed: list[DriveStep] = []
        refusal = None
        try:
            drive = self.driver.advance(
                session_id, gateway, max_steps=max_steps,
                attempts_per_slot=attempts_per_slot, repair_context=repair_context,
                model_timeout_seconds=model_timeout_seconds,
                timeout_seconds=timeout_seconds, parallel_arms=parallel_arms)
            performed = list(drive.steps)[:MAXIMUM_PERFORMED]
            stopped = drive.stopped_because
        except (ValueError, LookupError) as error:
            # A refusal is this turn's outcome, not something the caller has to
            # catch to discover the turn ended. Anything else is a defect and is
            # left to propagate, because reporting it as a turn state would hide it.
            refusal = f"{type(error).__name__}: {error}"
            stopped = REFUSED
        after = self.actions.decide(
            session_id, attempts_per_slot=attempts_per_slot, advisor=advisor,
            resolver=resolver, advisor_from=advisor_from)
        state = TurnState.FAILED if refusal is not None else after.turn_state
        return ConversationTurn(
            session_id=session_id, state=state, performed=performed, next=after,
            detail=_detail(stopped, performed, after), refusal=refusal)


def _detail(stopped: str, performed: list[DriveStep], after: NextAction) -> str:
    """One line saying what happened, never one that only describes the state.

    "Awaiting a person" is not an account of a turn. What was done, and what is
    now wanted, is -- and a turn that did nothing says that plainly rather than
    leaving it to be inferred from an empty list.
    """
    did = sum(1 for step in performed if step.performed)
    done = f"performed {did} operation(s)" if did else "performed nothing"
    if after.kind is NextActionKind.NONE:
        return f"{done}; nothing is left to do"
    # Why the turn stopped, only when it stopped short: there was more the
    # driver could have done, or it was refused. A turn that ran its three
    # steps and arrived at a person's decision had not run out of anything, and
    # "the step budget of 3 was spent" beside "waiting for you" read as though
    # it had.
    short = after.turn_state is TurnState.ACTION_QUEUED or stopped == REFUSED
    return f"{done}{f' ({stopped})' if short else ''}; next: {after.detail}"
