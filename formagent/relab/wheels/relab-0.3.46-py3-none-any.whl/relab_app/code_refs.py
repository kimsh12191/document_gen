"""Where a Python name is defined, and every place that uses it (M5.5).

The loop finds code by searching text. A search for `validate` finds every
`validate` -- in m55-nav2's same-name task, four of them, only one of which
checkout calls -- and a search for a helper's callers finds every line that
mentions the word. This reads the syntax trees instead:

    definitions   functions, classes, methods and module-level names called so
    uses          where an import binds one of them, by its own name or an
                  alias, and every use of that binding; a module imported and
                  used as `module.name`; uses inside the defining module
    possible      `something.name` where what `something` is cannot be known
                  without running the code -- a method called on an object

Every location comes from a parser; nothing is guessed. What it does not
follow is said with the answer: imports made at run time, `getattr`, names
patched in later, and the names a star import brings.
"""

import ast
import os
import re
from pathlib import Path

from pydantic import Field

from relab_core.contracts import Contract
from relab_core.targets import UNSEARCHED_DIRECTORIES, unusable_path

MAXIMUM_FILES = 5000
FILE_BYTES = 400_000
MAXIMUM_USES = 200
MAXIMUM_POSSIBLE = 40
LINE_TEXT = 160
NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,127}$")
NOT_FOLLOWED = ("imports made at run time (importlib, __import__), getattr and other "
                "reflection, names patched in later, and the names a star import brings")


class SymbolLocation(Contract):
    """Where a name is defined."""

    name: str
    kind: str  # function, class, method or variable
    path: str
    line: int = Field(ge=1)
    qualified_name: str


class SymbolReference(Contract):
    """One place that uses a name: the line, and how it uses it."""

    path: str
    line: int = Field(ge=1)
    kind: str  # import, call or use
    text: str
    # The definition it resolves to; None for a possible use.
    definition: str | None = None


class SymbolReferences(Contract):
    symbol: str
    definitions: list[SymbolLocation] = Field(default_factory=list)
    uses: list[SymbolReference] = Field(default_factory=list)
    possible: list[SymbolReference] = Field(default_factory=list)
    files_read: int = Field(default=0, ge=0)
    unparsed: list[str] = Field(default_factory=list)
    # More uses than are kept, or more files than are read.
    cut: bool = False
    not_followed: str = NOT_FOLLOWED


class _Module:
    def __init__(self, path: str, dotted: str, tree: ast.Module, lines: list[str]) -> None:
        self.path, self.dotted, self.tree, self.lines = path, dotted, tree, lines
        # A local name bound by an import: to (module, attribute) or, for a
        # module itself, (module, None).
        self.bound: dict[str, tuple[str, str | None]] = {}
        self.star = False


def _dotted(path: str) -> str:
    parts = path.removesuffix(".py").split("/")
    if parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def _python_files(workspace: Path, base: Path) -> tuple[list[str], bool]:
    found: list[str] = []
    for root, directories, files in os.walk(base):
        directories[:] = sorted(item for item in directories
                                if item not in UNSEARCHED_DIRECTORIES and not item.startswith("."))
        for name in sorted(files):
            if not name.endswith(".py"):
                continue
            relative = Path(root, name).relative_to(workspace).as_posix()
            if unusable_path(relative) is None:
                found.append(relative)
            if len(found) >= MAXIMUM_FILES:
                return found, True
    return found, False


def _absolute(module: _Module, level: int, name: str | None) -> str:
    """The module a relative import names, from the importing module's package."""
    if level == 0:
        return name or ""
    package = module.dotted.split(".")
    if not module.path.endswith("__init__.py"):
        package = package[:-1]
    package = package[:len(package) - (level - 1)] if level > 1 else package
    return ".".join([*package, *([name] if name else [])])


class _Index:
    """Every parsed module, and how to find one from what an import calls it."""

    def __init__(self, modules: list[_Module]) -> None:
        self.modules = modules
        self.by_dotted = {module.dotted: module for module in modules}

    def find(self, dotted: str) -> _Module | None:
        """The module an import names: exactly, or as the end of a longer path (a src/ root)."""
        if dotted in self.by_dotted:
            return self.by_dotted[dotted]
        ends = [module for name, module in self.by_dotted.items() if name.endswith("." + dotted)]
        return ends[0] if len(ends) == 1 else None

    def resolve(self, dotted: str, attribute: str, depth: int = 0) -> str | None:
        """The defining module of `attribute` as reached through module `dotted`, re-exports followed."""
        module = self.find(dotted)
        if module is None:
            return None
        if depth < 4 and attribute in module.bound:
            target, name = module.bound[attribute]
            if name is not None:
                return self.resolve(target, name, depth + 1)
        return module.dotted


def _parse(workspace: Path, path: str) -> _Module | None:
    try:
        raw = (workspace / path).read_bytes()[:FILE_BYTES]
        text = raw.decode("utf-8")
        tree = ast.parse(text)
    except (OSError, UnicodeDecodeError, SyntaxError, ValueError):
        return None
    module = _Module(path, _dotted(path), tree, text.splitlines())
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            source = _absolute(module, node.level, node.module)
            for alias in node.names:
                if alias.name == "*":
                    module.star = True
                    continue
                module.bound[alias.asname or alias.name] = (source, alias.name)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                if alias.asname:
                    module.bound[alias.asname] = (alias.name, None)
                else:
                    top = alias.name.split(".")[0]
                    module.bound[top] = (top, None)
    return module


def _definitions(module: _Module, symbol: str) -> list[SymbolLocation]:
    found = []
    for node in module.tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.name == symbol:
                kind = "class" if isinstance(node, ast.ClassDef) else "function"
                found.append(SymbolLocation(name=symbol, kind=kind, path=module.path,
                                            line=node.lineno,
                                            qualified_name=f"{module.dotted}.{symbol}"))
            if isinstance(node, ast.ClassDef):
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                            and item.name == symbol:
                        found.append(SymbolLocation(
                            name=symbol, kind="method", path=module.path, line=item.lineno,
                            qualified_name=f"{module.dotted}.{node.name}.{symbol}"))
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(target, ast.Name) and target.id == symbol for target in targets):
                found.append(SymbolLocation(name=symbol, kind="variable", path=module.path,
                                            line=node.lineno,
                                            qualified_name=f"{module.dotted}.{symbol}"))
    return found


def _chain(node: ast.expr) -> list[str] | None:
    """`a.b.c` as ["a", "b", "c"]; None when it does not start from a plain name."""
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if not isinstance(node, ast.Name):
        return None
    return [node.id, *reversed(parts)]


def _line(module: _Module, number: int) -> str:
    text = module.lines[number - 1].strip() if 0 < number <= len(module.lines) else ""
    return text[:LINE_TEXT]


def _uses(module: _Module, symbol: str, index: _Index, defining: dict[str, str],
          ) -> tuple[list[SymbolReference], list[SymbolReference]]:
    """This module's uses of `symbol` that resolve to a definition, and its possible ones."""
    uses: list[SymbolReference] = []
    possible: list[SymbolReference] = []
    calls = {id(node.func) for node in ast.walk(module.tree) if isinstance(node, ast.Call)}
    # Local names that stand for one of the definitions: imported ones, and the
    # defining module's own name for itself.
    local: dict[str, str] = {}
    for name, (source, attribute) in module.bound.items():
        if attribute is None:
            continue
        reached = index.resolve(source, attribute) if attribute == symbol else None
        if reached in defining:
            local[name] = defining[reached]
    if module.dotted in defining and symbol not in module.bound:
        local.setdefault(symbol, defining[module.dotted])
    # And names bound to modules, through which `module.symbol` reaches one.
    modules = {name: source for name, (source, attribute) in module.bound.items()
               if attribute is None}
    modules.update({name: f"{source}.{attribute}" for name, (source, attribute)
                    in module.bound.items() if attribute is not None and index.find(
                        f"{source}.{attribute}") is not None})

    def add(kind: str, node: ast.AST, definition: str | None) -> None:
        line = getattr(node, "lineno", 1)
        reference = SymbolReference(path=module.path, line=line, kind=kind,
                                    text=_line(module, line), definition=definition)
        (uses if definition is not None else possible).append(reference)

    for node in ast.walk(module.tree):
        if isinstance(node, ast.ImportFrom):
            source = _absolute(module, node.level, node.module)
            for alias in node.names:
                if alias.name == symbol:
                    reached = index.resolve(source, symbol)
                    if reached in defining:
                        add("import", node, defining[reached])
        elif isinstance(node, ast.Name) and node.id in local \
                and isinstance(node.ctx, ast.Load):
            add("call" if id(node) in calls else "use", node, local[node.id])
        elif isinstance(node, ast.Attribute) and node.attr == symbol \
                and isinstance(node.ctx, ast.Load):
            chain = _chain(node.value)
            through = None
            if chain is not None and chain[0] in modules:
                through = ".".join([modules[chain[0]], *chain[1:]])
            reached = index.resolve(through, symbol) if through is not None else None
            if reached in defining:
                add("call" if id(node) in calls else "use", node, defining[reached])
            elif not (chain is not None and chain[0] in modules):
                add("call" if id(node) in calls else "use", node, None)
    return uses, possible


def references(workspace: Path, symbol: str, *, folder: str | None = None,
               path: str | None = None) -> SymbolReferences:
    """Where `symbol` is defined under `folder` (or the workspace), and every use of it.

    `path` keeps only the definitions in that file: which of several
    `validate`s is meant. Methods are found where they are defined; a call
    `obj.method()` is a possible use, since what `obj` is is not known here.
    """
    if not NAME.fullmatch(symbol):
        raise ValueError(f"{symbol!r} is not a Python name")
    workspace = workspace.resolve()
    base = (workspace / folder).resolve() if folder else workspace
    if not base.is_relative_to(workspace) or not base.is_dir():
        raise ValueError(f"{folder} is not a folder in the workspace")
    paths, cut = _python_files(workspace, base)
    modules, unparsed = [], []
    for item in paths:
        parsed = _parse(workspace, item)
        if parsed is None:
            unparsed.append(item)
        else:
            modules.append(parsed)
    index = _Index(modules)
    definitions = [found for module in modules for found in _definitions(module, symbol)]
    if path is not None:
        definitions = [found for found in definitions if found.path == path]
    # A module's top-level definition is what an import of the name reaches.
    defining = {found.qualified_name.rsplit(".", 1)[0]: found.qualified_name
                for found in definitions if found.kind != "method"}
    uses: list[SymbolReference] = []
    possible: list[SymbolReference] = []
    for module in modules:
        found, maybe = _uses(module, symbol, index, defining)
        uses += found
        possible += maybe
    # A definition's own line is not a use of it.
    places = {(found.path, found.line) for found in definitions}
    uses = [use for use in uses if (use.path, use.line) not in places]
    possible = [use for use in possible if (use.path, use.line) not in places]
    cut = cut or len(uses) > MAXIMUM_USES or len(possible) > MAXIMUM_POSSIBLE
    return SymbolReferences(symbol=symbol, definitions=definitions, uses=uses[:MAXIMUM_USES],
                            possible=possible[:MAXIMUM_POSSIBLE], files_read=len(modules),
                            unparsed=unparsed[:20], cut=cut)


def said(found: SymbolReferences) -> str:
    """The answer as the loop reads it: each definition with its uses, then the possible ones."""
    lines = [(f"references of {found.symbol}: {len(found.definitions)} definition(s), "
              f"{len(found.uses)} use(s) resolved, {len(found.possible)} possible, "
              f"in {found.files_read} Python file(s)")]
    if not found.definitions:
        lines.append("no definition of this name here")
    for definition in found.definitions:
        mine = [use for use in found.uses if use.definition == definition.qualified_name]
        lines.append(f"{definition.kind} {definition.qualified_name} -- "
                     f"{definition.path}:{definition.line}"
                     + ("" if mine or definition.kind == "method" else " -- no uses found"))
        lines += [f"  {use.path}:{use.line} {use.kind}: {use.text}" for use in mine]
    if found.possible:
        lines.append(f"possible uses ({found.symbol} on an object whose type is not known "
                     f"here; a method's calls are these):")
        lines += [f"  {use.path}:{use.line} {use.kind}: {use.text}" for use in found.possible]
    if found.unparsed:
        lines.append(f"not parsed: {', '.join(found.unparsed)}")
    if found.cut:
        lines.append("cut short: more than shown; narrow it with path or a folder")
    lines.append(f"not followed: {found.not_followed}")
    return "\n".join(lines)
