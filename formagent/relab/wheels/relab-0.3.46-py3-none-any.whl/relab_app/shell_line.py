"""A command written as a shell line, run without a shell.

Models write `python -m pytest -q 2>&1 | tail -20`, `cd web && npm test`, or a
whole line in one argument, far more often than an argument list. Refused
outright, every one cost a step. A shell itself is never given the line: it
would run whatever the line says, unseen by the command policy. Instead the
line is read here into the programs it names, each judged by the policy as if
it had been given alone, and run one after another the way the line joins
them:

    a && b          b runs only if a succeeded
    a || b          b runs only if a failed
    a ; b           b runs either way
    cd dir && ...   the rest runs in dir, a workspace folder
    a 2>&1          a's errors are read with its output
    a | tail -20    a's output, cut by head, tail, grep, wc, sort or uniq --
                    done here, in Python, not by running those programs

Anything else a shell would do is refused with what to do instead: writing to
a file (`>`), reading one (`<`), command substitution, variables, running in
the background (`&`), and a pipe into any other program. Globs are not
expanded; a pattern reaches the program as written.
"""

import re
import shlex
from dataclasses import dataclass, field

from relab_app.command_policy import READING_PROGRAMS, SHELLS, _name, reading_paths

# How a shell is told to run a line: `bash -c "..."`, `cmd /c ...`, `pwsh -Command ...`.
LINE_FLAGS = {"-c", "-lc", "/c", "/C", "-Command", "-command"}
JOINS = {"&&", "||", ";"}
FILTERS = {"head", "tail", "grep", "wc", "sort", "uniq"}
MERGED = "2>&1"
PUNCTUATION = "|&;<>()"


@dataclass
class Stage:
    """One program of the line, with what joins it to the one before."""

    argv: list[str]
    join: str = ""
    # Filters its output is piped through, in order, each an argument list.
    filters: list[list[str]] = field(default_factory=list)


@dataclass
class Line:
    stages: list[Stage]
    # The workspace folder a leading `cd` moves to, as written.
    cwd: str | None = None
    # Whether errors are read with the output, as `2>&1` asks.
    merged: bool = False


def split_line(argv: list[str]) -> Line | None:
    """The line `argv` holds, or None when it is a plain argument list.

    Raises ValueError, saying what to do instead, for what is not run here.
    """
    if not argv:
        return None
    if _name(argv[0]) in SHELLS:
        if len(argv) >= 3 and argv[1] in LINE_FLAGS:
            return _parse(" ".join(argv[2:]))
        return None
    if len(argv) == 1 and re.search(r"\s", argv[0].strip()):
        return _parse(argv[0])
    if any(item in JOINS or item in {"|", MERGED} for item in argv):
        # Already split into words: the operators are words of their own.
        return _parse_words([item for item in argv if item != MERGED], MERGED in argv)
    return None


def _parse(text: str) -> Line:
    if "$(" in text or "`" in text:
        raise ValueError("variables and command substitution are not expanded here; "
                         "write the value itself")
    merged = bool(re.search(r"(?<!\S)2>&1(?!\S)", text))
    text = re.sub(r"(?<!\S)2>&1(?!\S)", " ", text)
    lexer = shlex.shlex(text, posix=True, punctuation_chars=PUNCTUATION)
    lexer.whitespace_split = True
    try:
        tokens = list(lexer)
    except ValueError as error:
        raise ValueError(f"the command line could not be read: {error}") from error
    return _parse_words(tokens, merged)


def _parse_words(tokens: list[str], merged: bool) -> Line:
    if not tokens:
        raise ValueError("an empty command line")
    stages: list[Stage] = []
    join = ""
    current: list[str] = []
    piped: list[list[str]] | None = None

    def close(next_join: str) -> None:
        nonlocal current, piped, join
        if not current:
            raise ValueError("a command line with nothing between its operators")
        if piped is not None:
            piped.append(current)
        else:
            stages.append(Stage(argv=current, join=join))
        current, piped, join = [], None, next_join

    for token in tokens:
        if token in JOINS:
            close(token)
        elif token == "|":
            if not current:
                raise ValueError("a pipe with nothing before it")
            if piped is None:
                stages.append(Stage(argv=current, join=join))
                piped = stages[-1].filters
            else:
                piped.append(current)
            current = []
        elif set(token) <= set(PUNCTUATION):
            raise ValueError(_refusal(token))
        else:
            if "$(" in token or "`" in token or re.search(r"\$\w|\$\{", token):
                raise ValueError("variables and command substitution are not expanded here; "
                                 "write the value itself")
            if not current and piped is None and re.match(r"^[A-Za-z_]\w*=", token):
                raise ValueError("setting a variable before a command is not done here; "
                                 "run the command alone")
            current.append(token)
    close("")
    for stage in stages:
        for item in stage.filters:
            if _name(item[0]) not in FILTERS:
                raise ValueError(
                    f"output is piped only into {', '.join(sorted(FILTERS))} here, not "
                    f"{item[0]!r}; run {item[0]!r} as its own step")
            filter_lines(item, "")  # its flags are checked now, before anything runs
    cwd = None
    if _name(stages[0].argv[0]) == "cd":
        first = stages.pop(0)
        if len(first.argv) != 2 or not stages or stages[0].join not in ("&&", ";"):
            raise ValueError("`cd` is taken only at the start, as `cd <folder> && <command>`")
        cwd = first.argv[1]
        stages[0].join = ""
    if any(_name(stage.argv[0]) == "cd" for stage in stages):
        raise ValueError("`cd` is taken only at the start, as `cd <folder> && <command>`")
    return Line(stages=stages, cwd=cwd, merged=merged)


def command_paths(argv: list[str]) -> list[str]:
    """The paths a command was given, as written; a leading `cd`'s folder before a relative one.

    A reading program's (`ls`, `cat`, `find`, `grep` ...) are the paths it reads.
    Another program's are its arguments written as paths -- with a "/" in them,
    `--input=/data/raw` too -- such as the folder a script is given to work on.
    Found in use (0.3.31): a model that looked at the folder a request named only
    through `ls` and its own script was held, twice, for never having read it.
    """
    try:
        line = split_line(argv)
    except ValueError:
        return []
    stages = line.stages if line is not None else [Stage(argv=list(argv))]
    found: list[str] = []
    for stage in stages:
        if not stage.argv:
            continue
        if _name(stage.argv[0]) in READING_PROGRAMS:
            given = reading_paths(stage.argv)
        else:
            values = [argument.partition("=")[2] if argument.startswith("-") else argument
                      for argument in stage.argv[1:]]
            given = [value for value in values if "/" in value.replace("\\", "/")]
        for path in given:
            path = path.replace("\\", "/")
            relative = not (path.startswith(("/", "~")) or re.match(r"^[A-Za-z]:/", path))
            if line is not None and line.cwd and relative:
                path = f"{line.cwd.rstrip('/')}/{path}"
            found.append(path)
    return found


def _refusal(token: str) -> str:
    if ">" in token:
        return ("writing a command's output to a file is not done here; the output comes "
                "back as the step's result, and write_file writes files")
    if "<" in token:
        return "reading a file into a command is not done here; give the file as an argument"
    if token == "&":
        return "a command is not run in the background this way; use start_process"
    return f"{token!r} is not taken here; run each command as its own step"


def filter_lines(argv: list[str], text: str) -> str:
    """What `head`, `tail`, `grep`, `wc`, `sort` or `uniq` would print for this input."""
    name, flags = _name(argv[0]), argv[1:]
    lines = text.splitlines()
    if name in ("head", "tail"):
        count, from_start = 10, False
        rest = list(flags)
        while rest:
            item = rest.pop(0)
            if item == "-n" and rest:
                item = rest.pop(0)
            elif item.startswith("-n"):
                item = item[2:]
            elif re.fullmatch(r"-\d+", item):
                item = item[1:]
            else:
                raise ValueError(f"{name} {item} is not taken here; use -n N")
            from_start = name == "tail" and item.startswith("+")
            if not item.lstrip("+").isdigit():
                raise ValueError(f"{name} -n takes a number, not {item!r}")
            count = int(item.lstrip("+"))
        if name == "head":
            kept = lines[:count]
        else:
            kept = lines[count - 1:] if from_start else (lines[-count:] if count else [])
        return "\n".join(kept)
    if name == "grep":
        options: set[str] = set()
        patterns: list[str] = []
        for item in flags:
            if item.startswith("-") and len(item) > 1 and not patterns:
                for letter in item[1:]:
                    if letter not in "ivncEF":
                        raise ValueError(f"grep -{letter} is not taken here (only -i -v -n -c "
                                         f"-E -F)")
                    options.add(letter)
            else:
                patterns.append(item)
        if len(patterns) != 1:
            raise ValueError("grep in a pipe takes one pattern and no files")
        try:
            pattern = re.compile(re.escape(patterns[0]) if "F" in options else patterns[0],
                                 re.IGNORECASE if "i" in options else 0)
        except re.error as error:
            raise ValueError(f"grep pattern {patterns[0]!r}: {error}") from error
        found = [(number, line) for number, line in enumerate(lines, 1)
                 if bool(pattern.search(line)) != ("v" in options)]
        if "c" in options:
            return str(len(found))
        return "\n".join(f"{number}:{line}" if "n" in options else line for number, line in found)
    if name == "wc":
        if any(item not in ("-l", "-w", "-c") for item in flags):
            raise ValueError("wc in a pipe takes -l, -w or -c")
        counts = {"-l": len(lines), "-w": len(text.split()), "-c": len(text.encode("utf-8"))}
        chosen = flags or ["-l", "-w", "-c"]
        return " ".join(str(counts[item]) for item in chosen)
    if name == "sort":
        if any(item not in ("-r", "-n", "-u") for item in flags):
            raise ValueError("sort in a pipe takes -r, -n or -u")

        def key(line: str) -> tuple[float, str]:
            number = re.match(r"\s*(-?\d+(?:\.\d+)?)", line)
            return (float(number.group(1)) if number else 0.0, line)

        kept = sorted(set(lines) if "-u" in flags else lines,
                      key=key if "-n" in flags else None, reverse="-r" in flags)
        return "\n".join(kept)
    if name == "uniq":
        if any(item != "-c" for item in flags):
            raise ValueError("uniq in a pipe takes only -c")
        runs: list[list[object]] = []
        for line in lines:
            if runs and runs[-1][1] == line:
                runs[-1][0] = int(str(runs[-1][0])) + 1
            else:
                runs.append([1, line])
        return "\n".join(f"{count:>7} {line}" if flags else str(line) for count, line in runs)
    raise ValueError(f"{name} is not a filter here")
