"""The skills this build has: existing procedures under a typed name (M7).

`docs/architecture/SKILL_MODEL.md` is the design; `relab_core.skills` the
contract. Each skill here delegates to code that already does the job and
says so (`delegates_to`); nothing is a second copy of a procedure. The set is
closed -- what this build contains, with no discovery and no loading.

A `SkillRunner` is made for one caller with the effects it permits. It
refuses a skill whose declared effect is not among them, and an input that is
not the skill's, before anything runs; and it records every invocation --
refused and failed ones too -- in `.relab/skills/invocations.jsonl`, appended
and never rewritten.
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar
from uuid import uuid4

from pydantic import Field, ValidationError

from relab_app.code_refs import references
from relab_app.command_policy import CommandClass, classify, resolve
from relab_app.lessons import LessonStore
from relab_app.memory import ResearchMemory
from relab_app.project_checks import ProjectCheck, find_checks, shown
from relab_core.contracts import Contract
from relab_core.skills import SkillDefinition, SkillEffect, SkillInvocation, SkillOutcome
from relab_workspace.patcher import Patcher
from relab_workspace.private_state import state_dir
from relab_workspace.runtime_readiness import host_python_command

if TYPE_CHECKING:
    from relab_app.coding_bench import BenchResult

INVOCATIONS = Path("skills") / "invocations.jsonl"
MAXIMUM_SAID = 400
# What a check's output keeps: its end, where a test runner says what failed.
OUTPUT_TAIL = 4000


class SkillContext:
    """Where a skill runs, for whom, and which effects that caller permits."""

    def __init__(self, workspace: Path, *, caller: str, permitted: set[SkillEffect],
                 python: str | None = None) -> None:
        self.workspace = workspace.resolve()
        self.caller = caller
        self.permitted = frozenset(permitted)
        self.python = python or host_python_command() or "python"


class Skill:
    """One skill: its definition, its input, and the work, delegated."""

    definition: ClassVar[SkillDefinition]
    Input: ClassVar[type[Contract]]

    def run(self, context: SkillContext, given: Contract) -> tuple[Contract, str]:
        """The result, and one line saying what it found or did."""
        raise NotImplementedError


class SkillFailed(Exception):
    """A skill that ran and could not do its work; the message is recorded."""


def _inside(context: SkillContext, folder: str | None) -> Path:
    """`folder` in the workspace, or the workspace; refused when it leads outside."""
    home = (context.workspace / folder).resolve() if folder else context.workspace
    if not home.is_relative_to(context.workspace):
        raise SkillFailed(f"{folder} is outside the workspace")
    if not home.is_dir():
        raise SkillFailed(f"{folder} is not a folder here")
    return home


# --- find_checks ---------------------------------------------------------------------------

class FolderInput(Contract):
    # The project's folder, relative to the workspace; none for the workspace.
    folder: str | None = Field(default=None, min_length=1, max_length=260)


class ChecksFound(Contract):
    folder: str | None
    checks: list[ProjectCheck]


class FindChecks(Skill):
    definition = SkillDefinition(
        name="find_checks", effect=SkillEffect.READ,
        summary="The commands that check a project, read from what it declares "
                "(tests folder or pytest settings, package.json scripts, go.mod, Cargo.toml)",
        delegates_to="relab_app.project_checks.find_checks")
    Input = FolderInput

    def run(self, context: SkillContext, given: Contract) -> tuple[Contract, str]:
        assert isinstance(given, FolderInput)
        _inside(context, given.folder)
        checks = find_checks(context.workspace, given.folder, context.python)
        said = ("; ".join(shown(check.argv, context.python) for check in checks)
                or "this project declares no check")
        return ChecksFound(folder=given.folder, checks=checks), said


# --- run_checks ----------------------------------------------------------------------------

class RunChecksInput(Contract):
    folder: str | None = Field(default=None, min_length=1, max_length=260)
    timeout_seconds: float = Field(default=300.0, gt=0, le=600)


class CheckRan(Contract):
    argv: list[str]
    exit_code: int | None
    timed_out: bool
    passed: bool
    output: str


class ChecksRan(Contract):
    folder: str | None
    passed: bool
    ran: list[CheckRan]


class RunChecks(Skill):
    definition = SkillDefinition(
        name="run_checks", effect=SkillEffect.MUTATE,
        summary="Run the checks a project declares, each as the command policy allows "
                "without asking, and say which passed",
        delegates_to="relab_app.project_checks.find_checks, relab_workspace.patcher.Patcher.measure")
    Input = RunChecksInput

    def run(self, context: SkillContext, given: Contract) -> tuple[Contract, str]:
        assert isinstance(given, RunChecksInput)
        home = _inside(context, given.folder)
        checks = find_checks(context.workspace, given.folder, context.python)
        if not checks:
            raise SkillFailed("this project declares no check")
        ran = []
        for check in checks:
            # Judged again here, where it runs: what was offered is not a permission.
            kind, why = classify(check.argv, context.python, home)
            command = resolve(check.argv, context.python)
            if kind is not CommandClass.RUN or command is None:
                raise SkillFailed(f"{' '.join(check.argv)} is not run here: "
                                  f"{why if kind is not CommandClass.RUN else 'not on this host'}")
            result = Patcher().measure(home, command, timeout_seconds=given.timeout_seconds)
            output = (result.stdout + ("\n" + result.stderr if result.stderr else "")).strip()
            ran.append(CheckRan(argv=check.argv, exit_code=result.exit_code,
                                timed_out=result.timed_out,
                                passed=result.exit_code == 0 and not result.timed_out,
                                output=output[-OUTPUT_TAIL:]))
        passed = all(item.passed for item in ran)
        said = ", ".join(f"{shown(item.argv, context.python)} {_verdict(item)}" for item in ran)
        return ChecksRan(folder=given.folder, passed=passed, ran=ran), said


# --- compare_benchmarks --------------------------------------------------------------------

class CompareInput(Contract):
    # A registered run's label, or a result file in the workspace.
    before: str = Field(min_length=1, max_length=260)
    after: str = Field(min_length=1, max_length=260)
    # The suite, when a label was run on more than one.
    suite: str | None = Field(default=None, min_length=1, max_length=120)


class Comparison(Contract):
    comparison: dict[str, object]
    # Why runs failed, by class, before and after.
    failures_by_class: dict[str, list[int]]


class CompareBenchmarks(Skill):
    definition = SkillDefinition(
        name="compare_benchmarks", effect=SkillEffect.READ,
        summary="Compare two benchmark runs -- registered labels or result files -- "
                "task by task, with why runs failed",
        delegates_to="relab_app.coding_bench.compare, relab_app.results_registry.ResultsRegistry")
    Input = CompareInput

    def run(self, context: SkillContext, given: Contract) -> tuple[Contract, str]:
        # Here, not at the top: the coding loop recalls through skills, and
        # the benchmark runs the coding loop.
        from relab_app.coding_bench import compare, failure

        assert isinstance(given, CompareInput)
        before = self._result(context, given.before, given.suite)
        after = self._result(context, given.after, given.suite)
        compared = compare(before, after)
        classes: dict[str, list[int]] = {}
        for index, result in enumerate((before, after)):
            for run in result.runs:
                why = failure(run)
                if why is not None:
                    classes.setdefault(why, [0, 0])[index] += 1
        rates = compared["solve_rate"]
        assert isinstance(rates, list)
        said = f"{before.label} {rates[0]} -> {after.label} {rates[1]}"
        return Comparison(comparison=compared, failures_by_class=dict(sorted(classes.items()))), said

    @staticmethod
    def _result(context: SkillContext, name: str, suite: str | None) -> "BenchResult":
        from relab_app.coding_bench import read_result
        from relab_app.results_registry import ResultsRegistry

        path = (context.workspace / name).resolve()
        if path.is_relative_to(context.workspace) and path.is_file():
            return read_result(path)
        registry = ResultsRegistry(context.workspace)
        entries = [entry for entry in registry.entries()
                   if entry.get("label") == name and (suite is None or entry.get("suite") == suite)]
        if not entries:
            raise SkillFailed(f"no registered run or result file is called {name}")
        if len(entries) > 1:
            raise SkillFailed(f"{name} was run on several suites; say which")
        result = registry.result(entries[0])
        if result is None:
            raise SkillFailed(f"the registered run {name} has lost its result file")
        return result


# --- recall --------------------------------------------------------------------------------

class RecallInput(Contract):
    text: str = Field(min_length=1, max_length=4000)
    project: str | None = Field(default=None, min_length=1, max_length=260)
    files: list[str] = Field(default_factory=list, max_length=40)
    # How many confirmed findings at most: a loop's context takes six, a
    # research planner's twelve (P4: both now recall through this skill).
    findings: int = Field(default=6, ge=1, le=12)


class Recalled(Contract):
    lessons: list[dict[str, object]]
    findings: list[dict[str, object]]


class Recall(Skill):
    definition = SkillDefinition(
        name="recall", effect=SkillEffect.READ,
        summary="What earlier work here found out by failing, and what studies established "
                "and a person confirmed, matched to a text",
        delegates_to="relab_app.lessons.LessonStore.relevant, "
                     "relab_app.memory.ResearchMemory.relevant")
    Input = RecallInput

    def run(self, context: SkillContext, given: Contract) -> tuple[Contract, str]:
        assert isinstance(given, RecallInput)
        lessons = LessonStore(context.workspace).relevant(given.text, given.project, given.files)
        findings = ResearchMemory(context.workspace).relevant(given.text, limit=given.findings)
        said = f"{len(lessons)} lesson(s), {len(findings)} confirmed finding(s)"
        return Recalled(
            lessons=[{"lesson_id": item.lesson_id, "kind": item.kind, "text": item.text,
                      "loop_id": item.loop_id} for item in lessons],
            findings=[{"memory_id": item.memory_id, "finding": item.finding,
                       "scope": item.scope, "conditions": item.conditions[:4]}
                      for item in findings]), said


# --- find_references -----------------------------------------------------------------------

class ReferencesInput(Contract):
    # A Python name: a function, a class, a method or a module-level name.
    symbol: str = Field(pattern=r"^[A-Za-z_][A-Za-z0-9_]{0,127}$")
    # Where to look, relative to the workspace; none for all of it.
    folder: str | None = Field(default=None, min_length=1, max_length=260)
    # Only the definition in this file, when several share the name.
    path: str | None = Field(default=None, min_length=1, max_length=260)


class FindReferences(Skill):
    definition = SkillDefinition(
        name="find_references", effect=SkillEffect.READ,
        summary="Where a Python name is defined and every place that uses it, from the "
                "syntax trees, imports and aliases followed",
        delegates_to="relab_app.code_refs.references")
    Input = ReferencesInput

    def run(self, context: SkillContext, given: Contract) -> tuple[Contract, str]:
        assert isinstance(given, ReferencesInput)
        _inside(context, given.folder)
        try:
            found = references(context.workspace, given.symbol, folder=given.folder,
                               path=given.path)
        except ValueError as error:
            raise SkillFailed(str(error)) from error
        said = (f"{len(found.definitions)} definition(s) of {given.symbol}, "
                f"{len(found.uses)} use(s), {len(found.possible)} possible, "
                f"in {found.files_read} file(s)")
        return found, said


SKILLS: dict[str, Skill] = {skill.definition.name: skill for skill in (
    FindChecks(), RunChecks(), CompareBenchmarks(), Recall(), FindReferences())}


def definitions() -> list[SkillDefinition]:
    return [skill.definition for skill in SKILLS.values()]


class SkillReply(Contract):
    invocation: SkillInvocation
    result: dict[str, object] | None = None


class SkillRunner:
    """Runs skills for one caller, within the effects it permits, and records each."""

    def __init__(self, context: SkillContext) -> None:
        self.context = context
        self.path = state_dir(context.workspace) / INVOCATIONS

    def invoke(self, name: str, given: dict[str, object]) -> SkillReply:
        skill = SKILLS.get(name)
        if skill is None:
            raise KeyError(f"no skill is called {name}; the skills are {', '.join(SKILLS)}")
        started = datetime.now(timezone.utc)
        effect = skill.definition.effect
        result: Contract | None = None
        if effect not in self.context.permitted:
            outcome, said = SkillOutcome.REFUSED, (
                f"{name} {effect.value}s, and this caller permits only "
                f"{', '.join(sorted(item.value for item in self.context.permitted)) or 'nothing'}")
        else:
            try:
                parsed = skill.Input.model_validate(given)
            except ValidationError as error:
                outcome, said = SkillOutcome.REFUSED, f"not an input of {name}: {_first(error)}"
            else:
                try:
                    result, said = skill.run(self.context, parsed)
                    outcome = SkillOutcome.DONE
                except SkillFailed as error:
                    outcome, said = SkillOutcome.FAILED, str(error)
        invocation = SkillInvocation(
            invocation_id=f"skill-{uuid4().hex}", skill=name, effect=effect,
            caller=self.context.caller, input=dict(given), outcome=outcome,
            said=said[:MAXIMUM_SAID], started_at=started, ended_at=datetime.now(timezone.utc))
        self._record(invocation)
        return SkillReply(invocation=invocation,
                          result=None if result is None else result.model_dump(mode="json"))

    def _record(self, invocation: SkillInvocation) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(invocation.model_dump_json() + "\n")

    def invocations(self, limit: int = 50) -> list[SkillInvocation]:
        """The latest invocations, newest last; a line that does not read is skipped."""
        try:
            lines = self.path.read_text(encoding="utf-8").splitlines()
        except FileNotFoundError:
            return []
        read = []
        for line in lines[-limit:]:
            try:
                read.append(SkillInvocation.model_validate(json.loads(line)))
            except (ValueError, ValidationError):
                continue
        return read


def _verdict(check: CheckRan) -> str:
    if check.passed:
        return "passed"
    return "timed out" if check.timed_out else f"exit {check.exit_code}"


def _first(error: ValidationError) -> str:
    detail = error.errors()[0]
    where = ".".join(str(part) for part in detail.get("loc", ())) or "input"
    return f"{where}: {detail.get('msg', 'invalid')}"
