"""What a person says to a coding loop while it runs (UX-02).

The loop runs in a process of its own; what the person says reaches it as a
line appended to the loop's steering file, which the loop reads at the end of
each turn. A file, not a message to a process: it survives the editor being
restarted, and the loop's record says when each line was read.
"""

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from relab_core.coding_loop import SteeringInstruction
from relab_workspace.private_state import private_folder

LOOP_ID = re.compile(r"^loop-[0-9a-f]{32}$")


def steering_path(workspace: Path, loop_id: str) -> Path:
    if not LOOP_ID.fullmatch(loop_id):
        raise ValueError(f"{loop_id!r} is not a coding loop's id")
    # What the person said: kept with their own records (0.2.62).
    return private_folder(workspace, "coding_loops") / f"{loop_id}.steer.jsonl"


def steer(workspace: Path, loop_id: str, instruction: str) -> SteeringInstruction:
    """Say `instruction` to the loop: appended, for it to read at its next turn's end."""
    said = SteeringInstruction(steering_id=f"steer-{uuid4().hex}", instruction=instruction.strip(),
                               created_at=datetime.now(timezone.utc))
    path = steering_path(workspace, loop_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as file:
        file.write(said.model_dump_json() + "\n")
    return said


def said_to(workspace: Path, loop_id: str) -> list[SteeringInstruction]:
    """Everything said to the loop and not withdrawn, oldest first; a line cut short or
    unreadable is passed over."""
    path = steering_path(workspace, loop_id)
    if not path.is_file():
        return []
    found = []
    withdrawn: set[str] = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            item = json.loads(line)
            if isinstance(item, dict) and isinstance(item.get("withdrawn"), str):
                withdrawn.add(item["withdrawn"])
                continue
            found.append(SteeringInstruction.model_validate(item))
        except (ValueError, TypeError):
            continue
    return [item for item in found if item.steering_id not in withdrawn]


def withdraw(workspace: Path, loop_id: str, steering_id: str, taken: set[str]) -> bool:
    """Take back something said before the loop read it; whether it was still unread.

    Asked for in use (0.2.37): a direction typed while a loop worked could not
    be taken back. Withdrawn by a line of its own, appended like the rest --
    the loop may be reading the file at the same moment, and a file only ever
    appended to is never read half-rewritten. `taken`: the ids the loop's
    record says it has read; one of those is past taking back.
    """
    if steering_id in taken or all(item.steering_id != steering_id
                                   for item in said_to(workspace, loop_id)):
        return False
    with steering_path(workspace, loop_id).open("a", encoding="utf-8") as file:
        file.write(json.dumps({"withdrawn": steering_id}) + "\n")
    return True
