"""Each skill's own evaluation: cases it must get right, run without a model.

A skill is worth keeping when it does its one job, and a case says what that
is in a form that can fail: a project laid out on disk and the checks it
declares, a passing and a failing test run, two benchmark results and their
difference, a lesson that must be recalled for a matching request and not for
another. Each case runs in its own temporary workspace through a
`SkillRunner`, as any caller would, so the effect rules and the record are
exercised too. `relab skill eval` runs them.
"""

import json
import sys
import tempfile
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path

from relab_app.coding_bench import BenchResult, BenchRun
from relab_app.lessons import Lesson, LessonStore
from relab_app.skills import SKILLS, SkillContext, SkillReply, SkillRunner
from relab_core.contracts import Contract
from relab_core.skills import SkillEffect, SkillOutcome

EVERYTHING = {SkillEffect.READ, SkillEffect.RECORD, SkillEffect.MUTATE}


class CaseResult(Contract):
    skill: str
    case: str
    passed: bool
    said: str


Case = Callable[[Path], tuple[bool, str]]


def _runner(workspace: Path, permitted: set[SkillEffect] | None = None) -> SkillRunner:
    return SkillRunner(SkillContext(workspace, caller="evaluation",
                                    permitted=EVERYTHING if permitted is None else permitted,
                                    python=sys.executable))


def _write(root: Path, files: dict[str, str]) -> None:
    for name, text in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")


def _checks(reply: SkillReply) -> list[str]:
    found = (reply.result or {}).get("checks") or []
    assert isinstance(found, list)
    return [" ".join(item["argv"][1:]) if item["argv"][0] == sys.executable
            else " ".join(item["argv"]) for item in found]


def _count(reply: SkillReply, key: str) -> int:
    found = (reply.result or {}).get(key)
    return len(found) if isinstance(found, list) else 0


def _expect(reply: SkillReply, wanted: object, got: object) -> tuple[bool, str]:
    return wanted == got, f"wanted {wanted}, got {got} ({reply.invocation.said})"


# --- find_checks ---------------------------------------------------------------------------

def python_tests_folder(root: Path) -> tuple[bool, str]:
    _write(root, {"app/calc.py": "def add(a, b):\n    return a + b\n",
                  "app/tests/test_calc.py": "def test_add():\n    pass\n"})
    reply = _runner(root).invoke("find_checks", {"folder": "app"})
    return _expect(reply, ["-m pytest -q"], _checks(reply))


def pyproject_tools(root: Path) -> tuple[bool, str]:
    _write(root, {"pyproject.toml": "[tool.pytest.ini_options]\naddopts = '-q'\n\n"
                                    "[tool.ruff]\nline-length = 100\n"})
    reply = _runner(root).invoke("find_checks", {})
    return _expect(reply, ["-m pytest -q", "-m ruff check ."], _checks(reply))


def node_scripts_without_placeholder(root: Path) -> tuple[bool, str]:
    _write(root, {"web/package.json": json.dumps({"scripts": {
        "test": 'echo "Error: no test specified" && exit 1', "lint": "eslint .",
        "build": "tsc"}}),
        "web/test/a.test.js": "// node tests, not Python\n"})
    reply = _runner(root).invoke("find_checks", {"folder": "web"})
    return _expect(reply, ["npm run lint"], _checks(reply))


def nothing_declared(root: Path) -> tuple[bool, str]:
    _write(root, {"script.py": "print('hello')\n"})
    reply = _runner(root).invoke("find_checks", {})
    return _expect(reply, [], _checks(reply))


def outside_the_workspace(root: Path) -> tuple[bool, str]:
    (root / "inner").mkdir()
    reply = _runner(root / "inner").invoke("find_checks", {"folder": ".."})
    return _expect(reply, SkillOutcome.FAILED, reply.invocation.outcome)


# --- run_checks ----------------------------------------------------------------------------

def passing_tests(root: Path) -> tuple[bool, str]:
    _write(root, {"calc.py": "def add(a, b):\n    return a + b\n",
                  "tests/test_calc.py": "from calc import add\n\n"
                                        "def test_add():\n    assert add(2, 3) == 5\n",
                  "tests/conftest.py": "import sys, pathlib\n"
                                       "sys.path.insert(0, str(pathlib.Path(__file__).parents[1]))\n"})
    reply = _runner(root).invoke("run_checks", {"timeout_seconds": 120})
    return _expect(reply, True, (reply.result or {}).get("passed"))


def failing_tests(root: Path) -> tuple[bool, str]:
    _write(root, {"calc.py": "def add(a, b):\n    return a - b\n",
                  "tests/test_calc.py": "from calc import add\n\n"
                                        "def test_add():\n    assert add(2, 3) == 5\n",
                  "tests/conftest.py": "import sys, pathlib\n"
                                       "sys.path.insert(0, str(pathlib.Path(__file__).parents[1]))\n"})
    reply = _runner(root).invoke("run_checks", {"timeout_seconds": 120})
    ran = (reply.result or {}).get("ran") or [{}]
    assert isinstance(ran, list)
    return _expect(reply, (False, 1), ((reply.result or {}).get("passed"), ran[0].get("exit_code")))


def refused_where_only_reading(root: Path) -> tuple[bool, str]:
    _write(root, {"tests/test_x.py": "def test_x():\n    raise SystemExit('ran')\n"})
    reply = _runner(root, {SkillEffect.READ}).invoke("run_checks", {})
    return _expect(reply, (SkillOutcome.REFUSED, None),
                   (reply.invocation.outcome, reply.result))


# --- compare_benchmarks --------------------------------------------------------------------

def _run(task: str, solved: bool, ended: str | None = None) -> BenchRun:
    return BenchRun(task=task, kind="exercise", repeat=1, solved=solved,
                    outcome="finished" if ended is None else "failed", steps=3,
                    refused_steps=0, legs=1, model_calls=3, prompt_characters=10,
                    reply_characters=10, retries=0, seconds=1.0,
                    check_exit=0 if solved else 1, ended=ended)


def two_results(root: Path) -> tuple[bool, str]:
    now = datetime.now(timezone.utc)
    before = BenchResult(label="before", started_at=now, runs=[
        _run("a", True), _run("b", False),
        _run("c", False, "the model could not be reached: ModelTransportError (timeout)")])
    after = BenchResult(label="after", started_at=now, runs=[
        _run("a", True), _run("b", True), _run("c", False)])
    (root / "before.json").write_text(before.model_dump_json(), encoding="utf-8")
    (root / "after.json").write_text(after.model_dump_json(), encoding="utf-8")
    reply = _runner(root).invoke("compare_benchmarks", {"before": "before.json",
                                                        "after": "after.json"})
    result = reply.result or {}
    comparison = result.get("comparison") or {}
    assert isinstance(comparison, dict)
    return _expect(reply, ([0.333, 0.667], {"transport": [1, 0], "wrong_answer": [1, 1]}),
                   (comparison.get("solve_rate"), result.get("failures_by_class")))


def unknown_label(root: Path) -> tuple[bool, str]:
    reply = _runner(root).invoke("compare_benchmarks", {"before": "nothing", "after": "else"})
    return _expect(reply, SkillOutcome.FAILED, reply.invocation.outcome)


# --- recall --------------------------------------------------------------------------------

def _lesson(text: str, words: list[str]) -> Lesson:
    return Lesson(lesson_id="lesson-0123456789abcdef", kind="fixed_failure", text=text,
                  loop_id="loop-" + "0" * 32, steps=[1], project=None, files=["pager.py"],
                  words=words, created_at=datetime.now(timezone.utc))


def matching_lesson(root: Path) -> tuple[bool, str]:
    LessonStore(root).add([_lesson("paginate() is off by one at the last page; "
                                   "range(start, end + 1) fixed it",
                                   ["paginate", "pagination", "last", "page"])])
    found = _runner(root).invoke("recall", {"text": "fix pagination on the last page"})
    other = _runner(root).invoke("recall", {"text": "add a json flag to the cli"})
    counts = (_count(found, "lessons"), _count(other, "lessons"))
    return _expect(found, (1, 0), counts)


# --- find_references -----------------------------------------------------------------------

def _places(reply: SkillReply, key: str) -> list[tuple[str, int, str]]:
    found = (reply.result or {}).get(key) or []
    assert isinstance(found, list)
    return [(item["path"], item["line"], item["kind"]) for item in found]


def same_name_elsewhere(root: Path) -> tuple[bool, str]:
    """Two `validate`s; the one imported under an alias is the one used, the other unused."""
    _write(root, {"accounts/__init__.py": "", "accounts/validation.py": "def validate(a):\n    return a\n",
                  "orders/__init__.py": "", "orders/validation.py": "def validate(o):\n    return o\n",
                  "checkout.py": "from orders.validation import validate as check\n\n\n"
                                 "def place(order):\n    return check(order)\n"})
    reply = _runner(root, {SkillEffect.READ}).invoke("find_references", {"symbol": "validate"})
    found = (reply.result or {}).get("uses") or []
    assert isinstance(found, list)
    uses = [(item["path"], item["line"], item["kind"], item["definition"]) for item in found]
    return _expect(reply, [("checkout.py", 1, "import", "orders.validation.validate"),
                           ("checkout.py", 5, "call", "orders.validation.validate")], uses)


def through_the_module(root: Path) -> tuple[bool, str]:
    """`module.name`, with the module imported from its package or under an alias."""
    _write(root, {"pkg/__init__.py": "", "pkg/util.py": "def helper():\n    return 1\n",
                  "a.py": "from pkg import util\n\nutil.helper()\n",
                  "b.py": "import pkg.util as u\n\nu.helper()\n"})
    reply = _runner(root, {SkillEffect.READ}).invoke("find_references", {"symbol": "helper"})
    return _expect(reply, [("a.py", 3, "call"), ("b.py", 3, "call")], _places(reply, "uses"))


def a_method_is_a_possible_use(root: Path) -> tuple[bool, str]:
    """What `obj` is cannot be known without running: its `.render()` is possible, not resolved."""
    _write(root, {"channels.py": "class Sms:\n    def render(self, text):\n        return [text]\n",
                  "send.py": "def send(channel, text):\n    return channel.render(text)\n"})
    reply = _runner(root, {SkillEffect.READ}).invoke("find_references", {"symbol": "render"})
    got = (_count(reply, "definitions"), _places(reply, "uses"), _places(reply, "possible"))
    return _expect(reply, (1, [], [("send.py", 2, "call")]), got)


def not_a_name(root: Path) -> tuple[bool, str]:
    reply = _runner(root, {SkillEffect.READ}).invoke("find_references", {"symbol": "1 + 1"})
    return _expect(reply, SkillOutcome.REFUSED, reply.invocation.outcome)


CASES: dict[str, list[Case]] = {
    "find_checks": [python_tests_folder, pyproject_tools, node_scripts_without_placeholder,
                    nothing_declared, outside_the_workspace],
    "run_checks": [passing_tests, failing_tests, refused_where_only_reading],
    "compare_benchmarks": [two_results, unknown_label],
    "recall": [matching_lesson],
    "find_references": [same_name_elsewhere, through_the_module, a_method_is_a_possible_use,
                        not_a_name],
}


def evaluate(only: str | None = None) -> list[CaseResult]:
    """Every case of every skill, or of one; each in a workspace of its own."""
    if only is not None and only not in SKILLS:
        raise KeyError(f"no skill is called {only}; the skills are {', '.join(SKILLS)}")
    results = []
    for skill, cases in CASES.items():
        if only is not None and skill != only:
            continue
        for case in cases:
            with tempfile.TemporaryDirectory(prefix="relab-skill-") as scratch:
                try:
                    passed, said = case(Path(scratch))
                except Exception as error:  # noqa: BLE001 -- a case that breaks fails, said why
                    passed, said = False, f"{type(error).__name__}: {error}"
            results.append(CaseResult(skill=skill, case=case.__name__, passed=passed,
                                      said=said[:400]))
    return results
