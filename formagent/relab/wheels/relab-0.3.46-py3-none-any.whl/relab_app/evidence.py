"""A concluded study's evidence package, built from its records (M8a).

Derived, not stored: a conclusion freezes the assessment it was taken on, and
the interpretation reads only that, so the same conclusion always gives the
same package -- after a restart too. Reopening a study sets its conclusion
aside; concluding it again gives a package with a new id, and the old one is
still built from that event's snapshot. Nothing here calls a model, and
nothing is recorded. See docs/architecture/EVIDENCE_HANDOFF.md.
"""

from pathlib import Path

from relab_app.interpretation import SessionInterpreter
from relab_app.sessions import ResearchSessionService
from relab_core.evaluation import DecisionSupport
from relab_core.evidence import (
    MAXIMUM_PACKAGE_CITATIONS,
    MAXIMUM_PACKAGE_CLAIMS,
    MAXIMUM_PACKAGE_LINES,
    MAXIMUM_PACKAGE_METRICS,
    EvidenceClaim,
    EvidenceMetric,
    EvidenceOutcome,
    EvidencePackage,
)
from relab_core.research import ResearchDecision, ResearchSession, ResearchSessionAssessment
from relab_core.sensitivity import SensitivityStatus

OUTCOMES = {
    ResearchDecision.ACCEPTED: EvidenceOutcome.SUPPORTS,
    ResearchDecision.REJECTED: EvidenceOutcome.REFUTES,
    ResearchDecision.INCONCLUSIVE: EvidenceOutcome.INCONCLUSIVE,
}


def research_evidence(workspace: Path, session_id: str,
                      event_sequence: int | None = None) -> EvidencePackage:
    """The evidence package of `session_id`'s conclusion -- the latest, or the one at `event_sequence`.

    Refused, as a ValueError, for a study not concluded or abandoned: a package
    is evidence a conclusion gate let through, never a draft of one.
    """
    service = ResearchSessionService(workspace)
    if event_sequence is None:
        session = service.store.latest(session_id).snapshot
    else:
        session = _concluded_at(service, session_id, event_sequence)
    conclusion = session.conclusion
    if conclusion is None:
        raise ValueError(f"{session_id} has not concluded: a package is built from a conclusion")
    outcome = OUTCOMES.get(conclusion.decision)
    if outcome is None or conclusion.assessment is None:
        raise ValueError(f"{session_id} was abandoned: it concluded nothing to hand on")
    assessment = conclusion.assessment
    interpretation = SessionInterpreter(workspace).interpret(session_id)
    pinned = _pinned(assessment)
    claims = []
    if event_sequence is None or event_sequence == interpretation.event_sequence:
        for claim in interpretation.claims[:MAXIMUM_PACKAGE_CLAIMS]:
            for item in claim.citations:
                if (item.run_id, item.event_sequence) not in pinned:
                    raise ValueError(f"a claim cites {item.run_id}@{item.event_sequence}, "
                                     "which this study's conclusion did not measure")
            claims.append(EvidenceClaim(statement=claim.statement, citations=claim.citations))
    cited = list({(item.run_id, item.event_sequence): item
                  for claim in claims for item in claim.citations}.values())
    return EvidencePackage(
        package_id=f"{session_id}/evidence-{conclusion.event_sequence}",
        session_id=session_id, concluded_at_sequence=conclusion.event_sequence,
        objective=session.objective, rationale=conclusion.rationale,
        decision=conclusion.decision.value, outcome=outcome,
        evidence_support=assessment.decision_support.value,
        claims=claims, metrics=_metrics(session, assessment)[:MAXIMUM_PACKAGE_METRICS],
        conditions=_conditions(session, assessment, interpretation.scope_facts),
        limitations=_limitations(service, session_id, conclusion.decision, assessment,
                                 interpretation.limits, interpretation.refused,
                                 interpretation.reason),
        citations=cited[:MAXIMUM_PACKAGE_CITATIONS])


def resolves(workspace: Path, package: EvidencePackage) -> list[str]:
    """What in `package` does not resolve to the study it names: empty when it all does.

    A package handed in from outside -- a file, a message -- is checked against
    the records before anything uses it: the conclusion it names, and every run
    event it cites among those that conclusion measured.
    """
    try:
        built = research_evidence(workspace, package.session_id, package.concluded_at_sequence)
    except (ValueError, LookupError) as error:
        return [str(error)]
    conclusion = _concluded_at(ResearchSessionService(workspace), package.session_id,
                               package.concluded_at_sequence).conclusion
    assessment = conclusion.assessment if conclusion is not None else None
    pinned = _pinned(assessment) if assessment is not None else set()
    wrong = [f"{item.run_id}@{item.event_sequence} is not a run event this study measured"
             for item in package.citations if (item.run_id, item.event_sequence) not in pinned]
    if package.outcome is not built.outcome:
        wrong.append(f"the study concluded {built.outcome.value}, not {package.outcome.value}")
    return wrong


def _concluded_at(service: ResearchSessionService, session_id: str,
                  sequence: int) -> ResearchSession:
    """The snapshot holding the conclusion taken at event `sequence` -- the newest, if reopened."""
    for event in reversed(service.store.events(session_id)):
        conclusion = event.snapshot.conclusion
        if conclusion is not None and conclusion.event_sequence == sequence:
            return event.snapshot
    raise ValueError(f"{session_id} has no conclusion taken at event {sequence}")


def _pinned(assessment: ResearchSessionAssessment) -> set[tuple[str, int]]:
    """The run events a conclusion's assessment measured: usable runs and what it compared."""
    found = {(run.run_id, run.event_sequence) for arm in assessment.readiness.arms
             for run in arm.runs if run.usable}
    for comparison in assessment.comparisons:
        found |= {(comparison.candidate.run_id, comparison.candidate.event_sequence),
                  (comparison.baseline.run_id, comparison.baseline.event_sequence)}
    for arm in assessment.arms:
        if arm.repeatability is not None:
            found |= {(sample.run_id, sample.event_sequence)
                      for sample in arm.repeatability.samples}
    return found


def _metrics(session: ResearchSession, assessment: ResearchSessionAssessment) -> list[EvidenceMetric]:
    plan = session.plan
    usable = {arm.arm: arm.usable for arm in assessment.readiness.arms}
    candidate = usable.get(plan.candidate_arm or "", 0) if plan is not None else 0
    baseline = usable.get(plan.baseline_arm or "", 0) if plan is not None else 0
    found = []
    for comparison in assessment.comparisons:
        directions = {rule.name: rule.direction.value for rule in comparison.registry.rules}
        for item in comparison.items:
            found.append(EvidenceMetric(
                name=item.name, direction=directions.get(item.name),
                candidate=item.candidate_value, baseline=item.baseline_value, delta=item.delta,
                passed=item.passed, candidate_runs=candidate, baseline_runs=baseline))
    return found


def _conditions(session: ResearchSession, assessment: ResearchSessionAssessment,
                scope_facts: list[str]) -> list[str]:
    found = list(scope_facts)
    plan = session.plan
    if plan is not None and plan.expected_model:
        found.append(f"model: {plan.expected_model}")
    found += [f"{name} took one value in every run of every arm"
              for name in assessment.identical_everywhere]
    return list(dict.fromkeys(found))[:MAXIMUM_PACKAGE_LINES]


def _limitations(service: ResearchSessionService, session_id: str, decision: ResearchDecision,
                 assessment: ResearchSessionAssessment, limits: list[str], refused: bool,
                 reason: str) -> list[str]:
    found = list(limits)
    if refused:
        found.append(f"nothing here may be carried forward: {reason}")
    if decision is ResearchDecision.REJECTED \
            and assessment.decision_support is not DecisionSupport.SUPPORTS_REJECTION:
        # Rejecting is a person's choice with no evidence gate; said beside it.
        found.append(f"rejected by a person; the evidence itself said "
                     f"{assessment.decision_support.value}")
    for arm in assessment.readiness.arms:
        if arm.usable < arm.required:
            found.append(f"arm {arm.arm}: {arm.usable} usable run(s) of {arm.required} required")
    if assessment.unpaired_run_ids:
        found.append(f"{len(assessment.unpaired_run_ids)} run(s) had no pair to compare with")
    try:
        sensitivity = service.sensitivity(session_id)
    except (ValueError, LookupError):
        sensitivity = None
    if sensitivity is not None and sensitivity.status is not SensitivityStatus.DEMONSTRATED:
        # Not frozen in the conclusion: said as it stands when the package is built.
        found.append(f"whether the measurement could detect a change: "
                     f"{sensitivity.status.value} (as of building this package)")
    return list(dict.fromkeys(found))[:MAXIMUM_PACKAGE_LINES]
