"""Reading every session's next action into one ordered list.

This is the read a conversation makes when it opens: one call instead of one per
session, and the ordering decided here rather than by whichever surface happens
to be rendering. Two clients ordering the same workspace differently would be two
answers to "what should I do now".
"""

from pathlib import Path

from relab_app.client import WorkspaceClient
from relab_app.next_action import NextActions
from relab_core.agenda import AGENDA_ORDER, MAXIMUM_ENTRIES, AgendaEntry, WorkspaceAgenda
from relab_core.turns import TurnState
from relab_research.next_action import AmendmentAdvisor


class WorkspaceAgendaReader:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.client = WorkspaceClient(self.workspace)
        self.actions = NextActions(self.workspace)

    def agenda(
        self, *, attempts_per_slot: int = 1, advisor: AmendmentAdvisor | None = None,
    ) -> WorkspaceAgenda:
        """Where every session stands. This performs nothing and records nothing."""
        entries = []
        for summary in self.client.overview().sessions[:MAXIMUM_ENTRIES]:
            entries.append(self._entry(summary.session_id, summary.objective,
                                       attempts_per_slot, advisor))
        entries.sort(key=_place)
        return WorkspaceAgenda(
            workspace=str(self.workspace), entries=entries,
            awaiting_human=sum(1 for item in entries
                               if item.state is TurnState.AWAITING_HUMAN),
            unreadable=sum(1 for item in entries if item.action is None),
        )

    def _entry(
        self, session_id: str, objective: str, attempts_per_slot: int,
        advisor: AmendmentAdvisor | None,
    ) -> AgendaEntry:
        try:
            action = self.actions.decide(
                session_id, attempts_per_slot=attempts_per_slot, advisor=advisor)
        except (ValueError, LookupError) as error:
            # One session nobody can read must not hide every other one. It is
            # listed with its reason, which is what a person can act on.
            return AgendaEntry(session_id=session_id, objective=objective,
                               unreadable=f"{type(error).__name__}: {error}")
        return AgendaEntry(session_id=session_id, objective=objective, action=action)


def _place(entry: AgendaEntry) -> tuple[int, str]:
    """Most in need of someone first, then by id so the order is total.

    A session nobody could read sorts with the ones waiting on a person: not
    knowing where something stands is itself something a person has to look at.
    """
    state = entry.state
    rank = AGENDA_ORDER.index(TurnState.AWAITING_HUMAN) if state is None \
        else AGENDA_ORDER.index(state)
    return rank, entry.session_id
