"""What a task produced, looked at before it is called finished (0.2.80).

Found comparing ReLab with Cline on DART report summaries: ReLab's runs passed
their tests and finished, while most fields of the reports they wrote said
"없음" -- the extraction had fallen through to its default, and nothing looked.
And an analysis of those reports stated shares ("80-90% complete") having run
nothing, where the other agent quoted the values it read.

Two checks, each said once, by rule and with no model call:

- `hollow_outputs`: the text files written in the task's folder while it ran
  (by its own writes or its programs), and how many of their values are a
  placeholder for nothing found. Many, and it is sent back to find out why.
- `unmeasured_shares`: an answer stating several percentages when nothing was
  run, sent back to count them, quote them, or say they are estimates.
- `fixed_addresses` (0.2.85): code this task wrote naming a service's address
  in a constant, where people running it elsewhere cannot change it -- seen
  next to Cline's `--api-url`, ReLab's `VLM_BASE_URL = "http://..."`.
- `copied_summaries` (0.2.84): asked for a summary, the reports it wrote
  repeat, line for line, a larger text of the same task -- the pages read, a
  dump of them. Seen with 0.2.80: no field said "없음" any more, because the
  source had been pasted into them.
- `rule_made_summaries` (0.2.87): asked for a summary made with a model, the
  code this task wrote asks the model only to read. Seen with 0.2.86 on the
  DART task: each page went to the VLM to be transcribed, and the report was
  then filled by keyword lists over the transcript -- "회사명 미상", the same
  sentence under two headings, "페이지별 추출 완료" for the sources. And with
  0.2.87, the summary prompts kept in settings.py and read nowhere: a prompt
  counts when it is used.
- `unused_settings` (0.2.88): a config module this task wrote holds settings
  no code reads -- with 0.2.87, the prompts and BATCH_SIZE = 4 next to code
  sending one page at a time.
"""

import ast
import csv
import io
import json
import re
from pathlib import Path

from relab_app.ablation import advising, without
from relab_core.coding_loop import CodingLoop, LoopActionKind

# A value that says nothing was found. Matched whole, after trimming.
PLACEHOLDER = re.compile(
    r"^(?:없음|정보\s*없음|해당\s*없음|자료\s*없음|미기재|미확인|확인\s*불가|추출\s*실패|알\s*수\s*없음"
    r"|n/?a|none|null|nil|unknown|not\s+(?:found|available|specified)|tbd|-|—|–|\?)$",
    re.IGNORECASE)
OUTPUT_SUFFIXES = frozenset({".md", ".markdown", ".txt", ".json", ".csv", ".tsv", ".html", ".htm"})
SKIPPED = frozenset({".git", ".relab", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv",
                     ".mypy_cache", ".pytest_cache", ".ruff_cache", ".tox", "dist", "build"})
# How much is looked at: paths walked, files read, and bytes of each.
MAXIMUM_WALKED = 5000
MAXIMUM_OUTPUTS = 80
MAXIMUM_BYTES = 256 * 1024
# Empty values, at least this many and at least this share of all, to send it back.
MINIMUM_EMPTY = 10
EMPTY_SHARE = 0.3
# A summary that already says the outputs are not complete.
SAID_INCOMPLETE = re.compile(r"not complete|incomplete|partly empty|미완|일부만|비어\s*있|채우지\s*못",
                             re.IGNORECASE)
# Percentages in an answer, and the words that mark them as estimates.
PERCENT = re.compile(r"(?<![\w.])\d{1,3}(?:\.\d+)?\s*(?:[-~–]\s*\d{1,3}(?:\.\d+)?\s*)?%")
ESTIMATED = re.compile(r"estimate|approximate|roughly|추정|대략|어림|짐작", re.IGNORECASE)
MINIMUM_SHARES = 3
# A request that asks for a summary, in the words people use for one.
SUMMARY_ASKED = re.compile(r"요약|간추|summar|digest|condense|\bbrief\b|\babstract\b", re.IGNORECASE)
# A folder, file or name in the request -- dart_summary/, summarize.py -- is not
# the request asking for a summary (0.2.87).
NAMED_THING = re.compile(r"\S*[/\\_]\S*|\S+\.(?:py|md|txt|json|csv|pdf|ya?ml)\b", re.IGNORECASE)


def asks_summary(request: str) -> bool:
    """Whether the request asks for a summary, in its words rather than in names it gives."""
    return bool(SUMMARY_ASKED.search(NAMED_THING.sub(" ", request)))
# Lines long enough to say something, compared whole after trimming spaces.
COPIED_LINE = 30
# A report repeating at least this share of its long lines from a text at least
# twice its size; with at least this many long lines among the reports.
COPIED_SHARE = 0.5
MINIMUM_LINES = 10
SOURCE_RATIO = 2


def values(text: str, suffix: str) -> list[str]:
    """The values a written file holds, as a person would read its fields."""
    if suffix == ".json":
        try:
            return [str(item) for item in _leaves(json.loads(text))]
        except ValueError:
            return []
    if suffix in (".csv", ".tsv"):
        rows = list(csv.reader(io.StringIO(text), delimiter="\t" if suffix == ".tsv" else ","))
        return [cell for row in rows[1:] for cell in row]
    found: list[str] = []
    lines = [re.sub(r"<[^>]+>", " ", line).strip() for line in text.splitlines()]
    for index, stripped in enumerate(lines):
        if stripped.startswith("|") and stripped.endswith("|") and stripped.count("|") >= 3:
            cells = [cell.strip() for cell in stripped.strip("|").split("|")]
            if _rule_row(cells):
                continue
            following = lines[index + 1] if index + 1 < len(lines) else ""
            if following.startswith("|") and _rule_row([cell.strip() for cell in following.strip("|").split("|")]):
                # The header: it names the columns, it holds no values.
                continue
            # A table's first column names the row; the rest are its values.
            found += cells[1:]
            continue
        held = re.match(r"^(?:[-*+]\s+|\d+[.)]\s+)?(?:\*\*)?([^:：|]{1,60}?)(?:\*\*)?\s*[:：]\s*(.*)$", stripped)
        if held is not None and not held.group(1).strip().startswith(("http", "#")):
            found.append(held.group(2).strip().strip("*").strip())
    return found


def _rule_row(cells: list[str]) -> bool:
    """A markdown table's line under its header: `|---|:--:|`."""
    return any(cells) and all(re.fullmatch(r":?-{2,}:?", cell) for cell in cells if cell)


def _leaves(value: object) -> list[object]:
    if isinstance(value, dict):
        return [leaf for item in value.values() for leaf in _leaves(item)]
    if isinstance(value, list):
        return [leaf for item in value for leaf in _leaves(item)]
    return ["null" if value is None else value]


def _empty(value: str) -> bool:
    return value == "" or PLACEHOLDER.fullmatch(value.strip().strip("\"'`")) is not None


def written_outputs(root: Path, since: float) -> list[Path]:
    """Text files under `root` changed at or after `since`, newest first; bounded."""
    found: list[tuple[float, Path]] = []
    walked = 0
    stack = [root]
    while stack and walked < MAXIMUM_WALKED:
        folder = stack.pop()
        try:
            entries = list(folder.iterdir())
        except OSError:
            continue
        for entry in entries:
            walked += 1
            if entry.is_symlink():
                continue
            if entry.is_dir():
                if entry.name not in SKIPPED and not entry.name.startswith("."):
                    stack.append(entry)
                continue
            if entry.suffix.lower() not in OUTPUT_SUFFIXES:
                continue
            try:
                changed = entry.stat().st_mtime
            except OSError:
                continue
            if changed >= since:
                found.append((changed, entry))
    found.sort(key=lambda pair: pair[0], reverse=True)
    return [path for _, path in found[:MAXIMUM_OUTPUTS]]


def hollow_outputs(workspace: Path, loop: CodingLoop, summary: str = "") -> str | None:
    """Why not to finish yet: what the task wrote is mostly placeholders for nothing found."""
    if without("hollow-outputs"):
        return None
    if loop.helper_of is not None or SAID_INCOMPLETE.search(summary):
        return None
    root = workspace.joinpath(*loop.scope.split("/")) if loop.scope else workspace
    if not root.is_dir():
        return None
    total = empty = 0
    by_file: list[tuple[int, int, str]] = []
    for path in written_outputs(root, loop.started_at.timestamp() - 1):
        try:
            with path.open("rb") as stream:
                text = stream.read(MAXIMUM_BYTES).decode("utf-8", errors="replace")
        except OSError:
            continue
        held = values(text, path.suffix.lower())
        missing = sum(1 for value in held if _empty(value))
        if held:
            total += len(held)
            empty += missing
            if missing:
                by_file.append((missing, len(held), path.relative_to(workspace).as_posix()))
    if empty < MINIMUM_EMPTY or empty < EMPTY_SHARE * total:
        return None
    by_file.sort(reverse=True)
    worst = ", ".join(f"{name} ({missing}/{held})" for missing, held, name in by_file[:3])
    return (f"not finished: the outputs written while this task ran leave many fields empty -- "
            f"{empty} of {total} values ({round(100 * empty / total)}%) say 없음, N/A or the like, in "
            f"{len(by_file)} file(s); most in {worst}. Open a few, and the inputs they came from, and "
            f"find why: a method that misses what is there, a parse that falls through to its "
            f"default. Fix that and run it again -- with what the field asks for, not the source "
            f"text pasted into it; or, if the inputs truly lack them, finish with a summary that "
            f"starts \"Not complete:\" and says which fields and why")


def _long_lines(text: str) -> list[str]:
    lines = []
    for line in text.splitlines():
        trimmed = " ".join(re.sub(r"^[\s#>*|+-]+|[\s|*]+$", "", line).split())
        if len(trimmed) >= COPIED_LINE:
            lines.append(trimmed)
    return lines


def copied_summaries(workspace: Path, loop: CodingLoop, request: str, summary: str = "") -> str | None:
    """Why not to finish yet: asked for a summary, the reports repeat their sources line for line."""
    if without("copied-summaries"):
        return None
    if loop.helper_of is not None or not asks_summary(request) or SAID_INCOMPLETE.search(summary):
        return None
    root = workspace.joinpath(*loop.scope.split("/")) if loop.scope else workspace
    if not root.is_dir():
        return None
    texts: dict[str, tuple[int, list[str], float]] = {}
    for path in written_outputs(root, loop.started_at.timestamp() - 1):
        try:
            with path.open("rb") as stream:
                text = stream.read(MAXIMUM_BYTES).decode("utf-8", errors="replace")
        except OSError:
            continue
        try:
            changed = path.stat().st_mtime
        except OSError:
            continue
        texts[path.relative_to(workspace).as_posix()] = (len(text), _long_lines(text), changed)
    total = copied = 0
    worst: list[tuple[int, int, str, str]] = []
    for name, (size, lines, changed) in texts.items():
        # A source is a larger text of the same task, written no later: what the report was
        # made from -- not a final report that later gathered this one's lines.
        sources = [(other, set(other_lines)) for other, (other_size, other_lines, other_changed)
                   in texts.items()
                   if other != name and other_size >= SOURCE_RATIO * size and other_changed <= changed]
        if not lines or not sources:
            continue
        repeated, source = 0, ""
        for other, held in sources:
            count = sum(1 for line in lines if line in held)
            if count > repeated:
                repeated, source = count, other
        total += len(lines)
        copied += repeated
        if repeated:
            worst.append((repeated, len(lines), name, source))
    if total < MINIMUM_LINES or copied < COPIED_SHARE * total:
        return None
    worst.sort(reverse=True)
    shown = ", ".join(f"{name} ({count}/{held} from {source})" for count, held, name, source in worst[:3])
    return (f"not finished: the request asks for a summary, and the reports written repeat their "
            f"sources line for line -- {copied} of {total} long lines ({round(100 * copied / total)}%) "
            f"are copied from a larger text of this task; most in {shown}. A summary is shorter than "
            f"what it sums up and says it in its own words: what the request asks for, picked and "
            f"condensed, not the pages pasted in. Make the summaries that, and run it again")

# A service's address in code: a scheme and a host, a port or a path.
ADDRESS = re.compile(r"""["'](https?://[^\s"'/]+(?::\d+)?[^\s"']*)["']""")
# Where an address belongs: an option's default, or a config module's setting.
ADDRESS_HOME = re.compile(r"default\s*=|add_argument|getenv|environ|os\.environ|config|settings",
                          re.IGNORECASE)
CONFIG_FILE = re.compile(r"(?:^|/)(?:config|settings|conf)[^/]*\.py$|(?:^|/)config/", re.IGNORECASE)
# Addresses that are documentation or a format, not a service this code calls.
NOT_A_SERVICE = re.compile(r"example\.(?:com|org)|localhost/docs|schemas?\.|w3\.org|json-schema|github\.com",
                           re.IGNORECASE)


def fixed_addresses(workspace: Path, loop: CodingLoop) -> str | None:
    """Why not to finish yet: code this task wrote fixes a service's address in a constant."""
    if without("fixed-addresses"):
        return None
    if loop.helper_of is not None:
        return None
    found: list[str] = []
    for item in loop.written:
        if not item.path.endswith(".py") or CONFIG_FILE.search(item.path) or "test" in item.path.lower():
            continue
        try:
            text = workspace.joinpath(*item.path.split("/")).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for number, line in enumerate(text.splitlines(), start=1):
            if line.lstrip().startswith("#") or ADDRESS_HOME.search(line):
                continue
            for match in ADDRESS.finditer(line):
                if not NOT_A_SERVICE.search(match.group(1)):
                    found.append(f"{item.path}:{number} ({match.group(1)[:60]})")
    if not found:
        return None
    return (f"not finished: the code fixes a service's address in a constant -- "
            f"{', '.join(found[:3])}{f' and {len(found) - 3} more' if len(found) > 3 else ''}. "
            f"Someone running it elsewhere cannot change it. Make it a command-line option or a "
            f"setting of the config module, with this address as its default, and the model's "
            f"name and the folders too")

# What a run that measured something prints: a share, a count of a whole, or a number stated.
COUNTED = re.compile(r"\d+(?:\.\d+)?\s*%|\b\d+\s*/\s*\d+\b|\b\d+\s+(?:of|out of)\s+\d+\b", re.IGNORECASE)


def _measured(output: str, shares: list[str]) -> bool:
    """Whether a command's output measured something the answer's shares could come from (EVI-14).

    `git status`, `echo ok` or a test run that passed print no share and no
    count: they lift nothing. Output with a share, a count of a whole, or one
    of the numbers stated does.
    """
    if COUNTED.search(output):
        return True
    stated = {number for share in shares for number in re.findall(r"\d+(?:\.\d+)?", share)}
    return any(re.search(rf"(?<![\d.]){re.escape(number)}(?![\d])", output) for number in stated)


def unmeasured_shares(loop: CodingLoop, summary: str = "") -> str | None:
    """Why not to finish yet: an answer stating shares that nothing here measured."""
    if without("unmeasured-shares"):
        return None
    if loop.helper_of is not None:
        return None
    said = f"{loop.report or ''}\n{summary}"
    shares = PERCENT.findall(said)
    if len(shares) < MINIMUM_SHARES or ESTIMATED.search(said):
        return None
    if any(_measured(step.observation, shares) for step in loop.steps
           if step.action.action is LoopActionKind.RUN and step.succeeded):
        return None
    return (f"not finished: the answer states {len(shares)} percentages ({', '.join(shares[:4])}) "
            f"and nothing was run to measure them. Count what they describe with a short "
            f"read-only command -- a script over the files -- and give the counts; quote the values "
            f"you read as the evidence; or say plainly that they are estimates")


# A request naming the model that does the work.
MODEL_ASKED = re.compile(r"VLM|LLM|vllm|모델|\bmodel\b|openai|\bgpt|qwen|claude|gemini|ollama",
                         re.IGNORECASE)
# A prompt asking the model to read, and one asking it to sum up or write the report.
# A heading such as "## 3. 재무 요약" is neither: the verbs are what is matched.
READ_ASK = re.compile(r"추출|받아\s*적|받아\s*쓰|옮겨\s*적|\bOCR\b|extract|transcri|"
                      r"read (?:all|the|every|each)|all (?:the )?text", re.IGNORECASE)
SUMMARIZE_ASK = re.compile(r"요약(?:하|해|할|한|본|문을)|간추려|정리(?:하|해)|종합(?:하|해)|"
                           r"템플릿[^.\n]{0,20}(?:채우|채워|작성|따라|따르|맞춰|맞게)|"
                           r"(?:작성|채워)(?:하세요|하십시오|해\s*주|해라|하라)|"
                           r"summari[sz]|condense|write (?:a|the) (?:summary|report)|"
                           r"fill (?:in )?(?:the |this )?(?:template|form|sections?)",
                           re.IGNORECASE)
PROMPT_LENGTH = 20
# Text files a prompt may be kept in, besides Python.
PROMPT_SUFFIXES = frozenset({".txt", ".yaml", ".yml", ".j2", ".jinja", ".jinja2", ".prompt", ".tmpl"})


def _prompts(path: str, text: str) -> list[tuple[int, str, str | None]]:
    """The strings of a written file that could be a prompt, with their lines and names.

    In Python, string constants and the fixed parts of f-strings, but not
    docstrings or other bare string statements: those say what code does, to
    a reader, and ask no model anything. A string assigned to a name
    (`FINAL_SUMMARY_PROMPT = "..."`) carries the name, so its use can be looked for.
    """
    if not path.endswith(".py"):
        return [(1, text, None)] if len(text) >= PROMPT_LENGTH else []
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    bare = {id(node.value) for node in ast.walk(tree)
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant)}
    named: dict[int, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            named[id(node.value)] = node.targets[0].id
        elif isinstance(node, ast.AnnAssign) and node.value is not None and isinstance(node.target, ast.Name):
            named[id(node.value)] = node.target.id
    found: list[tuple[int, str, str | None]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.JoinedStr):
            fixed = "".join(part.value for part in node.values
                            if isinstance(part, ast.Constant) and isinstance(part.value, str))
            if len(fixed) >= PROMPT_LENGTH:
                found.append((node.lineno, fixed, named.get(id(node))))
        elif (isinstance(node, ast.Constant) and isinstance(node.value, str)
              and id(node) not in bare and len(node.value) >= PROMPT_LENGTH):
            found.append((node.lineno, node.value, named.get(id(node))))
    return found


def _reads(text: str) -> set[str] | None:
    """The names a Python text reads: a name loaded, an attribute read, a name given as a string.

    Read from its syntax, so a comment or a docstring naming a setting is not a
    use of it (0.2.94: a review found `# SUMMARY_PROMPT is for later` counted as
    one). A string equal to a name counts, for `getattr(settings, "NAME")`.
    None when the text is not Python that parses.
    """
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return None
    bare = {id(node.value) for node in ast.walk(tree)
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant)}
    read: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            read.add(node.id)
        elif isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Load):
            read.add(node.attr)
        elif (isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) not in bare
              and node.value.isidentifier()):
            read.add(node.value)
    return read


def _used(name: str, texts: dict[str, str]) -> bool:
    """Whether a name is read by the code of these texts, not only defined or mentioned."""
    for text in texts.values():
        read = _reads(text)
        if read is None:
            # Not Python that parses: named twice, as before.
            if len(re.findall(rf"(?<![\w]){re.escape(name)}(?![\w])", text)) > 1:
                return True
        elif name in read:
            return True
    return False


def _written_texts(workspace: Path, loop: CodingLoop) -> dict[str, str]:
    texts: dict[str, str] = {}
    for item in loop.written:
        suffix = Path(item.path).suffix.lower()
        if "test" in item.path.lower() or not (suffix == ".py" or suffix in PROMPT_SUFFIXES):
            continue
        try:
            texts[item.path] = workspace.joinpath(*item.path.split("/")).read_text(
                encoding="utf-8", errors="replace")
        except OSError:
            continue
    return texts


def rule_made_summaries(workspace: Path, loop: CodingLoop, request: str, summary: str = "") -> str | None:
    """Why not to finish yet: a summary asked of a model, and the model asked only to read.

    Read in the code this task wrote, and -- for a prompt that asks the model
    to sum up -- in the rest of the project too (R07): a summary module kept
    as it was, while only the reading was changed, is the summary made with
    the model (CHK-01). What the project's code could not all be looked at for
    is said as not known, with what was looked at, never as found (CHK-02).
    """
    if without("rule-made-summaries"):
        return None
    if (loop.helper_of is not None or not asks_summary(request)
            or not MODEL_ASKED.search(request) or SAID_INCOMPLETE.search(summary)):
        return None
    texts = _written_texts(workspace, loop)
    project, complete = _project_texts(workspace, loop)
    python = {**{path: text for path, text in project.items() if path.endswith(".py")},
              **{path: text for path, text in texts.items() if path.endswith(".py")}}
    reading: list[str] = []
    unused: list[str] = []
    for path, text in texts.items():
        for line, prompt, name in _prompts(path, text):
            if SUMMARIZE_ASK.search(prompt):
                # Seen with 0.2.87: the summary prompts kept in settings.py, and
                # the code still asking the model only to read. Defined is not used.
                if name is None or _used(name, python):
                    return None
                unused.append(f"{name} ({path}:{line})")
            elif READ_ASK.search(prompt):
                reading.append(f"{path}:{line} ({' '.join(prompt.split())[:60]})")
    if not reading and not unused:
        return None
    # A prompt elsewhere in the project that asks the model to sum up, and is used.
    for path, text in project.items():
        if path in texts:
            continue
        for _, prompt, name in _prompts(path, text):
            if SUMMARIZE_ASK.search(prompt) and (name is None or _used(name, python)):
                return None
    scope = f"{len(python)} Python file(s) under {loop.scope or 'the workspace'}"
    if unused:
        said = (f"the prompts that ask for it -- {', '.join(unused[:3])} -- are read nowhere in the "
                f"{scope}" + (f", and the code asks the model only to read -- {reading[0]}" if reading else ""))
    else:
        said = (f"the code this task wrote asks the model only to read -- {', '.join(reading[:2])}; "
                f"and no prompt that asks it to sum up or to fill the request's template was found in "
                f"the {scope}")
    if not complete:
        # Not all of it could be looked at: not known, and said so (CHK-02).
        return (f"unknown: the request asks for a summary made with a model, and {said} -- but not "
                f"all of the project's code could be looked at. Say where the model makes the summary "
                f"(the file and the call), or make it there, and run it")
    return (f"not finished: the request asks for a summary made with a model, and {said}. Reading "
            f"the pages with the model is not summarizing them with it. If the summary is made "
            f"elsewhere, say where -- the file and the call; if not, give what was read to the model "
            f"with the request's template and what to pick -- in parts when it is long, and once more "
            f"to join the parts -- and run it again. If rules are what you mean to keep, say why "
            f"under \"Not done:\"")


def _project_texts(workspace: Path, loop: CodingLoop) -> tuple[dict[str, str], bool]:
    """The project's code and prompt files, tests aside, and whether all of it was looked at."""
    root = workspace.joinpath(*loop.scope.split("/")) if loop.scope else workspace
    found: dict[str, str] = {}
    complete = True
    for count, path in enumerate(sorted(root.rglob("*"))):
        if count >= MAXIMUM_WALKED:
            complete = False
            break
        suffix = path.suffix.lower()
        if not (suffix == ".py" or suffix in PROMPT_SUFFIXES) or not path.is_file():
            continue
        relative = path.relative_to(workspace).as_posix()
        if any(part in SKIPPED for part in path.parts) or _test_path(relative):
            continue
        try:
            found[relative] = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            complete = False
    return found, complete


# A setting: a name in capitals at the top of a config module.
SETTING = re.compile(r"^([A-Z][A-Z0-9_]{2,})\s*(?::[^=]+)?=", re.MULTILINE)
MAXIMUM_SETTINGS_SHOWN = 6


def unused_settings(workspace: Path, loop: CodingLoop) -> str | None:
    """Why not to finish yet: a config module this task wrote holds settings no code reads (0.2.88).

    Seen with 0.2.87 on the DART task: settings.py held the summary prompts
    and BATCH_SIZE = 4, and the code sent one page at a time with a prompt of
    its own and filled the report by keyword lists -- slow, and no summary. A
    setting no code reads is a promise the program does not keep.
    """
    if without("unused-settings") or loop.helper_of is not None:
        return None
    configs = [item.path for item in loop.written
               if item.path.endswith(".py") and CONFIG_FILE.search(item.path) and "test" not in item.path.lower()]
    if not configs:
        return None
    root = workspace.joinpath(*loop.scope.split("/")) if loop.scope else workspace
    readers: dict[str, str] = {}
    for path in sorted(root.rglob("*.py"))[:MAXIMUM_WALKED]:
        relative = path.relative_to(workspace).as_posix()
        if any(part in SKIPPED for part in path.parts) or _test_path(relative):
            continue
        try:
            readers[relative] = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
    unread: list[str] = []
    for config in configs:
        text = readers.get(config)
        if text is None:
            continue
        for name in dict.fromkeys(SETTING.findall(text)):
            if not _used(name, readers):
                unread.append(f"{name} ({config})")
    if not unread:
        return None
    shown = ", ".join(unread[:MAXIMUM_SETTINGS_SHOWN])
    more = f" and {len(unread) - MAXIMUM_SETTINGS_SHOWN} more" if len(unread) > MAXIMUM_SETTINGS_SHOWN else ""
    if advising():
        return (f"not finished: settings this task wrote are read by no code -- {shown}{more}. "
                f"Find out whether the program does what they say: where each should be used, "
                f"use it and run two or three real inputs again; where one is not meant, say why "
                f"in the summary or take it out of the config")
    return (f"not finished: settings this task wrote are read by no code -- {shown}{more}. The "
            f"program does not do what they say: a prompt set out and not sent, a batch size and "
            f"not used. Use each where it belongs -- the prompts in the calls, the sizes in the "
            f"batching -- run it again, and finish; or remove the ones that are not meant")


def _test_path(path: str) -> bool:
    name = path.rsplit("/", 1)[-1]
    return name.startswith("test_") or name.endswith("_test.py") or "/tests/" in f"/{path}"


# A request about many items: every page, each report, all the files.
MANY_ITEMS = re.compile(r"모든|전체|여러|마다|각각|각\s|페이지|쪽|every|\ball\b|\beach\b|\bpages\b|"
                        r"\bfiles\b|\bdocuments\b|\breports\b|batch|배치", re.IGNORECASE)
# Code that calls a model or a service over the network.
MODEL_CALL = re.compile(r"chat\.completions|/chat/completions|/completions|\bOpenAI\(|AsyncOpenAI|"
                        r"requests\.post|httpx\.|aiohttp|urllib\.request")
# Calls that run calls or work at once (0.2.94: called, not imported -- an import
# alone had counted; and anywhere in the project, where a shared module may do it).
# A semaphore only bounds what something else runs at once (R07): not one of them.
CONCURRENT_CALLS = frozenset({"ThreadPoolExecutor", "ProcessPoolExecutor", "Pool", "ThreadPool", "gather",
                              "as_completed", "create_task", "TaskGroup", "map_async", "imap",
                              "imap_unordered", "starmap", "Parallel"})
# A request that asks for items in turn (CHK-06): nothing is asked to run at once.
IN_TURN_ASKED = re.compile(r"순서대로|차례대로|하나씩|한\s*번에\s*하나|순차|동시성\s*1\b|one at a time|"
                           r"sequential|in turn|concurrency\s*(?:of\s*)?1\b", re.IGNORECASE)


def _runs_at_once(text: str, called: set[str] | None = None) -> bool | None:
    """Whether the code runs an executor, a pool, gather or the like, where it runs -- by its syntax.

    A name imported or assigned under another (`ThreadPoolExecutor as Workers`)
    is read as the one it stands for (CHK-04). A call inside a function counts
    when that function is called (`called`: the names the code reads), when it
    makes the model's calls itself, or at the module's top (CHK-05: a pool in
    a function nothing calls, around calls made elsewhere, runs nothing).
    None when it cannot be told: an executor named and passed around, or work
    submitted to something whose kind is not seen.
    """
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return False
    aliases: dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            for item in node.names:
                if item.asname:
                    aliases[item.asname] = item.name
        elif (isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
              and isinstance(node.value, (ast.Name, ast.Attribute))):
            aliases[node.targets[0].id] = (node.value.id if isinstance(node.value, ast.Name)
                                           else node.value.attr)
    parents: dict[int, ast.AST] = {}
    for node in ast.walk(tree):
        for child in ast.iter_child_nodes(node):
            parents[id(child)] = node

    def enclosing(node: ast.AST) -> ast.FunctionDef | ast.AsyncFunctionDef | None:
        while id(node) in parents:
            node = parents[id(node)]
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                return node
        return None

    unsure = False
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            name = func.id if isinstance(func, ast.Name) else func.attr if isinstance(func, ast.Attribute) else ""
            name = aliases.get(name, name)
            if name in CONCURRENT_CALLS:
                where = enclosing(node)
                if (where is None or called is None or where.name in called
                        or MODEL_CALL.search(ast.get_source_segment(text, where) or "")):
                    return True
            elif name == "submit":
                unsure = True
        elif isinstance(node, (ast.Name, ast.Attribute)) and isinstance(getattr(node, "ctx", None), ast.Load):
            named = node.id if isinstance(node, ast.Name) else node.attr
            if aliases.get(named, named) in CONCURRENT_CALLS and not isinstance(parents.get(id(node)), ast.Call):
                unsure = True
    return None if unsure else False


def _connected(callers: list[str], python: dict[str, str]) -> dict[str, str]:
    """The model's callers and the project modules they import or that import them: where they run."""
    def module_names(path: str) -> set[str]:
        parts = path.removesuffix(".py").split("/")
        if parts[-1] == "__init__":
            parts = parts[:-1]
        return {".".join(parts[index:]) for index in range(len(parts))} | {parts[-1]} if parts else set()

    def imports(text: str) -> set[str]:
        try:
            tree = ast.parse(text)
        except SyntaxError:
            return set()
        found: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                found.update(item.name for item in node.names)
            elif isinstance(node, ast.ImportFrom):
                base = node.module or ""
                found.add(base)
                found.update(f"{base}.{item.name}".strip(".") for item in node.names)
        return found

    names = {path: module_names(path) for path in python}
    imported = {path: imports(text) for path, text in python.items()}
    linked = set(callers)
    for caller in callers:
        for path in python:
            if imported[path] & names[caller] or imported[caller] & names[path]:
                linked.add(path)
    return {path: python[path] for path in sorted(linked)}


def _project_python(workspace: Path, loop: CodingLoop) -> dict[str, str]:
    """The project's Python, tests aside: the files this loop wrote and the ones they live beside."""
    root = workspace.joinpath(*loop.scope.split("/")) if loop.scope else workspace
    found: dict[str, str] = {}
    for path in sorted(root.rglob("*.py"))[:MAXIMUM_WALKED]:
        relative = path.relative_to(workspace).as_posix()
        if any(part in SKIPPED for part in path.parts) or _test_path(relative):
            continue
        try:
            found[relative] = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
    return found


def many_items(request: str) -> bool:
    """Whether the request is about many items, in its words rather than in names it gives."""
    return bool(MANY_ITEMS.search(NAMED_THING.sub(" ", request)))


def sequential_calls(workspace: Path, loop: CodingLoop, request: str, summary: str = "") -> str | None:
    """Why not to finish yet: many items, and the code sends its model calls one at a time (0.2.89).

    Seen with 0.2.88 on the DART task: a 90-page report took over 40 minutes,
    each page sent and waited on in turn, though the instruction said to send
    several at once and to turn pages into images across processes. Said, it
    was not done; this looks for it in the code.
    """
    if without("sequential-calls"):
        return None
    if (loop.helper_of is not None or not many_items(request) or not MODEL_ASKED.search(request)
            or SAID_INCOMPLETE.search(summary)):
        return None
    if IN_TURN_ASKED.search(request):
        # Asked for in turn: running at once is not asked of it (CHK-06).
        return None
    python = {path: text for path, text in _written_texts(workspace, loop).items() if path.endswith(".py")}
    callers = [path for path, text in python.items() if MODEL_CALL.search(text)]
    if not callers:
        return None
    # Where the callers run: them, and the project's modules they import or that import them
    # -- a pool in a module nothing here uses runs none of their calls (CHK-05).
    linked = _connected(callers, {**_project_python(workspace, loop), **python})
    called: set[str] = set()
    for text in linked.values():
        called |= _reads(text) or set()
    found = [_runs_at_once(text, called) for text in linked.values()]
    if any(item is True for item in found):
        return None
    if any(item is None for item in found):
        return (f"unknown: the request is about many items through a model, and whether the calls "
                f"in {', '.join(callers[:3])} run at once could not be told from the code -- an executor "
                f"is named or work submitted where its kind is not seen. Time two or three items and "
                f"say how the run goes, at once or in turn")
    if advising():
        return (f"not finished: the request is about many items through a model, and nothing in "
                f"the code runs its calls at once -- {', '.join(callers[:3])} calls the model, and "
                f"no executor, pool or gather is called. Find out whether that is right: time two "
                f"or three items and say how long the whole run will take; where items do not "
                f"depend on each other, run them at once within what the server takes; where they "
                f"must go in turn, say why in the summary")
    return (f"not finished: the request is about many items, and the code sends its model calls one "
            f"at a time -- {', '.join(callers[:3])} calls the model, and nothing in the code runs "
            f"calls at once (no thread pool, process pool or asyncio.gather). Every item then waits "
            f"for the one before: the run takes the items times each call. Send several calls at "
            f"once -- as many as the server takes, 4 unless it says more, a setting with that "
            f"default -- turn pages into images and parse files in a process pool sized by an "
            f"option, keep the results in the input's order, report a failed item without stopping "
            f"the rest; time a few items before and after, and run it again")
