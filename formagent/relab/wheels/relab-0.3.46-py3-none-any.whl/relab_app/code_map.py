"""What a project's code defines, and where, without reading it whole.

Before a model can change a function it has to find it, and in a project of
more than a few files that was a search, a read, another read. Other coding
agents give the model a map -- the definitions in each file, with their
signatures and lines -- and so does this:

    Python          from the syntax tree: classes and their methods,
                    functions, each with its arguments and return annotation
    JS / TS         by pattern: functions, classes and their methods, arrow
                    functions bound to a name
    Go              by pattern: functions and methods

It reads files the way a read does -- bounded, nothing protected -- and runs
nothing. A file it cannot parse is listed as such rather than guessed at.
"""

import ast
import re
from pathlib import Path

from relab_core.targets import unusable_path
from relab_workspace.file_index import safe_file

PYTHON = {".py"}
SCRIPT = {".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx", ".mts", ".cts"}
GO = {".go"}
MAPPED = PYTHON | SCRIPT | GO
# A file larger than this is outlined from its beginning only.
FILE_BYTES = 400_000

SCRIPT_FUNCTION = re.compile(
    r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s*\*?\s*(\w+)\s*\(([^)]*)\)")
SCRIPT_CLASS = re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:abstract\s+)?class\s+(\w+)")
SCRIPT_ARROW = re.compile(
    r"^\s*(?:export\s+)?(?:const|let|var)\s+(\w+)\s*(?::[^=]+)?=\s*(?:async\s*)?\(([^)]*)\)[^=]*=>")
SCRIPT_METHOD = re.compile(
    r"^\s+(?:public\s+|private\s+|protected\s+|static\s+|readonly\s+|async\s+|get\s+|set\s+)*"
    r"(\w+)\s*\(([^)]*)\)\s*(?::\s*[^{]+)?\{\s*$")
NOT_METHODS = {"if", "for", "while", "switch", "catch", "function", "return", "constructor"}
GO_FUNCTION = re.compile(r"^func\s+(\([^)]*\)\s*)?(\w+)\s*\(([^)]*)\)")


def outline(workspace: Path, paths: list[str], *, limit: int) -> tuple[str, bool]:
    """The definitions in `paths` (workspace files), at most `limit` characters; and whether cut."""
    parts: list[str] = []
    size = 0
    for path in paths:
        if Path(path).suffix.lower() not in MAPPED or unusable_path(path) is not None:
            continue
        lines = _file(workspace, path)
        if not lines:
            continue
        block = "\n".join([path, *lines])
        if size + len(block) > limit:
            return "\n".join(parts), True
        parts.append(block)
        size += len(block) + 1
    return "\n".join(parts), False


def _file(workspace: Path, path: str) -> list[str]:
    if not safe_file(workspace.resolve(strict=True), path, exclude_noise=False):
        return ["  (not readable as text)"]
    try:
        target = workspace.joinpath(*path.split("/")).resolve(strict=True)
        target.relative_to(workspace.resolve(strict=True))
        with target.open("rb") as stream:
            data = stream.read(FILE_BYTES)
        text = data.decode("utf-8")
    except (OSError, UnicodeDecodeError, ValueError):
        return ["  (not readable as text)"]
    suffix = Path(path).suffix.lower()
    if suffix in PYTHON:
        return _python(text)
    if suffix in SCRIPT:
        return _script(text)
    return _go(text)


def _python(text: str) -> list[str]:
    try:
        tree = ast.parse(text)
    except SyntaxError as error:
        return [f"  (does not parse: line {error.lineno}: {error.msg})"]
    found: list[str] = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            found.append(f"  {node.lineno}: {_signature(node)}")
        elif isinstance(node, ast.ClassDef):
            bases = ", ".join(ast.unparse(base) for base in node.bases)
            found.append(f"  {node.lineno}: class {node.name}{f'({bases})' if bases else ''}")
            found.extend(f"    {item.lineno}: {_signature(item)}" for item in node.body
                         if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)))
    return found


def _signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    kind = "async def" if isinstance(node, ast.AsyncFunctionDef) else "def"
    returns = f" -> {ast.unparse(node.returns)}" if node.returns is not None else ""
    return f"{kind} {node.name}({ast.unparse(node.args)}){returns}"


def _script(text: str) -> list[str]:
    found: list[str] = []
    in_class = False
    for number, line in enumerate(text.splitlines(), start=1):
        if (match := SCRIPT_CLASS.match(line)) is not None:
            found.append(f"  {number}: class {match[1]}")
            in_class = True
        elif (match := SCRIPT_FUNCTION.match(line)) is not None:
            found.append(f"  {number}: function {match[1]}({' '.join(match[2].split())})")
            in_class = line.startswith((" ", "\t")) and in_class
        elif (match := SCRIPT_ARROW.match(line)) is not None:
            found.append(f"  {number}: const {match[1]} = ({' '.join(match[2].split())}) =>")
        elif in_class and (match := SCRIPT_METHOD.match(line)) is not None \
                and match[1] not in NOT_METHODS:
            found.append(f"    {number}: {match[1]}({' '.join(match[2].split())})")
        elif line and not line[0].isspace() and not line.startswith(("}", "//", "/*", "*")):
            in_class = False
    return found


def _go(text: str) -> list[str]:
    return [f"  {number}: func {(match[1] or '').strip()} {match[2]}({' '.join(match[3].split())})"
            .replace("func  ", "func ")
            for number, line in enumerate(text.splitlines(), start=1)
            if (match := GO_FUNCTION.match(line)) is not None]
