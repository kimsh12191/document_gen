"""Classify the checkouts an isolated attempt left, and remove only the settled ones.

The classification follows the same rule the interruption diagnosis does: evidence
of activity wins, an absence of evidence is never read as permission, and anything
that cannot be attributed is a person's to decide rather than this code's to guess.
"""

from pathlib import Path

from relab_app.runs import CodingRunService
from relab_core.checkouts import (
    CheckoutCleanup,
    CheckoutFinding,
    CheckoutRecord,
    CheckoutReport,
    CheckoutState,
)
from relab_core.contracts import RunState
from relab_workspace.locking import session_execution_held, workspace_mutation_held
from relab_workspace.worktree import abandoned_checkouts, remove_checkout

SETTLED = frozenset({RunState.COMPLETED, RunState.FAILED, RunState.CANCELLED})


class WorkspaceCheckouts:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.runs = CodingRunService(self.workspace)

    def report(self) -> CheckoutReport:
        """Say what each checkout is; this removes nothing and records nothing."""
        findings = [self._classify(record) for record in abandoned_checkouts(self.workspace)]
        return CheckoutReport(
            workspace=str(self.workspace), findings=findings,
            active=sum(1 for item in findings if item.state is CheckoutState.ACTIVE),
            recoverable=sum(1 for item in findings if item.state is CheckoutState.RECOVERABLE),
            manual=sum(1 for item in findings if item.state is CheckoutState.MANUAL),
        )

    def clean(self, *, name: str | None = None) -> CheckoutCleanup:
        """Remove the settled checkouts, and only those; everything else is kept.

        Naming one asks for that one and still refuses it unless it is settled:
        an explicit request is not evidence that the work behind it ended.
        """
        removed, kept = [], []
        for finding in self.report().findings:
            if name is not None and finding.checkout.name != name:
                continue
            if finding.state is not CheckoutState.RECOVERABLE:
                kept.append(finding)
                continue
            remove_checkout(self.workspace, finding.checkout.name)
            removed.append(finding.checkout.name)
        if name is not None and not removed and not kept:
            raise LookupError(f"no such checkout in this workspace: {name}")
        return CheckoutCleanup(workspace=str(self.workspace), removed=removed, kept=kept)

    def _classify(self, record: CheckoutRecord) -> CheckoutFinding:
        """Active first; an unattributed checkout is never assumed to be finished."""
        if record.session_id is not None and session_execution_held(
            self.workspace, record.session_id,
        ):
            return self._finding(record, CheckoutState.ACTIVE,
                                 "its session is executing right now")
        if workspace_mutation_held(self.workspace):
            return self._finding(record, CheckoutState.ACTIVE,
                                 "a patch operation holds this workspace")
        if record.owner_run_id is None:
            return self._finding(record, CheckoutState.MANUAL,
                                 "it records no owner, so nothing says whose work this was")
        try:
            run = self.runs.store.load(record.owner_run_id)
        except (LookupError, ValueError):
            return self._finding(record, CheckoutState.MANUAL,
                                 "its owner is not a run this workspace records")
        if run.state in SETTLED:
            return self._finding(record, CheckoutState.RECOVERABLE,
                                 f"its owner finished as {run.state.value}")
        return self._finding(
            record, CheckoutState.MANUAL,
            f"its owner is {run.state.value} and no lock says whether that is still true")

    @staticmethod
    def _finding(record: CheckoutRecord, state: CheckoutState, reason: str) -> CheckoutFinding:
        return CheckoutFinding(checkout=record, state=state, reason=reason)
