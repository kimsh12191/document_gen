"""What an arm has already failed with, read from the evidence it left.

There is no repair store. Every failed attempt is already a run event with its
verifier's output on it, so a second record of the same thing could only agree
with the first or be wrong.

That also means the history cannot drift from the evidence, cannot be rebuilt
incorrectly after an interruption, and needs no migration when the fingerprint
rule changes -- the digests are recomputed from what was recorded.
"""

from pathlib import Path

from relab_app.sessions import ResearchSessionService
from relab_core.explanation import FailureExplanation
from relab_core.repair import RepairHistory
from relab_evaluation.explanation import explain_failures
from relab_evaluation.repair import repair_history
from relab_workspace.run_store import RunStore


class RepairMemory:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.sessions = ResearchSessionService(self.workspace)
        self.runs = RunStore(self.workspace)

    def history(self, session_id: str, arm: str) -> RepairHistory:
        """What this arm has failed with. This performs nothing and records nothing."""
        readiness = self.sessions.readiness(session_id)
        found = next((item for item in readiness.arms if item.arm == arm), None)
        if found is None:
            return RepairHistory(session_id=session_id, arm=arm)
        snapshots = {item.run_id: self.runs.load(item.run_id) for item in found.runs}
        return repair_history(session_id, arm, found.runs, snapshots)

    def explain(self, session_id: str, arm: str) -> FailureExplanation:
        """The same history, in the shape a person reads rather than a machine.

        Nothing is added on the way: no cause, no recommendation, no model. What
        to try next is a judgement, and it belongs where judgements are made.
        """
        return explain_failures(self.history(session_id, arm))
