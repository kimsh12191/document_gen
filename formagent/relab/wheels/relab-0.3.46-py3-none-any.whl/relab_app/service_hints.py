"""Where this workspace already says how to reach a model or a service (0.2.61).

Measured against Cline in use, on the same task: a VLM was to be called, its
working settings were in another folder of the workspace, and ReLab -- given
its project folder's files and the other folders by name only -- used made-up
ones and failed, while Cline found them and ran OCR first. When a request is
about a model or a service, the lines of the workspace that name an endpoint
or a model are found at the start, by search, and given to the model with
where they are. Nothing is called; a line that holds a key is not shown.
"""

import re
from collections.abc import Callable

from relab_workspace.code_search import CodeSearchQuery, CodeSearchService

# A request about reaching a model or a service.
ABOUT_SERVICES = re.compile(
    r"\b(?:vlm|llm|ocr|api|endpoint|vllm|openai|ollama|base_?url|model|server|gpt|qwen|llama|"
    r"inference|embedding|rag)\b|모델|엔드포인트|서버|추론|연결|호출|임베딩",
    re.IGNORECASE)
# What names where a model or service is: searched, as written in code and config.
QUERIES = ("base_url", "api_base", "BASE_URL", "API_BASE", "endpoint", "/v1", "model_name",
           "MODEL_NAME", "vllm", "VLLM")
# A line that holds a secret is never shown, whatever else it says.
SECRET = re.compile(r"key|token|secret|passw|bearer|authorization|credential", re.IGNORECASE)
SHOWN = 10
PER_FILE = 2


def service_lines(search: CodeSearchService, request: str, *,
                  hidden: Callable[[str], bool] | None = None) -> list[str]:
    """The workspace's lines that say where a model or service is, when the request is about one."""
    if ABOUT_SERVICES.search(request) is None:
        return []
    try:
        results = search.search_many([CodeSearchQuery(query=query) for query in QUERIES])
    except (OSError, ValueError):
        return []
    found: list[str] = []
    per_file: dict[str, int] = {}
    seen: set[tuple[str, int]] = set()
    for result in results:
        for match in result.matches:
            path = match.path.replace("\\", "/")
            if (path.startswith(".relab/") or "/test" in f"/{path}" or (match.path, match.line) in seen
                    or SECRET.search(match.text) or (hidden is not None and hidden(path))):
                continue
            if per_file.get(path, 0) >= PER_FILE:
                continue
            seen.add((match.path, match.line))
            per_file[path] = per_file.get(path, 0) + 1
            found.append(f"{path}:{match.line}: {' '.join(match.text.split())[:160]}")
            if len(found) >= SHOWN:
                return found
    return found
