"""A coding loop's project folder, and the two rules that keep a project its own.

A person asked that a project be shippable on its own: code elsewhere in the
workspace -- another project, an older experiment -- may be read and learned
from, but not imported or called across into. The instruction said so, and an
instruction is a request to a model; these are the checks that hold whatever
the model writes.

    writing     a file outside the project folder is refused
    importing   a Python file whose code reaches another folder of this
                workspace -- `import other_project`, `from other.x import y`, a
                relative import that climbs out of the project, `importlib`
                pointed at one by a literal -- is refused before it is written;
                and so is one that imports the project by its own folder's
                name (`from relab_target.ocr_agent import ...`), which works
                only from the workspace root and not where the project ships

Installed libraries are untouched: they are not folders of this workspace. The
check reads the code (`ast`), never runs it, and is shallow in the way such a
check has to be -- a path built at run time is not seen -- which is written
down rather than pretended away.
"""

import ast
import re
from pathlib import Path

from relab_app.probe_files import SCRATCH
from relab_core.targets import UNSEARCHED_DIRECTORIES, unusable_path


def local_names(workspace: Path) -> set[str]:
    """What an import could name in this workspace: its top-level folders and modules."""
    names: set[str] = set()
    for item in workspace.iterdir():
        if item.name.startswith(".") or item.name in UNSEARCHED_DIRECTORIES:
            continue
        if item.is_dir():
            names.add(item.name)
        elif item.suffix == ".py":
            names.add(item.stem)
    return names


# A path in a request: a Windows or POSIX absolute one, or a relative one with
# a separator. ASCII only, so a Korean particle after it is not part of it.
NAMED_PATH = re.compile(r"(?:[A-Za-z]:[\\/]|/)?[A-Za-z0-9_.-]+(?:[\\/][A-Za-z0-9_.-]+)+")


def scope_from_request(workspace: Path, request: str) -> str | None:
    """The project folder the request names, or None.

    A folder of this workspace named by its path, at any depth and absolute or
    not ("C:\\work\\debug_relab\\compare\\relab", "compare/relab") -- the
    deepest one, when one path is inside another; otherwise the one existing
    top-level folder named as a word or as the start of a path ("in
    vlm_ocr_project", or "vlm_ocr_project/solution.py"). Two named, or none,
    leaves it unset: which project is meant is then the plan's to say.

    A live request named `C:\\iyyun_work\\debug_relab\\compare\\relab` and
    got `compare` -- one level up, where the next project also lives.
    """
    nested = [folder for folder in _named_folders(workspace, request)
              if not holds_only_data(workspace / folder)]
    if len(nested) == 1:
        return project_of(workspace, nested[0])
    named = [
        item.name for item in workspace.iterdir()
        if item.is_dir() and not item.name.startswith(".")
        and item.name not in UNSEARCHED_DIRECTORIES
        and not holds_only_data(item)
        # An ASCII boundary, not `\w`: "ocr_app에서" names ocr_app, and a
        # Korean particle is a word character to `\w`.
        and re.search(rf"(?<![A-Za-z0-9_-]){re.escape(item.name)}(?![A-Za-z0-9_-])", request)
    ]
    return project_of(workspace, named[0]) if len(named) == 1 else None


# The project is the whole workspace, said outright: nothing is inferred from
# the request (a benchmark task whose answer is written at the top).
WHOLE_WORKSPACE = "."

# What a folder of input holds: tables, arrays, documents, archives, pictures.
DATA_SUFFIXES = frozenset({
    ".csv", ".tsv", ".json", ".jsonl", ".parquet", ".feather", ".arrow", ".xlsx", ".xls",
    ".txt", ".dat", ".xml", ".npy", ".npz", ".h5", ".hdf5", ".pkl", ".pickle", ".sqlite",
    ".db", ".zip", ".gz", ".tar", ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff",
    ".pdf",
})
# How many files are looked at before a folder of only data is taken as one.
DATA_FILES_LOOKED_AT = 2000


def holds_only_data(folder: Path) -> bool:
    """Whether `folder` holds files and every one of them is data, not code.

    A DABench request said "from the data in data/test_ave.csv", and `data/`
    -- one CSV -- became the project: the answer the request asked for at the
    top of the workspace was refused as outside it, written to data/answer.txt,
    and scored as missing. A folder of input is what a project reads, not the
    project. An empty folder is not data: it may be where a project is to be
    built.
    """
    seen = 0
    try:
        for item in folder.rglob("*"):
            if any(part.startswith(".") or part in UNSEARCHED_DIRECTORIES
                   for part in item.relative_to(folder).parts):
                continue
            if not item.is_file():
                continue
            if item.suffix.lower() not in DATA_SUFFIXES:
                return False
            seen += 1
            if seen >= DATA_FILES_LOOKED_AT:
                break
    except OSError:
        return False
    return seen > 0


def project_of(workspace: Path, folder: str) -> str | None:
    """The project `folder` is part of: itself, or the folder holding it when it is a package.

    A Python package (a folder with `__init__.py`) is imported by its name
    from the folder above it, so that is where its commands run and its code
    is shipped from. Taken as the project, a benchmark's `shop` package ran its
    tests inside `shop/` and refused `from shop.pricing import ...` -- the
    import the package's own code used -- so the model rewrote every import
    to `from pricing import ...`, which no longer imported from the root.
    None when the package sits at the workspace's top: the workspace is then
    the project.
    """
    parts = folder.split("/")
    while parts and workspace.joinpath(*parts, "__init__.py").is_file():
        parts.pop()
    return "/".join(parts) or None


def _named_folders(workspace: Path, request: str) -> list[str]:
    """Folders of this workspace the request names by a path, the deepest of each line."""
    root = workspace.resolve()
    found: set[str] = set()
    for token in NAMED_PATH.findall(request):
        path = token.replace("\\", "/").rstrip("/.")
        if re.match(r"^[A-Za-z]:/|^/", path):
            try:
                relative = Path(path).resolve().relative_to(root).as_posix()
            except (ValueError, OSError):
                continue
        else:
            relative = path.removeprefix("./")
        if not relative or relative == "." or unusable_path(relative) is not None:
            continue
        if root.joinpath(*relative.split("/")).is_dir():
            found.add(relative)
    # A folder inside another named one is the more precise of the two.
    return sorted(item for item in found
                  if not any(other.startswith(f"{item}/") for other in found))


def scope_from_plan(paths: list[str], workspace: Path | None = None) -> str | None:
    """The folder every planned file sits under, when they share one and it is not a package."""
    tops = {path.split("/", 1)[0] for path in paths if "/" in path}
    if len(tops) != 1 or any("/" not in path for path in paths):
        return None
    top = next(iter(tops))
    # scratch/ holds the scripts a loop writes to look at something (0.3.20): a
    # DABench loop that wrote only those and stopped to ask was given scratch/ as
    # its project, and the answer it was asked for at the top was refused.
    if top == SCRATCH or unusable_path(top) is not None or f"{top}/__init__.py" in paths:
        return None
    return project_of(workspace, top) if workspace is not None else top


def outside_write(scope: str | None, path: str) -> str | None:
    """Why writing `path` leaves the project, or None."""
    if scope is None or path == scope or path.startswith(f"{scope}/"):
        return None
    return (f"{path!r} is outside the project folder {scope!r}; everything this "
            f"project needs is written inside it")


def outside_imports(scope: str | None, path: str, content: str, names: set[str], *,
                    inner_package: bool = False) -> str | None:
    """Why this Python file's code reaches another folder of the workspace, or None.

    `inner_package`: the project holds a package of its own folder's name
    (`text2sql_agent/text2sql_agent/`), the usual Python layout. Its name then
    imports that package from inside the project, and is no reach outside: a
    live loop, refused it, renamed the package and spent fourteen steps on it.
    """
    if scope is None or not path.endswith(".py"):
        return None
    try:
        tree = ast.parse(content)
    except SyntaxError:
        # Not this check's to judge; running it will say so.
        return None
    others = names - {scope}
    own = scope.split("/", 1)[0]
    # How deep the file sits inside the project, for relative imports.
    depth = len(path.split("/")) - 2
    found: list[str] = []
    itself: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found += [alias.name for alias in node.names if alias.name.split(".")[0] in others]
            itself += [alias.name for alias in node.names if alias.name.split(".")[0] == own]
        elif isinstance(node, ast.ImportFrom):
            if node.level > 0 and node.level - 1 > depth:
                found.append("." * node.level + (node.module or ""))
            elif node.level == 0 and node.module and node.module.split(".")[0] in others:
                found.append(node.module)
            elif node.level == 0 and node.module and node.module.split(".")[0] == own:
                itself.append(node.module)
        elif isinstance(node, ast.Call) and _loads_by_name(node):
            for argument in node.args[:2]:
                if isinstance(argument, ast.Constant) and isinstance(argument.value, str):
                    target = argument.value.replace("\\", "/").lstrip("./")
                    top = re.split(r"[./]", target, maxsplit=1)[0]
                    if top in others:
                        found.append(argument.value)
    if itself and not found and not inner_package:
        inside = sorted({name.split(".", 1)[1] if "." in name else name for name in itself})
        return (f"{path!r} imports the project by its folder's name ({', '.join(sorted(set(itself)))}), "
                f"which works only from the workspace root; commands run inside {scope!r}, so "
                f"import its modules as they are there ({', '.join(inside)})")
    if not found:
        return None
    return (f"{path!r} would use code from outside the project folder {scope!r}: "
            f"{', '.join(sorted(set(found)))}. Read that code and write what this "
            f"project needs inside {scope!r} instead of importing it across")


def _loads_by_name(node: ast.Call) -> bool:
    """`importlib.import_module(...)`, `spec_from_file_location(...)` and their kin."""
    called = node.func
    name = called.attr if isinstance(called, ast.Attribute) else (
        called.id if isinstance(called, ast.Name) else "")
    return name in {"import_module", "spec_from_file_location", "__import__", "run_path"}
