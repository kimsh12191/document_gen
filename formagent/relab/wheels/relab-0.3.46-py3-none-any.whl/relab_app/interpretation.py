"""Reading a session's records as claims, limits and a refusal.

This performs nothing and records nothing. It does not evaluate the holdout,
because a first evaluation is itself recorded, and an interpretation that could
change what it is interpreting would not be one.
"""

from pathlib import Path

from relab_app.client import WorkspaceClient
from relab_core.client import SessionReport
from relab_core.evaluation import MetricComparison, RepeatabilityReport
from relab_core.interpretation import (
    MAXIMUM_LIMITS,
    MAXIMUM_SCOPE_FACTS,
    ClaimKind,
    InterpretedClaim,
    SessionInterpretation,
)
from relab_core.memory import EvidenceCitation
from relab_core.provenance import ConditionsComparison
from relab_core.research import ResearchSessionAssessment

# Enough of a failing rule to know which one, short enough to stay one sentence.
MAXIMUM_REASONS = 4


class SessionInterpreter:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.client = WorkspaceClient(self.workspace)

    def interpret(self, session_id: str) -> SessionInterpretation:
        """What this session's records support, and what they refuse to support."""
        report = self.client.report(session_id)
        assessment = report.assessment
        refused = not report.rules_held
        claims: list[InterpretedClaim] = []
        limits: list[str] = []
        if refused:
            # The goalpost rule reaches into memory. A session whose deciding rules
            # moved once results existed states nothing, rather than stating it with
            # a caveat a later reader could drop.
            moved = sorted({field for change in report.policy_changes
                            for field in change.deciding_fields})
            limits = ["nothing recorded here may be carried forward"]
            reason = ("the rules deciding whether a result passes were changed after "
                      f"results existed: {', '.join(moved)}")
        elif assessment is None:
            reason = report.assessment_unavailable or "this session has no assessment yet"
        else:
            claims = [*_outcome_claims(assessment), *_spread_claims(assessment)]
            limits = _limits(report, assessment)[:MAXIMUM_LIMITS]
            reason = _reason(claims, assessment)
        return SessionInterpretation(
            session_id=session_id, event_sequence=report.event_sequence,
            objective=report.objective, decision=report.decision,
            scope_facts=_scope_facts(report)[:MAXIMUM_SCOPE_FACTS],
            claims=claims, limits=limits, carries_findings=bool(claims),
            refused=refused, reason=reason,
        )


def _reason(claims: list[InterpretedClaim], assessment: ResearchSessionAssessment) -> str:
    if claims:
        return f"{len(claims)} claim(s) rest on the evidence this session pinned"
    # Covered but silent is a different answer from uncovered, and both are useful.
    if assessment.readiness.ready:
        return "the design is covered but the declared policy produced no comparison"
    return "the declared design is not covered by usable evidence"


def _cite(metrics_run_id: str, event_sequence: int) -> EvidenceCitation:
    return EvidenceCitation(run_id=metrics_run_id, event_sequence=event_sequence)


def _outcome_claims(assessment: ResearchSessionAssessment) -> list[InterpretedClaim]:
    return [
        InterpretedClaim(
            kind=ClaimKind.OUTCOME, statement=_outcome_statement(comparison),
            citations=[_cite(comparison.candidate.run_id, comparison.candidate.event_sequence),
                       _cite(comparison.baseline.run_id, comparison.baseline.event_sequence)],
        )
        for comparison in assessment.comparisons
    ]


def _outcome_statement(comparison: MetricComparison) -> str:
    verdict = "met" if comparison.passed else "did not meet"
    # Name the rules that decided it, so the sentence cannot be read as a bare
    # verdict once it is separated from the comparison it came from.
    decided = [item for item in comparison.items if item.passed is comparison.passed]
    named = "; ".join(f"{item.name} {item.reason}" for item in decided[:MAXIMUM_REASONS])
    return _bounded(
        f"the candidate {verdict} the declared rules against the baseline"
        + (f" ({named})" if named else ""))


def _spread_claims(assessment: ResearchSessionAssessment) -> list[InterpretedClaim]:
    claims = []
    for arm in assessment.arms:
        report = arm.repeatability
        if report is None:
            continue
        citations = [_cite(sample.run_id, sample.event_sequence) for sample in report.samples]
        if not citations:
            continue
        claims.append(InterpretedClaim(
            kind=ClaimKind.SPREAD, statement=_spread_statement(arm.arm, report),
            citations=citations))
    return claims


def _spread_statement(arm: str, report: RepeatabilityReport) -> str:
    verdict = "stayed within" if report.passed else "moved beyond"
    return _bounded(
        f"arm '{arm}' {verdict} the declared spread across "
        f"{len(report.samples)} run(s): {report.reason}")


def _bounded(statement: str) -> str:
    return statement if len(statement) <= 2000 else statement[:1997] + "..."


def _limits(
    report: SessionReport, assessment: ResearchSessionAssessment,
) -> list[str]:
    """Everything these records do not let you say, stated rather than left absent."""
    limits = []
    if not report.pre_registered:
        # The deciding rules held or this would have been refused; something else
        # in the policy still changed with results in hand.
        limits.append("the declared policy was changed after results existed, "
                      "though not the rules that decide whether a result passes")
    limits.extend(_conditions_limits(assessment.conditions, "the compared runs"))
    for arm in assessment.arms:
        limits.extend(_conditions_limits(arm.conditions, f"the repeats of arm '{arm.arm}'"))
    single = sorted(arm.arm for arm in assessment.arms
                    if arm.repeatability is None and arm.run_ids)
    if single:
        limits.append(f"arm(s) {', '.join(single)} have no observable spread here, "
                      "so nothing says their numbers repeat")
    if assessment.unpaired_run_ids:
        limits.append(f"{len(assessment.unpaired_run_ids)} run(s) were not paired into any "
                      "comparison and decided nothing")
    if not assessment.comparisons:
        limits.append("the declared policy produced no comparison, so nothing here "
                      "compares the arms")
    limits.extend(_holdout_limits(report))
    restored = sorted(item.run_id for item in report.evidence if item.restored)
    if restored:
        limits.append(f"the edit of run(s) {', '.join(restored)} was undone afterwards, "
                      "so the workspace no longer holds what was measured")
    return limits


def _conditions_limits(
    conditions: ConditionsComparison | None, subject: str,
) -> list[str]:
    if conditions is None:
        return []
    limits = []
    if not conditions.comparable:
        reasons = "; ".join(conditions.reasons[:MAXIMUM_REASONS])
        limits.append(f"{subject} did not start from the same conditions ({reasons}), "
                      "so a difference between them is not attributable to the design")
    if conditions.changed_data_run_ids:
        # Not a disagreement between runs: the data moved underneath one of them.
        limits.append(f"declared data changed while run(s) "
                      f"{', '.join(conditions.changed_data_run_ids)} were running, "
                      "so their own conditions are unknown")
    if conditions.missing_run_ids:
        limits.append(f"run(s) {', '.join(conditions.missing_run_ids)} recorded no conditions, "
                      "so nothing is known about what they ran under")
    return limits


def _holdout_limits(report: SessionReport) -> list[str]:
    plan = report.plan
    if plan is None or plan.holdout_registry is None:
        return []
    if report.holdout is None:
        return [("held-out rules were declared but never opened, "
                 "so nothing here is a held-out result")]
    if [item.run_id for item in report.holdout.pins] != [
            item.run_id for item in report.evidence]:
        return [("the pinned evidence changed after the holdout was first opened, "
                 "so the held-out reading no longer covers what is pinned now")]
    return []


def _scope_facts(report: SessionReport) -> list[str]:
    """What is known about where any of this held. No scope is invented from it."""
    facts = []
    models = sorted({item.reported_model for item in report.evidence
                     if item.reported_model is not None})
    if models:
        facts.append(f"the model that reported was {', '.join(models)}")
    plan = report.plan
    if plan is not None and plan.expected_model is not None:
        facts.append(f"the plan required {plan.expected_model.provider}/"
                     f"{plan.expected_model.model}")
    assessment = report.assessment
    revisions = [] if assessment is None or assessment.conditions is None else \
        assessment.conditions.code_revisions
    if revisions:
        facts.append(f"the code revision(s) measured were {', '.join(revisions)}")
    if report.holdout is not None:
        facts.append(f"held-out data was first opened at session event "
                     f"{report.holdout.event_sequence}")
    return facts
