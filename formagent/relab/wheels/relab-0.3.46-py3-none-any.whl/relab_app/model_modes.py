"""What a model server was found not to take, remembered for a while (RL-05).

A loop learns it the hard way: a server without a tool parser refuses tool
calls, and a model under a reply schema it cannot finish runs out its whole
call timeout. Each loop used to learn it again -- every `relab code` run is a
new process -- so a JSON-only server cost a refused call per loop, and a
schema that never ends cost up to ten minutes per loop. What was found is
kept here per provider, endpoint and model, for a day: a server restarted with
a parser is tried with tools again by tomorrow, or at once by deleting the file.

Best-effort, like the operations journal: a workspace where this cannot be
read or written runs exactly as before, finding out each time.
"""

import json
import os
import time
from pathlib import Path

from relab_workspace.private_state import state_dir

MODES_FILE = "model_modes.json"
# How long a finding holds before the mode is tried again.
REMEMBERED_SECONDS = 24 * 60 * 60
# The modes a server may be found not to take.
NATIVE_TOOLS = "native_tools"
JSON_SCHEMA = "json_schema"
MODES = (NATIVE_TOOLS, JSON_SCHEMA)


def server_of(gateway: object) -> str | None:
    """Which server and model a gateway calls, as a key; None for one that does not say."""
    try:
        identity = getattr(gateway, "identity", None)
    except Exception:  # noqa: BLE001 -- a gateway whose identity cannot be had
        return None
    provider = getattr(identity, "provider", None)
    model = getattr(identity, "model", None)
    if not isinstance(provider, str) or not isinstance(model, str):
        return None
    host, port, path = (getattr(gateway, name, None) for name in ("host", "port", "path"))
    where = f"{host}:{port}{path}" if isinstance(host, str) else "?"
    return f"{provider}|{where}|{model}"


class ModelModes:
    def __init__(self, workspace: Path) -> None:
        self.path = state_dir(workspace) / MODES_FILE

    def _all(self) -> dict[str, dict[str, dict[str, object]]]:
        try:
            if self.path.is_symlink() or self.path.parent.is_symlink():
                return {}
            said = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return said if isinstance(said, dict) else {}

    def known(self, server: str | None, *, now: float | None = None) -> dict[str, str]:
        """The modes this server was found not to take, still held: mode -> why."""
        if server is None:
            return {}
        now = time.time() if now is None else now
        entry = self._all().get(server)
        if not isinstance(entry, dict):
            return {}
        held: dict[str, str] = {}
        for mode, found in entry.items():
            if mode not in MODES or not isinstance(found, dict):
                continue
            at, why = found.get("at"), found.get("why")
            if isinstance(at, (int, float)) and now - at < REMEMBERED_SECONDS:
                held[mode] = why if isinstance(why, str) else "found before"
        return held

    def remember(self, server: str | None, mode: str, why: str) -> None:
        """Keep that this server does not take `mode`, and why; never raises."""
        if server is None or mode not in MODES:
            return
        try:
            if self.path.parent.is_symlink() or self.path.is_symlink():
                return
            every = self._all()
            entry = every.setdefault(server, {})
            entry[mode] = {"why": why[:200], "at": time.time()}
            self.path.parent.mkdir(exist_ok=True)
            temporary = self.path.with_suffix(f".{os.getpid()}.tmp")
            temporary.write_text(json.dumps(every, indent=1), encoding="utf-8")
            temporary.replace(self.path)
        except OSError:
            return
