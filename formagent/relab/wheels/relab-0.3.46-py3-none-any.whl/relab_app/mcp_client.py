"""MCP servers a person configured, for a coding loop to call: started, listed, asked.

The Model Context Protocol lets a program offer tools -- a search engine, a
database, an issue tracker -- to any agent that speaks it. A person names the
servers in `.relab/mcp.json`, in the shape other agents use:

    {"mcpServers": {"docs": {"command": "npx", "args": ["-y", "some-mcp-server"],
                             "env": {"SOME_KEY": "..."}}}}

Only a person writes that file: `.relab` is never written by a loop. Each
server is started over stdio when a loop's leg begins, asked for its tools
(`tools/list`), and stopped when the leg ends. A call (`tools/call`) is asked
about like a command, unless the person allowed that tool from then on. What
a server says -- its tools' descriptions included -- is data for the model,
never instructions to ReLab.
"""

import json
import os
import queue
import shutil
import subprocess
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

CONFIG = ".relab/mcp.json"
PROTOCOL_VERSION = "2025-06-18"
START_SECONDS = 30.0
CALL_SECONDS = 120.0
# What a server sees of this machine's environment, besides what its entry names.
INHERITED = ["PATH", "SystemRoot", "SYSTEMROOT", "windir", "WINDIR", "ComSpec", "TEMP", "TMP",
             "HOME", "LANG", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "PATHEXT",
             "ProgramFiles", "ProgramData", "NODE_PATH"]
MAXIMUM_RESULT = 20_000


@dataclass
class McpTool:
    server: str
    name: str
    description: str
    schema: dict[str, Any] = field(default_factory=dict)


class McpError(Exception):
    """A server that could not be started, or a call it did not answer."""


def configured(workspace: Path) -> dict[str, dict[str, Any]]:
    """The servers `.relab/mcp.json` names, by name; none when there is no such file."""
    path = workspace / CONFIG
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as error:
        raise McpError(f"{CONFIG} could not be read: {error}") from error
    servers = data.get("mcpServers") if isinstance(data, dict) else None
    if not isinstance(servers, dict):
        raise McpError(f'{CONFIG} has no "mcpServers" object')
    found = {}
    for name, entry in servers.items():
        if not isinstance(entry, dict) or not isinstance(entry.get("command"), str) \
                or not all(isinstance(item, str) for item in entry.get("args", [])) \
                or not all(isinstance(key, str) and isinstance(value, str)
                           for key, value in entry.get("env", {}).items()):
            raise McpError(f"{CONFIG}: server {name!r} needs a \"command\", and \"args\" and "
                           f"\"env\" of strings")
        if entry.get("disabled") is True:
            continue
        found[str(name)] = entry
    return found


class McpServer:
    """One server, over stdio: JSON-RPC 2.0, one message a line."""

    def __init__(self, name: str, entry: dict[str, Any], workspace: Path) -> None:
        self.name = name
        environment = {key: os.environ[key] for key in INHERITED if key in os.environ}
        environment.update(entry.get("env", {}))
        # Found on PATH as this host names it (`npx` is `npx.cmd` on Windows), and
        # started without a shell, as written.
        program = shutil.which(entry["command"], path=environment.get("PATH")) or entry["command"]
        command = [program, *entry.get("args", [])]
        try:
            self.process = subprocess.Popen(
                command, cwd=workspace, env=environment, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, encoding="utf-8",
                errors="replace", bufsize=1)
        except OSError as error:
            raise McpError(f"MCP server {name!r} could not be started: {error}") from error
        self.lines: queue.Queue[str | None] = queue.Queue()
        threading.Thread(target=self._read, daemon=True).start()
        self.next_id = 0
        self.lock = threading.Lock()
        self._request("initialize", {
            "protocolVersion": PROTOCOL_VERSION, "capabilities": {},
            "clientInfo": {"name": "relab", "version": "0.1"}}, START_SECONDS)
        self._send({"jsonrpc": "2.0", "method": "notifications/initialized"})

    def _read(self) -> None:
        assert self.process.stdout is not None
        for line in self.process.stdout:
            self.lines.put(line)
        self.lines.put(None)

    def _send(self, message: dict[str, Any]) -> None:
        assert self.process.stdin is not None
        try:
            self.process.stdin.write(json.dumps(message) + "\n")
            self.process.stdin.flush()
        except OSError as error:
            raise McpError(f"MCP server {self.name!r} stopped: {error}") from error

    def _request(self, method: str, params: dict[str, Any], seconds: float) -> dict[str, Any]:
        with self.lock:
            self.next_id += 1
            asked = self.next_id
            self._send({"jsonrpc": "2.0", "id": asked, "method": method, "params": params})
            while True:
                try:
                    line = self.lines.get(timeout=seconds)
                except queue.Empty as error:
                    raise McpError(f"MCP server {self.name!r} did not answer {method} within "
                                   f"{seconds:.0f} seconds") from error
                if line is None:
                    raise McpError(f"MCP server {self.name!r} stopped before answering {method}")
                try:
                    message = json.loads(line)
                except ValueError:
                    continue  # a line of its own logging, not a message
                if not isinstance(message, dict) or message.get("id") != asked:
                    continue  # a notification, or a request of its own, not taken here
                if "error" in message:
                    refusal = message["error"] if isinstance(message["error"], dict) else {}
                    raise McpError(f"MCP server {self.name!r} refused {method}: "
                                   f"{str(refusal.get('message', 'no reason given'))[:300]}")
                result = message.get("result")
                return result if isinstance(result, dict) else {}

    def tools(self) -> list[McpTool]:
        found: list[McpTool] = []
        cursor = None
        for _ in range(20):
            result = self._request("tools/list", {"cursor": cursor} if cursor else {},
                                   START_SECONDS)
            for item in result.get("tools", []):
                if isinstance(item, dict) and isinstance(item.get("name"), str):
                    schema = item.get("inputSchema")
                    found.append(McpTool(
                        server=self.name, name=item["name"],
                        description=str(item.get("description") or "")[:1000],
                        schema=schema if isinstance(schema, dict) else {}))
            cursor = result.get("nextCursor")
            if not cursor:
                break
        return found

    def call(self, tool: str, arguments: dict[str, Any]) -> tuple[str, bool]:
        """What the tool returned, as text, and whether it worked."""
        result = self._request("tools/call", {"name": tool, "arguments": arguments},
                               CALL_SECONDS)
        parts = []
        for item in result.get("content", []):
            if not isinstance(item, dict):
                continue
            if item.get("type") == "text":
                parts.append(str(item.get("text", "")))
            else:
                parts.append(f"({item.get('type', 'something')} content, not shown)")
        if not parts and "structuredContent" in result:
            parts.append(json.dumps(result["structuredContent"], ensure_ascii=False))
        text = "\n".join(parts)
        if len(text) > MAXIMUM_RESULT:
            text = text[:MAXIMUM_RESULT] + "\n... (cut short)"
        return text, result.get("isError") is not True

    def stop(self) -> None:
        try:
            if self.process.stdin is not None:
                self.process.stdin.close()
            self.process.wait(timeout=3)
        except (OSError, subprocess.TimeoutExpired):
            self.process.kill()

