"""What a command a loop ran verified, if anything, and on which revision of its work (R03, 0.3.0).

A run that succeeded is not a check that passed. `git status`, `echo`, `pwd`
or `python -c "print('ok')"` after a change verify nothing; a test runner that
collected no tests verified nothing either. A run counts as verification when
it is a check: the project's own (`checks_for_this_project`), a test runner, or
a script the loop wrote or a test file -- a reproduction or a smoke run for a
project with no suite. Its verdict comes from its exit and, for test runners,
from what they say they ran; what cannot be told is UNKNOWN, never PASS.

Each verdict is tied to the revision of the work it ran on: the files this loop
changed, by content. Code changed after the run, or while it ran, and the
verdict says nothing about what is there now.
"""

from __future__ import annotations

import hashlib
import json
import posixpath
import re
import secrets
from datetime import datetime
from pathlib import Path, PureWindowsPath

from relab_app.output_check import MODEL_CALL
from relab_app.probe_files import in_scratch
from relab_core.coding_loop import CodingLoop
from relab_core.completion import FindingResult, VerificationEvidence

# The files whose change asks for verification: code, and what configures or
# feeds it (SQL, YAML, settings) -- not only Python (EVI-10).
VERIFIED_SUFFIXES = frozenset({
    ".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java", ".kt", ".rb", ".php",
    ".c", ".h", ".cc", ".cpp", ".hpp", ".cs", ".swift", ".scala", ".sh", ".sql", ".yaml", ".yml",
    ".toml", ".ini", ".cfg", ".json", ".env"})
# What a project's dependencies are defined in: a change there asks for a check too (EVI-04).
DEPENDENCY_FILE = re.compile(r"^(?:requirements[\w.-]*\.txt|constraints[\w.-]*\.txt|Pipfile|Makefile|"
                             r"Dockerfile|setup\.py|setup\.cfg)$", re.IGNORECASE)

# Test runners, by the program and its first arguments.
RUNNERS = (
    ("pytest",), ("py.test",), ("python", "-m", "pytest"), ("python", "-m", "unittest"),
    ("python3", "-m", "pytest"), ("python3", "-m", "unittest"), ("npm", "test"), ("npm", "run", "test"),
    ("yarn", "test"), ("pnpm", "test"), ("go", "test"), ("cargo", "test"), ("mvn", "test"),
    ("gradle", "test"), ("ctest",), ("tox",), ("nox",), ("make", "test"), ("dotnet", "test"),
    ("jest",), ("vitest",), ("node", "--test"), ("npx", "vitest"), ("npx", "jest"))
# What a runner says when it ran nothing: its own summary line, at the start of a line --
# "10 passing" is not "0 passing", and a test that prints the words is not the summary (F3).
RAN_NOTHING = re.compile(r"^[\s=]*(?:no tests ran\b|collected 0 items\b|Ran 0 tests?\b|0 passing\b|"
                         r"No tests (?:found|were found)\b)|\[no test files\]|testing: warning: no tests",
                         re.IGNORECASE | re.MULTILINE)
# What a runner says when it ran some: a count above nought, which outweighs the words above.
RAN_SOME = re.compile(r"(?<![\d.])[1-9]\d* (?:passed|passing)\b|\bRan [1-9]\d* tests?\b|"
                      r"\bcollected [1-9]\d* items?\b|\bTests:\s+[1-9]\d* passed", re.IGNORECASE)
# What a project's checks read besides its code: tests, their configuration, its dependencies (F2).
CHECK_CONFIG = re.compile(r"^(?:pyproject\.toml|setup\.(?:cfg|py)|tox\.ini|pytest\.ini|noxfile\.py|conftest\.py|"
                          r"package(?:-lock)?\.json|yarn\.lock|pnpm-lock\.yaml|tsconfig[\w.-]*\.json|"
                          r"(?:jest|vitest|karma)\.config\.[\w]+|go\.(?:mod|sum)|Cargo\.(?:toml|lock)|"
                          r"Pipfile(?:\.lock)?|poetry\.lock|uv\.lock|Makefile|"
                          r"(?:requirements|constraints)[\w.-]*\.txt)$", re.IGNORECASE)
# A runner's options known to choose nothing -- how it reports, how fast, where it writes -- and
# those of them that take a value. A run is the whole suite only when every word after the
# runner is one of these (0.3.30): read the other way, as a list of options that choose,
# `--deselect=<id>` was not on it, and the run leaving the failing test out stood for the
# whole suite and hid the failure. An option not known, a path or a test id is a part.
QUIET = frozenset({"-q", "-v", "-s", "-x", "-l", "--quiet", "--verbose", "--exitfirst", "--no-header",
                   "--no-summary", "--disable-warnings", "--disable-pytest-warnings", "--ff", "--failed-first",
                   "--strict-markers", "--strict-config", "--showlocals", "--no-cov", "--full-trace"})
QUIET_VALUED = frozenset({"-p", "-n", "-W", "-r", "--tb", "--maxfail", "--log-level", "--log-cli-level",
                          "--basetemp", "--timeout", "--cov", "--cov-report", "--junitxml", "--junit-xml",
                          "--durations", "--import-mode", "--color", "--capture", "--dist", "--numprocesses"})
# Short switches of QUIET run together: `-qx`, `-vv`, `-vs`.
QUIET_SHORT = re.compile(r"^-[qvsxl]+$")
# Checks that read the code's shape and run none of it (EVI-07).
STATIC = frozenset({"mypy", "ruff", "flake8", "pylint", "pyright", "pyflakes", "pycodestyle", "bandit", "black",
                    "isort", "eslint", "tsc", "prettier", "golint", "staticcheck", "clippy", "cargo-clippy"})
# A stand-in for what the code calls, in a test or a script.
MOCKS = re.compile(r"\bunittest\.mock\b|^\s*(?:from|import) mock\b|\bMagicMock\b|\bAsyncMock\b|\bmock\.patch\b|"
                   r"@patch\b|\bpatch\(|\bmonkeypatch\b|\brequests_mock\b|\bresponses\.(?:add|activate)\b|"
                   r"\brespx\b|\bhttpx_mock\b|\bpytest_httpx\b|\bvcr\b|\bjest\.mock\(|\bvi\.mock\(|\bsinon\.|"
                   r"\bnock\(|\bclass \w*(?:Fake|Stub|StandIn|Dummy)\w*", re.MULTILINE)
# The most files read to tell a check's kind.
MAXIMUM_KIND_FILES = 200
# The most files a revision reads besides the ones the loop changed.
MAXIMUM_CHECK_INPUTS = 2000
PYTHONS = frozenset({"python", "python3", "py"})
# A script named as a project's verifier.
VERIFIER = re.compile(r"^(?:check|verify|validate|eval|evaluate|test)[\w-]*\.(?:py|sh)$", re.IGNORECASE)
# A script named as a check of other code, whose exit 0 must be able to mean a failure seen (F5);
# an evaluation script prints its scores, which are read apart (measurements).
CHECKING = re.compile(r"^(?:check|verify|validate|test)[\w-]*\.py$", re.IGNORECASE)
# What lets a script fail on a wrong result, not only by crashing: an assertion, an error raised,
# an exit other than 0, a test framework (F5).
FAILS = re.compile(r"^\s*assert\b|\braise\b|\b(?:sys\.)?exit\(\s*(?!0?\s*\))|\bos\._exit\(|\bunittest\b|"
                   r"\bpytest\b|\.assert\w*\(", re.MULTILINE)
# A file a script names, in quotes: `subprocess.run(["python", "app.py"])`, `open("rules.yaml")`.
NAMED_FILE = re.compile(r"[\"']([\w./\\-]+\.[A-Za-z0-9]{1,5})[\"']")


def _program(argv: list[str]) -> list[str]:
    """The command as compared: the interpreter by its name, not its path -- a Windows
    path too, wherever ReLab runs (on Linux, a Windows venv's python.exe with its
    backslashes was read as one name, 0.3.20)."""
    if not argv:
        return []
    head = PureWindowsPath(argv[0]).name.lower().removesuffix(".exe")
    return [("python" if head in PYTHONS or head.startswith("python") else head), *argv[1:]]


def is_test_runner(argv: list[str]) -> bool:
    words = _program(argv)
    return any(words[:len(prefix)] == list(prefix) for prefix in RUNNERS)


def check_id(words: list[str], cwd: str, shown: str) -> str:
    """A check's identity: the whole command and where it ran, by digest; `shown` only to read it by (F1).

    Two runs of one runner with other selectors (`pytest tests/test_a.py`, `pytest
    tests/test_b.py`), or in other folders, are other checks: one's pass never
    stands for the other's failure. Only the same command run again in the same
    place replaces what it found before.
    """
    place = (cwd or ".").replace("\\", "/").strip("/") or "."
    digest = hashlib.sha256(json.dumps({"command": words, "cwd": place}).encode("utf-8")).hexdigest()[:12]
    return f"verification:{shown[:80]}#{digest}"


def check_of(argv: list[str], *, project_checks: list[list[str]], written: set[str],
             is_test: object, cwd: str = ".") -> tuple[str, str] | None:
    """The check a command is and where it came from, or None when it verifies nothing."""
    words = _program(argv)
    if not words:
        return None
    if any(_program(check) == words for check in project_checks):
        return check_id(words, cwd, " ".join(words)), "project"
    if is_test_runner(argv):
        return check_id(words, cwd, " ".join(words)), "model"
    # A script this loop wrote, or a test file, run by its path: a reproduction or a smoke run.
    if words[0] == "python" and len(words) >= 2 and not words[1].startswith("-"):
        script = words[1].replace("\\", "/").removeprefix("./")
        if script in written or (callable(is_test) and is_test(script)):
            return check_id(words, cwd, script), "model"
        # The project's own verifier by its name: check.py, verify.py, evaluate.py.
        if VERIFIER.match(script.rsplit("/", 1)[-1]):
            return check_id(words, cwd, script), "project"
    return None


def _module_files(text: str, beside: Path, root: Path) -> list[Path]:
    """The project's own Python modules a text imports, one step: where they would be beside it or at the root."""
    found: list[Path] = []
    for match in re.finditer(r"^\s*(?:from\s+([\w.]+)\s+import|import\s+([\w.]+))", text, re.MULTILINE):
        name = (match.group(1) or match.group(2) or "").lstrip(".")
        if not name:
            continue
        parts = name.split(".")
        for base in (beside, root):
            for candidate in (base.joinpath(*parts).with_suffix(".py"), base.joinpath(*parts, "__init__.py")):
                if candidate.is_file() and candidate not in found:
                    found.append(candidate)
    return found


def check_kind(workspace: Path, argv: list[str], cwd: str = ".") -> tuple[str, bool]:
    """What a check is -- static, mock or real -- and whether what it ran calls a service, unstood-in (EVI-07).

    Static: an analyser, which runs none of the code. Else read from the files
    it runs: the test files it names, or the project's tests where it runs, or
    the script; and the project's modules they import, one step. A stand-in in
    any of them (`unittest.mock`, `monkeypatch`, a `Fake...` class) makes it a
    mock check: it says the code works with the stand-in, not with the service.
    Read by its words, so it can be wrong both ways; it never makes a check pass.
    """
    words = _program(argv)
    if not words:
        return "real", False
    head = words[1] if words[0] == "python" and len(words) > 2 and words[1] == "-m" else words[0]
    head = words[2] if head == "-m" else head
    if head in STATIC or (words[0] in ("npx", "pnpm", "yarn") and len(words) > 1 and words[1] in STATIC):
        return "static", False
    root = workspace if cwd in ("", ".") else workspace.joinpath(*cwd.strip("/").split("/"))
    files: list[Path] = []
    named = [word for word in words[1:] if not word.startswith("-") and word not in ("-m",)]
    for word in named:
        where = root.joinpath(*word.replace("\\", "/").split("::", 1)[0].split("/"))
        if where.is_file() and where.suffix in (".py", ".js", ".ts", ".mjs", ".cjs", ".tsx", ".sh"):
            files.append(where)
        elif where.is_dir():
            files += [path for path in sorted(where.rglob("*")) if path.is_file()
                      and path.suffix in (".py", ".js", ".ts") and check_input(path.name)][:MAXIMUM_KIND_FILES]
    if not files and is_test_runner(argv):
        files = [path for path in sorted(root.rglob("*")) if path.is_file()
                 and path.suffix in (".py", ".js", ".ts") and check_input(path.relative_to(root).as_posix())
                 and not any(part in (".venv", "venv", "node_modules", ".git", ".relab") for part in path.parts)
                 ][:MAXIMUM_KIND_FILES]
    texts: list[str] = []
    for path in files[:MAXIMUM_KIND_FILES]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        texts.append(text)
        if path.suffix == ".py":
            for module in _module_files(text, path.parent, root)[:20]:
                try:
                    texts.append(module.read_text(encoding="utf-8", errors="replace"))
                except OSError:
                    continue
    if any(MOCKS.search(text) for text in texts):
        return "mock", False
    return "real", any(MODEL_CALL.search(text) for text in texts)


def script_reach(workspace: Path, argv: list[str], cwd: str = ".", *,
                 is_test: object = None) -> tuple[list[str] | None, bool]:
    """What a script run as a check runs, and whether it can fail on what it finds (F5, 0.3.14).

    A script passes on exit 0 whatever it looks at: `print('ok')` passes. So its
    pass is of the files it runs -- itself, the project's modules it imports (one
    step), the workspace's files it names -- and of no other. A script named as a
    check (`check.py`, `verify.py`, a test file) that asserts nothing, raises
    nothing and never exits other than 0 fails only by crashing: `False`, and its
    exit 0 is no pass. A program run by itself (`python app.py`) stays a smoke run
    of what it runs. Read from its words, so it can be wrong both ways; `None` for
    a check that is not a script.
    """
    words = _program(argv)
    if len(words) < 2 or words[0] != "python" or words[1].startswith("-") or is_test_runner(argv):
        return None, True
    root = workspace if cwd in ("", ".") else workspace.joinpath(*cwd.strip("/").split("/"))
    script = root.joinpath(*words[1].replace("\\", "/").split("/"))
    try:
        text = script.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None, True
    top = workspace.resolve()

    def inside(path: Path) -> str | None:
        try:
            return path.resolve().relative_to(top).as_posix()
        except (OSError, ValueError):
            return None

    found: list[Path] = [script, *_module_files(text, script.parent, root)[:50]]
    for match in NAMED_FILE.finditer(text):
        parts = match.group(1).replace("\\", "/").removeprefix("./").split("/")
        for base in (script.parent, root, workspace):
            candidate = base.joinpath(*parts)
            if candidate.is_file():
                found.append(candidate)
                break
    runs = list(dict.fromkeys(path for path in map(inside, found) if path is not None))[:200]
    named = runs[0] if runs else script.name
    checking = bool(CHECKING.match(script.name)) or (callable(is_test) and bool(is_test(named)))
    return runs, not checking or bool(FAILS.search(text))


def verdict_of(argv: list[str], exit_code: int | None, output: str, *, timed_out: bool) -> tuple[
        FindingResult, str]:
    """A check's verdict and why: what it ran, not only that it ended."""
    if timed_out:
        return FindingResult.UNKNOWN, "stopped at the time limit"
    if exit_code is None:
        return FindingResult.UNKNOWN, "no exit status"
    if is_test_runner(argv) and (exit_code == 5 and _program(argv)[:3] != ["python", "-m", "unittest"]
                                 or (RAN_NOTHING.search(output) and not RAN_SOME.search(output))):
        return FindingResult.UNKNOWN, "it ran no tests"
    if exit_code == 0:
        return FindingResult.PASS, "exit 0"
    return FindingResult.FAIL, f"exit {exit_code}"


def asks_verification(path: str) -> bool:
    """Whether a change to this file asks for a check: code, configuration, dependencies."""
    where = Path(path)
    return where.suffix.lower() in VERIFIED_SUFFIXES or bool(DEPENDENCY_FILE.match(where.name))


def changed_files(loop: CodingLoop) -> list[str]:
    """The files this loop changed that ask for verification, oldest change first."""
    seen: dict[str, None] = {}
    for item in loop.written:
        if asks_verification(item.path):
            seen[item.path] = None
    return list(seen)


def check_input(path: str) -> bool:
    """Whether a file is one a project's checks read besides its code: a test, its configuration, a dependency."""
    name = path.rsplit("/", 1)[-1]
    parts = path.split("/")
    return (bool(CHECK_CONFIG.match(name)) or name.startswith("test_") or name.endswith(("_test.py", ".test.ts",
            ".test.js", ".spec.ts", ".spec.js", "_test.go")) or any(part in ("tests", "test") for part in parts[:-1]))


# What each file held, by its size and times: read again only when those change.
_DIGESTS: dict[str, tuple[tuple[int, int, int], str]] = {}


def _content(where: Path) -> str:
    try:
        stat = where.stat()
    except OSError:
        return "missing"
    key = (stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
    known = _DIGESTS.get(str(where))
    if known is not None and known[0] == key:
        return known[1]
    try:
        digest = hashlib.sha256(where.read_bytes()).hexdigest()
    except OSError:
        return "unreadable"
    if len(_DIGESTS) > 20_000:
        _DIGESTS.clear()
    _DIGESTS[str(where)] = (key, digest)
    return digest


def work_revision(workspace: Path, loop: CodingLoop, inputs: list[str] | tuple[str, ...] = ()) -> str:
    """The revision of this loop's work: the files it changed, and what its checks read, by what they hold now.

    The files it changed, and `inputs`: the project's tests, their
    configuration and its dependency files (F2) -- a test edited outside the
    loop, or a lockfile, makes a check that passed before about other files.
    Documents are not part of it, nor scripts in scratch/ (0.3.20). Never the whole workspace, and each file is
    read again only when its size or times changed. A file gone is part of the
    revision too. The request is not: a check verifies code, and a new request
    about the same code leaves the check standing (what is asked is judged anew).
    """
    digest = hashlib.sha256(b"work-v2")
    changed = {path for path in changed_files(loop) if not in_scratch(path)}
    for path in sorted(changed | set(inputs[:MAXIMUM_CHECK_INPUTS])):
        digest.update(f"\n{path}\0{_content(workspace.joinpath(*path.split('/')))}".encode())
    return "w-" + digest.hexdigest()[:16]


def evidence(*, check_id: str, origin: str, argv: list[str], cwd: str, step: int, before: str, after: str,
             exit_code: int | None, output: str, timed_out: bool, started: datetime,
             finished: datetime, job: str | None = None, stopped: bool = False,
             kind: str = "real", service: bool | None = None, runs: list[str] | None = None,
             can_fail: bool = True) -> VerificationEvidence:
    """The record of one check: its verdict on the revision it ran on, or UNKNOWN if that moved.

    `job`: the job it ran as (EVI-09); `stopped`: ended before it finished -- by the person,
    or gone -- which tells nothing. `runs` and `can_fail`: a script's reach (`script_reach`, F5).
    """
    verdict, why = verdict_of(argv, exit_code, output, timed_out=timed_out)
    if verdict is FindingResult.PASS and not can_fail:
        verdict, why = FindingResult.UNKNOWN, (
            "it checks nothing: it asserts nothing and exits 0 whatever it finds -- assert the result "
            "the request asks for (assert, or exit 1 when it is wrong)")
    if stopped:
        verdict, why = FindingResult.UNKNOWN, "it was stopped before it ended"
    if before != after:
        # The work changed while the check ran (it, or something else, wrote a
        # file it covers): what it says is not about either revision.
        verdict, why = FindingResult.UNKNOWN, "the files changed while it ran"
    return VerificationEvidence(
        evidence_id=f"ev-{secrets.token_hex(6)}", check_id=check_id, source_step=step,
        origin=origin, command=[str(item)[:200] for item in argv[:64]], cwd=cwd[:300],  # type: ignore[arg-type]
        input_revision=before, exit_code=exit_code, source_job=job, kind=kind, service=service,  # type: ignore[arg-type]
        runs=runs,
        state="timed_out" if timed_out else "completed", verdict=verdict,
        summary=why, started_at=started, finished_at=finished)


def covers_file(item: VerificationEvidence, path: str) -> bool:
    """Whether a check ran where a changed file is: in its folder, and not naming another project's paths.

    Run inside a folder, the file is under it; with paths named, read from
    where it ran, one of them is in the file's project -- the first folder of
    its path; a file at the top of the workspace is any run's from there. A
    check naming no path covers what it finds where it ran. A prefix of a path
    is all this says: never that the whole project is right. A script covers the
    files it runs, and only those (F5); another check's file (`test_*.py`,
    `check_*.py`) is a check, not the work, and asks none of it.
    """
    if item.runs is not None:
        name = path.rsplit("/", 1)[-1]
        return path in item.runs or bool(CHECKING.match(name)) or (check_input(path) and not CHECK_CONFIG.match(name))
    base ="" if item.cwd in ("", ".") else item.cwd.rstrip("/")
    if base and not (path == base or path.startswith(f"{base}/")):
        return False
    named = [posixpath.normpath(posixpath.join(base, word.replace("\\", "/"))) for word in item.command[1:]
             if "/" in word.replace("\\", "/") and not word.startswith("-")]
    if not named or "/" not in path:
        return True
    project = path.split("/", 1)[0]
    return any(word.split("/", 1)[0] == project for word in named)


def covers(item: VerificationEvidence, changed: list[str]) -> bool:
    """Whether a check ran where any of the changed files are: not only another project's tests (EVI-03)."""
    return not changed or any(covers_file(item, path) for path in changed)


def whole_suite(words: list[str]) -> bool:
    """Whether a runner's words after its name are known to choose nothing: then it ran the whole suite.

    An option is read in each form it is written in -- `--tb short`, `--tb=short`,
    `-p no:x`, `-pno:x`, `-qx` -- and one not known to choose nothing is taken as
    choosing: being wrong that way keeps a failure standing until the same check
    passes, the other way it hides one (0.3.30).
    """
    rest = iter(words)
    for word in rest:
        if word in QUIET or QUIET_SHORT.match(word):
            continue
        if word in QUIET_VALUED:
            if next(rest, None) is None:
                return False
            continue
        name, equals, _ = word.partition("=")
        if equals and name.startswith("--") and name in QUIET_VALUED:
            continue
        if not word.startswith("--") and len(word) > 2 and word[:2] in QUIET_VALUED:
            continue
        return False
    return True


def _suite(item: VerificationEvidence) -> tuple[tuple[str, ...], str, bool] | None:
    """A test runner's run as (the runner, where, whether it ran the whole suite): None for other checks."""
    words = _program(list(item.command))
    prefix = next((runner for runner in RUNNERS if words[:len(runner)] == list(runner)), None)
    if prefix is None:
        return None
    return prefix, item.cwd or ".", whole_suite(words[len(prefix):])


def standing(loop: CodingLoop, revision: str) -> list[VerificationEvidence]:
    """The latest verdict of each check on this revision of the work, where the work is.

    Each check by its identity (F1): another check's pass never hides one's
    failure. A run of the same runner in the same place known to choose
    nothing (`whole_suite`) -- the whole suite -- stands for the selected runs
    before it: it ran them. Any doubt, and it stands for nothing but itself.
    """
    changed = changed_files(loop)
    latest: dict[str, VerificationEvidence] = {}
    for item in loop.verifications:
        if item.input_revision != revision or not covers(item, changed):
            continue
        suite = _suite(item)
        if suite is not None and suite[2]:
            for key in [key for key, kept in latest.items()
                        if (found := _suite(kept)) is not None and found[:2] == suite[:2]]:
                del latest[key]
        latest[item.check_id] = item
    return list(latest.values())


def uncovered(found: list[VerificationEvidence], changed: list[str]) -> list[str]:
    """The changed files no passing check ran on: each needs one of its own (F2)."""
    passed = [item for item in found if item.verdict is FindingResult.PASS]
    return [path for path in changed if not any(covers_file(item, path) for item in passed)]


# A "Not done:" that leaves nothing: "nothing", "none", "-", "없음".
NOTHING_LEFT = re.compile(r"^(?:nothing|none|n/?a|nil|no|-+|\u2014|\uc5c6\uc74c|\uc5c6\uc2b5\ub2c8\ub2e4|\ud574\ub2f9\s*\uc5c6\uc74c)"
                          r"(?:\s+(?:left|remaining|else|outstanding))?[.!]?$", re.IGNORECASE)
SECTION = re.compile(r"^\s*(?:[-*]\s*)?(Changed|Ran|Not done|Next)\s*:\s*(.*)$", re.IGNORECASE)


def left_undone(summary: str) -> str | None:
    """What the summary says under "Not done:", when it says something is left (FIN-11)."""
    said: list[str] = []
    inside = False
    for line in summary.splitlines():
        heading = SECTION.match(line)
        if heading is not None:
            inside = heading.group(1).lower() == "not done"
            if inside and heading.group(2).strip():
                said.append(heading.group(2).strip())
            continue
        if inside and line.strip():
            said.append(line.strip().lstrip("-* ").strip())
    text = "; ".join(item for item in said if item and not NOTHING_LEFT.match(item))
    return text[:1000] or None
