"""What a loop's record says of its files, against what the files hold (RL-09).

Split out of `CodingLoopService`: settling a write a process ended in the
middle of, finding files changed since the loop wrote them (RL-06), showing a
file as it was on one side of the loop, and putting files back -- every file,
one file, one change, or everything after a checkpoint. Each of these reads
the record and the snapshot store and touches nothing else of a running loop,
so none needs the service's state: only the workspace, the store, a way to
save the record, and the rule for a path that may be written.

The rule throughout: a file is put back only when it holds what the record
says the loop left there. Somebody's work since is kept, and said.
"""

import difflib
import hashlib
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path

from relab_core.coding_loop import CodingLoop, FileChange, LoopOutcome, Revert, WrittenFile
from relab_workspace.snapshot_store import SnapshotStore


def counted(before: bytes | None, after: bytes) -> tuple[int | None, int | None]:
    """Lines added and removed between two versions of a text file; None when not text."""
    try:
        old = (before or b"").decode("utf-8").splitlines()
        new = after.decode("utf-8").splitlines()
    except UnicodeDecodeError:
        return None, None
    added = removed = 0
    for line in difflib.unified_diff(old, new, lineterm="", n=0):
        if line.startswith("+") and not line.startswith("+++"):
            added += 1
        elif line.startswith("-") and not line.startswith("---"):
            removed += 1
    return added, removed


class LoopFiles:
    def __init__(self, workspace: Path, snapshots: SnapshotStore,
                 save: Callable[[CodingLoop], None], writable: Callable[[str], Path]) -> None:
        self.workspace = workspace
        self.snapshots = snapshots
        self.save = save
        self.writable = writable

    def digest_of(self, path: str) -> str | None:
        """The digest of what a workspace file holds now; None when it is not there."""
        target = self.workspace.joinpath(*path.split("/"))
        try:
            return hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
        except OSError:
            return None

    # --- taking a loop up again (RL-06) ---------------------------------------------------------

    def settle(self, loop: CodingLoop) -> None:
        """Finish recording a write the process ended in the middle of, or drop it."""
        pending = loop.pending_write
        if pending is None:
            return
        loop.pending_write = None
        now = self.digest_of(pending.path)
        data = self.snapshots.get(pending.after_digest)
        if now == pending.after_digest and now != pending.just_before and data is not None:
            previous = (self.snapshots.get(pending.just_before) or b""
                        if pending.just_before is not None else b"")
            first = (self.snapshots.get(pending.before_digest) or b""
                     if pending.before_digest is not None else b"")
            added, removed = counted(first, data)
            loop.written = [item for item in loop.written if item.path != pending.path] + [
                WrittenFile(path=pending.path, before_digest=pending.before_digest,
                            after_digest=pending.after_digest, added=added, removed=removed)]
            step_added, step_removed = counted(previous, data)
            loop.changes.append(FileChange(
                change_id=len(loop.changes) + 1, step=pending.step, path=pending.path,
                before_digest=pending.just_before, after_digest=pending.after_digest,
                added=step_added, removed=step_removed))
        self.save(loop)

    def drifted(self, loop: CodingLoop) -> list[str]:
        """The files this loop wrote that hold something else now, said as such."""
        found = []
        for item in loop.written:
            now = self.digest_of(item.path)
            if now == item.after_digest:
                continue
            found.append(f"{item.path}: removed" if now is None
                         else f"{item.path}: changed since it was written")
        return found[:50]

    # --- one side of a file ---------------------------------------------------------------------

    def side(self, loop: CodingLoop, path: str, side: str) -> tuple[bool, str]:
        """What a file the loop wrote held before its first write, or after its last.

        From the record, never the workspace: a file changed since would show
        today's text as the loop's, and be most wrong exactly when somebody
        looks. Returns whether it existed on that side, and its text.
        """
        if side not in ("before", "after", "now", "proposed"):
            raise ValueError("side is before, after, now or proposed")
        if side in ("now", "proposed"):
            # The change a loop waits on: what the file holds, and what it would.
            held = loop.review
            if held is None or held.path != path:
                raise LookupError(f"{loop.loop_id} is not waiting on a change to {path!r}")
            digest = held.before_digest if side == "now" else held.after_digest
        else:
            item = next((entry for entry in loop.written if entry.path == path), None)
            if item is None:
                raise LookupError(f"{loop.loop_id} did not write {path!r}")
            digest = item.before_digest if side == "before" else item.after_digest
        if digest is None:
            return False, ""
        content = self.snapshots.get(digest)
        if content is None:
            raise LookupError(f"the {side} of {path!r} is no longer kept")
        try:
            return True, content.decode("utf-8")
        except UnicodeDecodeError as error:
            raise ValueError(f"{path!r} is not UTF-8 text") from error

    # --- putting back ---------------------------------------------------------------------------

    def undo(self, loop: CodingLoop) -> tuple[list[str], list[str]]:
        """Put every file the loop wrote back as it was; never a file changed since.

        Returns what was restored and what was left because it no longer holds
        what the loop wrote -- somebody's work since, which undo does not erase.
        """
        restored, kept = [], []
        for item in loop.written:
            if self.put_back(item.path, item.after_digest, item.before_digest):
                restored.append(item.path)
            else:
                kept.append(item.path)
        # `written` is left as it was: an undone loop still says what it had
        # changed, and its outcome says that it was undone.
        for change in loop.changes:
            if change.path in restored:
                change.reverted = True
        if restored and not kept:
            loop.outcome = LoopOutcome.UNDONE
        self.record_revert(loop, "loop", restored, kept)
        return restored, kept

    def revert_file(self, loop: CodingLoop, path: str) -> tuple[list[str], list[str]]:
        """Put one file the loop wrote back as it was before the loop; never one changed since."""
        item = next((item for item in loop.written if item.path == path), None)
        if item is None:
            raise ValueError(f"loop {loop.loop_id} has no change to {path!r} left to put back")
        restored, kept = [], []
        if self.put_back(path, item.after_digest, item.before_digest):
            restored.append(path)
            for change in loop.changes:
                if change.path == path:
                    change.reverted = True
            loop.written = [other for other in loop.written if other.path != path]
        else:
            kept.append(path)
        self.record_revert(loop, f"file:{path}", restored, kept)
        return restored, kept

    def revert_change(self, loop: CodingLoop, change_id: int) -> tuple[list[str], list[str]]:
        """Put back one change, when it is the latest to its file and the file still holds it.

        A change with later ones on top of it is not taken out from under them:
        those are put back first, or the file is returned to a checkpoint.
        """
        change = next((item for item in loop.changes if item.change_id == change_id), None)
        if change is None or change.reverted:
            raise ValueError(f"loop {loop.loop_id} has no change {change_id} left to put back")
        later = [item.change_id for item in loop.changes
                 if item.path == change.path and item.change_id > change_id and not item.reverted]
        if later:
            raise ValueError(f"change {change_id} has later changes to {change.path} on top of "
                             f"it ({', '.join(str(item) for item in later)}); put those back "
                             f"first, or return to a checkpoint")
        restored, kept = [], []
        if self.put_back(change.path, change.after_digest, change.before_digest):
            change.reverted = True
            restored.append(change.path)
            self.rewritten(loop, change.path, change.before_digest)
        else:
            kept.append(change.path)
        self.record_revert(loop, f"change:{change_id}", restored, kept)
        return restored, kept

    def revert_to_checkpoint(self, loop: CodingLoop,
                             checkpoint_id: int) -> tuple[list[str], list[str]]:
        """Put every file back as it was at a checkpoint; never one changed since.

        Each file is put back or kept on its own: one somebody changed since is
        left, and said, while the others go back.
        """
        point = next((item for item in loop.checkpoints if item.checkpoint_id == checkpoint_id),
                     None)
        if point is None:
            raise ValueError(f"loop {loop.loop_id} has no checkpoint {checkpoint_id}")
        since: dict[str, list[FileChange]] = {}
        for change in loop.changes:
            if change.change_id > point.changes and not change.reverted:
                since.setdefault(change.path, []).append(change)
        restored, kept = [], []
        for path, changes in since.items():
            first, last = changes[0], changes[-1]
            if self.put_back(path, last.after_digest, first.before_digest):
                for change in changes:
                    change.reverted = True
                restored.append(path)
                self.rewritten(loop, path, first.before_digest)
            else:
                kept.append(path)
        self.record_revert(loop, f"checkpoint:{checkpoint_id}", restored, kept)
        return restored, kept

    def put_back(self, path: str, expected: str, content_digest: str | None) -> bool:
        """Make `path` hold `content_digest` (or not exist), if it holds `expected` now."""
        target = self.writable(path)
        current = (hashlib.sha256(target.read_bytes()).hexdigest()
                   if target.is_file() else None)
        if current != expected:
            return False
        if content_digest is None:
            target.unlink()
            return True
        content = self.snapshots.get(content_digest)
        if content is None:
            return False
        target.write_bytes(content)
        return True

    def rewritten(self, loop: CodingLoop, path: str, holds: str | None) -> None:
        """What the loop's `written` says of a file after part of its changes were put back."""
        item = next((item for item in loop.written if item.path == path), None)
        if item is None:
            return
        if holds == item.before_digest or holds is None:
            # Back where the loop found it -- or, for a file the loop's first
            # change created, gone again: nothing of the loop's is left in it.
            loop.written = [other for other in loop.written if other.path != path]
            return
        content = self.snapshots.get(holds) or b""
        added, removed = counted(
            self.snapshots.get(item.before_digest) if item.before_digest is not None else b"",
            content)
        loop.written = [other if other.path != path else other.model_copy(update={
            "after_digest": holds, "added": added, "removed": removed})
            for other in loop.written]

    def record_revert(self, loop: CodingLoop, target: str, restored: list[str],
                      kept: list[str]) -> None:
        loop.reverts.append(Revert(target=target, restored=restored, kept=kept,
                                   at=datetime.now(timezone.utc)))
        self.save(loop)
