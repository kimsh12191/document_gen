"""When a loop that only reads is told so, and when it is stopped (R08, 0.3.0).

One place for the numbers and the words, so what the model is told and when
the loop stops come from the same rule. Reading what the request needs is
progress -- a file not read before, other lines of it, a version that
changed -- and a long analysis that keeps finding new ground is not told to
stop. Going over the same ground -- the same file and lines at the same
version -- is not progress: past `READING_STALL` steps of it in a row the loop
stops, and past `READING_CAP` read-only steps it stops whatever they read.
The model-call and time budgets are apart from this and unchanged.
"""

# Read-only steps in a row before the model is told how reading stands (a note, not a stop).
READING_NUDGE = 16
# Read-only steps in a row, going over the same ground, after which the loop stops.
READING_STALL = 40
# Read-only steps in a row after which the loop stops, new ground or not.
READING_CAP = 2 * READING_STALL


def reading_note(reading: int, rereading: bool) -> str | None:
    """What the model is told after `reading` read-only steps in a row; None before the nudge."""
    if reading < READING_NUDGE:
        return None
    if rereading:
        return (f"the last {reading} steps only read, and much of it had been read before, as it is. "
                f"Act on what you have -- the report for an analysis, the change for a fix -- or read "
                f"what is still missing. At {READING_STALL} in a row over the same ground, or "
                f"{READING_CAP} read-only steps in all, the loop stops")
    return (f"the last {reading} steps only read. Reading what the request needs is progress; "
            f"once you have it, act on it -- the report for an analysis, the change for a fix. "
            f"At {READING_STALL} in a row over the same ground, or {READING_CAP} read-only steps "
            f"in all, the loop stops")


def reading_stop(reading: int, rereading: bool) -> str | None:
    """Why the loop stops before its next call, or None: from the same numbers as the note."""
    if reading >= READING_CAP or (reading >= READING_STALL and rereading):
        return (f"stopped: {reading} steps in a row only read, and nothing was written or run. "
                f"Say more precisely what to build, or limit what it may read")
    return None
