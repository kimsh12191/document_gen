"""Reading an arm's case for being retasked, and turning an answer into a change.

Two things live here. What a stuck arm's situation is, read from records and
judged nowhere. And how a proposal about one arm becomes an amendment to a whole
plan -- which is where the other arms are protected.
"""

from pathlib import Path

from relab_app.repair import RepairMemory
from relab_app.sessions import ResearchSessionService
from relab_core.next_action import ProposedAmendment
from relab_core.replan import (
    MAXIMUM_TRIED,
    OUTPUT_TAIL_CHARACTERS,
    ProposedRetask,
    StuckArm,
    TriedApproach,
)
from relab_core.research import ResearchPlan


class ReplanReader:
    """Why an arm is stuck, in the shape an advisor is allowed to see."""

    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.memory = RepairMemory(self.workspace)
        self.sessions = ResearchSessionService(self.workspace)

    def stuck(self, session_id: str, arm: str) -> StuckArm | None:
        """The arm's case for a different task, or None when it does not have one.

        None covers three different situations that need no distinguishing here:
        the arm is not stuck, the plan never declared a task for it, or it has
        failed only in ways that were never fingerprinted.
        """
        history = self.memory.history(session_id, arm)
        digest = history.stuck_on
        if digest is None:
            return None
        plan = self.sessions.store.latest(session_id).snapshot.plan
        declared = None if plan is None else next(
            (item for item in plan.arm_tasks if item.arm == arm), None)
        if declared is None:
            return None
        same = history.matching(digest)
        last = same[-1].fingerprint
        return StuckArm(
            session_id=session_id, arm=arm, objective=declared.objective,
            targets=list(declared.targets), repeated=len(same),
            # The normalised text when there is one; a digest is still an answer
            # to "the same failure as what", just a less readable one.
            failure_signature=(last.signature if last is not None and last.signature
                               else digest),
            failure_detail=self._detail(same[-1].run_id),
            tried=[TriedApproach(run_id=item.run_id, patch_digest=item.patch_digest,
                                 reason=item.reason)
                   for item in history.attempts[-MAXIMUM_TRIED:]])

    def _detail(self, run_id: str) -> str:
        """What the verifier actually wrote, bounded the way a repair note is.

        The signature beside it has had paths and line numbers normalised away so
        that two runs of one fault compare equal. That is what it is for, and it
        is why it cannot be the only thing an advisor sees: a file named in a
        traceback is exactly the sort of thing normalisation removes and a
        proposal needs.
        """
        run = self.memory.runs.load(run_id)
        evidence = run.patch_evidence
        verification = None if evidence is None else evidence.verification
        if verification is None:
            return ""
        said = [f"{name}:\n{text[-OUTPUT_TAIL_CHARACTERS:].strip()}"
                for name, text in (("stdout", verification.stdout),
                                   ("stderr", verification.stderr))
                if text.strip()]
        return "\n".join(said)


def amendment_for(plan: ResearchPlan, retask: ProposedRetask) -> ProposedAmendment:
    """The retask as a change to this plan, with every other arm carried unchanged.

    `ProposedAmendment.arm_tasks` replaces the whole list, so a proposal about one
    arm that was passed straight through would silently withdraw the tasks of
    every arm it did not mention -- leaving them declared but unexecutable. The
    merge happens here, against the recorded list, so that cannot be expressed by
    whoever answered rather than merely being refused afterwards.
    """
    declared = next((item for item in plan.arm_tasks if item.arm == retask.arm), None)
    if declared is None:
        raise ValueError(f"the plan declares no task for arm {retask.arm!r}")
    changes: dict[str, object] = {"objective": retask.objective}
    if retask.targets is not None:
        changes["targets"] = list(retask.targets)
    changed = declared.model_copy(update=changes)
    if changed == declared:
        raise ValueError("a retask that changes nothing is not a retask")
    return ProposedAmendment(
        rationale=retask.rationale,
        # Carried, not re-derived. The model that wrote the objective is the one
        # this change is about, and losing that here would leave the record able
        # to say a plan was revised and not by whose words.
        proposed_by=retask.proposed_by,
        arm_tasks=[changed if item.arm == retask.arm else item for item in plan.arm_tasks])
