"""Reading a page of documentation from the web, for a coding loop that needs one.

A loop asked to call an API it had not seen -- OpenRouter's, a library's --
could only guess at it. This reads one page: an `http` or `https` GET, with no
credentials, bounded in time and size, of text (HTML, plain text, Markdown,
JSON), turned into plain text. It writes nothing and runs nothing; whether a
site may be read is the person's, asked like a command and kept, if they say
so, as a rule for that site (`fetch <host>`).
"""

import html
import json
import re
from html.parser import HTMLParser
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

FETCH_SECONDS = 20
FETCH_BYTES = 1_000_000
TEXT_TYPES = ("text/", "application/json", "application/xml", "application/xhtml")


def host_of(url: str) -> str:
    return (urlsplit(url).hostname or "").lower()


def check_url(url: str) -> str | None:
    """Why this is not a URL a loop may read, or None."""
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https"):
        return "only http and https pages are read"
    if not parts.hostname:
        return "the URL names no host"
    if parts.username or parts.password:
        return "a URL with a user or password in it is not read"
    return None


def fetch(url: str) -> tuple[str, bool]:
    """The page as text, said with what it was; and whether it was read."""
    wrong = check_url(url)
    if wrong is not None:
        return f"not read: {wrong}", False
    request = Request(url, headers={"User-Agent": "ReLab coding loop (reads documentation)",
                                    "Accept": "text/html,text/plain,text/markdown,application/json"})
    try:
        with urlopen(request, timeout=FETCH_SECONDS) as response:
            kind = response.headers.get("Content-Type", "")
            if not any(kind.lower().startswith(item) for item in TEXT_TYPES):
                return f"not read: {url} is {kind or 'of no stated type'}, not text", False
            data = response.read(FETCH_BYTES + 1)
            status = getattr(response, "status", 200)
    except HTTPError as error:
        return f"not read: {url} answered HTTP {error.code}", False
    except (URLError, OSError, ValueError) as error:
        return f"not read: {url} could not be reached ({type(error).__name__})", False
    cut = len(data) > FETCH_BYTES
    charset = re.search(r"charset=([\w-]+)", kind)
    text = data[:FETCH_BYTES].decode(charset[1] if charset else "utf-8", errors="replace")
    if "html" in kind.lower():
        text = _text_of_html(text)
    elif "json" in kind.lower():
        try:
            text = json.dumps(json.loads(text), indent=1, ensure_ascii=False)
        except ValueError:
            pass
    head = f"{url} (HTTP {status}, {kind.split(';')[0]}, {len(text)} characters" \
           f"{', cut at 1 MB' if cut else ''})"
    return f"{head}\n{text}", True


class _Text(HTMLParser):
    """The words of a page, its blocks on their own lines; no scripts, no styles."""

    SKIP = frozenset({"script", "style", "noscript", "svg", "head"})
    BLOCKS = frozenset({"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "pre", "section",
                        "article", "header", "footer", "table", "ul", "ol", "dt", "dd", "blockquote"})

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skipping = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self.SKIP:
            self.skipping += 1
        elif tag in self.BLOCKS:
            self.parts.append("\n")
        if tag in ("h1", "h2", "h3", "h4"):
            self.parts.append("#" * int(tag[1]) + " ")

    def handle_endtag(self, tag: str) -> None:
        if tag in self.SKIP and self.skipping:
            self.skipping -= 1
        elif tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self.skipping:
            self.parts.append(data)


def _text_of_html(page: str) -> str:
    parser = _Text()
    parser.feed(page)
    text = html.unescape("".join(parser.parts))
    lines = [" ".join(line.split()) for line in text.splitlines()]
    return "\n".join(line for line in lines if line)
