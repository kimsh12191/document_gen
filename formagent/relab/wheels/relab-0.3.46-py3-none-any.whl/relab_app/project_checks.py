"""The commands that check a project, read from what the project declares.

Until now the model chose its own check: the prompt suggested `python -m
pytest`, and a finish was refused only while nothing had run since the last
change. A project says how it is checked -- a tests folder or pytest settings,
`scripts.test` in package.json, a go.mod, a Cargo.toml -- and reading that is a
rule, not a judgement, so it is done here, by rule, and offered: the loop is
told the commands, and the `run_checks` skill runs them.

Only what the command policy runs without asking is offered (`classify`): a
check that would need a person's approval is not a check this can promise.
Nothing is run here.
"""

import json
import re
from pathlib import Path

from relab_app.command_policy import CommandClass, classify
from relab_core.contracts import Contract

# A package.json script, as `npm test` or `npm run <name>`.
NODE_SCRIPTS = ("test", "typecheck", "lint", "check")
# npm's placeholder for a project with no tests.
NO_TEST = "no test specified"
PYTEST_FILES = ("pytest.ini", "tox.ini", "setup.cfg", "conftest.py")
MAXIMUM_CHECKS = 6


class ProjectCheck(Contract):
    """One command that checks a project, and what in the project says so."""

    argv: list[str]
    why: str


def find_checks(workspace: Path, folder: str | None, python: str) -> list[ProjectCheck]:
    """The checks `folder` (relative to `workspace`; None: the workspace) declares."""
    root = workspace.resolve()
    home = (root / folder).resolve() if folder else root
    if not home.is_relative_to(root) or not home.is_dir():
        return []
    found = [*_python(home, python), *_node(home), *_other(home)]
    kept: list[ProjectCheck] = []
    for check in found:
        kind, _ = classify(check.argv, python, home)
        if kind is CommandClass.RUN and check.argv not in [held.argv for held in kept]:
            kept.append(check)
    return kept[:MAXIMUM_CHECKS]


def shown(argv: list[str], python: str) -> str:
    """A check as a person reads it: `python -m pytest -q`, whatever the interpreter's path."""
    return " ".join(["python" if index == 0 and part == python else part
                     for index, part in enumerate(argv)])


def _tools(path: Path) -> set[str]:
    """The `[tool.X]` tables a pyproject.toml has, by their headers.

    Headers only, not TOML: Python 3.10, the oldest this runs on, reads no
    TOML without a dependency, and a header is all this needs to know.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return set()
    return set(re.findall(r"^\s*\[\[?\s*tool\.([A-Za-z0-9_-]+)", text, flags=re.MULTILINE))


def _python(home: Path, python: str) -> list[ProjectCheck]:
    tool = _tools(home / "pyproject.toml")
    checks = []
    why = None
    if "pytest" in tool:
        why = "pyproject.toml has [tool.pytest]"
    elif any((home / name).is_file() for name in PYTEST_FILES):
        why = next(f"{name} is here" for name in PYTEST_FILES if (home / name).is_file())
    elif any(next((home / name).glob("**/*.py"), None) is not None
             for name in ("tests", "test") if (home / name).is_dir()):
        # With Python in it: `test/` beside a package.json holds a Node project's tests.
        why = "a tests folder with Python in it is here"
    elif any(home.glob("test_*.py")) or any(home.glob("*_test.py")):
        why = "test files are here"
    if why is not None:
        checks.append(ProjectCheck(argv=[python, "-m", "pytest", "-q"], why=why))
    if "ruff" in tool:
        checks.append(ProjectCheck(argv=[python, "-m", "ruff", "check", "."],
                                   why="pyproject.toml has [tool.ruff]"))
    if "mypy" in tool:
        checks.append(ProjectCheck(argv=[python, "-m", "mypy", "."],
                                   why="pyproject.toml has [tool.mypy]"))
    return checks


def _node(home: Path) -> list[ProjectCheck]:
    try:
        package = json.loads((home / "package.json").read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, ValueError):
        return []
    scripts = package.get("scripts") if isinstance(package, dict) else None
    if not isinstance(scripts, dict):
        return []
    checks = []
    for name in NODE_SCRIPTS:
        script = scripts.get(name)
        if not isinstance(script, str) or not script.strip() or NO_TEST in script:
            continue
        argv = ["npm", "test"] if name == "test" else ["npm", "run", name]
        checks.append(ProjectCheck(argv=argv, why=f"package.json has scripts.{name}"))
    return checks


def _other(home: Path) -> list[ProjectCheck]:
    checks = []
    if (home / "go.mod").is_file():
        checks.append(ProjectCheck(argv=["go", "test", "./..."], why="go.mod is here"))
    if (home / "Cargo.toml").is_file():
        checks.append(ProjectCheck(argv=["cargo", "test"], why="Cargo.toml is here"))
    return checks
