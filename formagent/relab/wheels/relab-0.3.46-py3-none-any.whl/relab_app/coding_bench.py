"""How well the coding loop codes, measured on a fixed suite of tasks.

Each task is a folder:

    task.json   what to ask, and how an unattended run answers the loop
    repo/       the workspace the loop starts in
    check/      acceptance tests the loop never sees, copied in after it ends

A run copies `repo/` into a fresh folder, works the request through with
nobody there -- a plan is approved, a question gets the task's answer, a
command that asks is allowed only if the task says so -- then copies `check/`
in and runs it. Solved means those tests passed; the loop's own "finished" is
recorded beside it and never counted as solved.

`task.json`:

    {"id": "fix_pagination", "kind": "bug_fix",
     "request": "page 2 repeats the last item of page 1; fix it",
     "scope": null,                  # project folder, when the task has one;
                                     # "." the whole workspace, not inferred
     "check_root": ".",              # where the check runs, inside the workspace
     "answer": "...",                # given to every question (optional)
     "allow_commands": false,        # allow a command the loop asks to run
     "max_steps": 24}

Nothing here contacts a provider by itself: the gateway is the caller's, and
a run spends that model's calls. That is the person's to start.
"""

import json
import re
import shutil
import statistics
import tempfile
import time
from collections.abc import Callable, Iterable
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from threading import Condition, Lock

from pydantic import Field

from relab_app.code_map import outline
from relab_app.coding_loop import (
    CONTEXT_OUTLINE,
    DEFAULT_STEPS,
    MAXIMUM_LISTED,
    MAXIMUM_STEPS,
    CodingLoopService,
    ModelLadder,
)
from relab_app.lessons import FAILURE_HEADER, LessonStore, evaluated, failure_statements
from relab_app.project_scope import WHOLE_WORKSPACE
from relab_core.coding_loop import CodingLoop, LoopActionKind, LoopOutcome
from relab_core.contracts import Contract
from relab_core.generation import (
    ChatGateway,
    MessageGateway,
    ModelGateway,
    ToolGateway,
    ToolReply,
)
from relab_workspace.patcher import Patcher
from relab_workspace.private_state import state_dir
from relab_workspace.runtime_readiness import host_python_command

CHECK_FOLDER = "_bench_check"
CHECK_SECONDS = 300.0
# What a run keeps of how its loop went.
ENDED_CHARACTERS = 2000
# What a hidden check's output keeps: its first failure, and its end.
CHECK_HEAD = 1600
CHECK_TAIL = 1000
# Other failures kept beside the first, a header and an error line each.
OTHER_FAILURES = 8
TRACE_STEPS = 80
TRACE_OBSERVATION = 200
TRACE_WRITTEN = 300
# A run that keeps waiting -- a question after a question -- ends here.
MAXIMUM_LEGS = 6
# How long one task may take, in all its legs, unless the run says otherwise:
# one task once took 59 minutes of a three-hour suite.
TASK_SECONDS = 900.0
# Tasks run at once, at most.
MAXIMUM_JOBS = 16
UNATTENDED = ("Nobody is here to answer: this is an unattended run. Choose what the "
              "request and the workspace suggest, say in the summary what you chose, and go on.")


class BenchTask(Contract):
    id: str = Field(pattern=r"^[a-z0-9_]{1,64}$")
    kind: str = Field(min_length=1, max_length=40)
    # What ability it measures: locate, modify, build, debug, maintain or
    # long_horizon -- so a weakness shows as a category, not one task.
    category: str | None = Field(default=None, min_length=1, max_length=40)
    request: str = Field(min_length=1, max_length=8000)
    scope: str | None = Field(default=None, min_length=1, max_length=260)
    check_root: str = Field(default=".", min_length=1, max_length=260)
    answer: str | None = Field(default=None, min_length=1, max_length=2000)
    allow_commands: bool = False
    max_steps: int = Field(default=DEFAULT_STEPS, ge=1, le=MAXIMUM_STEPS)
    # For scoring how the loop found its way, never shown to it (a run copies
    # repo/ alone): the files that lead to the answer, and those it changes.
    relevant_files: list[str] = Field(default_factory=list, max_length=64)
    must_modify: list[str] = Field(default_factory=list, max_length=64)


class Navigation(Contract):
    """How a run found its way, counted from its loop's steps: no model judges it.

    Steps are counted by their place in the loop, not by time, which a slow
    provider would move. The files read are the main loop's own reads; what an
    `explore` helper read is in its report, counted as one explore call here.
    """

    search_calls: int = Field(ge=0)
    list_calls: int = Field(ge=0)
    outline_calls: int = Field(ge=0)
    explore_calls: int = Field(ge=0)
    # The `references` step (M5.5): counted as a search when deciding whether it helped.
    references_calls: int = Field(default=0, ge=0)
    files_read: int = Field(ge=0)
    # The step (1-based) that first read or changed a relevant file; None if none did.
    first_relevant_step: int | None = Field(default=None, ge=1)
    steps_before_first_edit: int | None = Field(default=None, ge=0)
    files_modified: list[str] = Field(default_factory=list)
    # With the task's relevant_files and must_modify; empty without them.
    relevant_files_read: int = Field(default=0, ge=0)
    irrelevant_files_read: int = Field(default=0, ge=0)
    must_modify_missed: list[str] = Field(default_factory=list)
    unnecessary_files_modified: list[str] = Field(default_factory=list)
    # Whether the file list and the outline every call carries were cut short
    # in this workspace: when they were not, the answer may have been on the
    # page from the start.
    listing_cut: bool | None = None
    outline_cut: bool | None = None


class BenchRun(Contract):
    """One task, worked once."""

    task: str
    kind: str
    category: str | None = None
    repeat: int = Field(ge=1)
    solved: bool
    outcome: str
    loop_id: str | None = None
    steps: int = Field(ge=0)
    refused_steps: int = Field(ge=0)
    legs: int = Field(ge=0)
    model_calls: int = Field(ge=0)
    prompt_characters: int = Field(ge=0)
    reply_characters: int = Field(ge=0)
    # From the provider, when it reports them.
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    retries: int = Field(ge=0)
    seconds: float = Field(ge=0)
    check_exit: int | None = None
    check_output: str = ""
    # Whether the loop's replies came as native tool calls.
    tool_calls: bool | None = None
    # Why the run could not be scored, when it could not.
    error: str | None = None
    # Served from the provider's cache, and what the run cost, as reported.
    cached_tokens: int | None = None
    cost: float | None = None
    # Time to the first streamed token, mean and slowest, over the run's turn
    # calls; None where nothing streamed (RL-02).
    first_token_mean_s: float | None = None
    first_token_max_s: float | None = None
    # How the loop ended, in its own words: the model's summary, or ReLab's
    # sentence on why it stopped.
    ended: str | None = None
    # For a run not solved, or one whose loop did not finish: each step, one
    # line, with what it wrote -- enough to see what went wrong without the
    # workspace, which a run without --work does not keep.
    trace: list[str] = Field(default_factory=list)
    # With a model ladder: the moves up it made ("a -> b: reason"), and the
    # model working the task when it ended.
    model_changes: list[str] = Field(default_factory=list)
    final_model: str | None = None
    # Run again because the provider failed it (--retry-provider-failures).
    reruns: int = Field(default=0, ge=0)
    # How it found its way, for every run (M5.5), and for a task that says
    # what is relevant, why one not solved missed: see `locate_class`.
    navigation: Navigation | None = None
    locate: str | None = None
    # ReLab's own verdict on the run (R10), apart from the hidden check that scores it:
    # how the task and its verification stood, and whether ReLab counted it a success.
    task_status: str | None = None
    verification_status: str | None = None
    verified: bool | None = None
    # What a prompt comparison reads of a run (R09 11.4-11.5, 0.3.5): the condition
    # it ran under and its instruction as sent (by digest), the tools' schemas and the
    # policy's profile; the model call that made the first change that held; how many
    # times a finish was held back; files written that neither the task names nor a
    # test or a document is; whether the provider reported cached tokens at all.
    condition: str | None = Field(default=None, max_length=20)
    instruction: str | None = Field(default=None, max_length=40)
    instruction_digest: str | None = Field(default=None, max_length=64)
    tools_digest: str | None = Field(default=None, max_length=64)
    profile: str | None = Field(default=None, max_length=40)
    first_change_call: int | None = Field(default=None, ge=1)
    finish_holds: int = Field(default=0, ge=0)
    extra_files: int | None = Field(default=None, ge=0)
    cache_reported: bool | None = None


class BenchResult(Contract):
    """A suite run against one model: every run, and the totals."""

    bench_version: str = "coding-bench-v1"
    label: str = Field(min_length=1, max_length=120)
    started_at: datetime
    runs: list[BenchRun] = Field(default_factory=list)
    # What was run, and with what: the suite's folder name, the model and how it
    # was asked, and the commit of the code that ran -- for the results registry.
    suite: str | None = Field(default=None, max_length=120)
    model: str | None = Field(default=None, max_length=256)
    provider: str | None = Field(default=None, max_length=40)
    reasoning_effort: str | None = Field(default=None, max_length=20)
    commit: str | None = Field(default=None, max_length=40)
    # Lessons given to every run (`--given-lessons`, P3): what they were, so a result says.
    given_lessons: list[str] = Field(default_factory=list)

    def summary(self) -> dict[str, object]:
        return summarize(self.runs)


# Why a run did not solve its task, from its record alone, and whose it was:
# the model's, the provider's, the harness's, or a limit the run set.
FAILURE_GROUP = {
    "wrong_answer": "model", "unreadable": "model", "stalled": "model", "budget": "model",
    "rate_limit": "provider", "output_limit": "provider", "transport": "provider",
    "harness_error": "harness", "no_check": "harness", "waiting": "harness",
    "timeout": "limit", "other": "other",
}


def failure(run: BenchRun) -> str | None:
    """Why a run did not solve its task, as one of `FAILURE_GROUP`; None when it did.

    Polyglot's first runs were sorted by hand into tool calls written as text,
    output limits, rate limits and answers that were wrong; this says the same
    from the record, for every run, old ones included.
    """
    if run.solved:
        return None
    ended = (run.ended or "").lower()
    if run.error is not None:
        return "harness_error"
    if run.outcome == "waiting":
        return "waiting"
    if "time limit for this task" in ended:
        return "timeout"
    if "http 429" in ended:
        return "rate_limit"
    if "output limit" in ended:
        return "output_limit"
    if "could not be reached" in ended:
        return "transport"
    if "were not steps" in ended:
        return "unreadable"
    if "already failed, unchanged" in ended or "only read" in ended or "same steps" in ended:
        return "stalled"
    if "budget of" in ended:
        return "budget"
    if run.check_exit is None:
        return "no_check"
    if run.outcome == "finished":
        return "wrong_answer"
    return "other"


def summarize(runs: list[BenchRun]) -> dict[str, object]:
    """Solve rate overall and by task, and what a run cost, as plain numbers."""
    if not runs:
        return {"runs": 0}
    by_task: dict[str, list[BenchRun]] = {}
    for run in runs:
        by_task.setdefault(run.task, []).append(run)
    return {
        "runs": len(runs),
        "solved": sum(run.solved for run in runs),
        "solve_rate": round(sum(run.solved for run in runs) / len(runs), 3),
        # The product's own account, apart from the hidden check (OBS-07): how often the
        # model said it was done, how often ReLab's verdict agreed, and how often a run
        # ReLab counted a success failed the hidden check -- a false completion.
        "finished": sum(run.outcome == "finished" for run in runs),
        "verified": sum(run.verified is True for run in runs),
        "false_completions": sum(run.verified is True and not run.solved for run in runs),
        "finished_unverified": sum(run.outcome == "finished" and run.verified is not True for run in runs),
        "mean_steps": round(statistics.fmean(run.steps for run in runs), 2),
        "mean_model_calls": round(statistics.fmean(run.model_calls for run in runs), 2),
        "mean_prompt_characters": round(statistics.fmean(run.prompt_characters for run in runs)),
        "mean_seconds": round(statistics.fmean(run.seconds for run in runs), 1),
        "refused_steps": sum(run.refused_steps for run in runs),
        "by_task": {task: {"solved": sum(run.solved for run in items), "runs": len(items)}
                    for task, items in sorted(by_task.items())},
        "by_kind": _rates(runs, lambda run: run.kind),
        "by_category": _rates(runs, lambda run: run.category or "uncategorised"),
        # Solved by repeat: with lessons carried, whether later repeats fail less.
        "by_repeat": _rates(runs, lambda run: f"repeat {run.repeat}"),
        "failures": _counted(failure(run) for run in runs),
        # With a model ladder: runs that moved up it, and of those, solved.
        "moved_up": sum(bool(run.model_changes) for run in runs),
        "solved_after_moving_up": sum(run.solved and bool(run.model_changes) for run in runs),
        "failure_groups": _counted(FAILURE_GROUP.get(failure(run) or "", None)
                                   for run in runs if not run.solved),
        # Of the runs that knew what was relevant and did not solve it, why (M5.5).
        "locate": _counted(run.locate for run in runs),
        "total_seconds": round(sum(run.seconds for run in runs), 1),
        "total_cost": round(sum(run.cost or 0.0 for run in runs), 4) if any(
            run.cost is not None for run in runs) else None,
    }


def _rates(runs: list[BenchRun], key: Callable[[BenchRun], str]) -> dict[str, str]:
    """Solved of run, by a key, as "3/5"."""
    found: dict[str, list[BenchRun]] = {}
    for run in runs:
        found.setdefault(key(run), []).append(run)
    return {name: f"{sum(run.solved for run in items)}/{len(items)}"
            for name, items in sorted(found.items())}


def _counted(values: Iterable[str | None]) -> dict[str, int]:
    """How often each value came, most first; None left out."""
    counts: dict[str, int] = {}
    for value in values:
        if value is not None:
            counts[value] = counts.get(value, 0) + 1
    return dict(sorted(counts.items(), key=lambda item: (-item[1], item[0])))


def compare(before: BenchResult, after: BenchResult) -> dict[str, object]:
    """What changed between two results, task by task, on the tasks both ran."""
    old, new = before.summary(), after.summary()
    was, now = _by_task(before.runs), _by_task(after.runs)
    rows = {task: {"before": f"{was[task][0]}/{was[task][1]}",
                   "after": f"{now[task][0]}/{now[task][1]}"}
            for task in sorted(set(was) & set(now))}
    return {"before": before.label, "after": after.label,
            "solve_rate": [old.get("solve_rate"), new.get("solve_rate")],
            "mean_steps": [old.get("mean_steps"), new.get("mean_steps")],
            "mean_model_calls": [old.get("mean_model_calls"), new.get("mean_model_calls")],
            "mean_seconds": [old.get("mean_seconds"), new.get("mean_seconds")],
            "failures": [old.get("failures"), new.get("failures")],
            "by_kind": [old.get("by_kind"), new.get("by_kind")],
            "by_category": [old.get("by_category"), new.get("by_category")],
            "tasks": rows}


def _by_task(runs: list[BenchRun]) -> dict[str, tuple[int, int]]:
    """Solved and run, per task."""
    found: dict[str, tuple[int, int]] = {}
    for run in runs:
        solved, total = found.get(run.task, (0, 0))
        found[run.task] = (solved + run.solved, total + 1)
    return found


def load_suite(suite: Path, only: list[str] | None = None) -> list[tuple[BenchTask, Path]]:
    """The tasks under `suite`, by folder name, each with its folder."""
    found = []
    for folder in sorted(item for item in suite.iterdir() if (item / "task.json").is_file()):
        task = BenchTask.model_validate_json((folder / "task.json").read_text(encoding="utf-8"))
        if task.id != folder.name:
            raise ValueError(f"{folder}: task id {task.id!r} is not its folder's name")
        if not (folder / "repo").is_dir() or not (folder / "check").is_dir():
            raise ValueError(f"{folder}: a task needs repo/ and check/")
        if only is None or task.id in only:
            found.append((task, folder))
    if only is not None and len(found) != len(set(only)):
        missing = sorted(set(only) - {task.id for task, _ in found})
        raise ValueError(f"no such task in {suite}: {', '.join(missing)}")
    if not found:
        # Found in use (0.3.33): a folder one level up ran nothing and left an empty report.
        holding = sorted(item.name for item in suite.iterdir() if item.is_dir()
                         and any((child / "task.json").is_file() for child in item.iterdir() if child.is_dir()))
        raise ValueError(f"no tasks in {suite}: a task is a folder in it holding task.json, repo/ and check/"
                         + (f"; these folders in it hold tasks: {', '.join(holding[:6])}" if holding else ""))
    return found


class Counting:
    """The caller's gateway, counting what passes through it. Changes nothing."""

    def __init__(self, inner: ModelGateway) -> None:
        self.inner = inner
        self.calls = self.prompt_characters = self.reply_characters = 0
        self.prompt_tokens: int | None = None
        self.completion_tokens: int | None = None

    def complete(self, prompt: str, *, timeout_seconds: float,
                 response_contract: dict[str, object] | None = None,
                 reply_tokens: int | None = None) -> str:
        self.calls += 1
        self.prompt_characters += len(prompt)
        reply = self.inner.complete(prompt, timeout_seconds=timeout_seconds,
                                    response_contract=response_contract,
                                    reply_tokens=reply_tokens)
        self.reply_characters += len(reply)
        self._count(getattr(reply, "usage", None))
        return reply

    def complete_tools(self, prompt: str, *, tools: list[dict[str, object]],
                       timeout_seconds: float, reply_tokens: int | None = None) -> ToolReply:
        if not isinstance(self.inner, ToolGateway):
            # As the gateway itself would: no tools here, so the loop asks in JSON.
            raise AttributeError("complete_tools")  # noqa: TRY004 -- as a missing method does
        self.calls += 1
        self.prompt_characters += len(prompt)
        reply = self.inner.complete_tools(prompt, tools=tools, timeout_seconds=timeout_seconds,
                                          reply_tokens=reply_tokens)
        self.reply_characters += len(reply.content) + sum(
            len(json.dumps(call.arguments)) for call in reply.calls)
        self._count(reply.usage)
        return reply

    def complete_chat(self, messages: list[dict[str, object]], *, timeout_seconds: float,
                      response_contract: dict[str, object] | None = None,
                      reply_tokens: int | None = None) -> str:
        if not isinstance(self.inner, ChatGateway):
            raise AttributeError("complete_chat")  # noqa: TRY004 -- as a missing method does
        self.calls += 1
        self.prompt_characters += sum(len(str(item.get("content") or "")) for item in messages)
        reply = self.inner.complete_chat(messages, timeout_seconds=timeout_seconds,
                                         response_contract=response_contract,
                                         reply_tokens=reply_tokens)
        self.reply_characters += len(reply)
        self._count(getattr(reply, "usage", None))
        return reply

    def complete_messages(self, messages: list[dict[str, object]], *,
                          tools: list[dict[str, object]], timeout_seconds: float,
                          reply_tokens: int | None = None) -> ToolReply:
        if not isinstance(self.inner, MessageGateway):
            raise AttributeError("complete_messages")  # noqa: TRY004 -- as a missing method does
        self.calls += 1
        self.prompt_characters += sum(len(str(item.get("content") or "")) for item in messages)
        reply = self.inner.complete_messages(messages, tools=tools,
                                             timeout_seconds=timeout_seconds,
                                             reply_tokens=reply_tokens)
        self.reply_characters += len(reply.content) + sum(
            len(json.dumps(call.arguments)) for call in reply.calls)
        self._count(reply.usage)
        return reply

    def switch(self, inner: ModelGateway) -> "Counting":
        """Count another model's calls from now on, with the same totals: a move up a ladder."""
        self.inner = inner
        return self

    def _count(self, usage: object) -> None:
        if usage is None:
            return
        prompt = getattr(usage, "prompt_tokens", None)
        completion = getattr(usage, "completion_tokens", None)
        if prompt is not None:
            self.prompt_tokens = (self.prompt_tokens or 0) + prompt
        if completion is not None:
            self.completion_tokens = (self.completion_tokens or 0) + completion


def run_task(task: BenchTask, folder: Path, gateway: ModelGateway, *, repeat: int,
             work: Path, native_tools: bool = True,
             task_seconds: float | None = TASK_SECONDS,
             lessons_from: Path | None = None, keep_check: bool = False,
             ladder: ModelLadder | None = None,
             context_windows: dict[str, int] | None = None,
             context_budget: int | None = None,
             references: bool = False, instruction: str = "modular", compact_prompt: bool = False,
             condition: str | None = None, given_lessons: tuple[str, ...] = ()) -> BenchRun:
    """Work one task once in a fresh copy of its repository, and score it.

    `instruction` and `compact_prompt`: the instruction the loop sends -- a prompt
    comparison's condition (`condition`, recorded with the run).

    The task's call budget is one for all its legs: a command refused, a plan
    approved or a question answered goes on with what is left, not with a
    fresh budget -- one task once spent 115 calls in six legs. `task_seconds`
    bounds the task's wall-clock time, retries and waits included.
    """
    workspace = work / f"{task.id}-{repeat}"
    if workspace.exists():
        shutil.rmtree(workspace)
    shutil.copytree(folder / "repo", workspace)
    if lessons_from is not None and (state_dir(lessons_from) / "lessons.json").is_file():
        # What the repeat before learned, carried into this one (M6.5).
        shutil.copyfile(state_dir(lessons_from) / "lessons.json",
                        state_dir(workspace) / "lessons.json")
    counting = Counting(gateway)
    started = time.monotonic()
    service = CodingLoopService(workspace)
    service.native_tools = native_tools
    service.settings.instruction = instruction
    service.settings.compact_prompt = compact_prompt
    service.given_lessons = given_lessons
    service.context_windows = dict(context_windows or {})
    service.context_budget = context_budget
    service.references = references
    # Like any benchmark: offline. The tests it is scored by are on the web.
    service.offline = True
    # Nobody is watching: a question is answered inside the leg.
    service.unattended = task.answer or UNATTENDED
    if ladder is not None:
        # Unattended, so it moves up by itself; every model's calls are counted
        # as the task's, through the one counting gateway.
        service.model = ladder.models[0]
        service.ladder = ModelLadder(ladder.models,
                                     lambda model: counting.switch(ladder.build(model)),
                                     automatic=True, max_cost=ladder.max_cost,
                                     move_on=ladder.move_on, after_failures=ladder.after_failures)
    if task_seconds is not None:
        service.deadline = started + task_seconds
    # What the loop is shown of the workspace on every call, and whether it is
    # all of it: in a large repository, the answer may be past the cut.
    listed = service._listing(MAXIMUM_LISTED + 1,
                              under=None if task.scope == WHOLE_WORKSPACE else task.scope)
    listing_cut = len(listed) > MAXIMUM_LISTED
    outline_cut = outline(workspace, listed[:MAXIMUM_LISTED], limit=CONTEXT_OUTLINE)[1]
    loop = None
    legs = 0
    error = None
    try:
        loop = service.run(task.request, counting, max_steps=task.max_steps, scope=task.scope)
        legs = 1
        while loop.outcome is LoopOutcome.WAITING and legs < MAXIMUM_LEGS:
            left = task.max_steps - loop.calls
            if left < 1:
                break
            if loop.permission is not None:
                loop = service.decide(loop.loop_id, task.allow_commands, counting, max_steps=left)
            elif loop.review is not None:
                loop = service.review(loop.loop_id, True, counting, max_steps=left)
            elif loop.plan is not None and not loop.plan_approved:
                loop = service.approve(loop.loop_id, counting, max_steps=left)
            else:
                loop = service.answer(loop.loop_id, task.answer or UNATTENDED, counting,
                                      max_steps=left)
            legs += 1
    except Exception as error_raised:  # noqa: BLE001 -- recorded as the run's error
        error = f"{type(error_raised).__name__}: {error_raised}"[:400]
    seconds = time.monotonic() - started
    check_exit, output = _check(task, folder, workspace)
    if keep_check and loop is not None and check_exit not in (0, None):
        # Carried to the next repeat: the hidden check failed this attempt.
        LessonStore(workspace).add([evaluated(loop.loop_id, task.request, output,
                                              len(loop.steps))])
    found = (navigation(loop, task, listing_cut=listing_cut, outline_cut=outline_cut)
             if loop is not None else None)
    solved = error is None and check_exit == 0
    return BenchRun(
        task=task.id, kind=task.kind, category=task.category, repeat=repeat,
        solved=solved,
        outcome=loop.outcome.value if loop is not None else "error",
        loop_id=loop.loop_id if loop is not None else None,
        steps=len(loop.steps) if loop is not None else 0,
        refused_steps=sum(not step.succeeded for step in loop.steps) if loop is not None else 0,
        legs=legs, model_calls=counting.calls, prompt_characters=counting.prompt_characters,
        reply_characters=counting.reply_characters, prompt_tokens=counting.prompt_tokens,
        completion_tokens=counting.completion_tokens,
        retries=loop.retries if loop is not None else 0, seconds=round(seconds, 2),
        check_exit=check_exit, check_output=output,
        tool_calls=loop.tool_calls if loop is not None else None, error=error,
        cached_tokens=loop.cached_tokens if loop is not None else None,
        cost=loop.cost if loop is not None else None,
        first_token_mean_s=_first_tokens(loop)[0], first_token_max_s=_first_tokens(loop)[1],
        ended=loop.summary[:ENDED_CHARACTERS] if loop is not None and loop.summary else None,
        trace=_trace(loop) if loop is not None and (
            check_exit != 0 or loop.outcome is not LoopOutcome.FINISHED) else [],
        model_changes=[f"{item.from_model} -> {item.to_model}: {item.reason.value}"
                       for item in loop.model_changes] if loop is not None else [],
        final_model=loop.model if loop is not None else None,
        navigation=found,
        locate=locate_class(task, solved, found, output) if found is not None else None,
        task_status=(loop.assessment.task_status.value
                     if loop is not None and loop.assessment is not None else None),
        verification_status=(loop.assessment.verification_status.value
                             if loop is not None and loop.assessment is not None else None),
        verified=(loop.assessment.succeeded if loop is not None and loop.assessment is not None else None),
        condition=condition, instruction=instruction,
        instruction_digest=(loop.manifest.instruction_digest if loop is not None and loop.manifest else None),
        tools_digest=(loop.manifest.tools_digest if loop is not None and loop.manifest else None),
        profile=(loop.manifest.profile if loop is not None and loop.manifest else None),
        first_change_call=_first_change_call(loop) if loop is not None else None,
        finish_holds=loop.finish_repairs if loop is not None else 0,
        extra_files=_extra_files(loop, task) if loop is not None else None,
        cache_reported=(loop.cached_tokens is not None) if loop is not None else None)


def _first_change_call(loop: CodingLoop) -> int | None:
    """The model call whose step first changed a file and held: calls to the first valid change."""
    for step in loop.steps:
        if step.succeeded and step.action.action in EDITS | {LoopActionKind.EDIT_BATCH}:
            return step.turn
    return None


def _extra_files(loop: CodingLoop, task: BenchTask) -> int | None:
    """Files written that the task does not name and that are neither tests nor documents;
    None for a task that names no files, where nothing tells what is extra."""
    if not task.must_modify:
        return None
    named = set(task.must_modify)
    return sum(1 for item in loop.written
               if item.path not in named and not _incidental(item.path) and not _test_file(item.path))


def _test_file(path: str) -> bool:
    name = path.rsplit("/", 1)[-1]
    return (name.startswith("test_") or name.endswith(("_test.py", ".test.ts", ".test.js", ".spec.ts"))
            or any(part in ("tests", "test") for part in path.split("/")[:-1]))


READS = frozenset({LoopActionKind.READ_FILE})
EDITS = frozenset({LoopActionKind.WRITE_FILE, LoopActionKind.EDIT_FILE})
# What a loop may write besides the answer without having changed anything else.
INCIDENTAL = (".md", ".txt", ".rst")


def _incidental(path: str) -> bool:
    """A test or a document: written beside an answer, never "unnecessary"."""
    parts = path.split("/")
    name = parts[-1]
    return (any(part in {"tests", "test", CHECK_FOLDER} for part in parts[:-1])
            or name.startswith("test_") or name.endswith(("_test.py", *INCIDENTAL))
            or name == "conftest.py")


def navigation(loop: CodingLoop, task: BenchTask, *, listing_cut: bool | None = None,
               outline_cut: bool | None = None) -> Navigation:
    """How `loop` found its way through the task's workspace, from its steps alone."""
    relevant, must = set(task.relevant_files) | set(task.must_modify), set(task.must_modify)
    read: list[str] = []
    first_relevant = first_edit = None
    counts = {kind: 0 for kind in (LoopActionKind.SEARCH, LoopActionKind.LIST_FILES,
                                   LoopActionKind.OUTLINE, LoopActionKind.EXPLORE,
                                   LoopActionKind.REFERENCES)}
    for step in loop.steps:
        kind, path = step.action.action, step.action.path
        if kind in counts:
            counts[kind] += 1
        if not step.succeeded or path is None:
            continue
        if kind in READS and path not in read:
            read.append(path)
        if kind in READS | EDITS and first_relevant is None and path in relevant:
            first_relevant = step.index
        if kind in EDITS and first_edit is None:
            first_edit = step.index - 1
    modified = sorted({item.path for item in loop.written})
    return Navigation(
        search_calls=counts[LoopActionKind.SEARCH], list_calls=counts[LoopActionKind.LIST_FILES],
        outline_calls=counts[LoopActionKind.OUTLINE], explore_calls=counts[LoopActionKind.EXPLORE],
        references_calls=counts[LoopActionKind.REFERENCES],
        files_read=len(read), first_relevant_step=first_relevant,
        steps_before_first_edit=first_edit, files_modified=modified,
        relevant_files_read=sum(path in relevant for path in read),
        irrelevant_files_read=sum(path not in relevant for path in read) if relevant else 0,
        must_modify_missed=sorted(must - set(modified)),
        unnecessary_files_modified=[path for path in modified
                                    if must and path not in must and not _incidental(path)],
        listing_cut=listing_cut, outline_cut=outline_cut)


# Why a run that knew what was relevant did not solve it, first that applies:
#   locate                it changed none of the files it had to, or read none relevant
#   reference             it changed some of them and missed others (a caller, a rename)
#   regression            a test of what must not change (test_keep_*) failed
#   overreach             it changed code it had no need to
#   wrong_implementation  it changed the right files, and the check still failed
LOCATE_CLASSES = ("locate", "reference", "regression", "overreach", "wrong_implementation")
KEPT_FAILED = re.compile(r"FAILED \S*::test_keep_")


def locate_class(task: BenchTask, solved: bool, found: Navigation, check_output: str) -> str | None:
    """Which of LOCATE_CLASSES a run not solved falls in; None when solved or not scorable."""
    if solved or not task.must_modify:
        return None
    changed = set(found.files_modified) & set(task.must_modify)
    if not changed:
        return "locate"
    if found.must_modify_missed:
        return "reference"
    if KEPT_FAILED.search(check_output):
        return "regression"
    if found.unnecessary_files_modified:
        return "overreach"
    return "wrong_implementation"


def _first_tokens(loop: CodingLoop | None) -> tuple[float | None, float | None]:
    """The run's mean and slowest time to first token, from the loop's performance."""
    measured = loop.performance if loop is not None else {}
    count = measured.get("model_first_token_count", 0.0)
    if not count:
        return None, None
    return (round(measured.get("model_first_token_ms", 0.0) / count / 1000, 3),
            round(measured.get("model_first_token_max_ms", 0.0) / 1000, 3))

def _trace(loop: CodingLoop) -> list[str]:
    """Each step of `loop` as a line: what it did, how it went, and what it wrote."""
    lines = []
    for step in loop.steps[:TRACE_STEPS]:
        action = step.action
        target = (" ".join(action.argv) if action.argv else action.path or action.query
                  or action.url or "")
        said = step.observation.strip().splitlines()[0][:TRACE_OBSERVATION] \
            if step.observation.strip() else ""
        line = (f"{step.index} {action.action.value} {target} "
                f"[{'ok' if step.succeeded else 'refused'}] {said}")
        written = [*((edit.old_text, edit.new_text) for edit in action.edits or [])]
        if action.old_text is not None:
            written.append((action.old_text, action.new_text or ""))
        for old, new in written:
            line += f"\n  - {old[:TRACE_WRITTEN]!r}\n  + {new[:TRACE_WRITTEN]!r}"
        if action.content is not None:
            line += f"\n  = {action.content[:TRACE_WRITTEN]!r}"
        lines.append(line)
    if len(loop.steps) > TRACE_STEPS:
        lines.append(f"... and {len(loop.steps) - TRACE_STEPS} more steps")
    return lines


def check_report(output: str) -> str:
    """A hidden check's output, cut to the first failure in full and the end.

    The end alone -- 2,000 characters -- was a list of FAILED test names for
    every check that failed many tests (forth: 54, grep: 25): what failed
    first, and why, was cut off, both for the person reading and for the
    lesson the next repeat is given.
    """
    if len(output) <= CHECK_HEAD + CHECK_TAIL:
        return output
    first = FAILURE_HEADER.search(output)
    if first is None:
        return output[-(CHECK_HEAD + CHECK_TAIL):]
    following = FAILURE_HEADER.search(output, first.end())
    end = min(following.start() if following else len(output), first.start() + CHECK_HEAD)
    # And each other failure's header with pytest's statement of why, a line
    # each: what the lesson for the next repeat is made of.
    # pytest's header shape, so the lesson reads them back as failures.
    middle = "".join(f"_____ {test} _____\n{line}\n"
                     for test, line in failure_statements(output[end:], OTHER_FAILURES))
    return (output[first.start():end].rstrip() + "\n[...]\n" + middle
            + output[-CHECK_TAIL:])


def _check(task: BenchTask, folder: Path, workspace: Path) -> tuple[int | None, str]:
    """Copy the hidden tests in and run them where the task says; their exit and output."""
    root = workspace.joinpath(*task.check_root.split("/"))
    if not root.is_dir():
        return None, f"the check folder {task.check_root!r} does not exist after the run"
    target = root / CHECK_FOLDER
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(folder / "check", target)
    python = host_python_command() or "python"
    found = shutil.which(python)
    if found is None:
        return None, "no Python on this host to run the check"
    result = Patcher().measure(
        root, [found, "-m", "pytest", "-q", "--tb=short", "-p", "no:cacheprovider",
               CHECK_FOLDER],
        timeout_seconds=CHECK_SECONDS)
    output = check_report(result.stdout + result.stderr)
    # Gone once read: a later repeat, or a command looking around the disk,
    # finds no hidden tests in a finished workspace.
    shutil.rmtree(target, ignore_errors=True)
    return (None if result.timed_out else result.exit_code), output


# What a rerun is for: the provider's failures, not the model's.
PROVIDER_FAILURES = frozenset({"rate_limit", "transport"})


class Throttle:
    """How many runs may go at once: `jobs`, then fewer each time one is rate limited."""

    def __init__(self, jobs: int) -> None:
        self.limit = jobs
        self.active = 0
        self.ready = Condition()

    def __enter__(self) -> None:
        with self.ready:
            while self.active >= self.limit:
                self.ready.wait()
            self.active += 1

    def __exit__(self, *_: object) -> None:
        with self.ready:
            self.active -= 1
            self.ready.notify_all()

    def fewer(self) -> None:
        with self.ready:
            self.limit = max(1, self.limit - 1)


def run_suite(suite: Path, gateway: ModelGateway, *, label: str, repeats: int = 1,
              only: list[str] | None = None, work: Path | None = None,
              out: Path | None = None, native_tools: bool = True, jobs: int = 1,
              task_seconds: float | None = TASK_SECONDS, resume: bool = False,
              about: dict[str, str | None] | None = None,
              on_change: Callable[[BenchResult], object] | None = None,
              carry_lessons: bool = False,
              carry_check: bool = True,
              ladder: ModelLadder | None = None,
              retry_provider_failures: int = 0,
              context_windows: dict[str, int] | None = None,
              context_budget: int | None = None,
              references: bool = False, instruction: str = "modular", compact_prompt: bool = False,
              condition: str | None = None, given_lessons: tuple[str, ...] = ()) -> BenchResult:
    """Every task of `suite`, `repeats` times, written to `out` after each run.

    `jobs` tasks run at once, each in its own workspace with its own loop; the
    gateway is shared, and its calls are what is spent, the same as one by one.
    `resume` keeps the runs `out` already holds -- of the same label -- and runs
    only the rest: a suite stopped part-way goes on where it was.
    `carry_check` false carries only the lessons the loops wrote, not a lesson
    made of the failed hidden check: memory without the test's feedback (RL-10).
    `given_lessons` go to every run's loop before its workspace's own (P3).
    """
    if not 1 <= repeats <= 20:
        raise ValueError("repeats is between 1 and 20")
    if not 1 <= jobs <= MAXIMUM_JOBS:
        raise ValueError(f"jobs is between 1 and {MAXIMUM_JOBS}")
    tasks = load_suite(suite, only)
    # `about`: model, provider, reasoning_effort and commit, as the caller knows them.
    described = {key: value for key, value in (about or {}).items()
                 if key in ("model", "provider", "reasoning_effort", "commit")}
    result = BenchResult.model_validate({"label": label, "suite": suite.name,
                                         "started_at": datetime.now(timezone.utc),
                                         "given_lessons": list(given_lessons), **described})
    if resume and out is not None and out.is_file():
        earlier = read_result(out)
        if earlier.label != label:
            raise ValueError(f"{out} holds {earlier.label!r}, not {label!r}: resume the same run")
        result = earlier.model_copy(update={"suite": earlier.suite or suite.name,
                                            **{key: value for key, value in described.items()
                                               if getattr(earlier, key) is None}})
    done = {(run.task, run.repeat) for run in result.runs}
    todo = [(task, folder, repeat) for task, folder in tasks
            for repeat in range(1, repeats + 1) if (task.id, repeat) not in done]
    keep = work is not None
    work = work or Path(tempfile.mkdtemp(prefix="relab-bench-"))
    lock = Lock()

    throttle = Throttle(jobs)

    def one(item: tuple[BenchTask, Path, int], reruns: int = 0) -> None:
        task, folder, repeat = item
        before = work / f"{task.id}-{repeat - 1}"
        with throttle:
            run = run_task(task, folder, gateway, repeat=repeat, work=work,
                           native_tools=native_tools, task_seconds=task_seconds,
                           lessons_from=before if carry_lessons and repeat > 1 else None,
                           keep_check=carry_lessons and carry_check, ladder=ladder,
                           context_windows=context_windows, context_budget=context_budget,
                           references=references,
                           instruction=instruction, compact_prompt=compact_prompt, condition=condition,
                           given_lessons=given_lessons)
            if failure(run) == "rate_limit":
                # Rate limited: fewer at once from now on, down to one.
                throttle.fewer()
        run = run.model_copy(update={"reruns": reruns})
        with lock:
            result.runs = [found for found in result.runs
                           if (found.task, found.repeat) != (task.id, repeat)]
            result.runs.append(run)
            result.runs.sort(key=lambda found: (found.task, found.repeat))
            if out is not None:
                # After every run, so a long suite stopped part-way keeps what it has.
                out.write_text(result.model_dump_json(indent=2), encoding="utf-8")
            if on_change is not None:
                # The results registry, and its report, as the run goes.
                on_change(result)

    # Carrying lessons, a task's repeats run in order, one after another; the
    # tasks still run at once.
    units: list[list[tuple[BenchTask, Path, int]]] = (
        [[item for item in todo if item[0].id == task.id] for task, _ in tasks]
        if carry_lessons else [[item] for item in todo])

    def unit(items: list[tuple[BenchTask, Path, int]]) -> None:
        for item in items:
            one(item)

    try:
        if jobs == 1:
            for items in units:
                unit(items)
        else:
            with ThreadPoolExecutor(max_workers=jobs) as pool:
                for finished in [pool.submit(unit, items) for items in units if items]:
                    finished.result()
        # Runs the provider failed -- rate limited, or not reached -- run again,
        # one at a time: what they measured was the provider, not the model.
        by_id = {task.id: (task, folder) for task, folder in tasks}
        for attempt in range(1, retry_provider_failures + 1):
            again = [run for run in result.runs if run.task in by_id
                     and failure(run) in PROVIDER_FAILURES]
            if not again:
                break
            for run in again:
                task, folder = by_id[run.task]
                one((task, folder, run.repeat), reruns=attempt)
    finally:
        if not keep:
            shutil.rmtree(work, ignore_errors=True)
    return result


def read_result(path: Path) -> BenchResult:
    return BenchResult.model_validate_json(path.read_text(encoding="utf-8"))


def dumps(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2)
