import math
from contextlib import ExitStack
from pathlib import Path
from uuid import uuid4

from relab_coding.generation import (
    generate_change,
    generate_multiple_changes,
    refuse_mismatch,
)
from relab_coding.ollama import ModelTransportError
from relab_core.coding.consumer import ReceivedCodingResult
from relab_core.coding.dependency import (
    DependencyDecision,
    DependencyInstallDecision,
    DependencyInstallPolicy,
)
from relab_core.coding.patch import PatchProposal, PatchStatus
from relab_core.coding.sandbox import SandboxPolicy
from relab_core.contracts import RunState
from relab_core.dependency import DependencyPreflight
from relab_core.evaluation import (
    CodingEvaluation,
    CodingMetrics,
    MetricComparison,
    MetricRegistry,
    RepeatabilityReport,
)
from relab_core.generation import IdentifiedGateway, ModelGateway, ModelReply
from relab_core.operations import (
    ModelCallDetail,
    OperationKind,
    OperationObserver,
    narrate,
)
from relab_core.provenance import RunConditions
from relab_core.routing import ModelRole
from relab_core.runs import CodingRun, HumanGateQueue, PendingHumanGate, RestoreReason
from relab_core.snapshots import RecordedContent
from relab_core.targets import EditTarget, TargetOperation
from relab_evaluation.coding import evaluate_coding
from relab_evaluation.comparison import compare_metrics
from relab_evaluation.metrics import extract_coding_metrics
from relab_evaluation.repeatability import assess_repeatability
from relab_workspace.dependency_installer import install_dependency
from relab_workspace.dependency_policy import validate_dependency_target
from relab_workspace.edit_context import read_change_source
from relab_workspace.locking import session_execution_lock, workspace_lock
from relab_workspace.operation_recorder import OperationRecorder
from relab_workspace.patch_store import reconcilable_evidence
from relab_workspace.private_state import state_dir
from relab_workspace.provenance import (
    capture_conditions,
    changed_data,
    changed_holdout_data,
)
from relab_workspace.run_store import RunStore
from relab_workspace.service import WorkspacePatchService
from relab_workspace.session_store import SessionStore
from relab_workspace.snapshot_store import SnapshotStore


class CodingRunService:
    """Record an explicitly submitted coding result with identity and audit checks."""

    def __init__(
        self, workspace: Path, *, observe: OperationObserver | None = None,
    ) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.store = RunStore(self.workspace)
        # Narrated by default, so a study driven from the CLI, the editor or
        # the unattended loop all say what they are doing without each having
        # to remember to ask. A caller that wants silence passes one that
        # does nothing. What this holds can only append: reading the journal
        # back is `OperationStore`, which nothing that decides may hold.
        self.observe: OperationObserver | None = (
            OperationRecorder.open(self.workspace) if observe is None else observe)

    def recorded_content(self, run_id: str, path: str, *, side: str) -> RecordedContent:
        """What one file held either side of this run's recorded patch.

        Records only. It reads no workspace file, so an attempt undone after
        measurement reads back exactly as it did at the time, and a file
        someone has edited since is not quietly presented as the historical
        original -- which is the whole reason this is kept rather than
        reconstructed.

        The content is fetched by the digest the record names and checked
        against it on the way out, so what comes back is that state of that
        file or nothing at all.
        """
        if side not in {"before", "after"}:
            raise ValueError("side must be 'before' or 'after'")
        evidence = self.store.load(run_id).patch_evidence
        if evidence is None:
            raise LookupError(f"no patch was recorded for {run_id}")
        found = next((item for item in evidence.snapshots if item.path == path), None)
        if found is None:
            raise LookupError(f"this patch recorded no snapshot for {path}")
        if found.omitted is not None:
            raise LookupError(f"the content was not kept: {found.omitted.value}")
        digest = found.before_digest if side == "before" else found.after_digest
        if digest is None:
            # The file was not there on that side. Empty is what a comparison
            # should show for it, and `existed` is how it says which it is --
            # an empty file has a digest of its own and reads back as one.
            return RecordedContent(run_id=run_id, path=path, side=side,
                                   existed=False, content="")
        content = SnapshotStore(state_dir(self.workspace) / "snapshots.db").get(digest)
        if content is None:
            raise LookupError("the recorded content is no longer held in this workspace")
        return RecordedContent(run_id=run_id, path=path, side=side,
                               existed=True, content=content.decode("utf-8"))

    def evaluate(self, run_id: str) -> CodingEvaluation:
        events = self.store.events(run_id)
        if not events:
            raise LookupError(f"run not found: {run_id}")
        return evaluate_coding(events[-1])

    def metrics(self, run_id: str) -> CodingMetrics:
        events = self.store.events(run_id)
        if not events:
            raise LookupError(f"run not found: {run_id}")
        return extract_coding_metrics(events[-1])

    def compare(
        self, candidate_id: str, baseline_id: str, registry: MetricRegistry,
    ) -> MetricComparison:
        return compare_metrics(self.metrics(candidate_id), self.metrics(baseline_id), registry)

    def repeatability(
        self, run_ids: list[str], registry: MetricRegistry, *, minimum_runs: int = 3,
    ) -> RepeatabilityReport:
        return assess_repeatability(
            [self.metrics(run_id) for run_id in run_ids], registry, minimum_runs=minimum_runs,
        )

    def generate_and_apply(
        self, run_id: str,
        target: str | EditTarget | list[str] | list[EditTarget] | list[str | EditTarget],
        gateway: ModelGateway,
        *, verify_argv: list[str],
        model_timeout_seconds: float = 60, timeout_seconds: float = 300,
        data_paths: list[str] | None = None, execution_root: Path | None = None,
        sandbox: SandboxPolicy | None = None, holdout_paths: list[str] | None = None,
        measurement_snapshot_id: str | None = None,
    ) -> CodingRun:
        if not verify_argv or not all(verify_argv):
            raise ValueError("verification argv is required")
        if any(not math.isfinite(value) or value <= 0
               for value in (model_timeout_seconds, timeout_seconds)):
            raise ValueError("timeouts must be finite and positive")
        run = self.store.load(run_id)
        if run.state != RunState.CREATED:
            raise ValueError("generation requires an unstarted run")
        # A bare path is read as an edit, the same reading rule `ArmTask` applies
        # to plans recorded before targets were typed. It is a rule about what a
        # string means, not an inference from the filesystem: a path naming a file
        # that is not there is still an edit, and is still refused for being one.
        given = [target] if isinstance(target, (str, EditTarget)) else list(target)
        targets = [
            EditTarget(path=item, operation=TargetOperation.EDIT) if isinstance(item, str)
            else item
            for item in given
        ]
        named = [item.path for item in targets]
        if not 1 <= len(targets) <= 8 or len({p.casefold() for p in named}) != len(named):
            raise ValueError("select 1-8 distinct paths (case-insensitive)")
        # Everything about the attempt is read from the tree it will edit.
        tree = self.workspace if execution_root is None else execution_root.resolve(strict=True)
        # Capture first: an unusable declaration must cost no model call and no record.
        conditions = capture_conditions(tree, data_paths, named, sandbox,
                                        holdout_paths=holdout_paths,
                                        verify_argv=verify_argv)
        # What the plan intends, and what the tree was observed to hold. A file a
        # target means to create is read as absent rather than as an error.
        sources = [(item, read_change_source(tree, item)) for item in targets]
        # Reconciled *here*, under the same rule generation applies, and before
        # anything is recorded. Generation checks again because it is reachable
        # on its own; this call site checks because the alternative is a run that
        # transitioned to RUNNING on a declaration that was never usable.
        for item, found in sources:
            refuse_mismatch(item, found)
        present = [found for _, found in sources if found is not None]
        if sum(map(len, present)) > 65536:
            raise ValueError("selected files exceed 64 KiB combined")
        running = run.model_copy(update={
            "state": RunState.RUNNING,
            "generation_target": named[0] if len(named) == 1 else None,
            "generation_targets": named, "generation_calls": 1,
            "generation_timeout_seconds": model_timeout_seconds,
            "generation_model": gateway.identity if isinstance(gateway, IdentifiedGateway) else None,
            "conditions": conditions,
        })
        self.store.append(running, "coding.generation_started", 1)

        def observe_reply(reply: ModelReply) -> None:
            nonlocal running
            running = running.model_copy(update={
                "generation_usage": reply.usage, "generation_reported_model": reply.reported_model,
            })

        identity = running.generation_model
        try:
            # "Calling coding model", which nothing said before: the whole
            # attempt arrived as one `coding.generation_started` and a person
            # watching could not tell a slow provider from a slow verifier.
            with narrate(
                self._about(run.run_id), OperationKind.MODEL_CALL,
                ModelCallDetail(
                    role=ModelRole.CODING.value,
                    provider=identity.provider if identity is not None else "unreported",
                    model=identity.model if identity is not None else "unreported"),
            ) as asking:
                if len(targets) == 1:
                    proposal = generate_change(
                        run.objective, targets[0], sources[0][1], run.request_id, gateway,
                        timeout_seconds=model_timeout_seconds, observe_reply=observe_reply,
                    )
                else:
                    proposal = generate_multiple_changes(
                        run.objective, sources, run.request_id, gateway,
                        timeout_seconds=model_timeout_seconds, observe_reply=observe_reply,
                    )
                # Which model answered, when the provider said. The route asked
                # for is above; this is the one that replied, and they differ.
                answered = running.generation_reported_model
                if answered is not None:
                    asking.detail = ModelCallDetail(
                        role=ModelRole.CODING.value,
                        provider=identity.provider if identity is not None else "unreported",
                        model=answered)
        except BaseException as error:
            failed = running.model_copy(update={
                "state": RunState.FAILED,
                # Provider errors can contain credentials/prompt content; do not persist them.
                "execution_error": f"generation failed: {type(error).__name__}",
                # Which provider condition ended it, when one did. The arm
                # accounting reads this to decide whether a repeat was spent: a
                # reply that never finished produced no code to judge, and
                # counting it against the experiment would record a fact about
                # the provider as a fact about the arm.
                "provider_incident": getattr(error, "incident", None),
                # The one message that is safe to keep: ReLab's own, and only
                # from the error type documented as safe to display.
                "generation_failure_reason": (
                    str(error)[:400] or None if isinstance(error, ModelTransportError) else None),
            })
            self.store.append(failed, "coding.generation_failed", 2)
            raise
        return self._execute_patch(
            running, proposal, verify_argv=verify_argv, timeout_seconds=timeout_seconds,
            expected_sequence=2, event_prefix="coding.patch", conditions=conditions,
            execution_root=execution_root, sandbox=sandbox,
            # What this attempt was told to write is what the measurement is
            # of, so the tree is observed at those paths when the verifier runs.
            subject_paths=named, measurement_snapshot_id=measurement_snapshot_id,
        )

    def create(
        self, objective: str, request_id: str, *, once_per_request: bool = False,
    ) -> CodingRun:
        run = CodingRun(
            run_id=f"run-{uuid4()}", workspace=str(self.workspace),
            objective=objective, request_id=request_id,
        )
        if once_per_request:
            return self.store.create_for_request(run)
        self.store.append(run, "coding.created", expected_sequence=0)
        return run

    def measure_holdout(
        self, run_id: str, argv: list[str], *, timeout_seconds: float = 300,
        sandbox: SandboxPolicy | None = None,
        execution_root: Path | None = None,
    ) -> CodingRun:
        """Measure a verified attempt with a second command, before anything undoes it."""
        if not argv or not all(argv):
            raise ValueError("holdout argv is required")
        if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
            raise ValueError("timeout must be finite and positive")
        events = self.store.events(run_id)
        if not events:
            raise LookupError(f"run not found: {run_id}")
        run = events[-1].snapshot
        if run.holdout_verification is not None:
            if run.holdout_verification.argv == list(argv):
                return run
            raise ValueError("this run already has a different holdout measurement")
        if run.holdout_argv:
            raise ValueError("holdout measurement already started; inspect history before acting")
        evidence = run.patch_evidence
        if (run.state != RunState.COMPLETED or run.restored or evidence is None
                or evidence.status != PatchStatus.APPLIED):
            raise ValueError("measure a holdout on a completed, applied and unrestored run")
        started = run.model_copy(update={
            "holdout_argv": list(argv), "holdout_timeout_seconds": timeout_seconds,
        })
        claim = self.store.append(started, "coding.holdout_started", events[-1].sequence)
        try:
            verification = WorkspacePatchService().measure(
                self.workspace, list(argv), timeout_seconds=timeout_seconds,
                sandbox_policy=sandbox, execution_root=execution_root)
        except BaseException as error:
            interrupted = started.model_copy(update={
                "holdout_error": f"holdout interrupted: {type(error).__name__}",
            })
            self.store.append(interrupted, "coding.holdout_interrupted", claim.sequence)
            raise
        measured = started.model_copy(update={"holdout_verification": verification})
        self.store.append(measured, "coding.holdout_measured", claim.sequence)
        return measured

    def abandon_holdout(
        self, run_id: str, *, expected_sequence: int, reason: str, worker_stopped: bool,
    ) -> CodingRun:
        """Record a person's abandonment, without inventing an outcome or rerunning."""
        if worker_stopped is not True:
            raise ValueError("confirm the holdout worker stopped before abandoning")
        if type(expected_sequence) is not int or expected_sequence < 1:
            raise ValueError("expected_sequence must be a positive integer")
        if not isinstance(reason, str) or not reason.strip() or len(reason) > 2000:
            raise ValueError("reason must contain 1 to 2000 characters")
        self.store.load(run_id)
        sessions = SessionStore(self.workspace)
        with ExitStack() as locks:
            for session_id in sorted(sessions.session_ids()):
                if any(ref.run_id == run_id for ref in sessions.latest(session_id).snapshot.runs):
                    locks.enter_context(session_execution_lock(self.workspace, session_id))
            locks.enter_context(workspace_lock(self.workspace))
            event = self.store.events(run_id)[-1]
            if event.sequence != expected_sequence:
                raise ValueError("run changed; inspect history before abandoning holdout")
            run = event.snapshot
            if not run.holdout_argv or run.holdout_verification is not None:
                raise ValueError("only a claimed holdout without an outcome can be abandoned")
            if run.holdout_abandon_reason is not None:
                raise ValueError("holdout was already abandoned")
            abandoned = run.model_copy(update={"holdout_abandon_reason": reason.strip()})
            self.store.append(abandoned, "coding.holdout_abandoned", expected_sequence)
            return abandoned

    def restore(self, run_id: str, reason: RestoreReason) -> CodingRun:
        """Undo a verified attempt's edit so the next one starts where it did.

        Evidence is already recorded and is never rewritten: this changes the
        workspace and notes that it did, it does not un-record the attempt.

        The reason is required rather than defaulted. Whoever undoes an edit
        knows why; a default would put a guess on the record, and the surfaces
        that tell a person where their code went would then be repeating it.
        """
        events = self.store.events(run_id)
        if not events:
            raise LookupError(f"run not found: {run_id}")
        run = events[-1].snapshot
        if run.restored:
            return run
        if run.holdout_argv and run.holdout_verification is None:
            raise ValueError("holdout measurement is unresolved; inspect history before restoring")
        evidence = run.patch_evidence
        if (run.state != RunState.COMPLETED or evidence is None
                or evidence.status != PatchStatus.APPLIED or run.proposal is None):
            raise ValueError("only a completed run with an applied patch can be restored")
        if not WorkspacePatchService().restore(self.workspace, run.proposal):
            raise ValueError("the applied edit no longer reverses cleanly; inspect the workspace")
        restored = run.model_copy(update={"restored": True, "restore_reason": reason})
        self.store.append(restored, "coding.patch_restored", events[-1].sequence)
        return restored

    def pending_gates(self) -> HumanGateQueue:
        """List the runs awaiting a person; this resolves nothing and runs nothing."""
        gates = []
        for run_id in self.store.run_ids():
            events = self.store.events(run_id)
            run = events[-1].snapshot
            gate = run.human_gate
            if gate is None or gate.resolved:
                continue
            gates.append(PendingHumanGate(
                gate_id=gate.gate_id, run_id=run_id, objective=run.objective,
                reason=gate.reason, state=run.state, event_sequence=events[-1].sequence,
            ))
        return HumanGateQueue(workspace=str(self.workspace), gates=gates)

    def record(self, run_id: str, result: ReceivedCodingResult) -> CodingRun:
        run = self.store.load(run_id)
        if result.request_id != run.request_id or result.objective != run.objective:
            raise ValueError("coding result identity/objective does not match run")
        result_workspace = (self.workspace / result.workspace).resolve()
        if result_workspace != self.workspace:
            raise ValueError("coding result workspace does not match run")
        if run.result is not None:
            if run.result == result:
                return run
            raise ValueError("run already has a different result; imported results are immutable")
        if run.state != RunState.CREATED:
            raise ValueError("only an unstarted run can import a result")
        state, gate = result.project(run_id)
        updated = run.model_copy(update={"state": state, "result": result, "human_gate": gate})
        self.store.append(updated, "coding.result_recorded", expected_sequence=1)
        return updated

    def decide_dependency(
        self, run_id: str, decision: DependencyInstallDecision,
    ) -> CodingRun:
        """Record a human decision only; approval does not execute an installer."""
        events = self.store.events(run_id)
        if not events:
            raise LookupError(f"run not found: {run_id}")
        run = events[-1].snapshot
        if (
            run.result is None or run.result.status != "awaiting_dependency"
            or run.result.failure is None
            or run.result.failure.dependency_install_request is None
            or run.human_gate is None
        ):
            raise ValueError("run has no dependency approval request")
        request = run.result.failure.dependency_install_request
        if decision.request_id != request.request_id or decision.request_id != run.human_gate.gate_id:
            raise ValueError("dependency decision request ID does not match the human gate")
        if run.dependency_decision is not None:
            if run.dependency_decision == decision:
                return run
            raise ValueError("human gate already has a different decision")
        if run.state != RunState.AWAITING_HUMAN or run.human_gate.resolved:
            raise ValueError("dependency human gate is not awaiting a decision")
        approved = decision.decision == DependencyDecision.APPROVE
        updated = run.model_copy(update={
            "state": RunState.AWAITING_DEPENDENCY if approved else RunState.CANCELLED,
            "human_gate": run.human_gate.model_copy(update={"resolved": True}),
            "dependency_decision": decision,
        })
        self.store.append(
            updated, "coding.dependency_approved" if approved else "coding.dependency_rejected",
            expected_sequence=events[-1].sequence,
        )
        return updated

    def check_dependency(
        self, run_id: str, policy: DependencyInstallPolicy,
    ) -> DependencyPreflight:
        """Read-only preflight of the stored approved request; no state transition."""
        run = self.store.load(run_id)
        if (
            run.state != RunState.AWAITING_DEPENDENCY or run.dependency_decision is None
            or run.dependency_decision.decision != DependencyDecision.APPROVE
            or run.human_gate is None or not run.human_gate.resolved
            or run.result is None or run.result.failure is None
            or run.result.failure.dependency_install_request is None
        ):
            raise ValueError("dependency preflight requires a stored approved request")
        request = run.result.failure.dependency_install_request
        if not (request.request_id == run.dependency_decision.request_id == run.human_gate.gate_id):
            raise ValueError("stored dependency approval identity mismatch")
        return validate_dependency_target(self.workspace, request, policy)

    def install_dependency(
        self, run_id: str, policy: DependencyInstallPolicy, *, timeout_seconds: float = 300,
    ) -> CodingRun:
        if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
            raise ValueError("timeout must be finite and positive")
        with workspace_lock(self.workspace):
            self.check_dependency(run_id, policy)
            events = self.store.events(run_id)
            run = events[-1].snapshot
            assert run.result is not None and run.result.failure is not None
            request = run.result.failure.dependency_install_request
            assert request is not None and run.dependency_decision is not None
            running = run.model_copy(update={
                "state": RunState.RUNNING, "dependency_policy": policy,
                "dependency_timeout_seconds": timeout_seconds,
            })
            self.store.append(running, "coding.dependency_install_started", events[-1].sequence)
            try:
                installation = install_dependency(
                    self.workspace, request, run.dependency_decision, policy,
                    timeout_seconds=timeout_seconds,
                )
            except BaseException as error:
                failed = running.model_copy(update={
                    "state": RunState.FAILED, "execution_error": f"{type(error).__name__}: {error}",
                })
                self.store.append(failed, "coding.dependency_install_interrupted",
                                  events[-1].sequence + 1)
                raise
            finished = running.model_copy(update={
                "state": RunState.DEPENDENCY_INSTALLED if installation.outcome.succeeded
                else RunState.FAILED, "dependency_installation": installation,
            })
            self.store.append(finished, "coding.dependency_install_finished", events[-1].sequence + 1)
            return finished

    def apply(
        self, run_id: str, proposal: PatchProposal, *, verify_argv: list[str],
        timeout_seconds: float = 300, data_paths: list[str] | None = None,
        sandbox: SandboxPolicy | None = None,
    ) -> CodingRun:
        if not verify_argv or not all(verify_argv):
            raise ValueError("verification argv is required")
        if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
            raise ValueError("timeout must be finite and positive")
        run = self.store.load(run_id)
        if run.state != RunState.CREATED:
            raise ValueError("run already started; automatic re-execution is prohibited")
        if proposal.request_id != run.request_id:
            raise ValueError("patch request ID does not match run")
        return self._execute_patch(
            run, proposal, verify_argv=verify_argv, timeout_seconds=timeout_seconds,
            expected_sequence=1, event_prefix="coding.patch", sandbox=sandbox,
            conditions=capture_conditions(self.workspace, data_paths, None, sandbox,
                                          verify_argv=verify_argv),
        )

    def resume_dependency(
        self, run_id: str, *, verify_argv: list[str], timeout_seconds: float = 300,
        data_paths: list[str] | None = None, execution_root: Path | None = None,
        sandbox: SandboxPolicy | None = None, holdout_paths: list[str] | None = None,
    ) -> CodingRun:
        """Verify the exact stored resume diff, without reinstalling or replanning.

        `execution_root` continues the attempt in its own checkout. The installed
        environment is not carried there and is not reinstalled: it stays where it
        was installed, so a verifier that needs it must name it by a path that
        resolves from the checkout it now runs in.
        """
        if not verify_argv or not all(verify_argv):
            raise ValueError("verification argv is required")
        if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
            raise ValueError("timeout must be finite and positive")
        # Everything about the continuation is read from the tree it will edit.
        tree = self.workspace if execution_root is None else execution_root.resolve(strict=True)
        conditions = capture_conditions(tree, data_paths, None, sandbox,
                                        holdout_paths=holdout_paths,
                                        verify_argv=verify_argv)
        events = self.store.events(run_id)
        if not events:
            raise LookupError(f"run not found: {run_id}")
        run = events[-1].snapshot
        if (
            run.state != RunState.DEPENDENCY_INSTALLED or run.dependency_installation is None
            or not run.dependency_installation.outcome.succeeded
            or run.dependency_decision is None
            or run.dependency_decision.decision != DependencyDecision.APPROVE
            or run.human_gate is None or not run.human_gate.resolved
            or run.result is None or run.result.status != "awaiting_dependency"
            or run.result.failure is None
            or run.result.failure.dependency_install_request is None
        ):
            raise ValueError("resume requires a successfully installed dependency on this run")
        request = run.result.failure.dependency_install_request
        outcome = run.dependency_installation.outcome
        if not (
            request.request_id == outcome.request_id == run.dependency_decision.request_id
            == run.human_gate.gate_id
            and request.environment == outcome.environment
            and request.dependency == outcome.dependency and request.installer == outcome.installer
        ):
            raise ValueError("dependency installation does not match the stored request")
        proposal = PatchProposal(
            request_id=f"{run.run_id}:dependency-resume", diff=request.resume_diff,
            base_hashes=request.resume_base_hashes, summary="Resume stored dependency patch",
        )
        return self._execute_patch(
            run, proposal, verify_argv=verify_argv, timeout_seconds=timeout_seconds,
            expected_sequence=events[-1].sequence, event_prefix="coding.dependency_resume",
            conditions=conditions, execution_root=execution_root, sandbox=sandbox,
            # The same subjects the interrupted attempt declared; resuming does
            # not change what is being measured.
            subject_paths=list(run.generation_targets),
        )

    def _execute_patch(
        self, run: CodingRun, proposal: PatchProposal, *, verify_argv: list[str],
        timeout_seconds: float, expected_sequence: int, event_prefix: str,
        conditions: RunConditions, execution_root: Path | None = None,
        sandbox: SandboxPolicy | None = None, subject_paths: list[str] | None = None,
        measurement_snapshot_id: str | None = None,
    ) -> CodingRun:
        running = run.model_copy(update={
            "state": RunState.RUNNING, "proposal": proposal, "verify_argv": list(verify_argv),
            "conditions": conditions,
        })
        # Claim the run atomically before any patch mutation. A competing caller loses here.
        self.store.append(running, f"{event_prefix}_started", expected_sequence=expected_sequence)
        try:
            evidence = WorkspacePatchService().apply(
                self.workspace, proposal, verify_argv=verify_argv,
                timeout_seconds=timeout_seconds, execution_root=execution_root,
                sandbox_policy=sandbox, subject_paths=subject_paths,
                measurement_snapshot_id=measurement_snapshot_id,
                observe=self._about(run.run_id),
            )
        except BaseException as error:
            failed = running.model_copy(update={
                "state": RunState.FAILED,
                "execution_error": f"{type(error).__name__}: {error}",
            })
            self.store.append(failed, f"{event_prefix}_interrupted",
                              expected_sequence=expected_sequence + 1)
            raise
        finished = running.model_copy(update={
            "state": RunState.COMPLETED if evidence.status == PatchStatus.APPLIED
            else RunState.FAILED,
            "patch_evidence": evidence,
            # Asked of the tree the attempt actually ran in, once it has stopped
            # running: only then can the captured digests be called what it read.
            "conditions": self._rechecked(conditions, execution_root),
        })
        self.store.append(finished, f"{event_prefix}_finished",
                          expected_sequence=expected_sequence + 1)
        return finished

    def _about(self, run_id: str) -> OperationObserver | None:
        """Stamp the attempt onto whatever the layers below narrate.

        The patch service knows a tree and a diff. Which attempt that belongs
        to is this layer's to say, and handing a run identifier down would tell
        a workspace about a study it has no other reason to know.

        Which *session* is nobody's to stamp here: the timeline reads that from
        the attachment records, which are the authority on it and can change
        after a line was written.
        """
        observe = self.observe
        if observe is None:
            return None
        return lambda event: observe(event.model_copy(update={"run_id": run_id}))

    def _rechecked(
        self, conditions: RunConditions, execution_root: Path | None,
    ) -> RunConditions:
        """Ask the tree the attempt ran in, once it has stopped running."""
        tree = self.workspace if execution_root is None else execution_root
        return conditions.model_copy(update={
            "data_rechecked": True,
            "data_changed": changed_data(tree, conditions),
            # Held-out data the attempt altered is not a disagreement to weigh; it
            # is the thing being measured having written its own answer sheet.
            "holdout_data_changed": changed_holdout_data(tree, conditions),
        })

    def recover(self, run_id: str) -> CodingRun:
        """Reconcile an interrupted record from stored evidence; never execute a patch."""
        events = self.store.events(run_id)
        if not events:
            raise LookupError(f"run not found: {run_id}")
        run = events[-1].snapshot
        if run.patch_evidence is not None:
            return run
        if run.state != RunState.RUNNING:
            raise ValueError("recovery requires a running task with recorded proposal and verifier")
        evidence, reason = reconcilable_evidence(self.workspace, run)
        if evidence is None:
            raise ValueError(f"recovery is not settled by stored evidence: {reason}")
        recovered = run.model_copy(update={
            "state": RunState.COMPLETED if evidence.status == PatchStatus.APPLIED
            else RunState.FAILED,
            "patch_evidence": evidence,
        })
        self.store.append(recovered, "coding.patch_recovered", events[-1].sequence)
        return recovered
