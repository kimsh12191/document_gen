"""What a loop's evaluation runs measured, run after run (P5, step 1).

Seen in use (0.2.45-0.2.48): a text2sql loop worked toward "80%+ accuracy" for
hours, running its evaluation script again and again. Whether a change made
the score better or worse was in each run's output only, and once earlier
steps were summarized (0.2.49) not even there. Read from the record -- the
runs' own output, by rule, with no model call -- the scores each evaluation
command printed are put side by side, with the best, for the model each turn
and for the person on the card.

Only names that mean "higher is better" are read, and only where a number
follows the name on the same line: `accuracy: 0.78`, `Accuracy = 78.5%`,
`정확도: 78%`, `F1 0.66`, `pass rate 12/20` is not one (no single number).
"""

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from relab_app.ablation import without
from relab_core.coding_loop import CodingLoop, LoopActionKind, LoopStep
from relab_research.proposals import repeats_for
from relab_workspace.private_state import state_dir

# Of each command, how many of its latest runs are shown; and how many commands.
SHOWN_RUNS = 6
SHOWN_COMMANDS = 3
SHOWN_METRICS = 3
# Runs in a row with the same score, from which it is said the changes did not move it.
FLAT_RUNS = 3
# Runs of one version of the code an evaluation may be measured by: repeats show how
# much it varies (0.2.77); past these, a run on unchanged files is refused as before.
REPEATS_PER_VERSION = 3
# A move between versions this small (a share), with no repeat of one version to
# say how much the evaluation varies, is asked to be measured again (0.2.77).
SMALL_MOVE = 0.02
METRIC = re.compile(
    r"(?<![\w-])(?P<name>accuracy|exact[ _-]?match|execution[ _-]?accuracy|f1(?:[ _-]?score)?"
    r"|precision|recall|pass[ _-]?rate|success[ _-]?rate|bleu|rouge[ _-]?l?"
    r"|정확도|정답률|통과율|성공률)(?![\w-])[^\S\n]*(?:[:=]|is)?[^\S\n]*"
    r"(?P<value>\d+(?:\.\d+)?)(?![\d/])[^\S\n]*(?P<percent>%)?", re.IGNORECASE)
# A goal the request states (P5, step 2): "90%를 목표로", "80%+", "at least 85%",
# "정확도 90% 이상". A percentage, next to a word that makes it a goal.
TARGET = re.compile(
    r"(?:(?:목표|target|at least|reach|이상으로|최소)[^\d\n%]{0,24}(\d{1,3}(?:\.\d+)?)\s*%)"
    r"|(?:(\d{1,3}(?:\.\d+)?)\s*%\s*(?:\+|이상|넘|를\s*목표|을\s*목표|목표|target|or (?:more|higher)))",
    re.IGNORECASE)
# Which metric a goal is read against, when a run prints several.
PREFERRED = ("accuracy", "execution accuracy", "exact match", "정확도", "정답률", "f1 score", "f1",
             "pass rate", "통과율", "success rate", "성공률")
# What a summary says when it finishes short of the goal, and says so.
SAID_SHORT = re.compile(r"not reached|short of|미달|도달하지\s*못|못\s*미쳤|달성하지\s*못",
                        re.IGNORECASE)
# A finish short of the goal sent back to go on, at most this many times a request,
# and only with this share of the calls and the time left (0.3.15).
GOAL_HOLDS = 3
ROOM_LEFT = 0.2
# What stops work from outside it: a reason to stop short that the work cannot change.
BLOCKED = re.compile(
    r"(?:cannot|can't|could not|couldn't) (?:be )?(?:reach|connect|access)|unreachable|not reachable|no access|"
    r"permission|access denied|forbidden|quota|rate[ -]limit|out of memory|\bOOM\b|no GPU|disk (?:is )?full|"
    r"needs? (?:the person|a person|you|your)|ask(?:s|ed)? the person|person'?s decision|"
    r"접근(?:할 수|이 안|\s*불가|\s*권한)|권한|연결(?:할 수|이 안|\s*불가)|닿지 않|응답(?:이)? 없|"
    r"(?:사용자|사람)(?:의|가|에게)\s*(?:결정|확인|승인|선택)|결정이 필요|승인이 필요|"
    r"메모리 부족|용량 부족|GPU(?:가)? 없|할당량|비용 (?:한도|제한)", re.IGNORECASE)
# A summary's "Next:" heading, or another heading that ends the list under it.
NEXT_HEADING = re.compile(r"^\s*(?:[-*]\s*)?(?:\*\*)?(?:(Next|다음)|Changed|Ran|Not done|변경|실행|미완료)"
                          r"(?:\*\*)?\s*:\s*(?:\*\*)?(.*)$", re.IGNORECASE)
# A summary that says a score moved, up or down ...
CLAIMED = re.compile(
    r"improv|\b(?:better|higher|lower|worse|rose|fell|gain(?:ed|s)?|went (?:up|down))\b|increas|raised|boost"
    r"|\bdropp?(?:ed|s)?\b|decreas|regress|향상|개선|올랐|올라|높아|상승|증가|좋아|떨어|낮아|하락|감소|나빠", re.IGNORECASE)
# ... and one that says the move is no more than runs differ.
NOISE_SAID = re.compile(
    r"noise|spread|variance|vari(?:es|ation)|within|not shown|run[- ]to[- ]run|repeat|significan|margin"
    r"|편차|오차|변동|반복|유의|구분(?:할 수|되지|이 안)|차이(?:가|는)? (?:없|크지 않)", re.IGNORECASE)
# A line that states the whole result, not one part of it.
OVERALL = re.compile(r"overall|total|average|mean|전체|평균|종합|최종", re.IGNORECASE)


@dataclass(frozen=True)
class Score:
    """One metric one run printed."""

    step: int
    name: str
    shown: str
    # Comparable across runs: a share from 0 to 1 when it reads as one.
    value: float


def _name(raw: str) -> str:
    return re.sub(r"[ _-]+", " ", raw.strip().casefold())


def scores(output: str, step: int) -> dict[str, Score]:
    """The metrics a run's output printed, each once: the overall line's, else the last."""
    found: dict[str, tuple[bool, Score]] = {}
    for line in output.splitlines():
        overall = OVERALL.search(line) is not None
        for match in METRIC.finditer(line):
            number = float(match.group("value"))
            percent = match.group("percent") is not None
            value = number / 100 if percent or 1 < number <= 100 else number
            if value > 1:
                continue
            name = _name(match.group("name"))
            score = Score(step, name, match.group("value") + ("%" if percent else ""), value)
            held = found.get(name)
            # The last overall line, once there is one; until then, the last line.
            if overall or held is None or not held[0]:
                found[name] = (overall, score)
    return {name: score for name, (_, score) in found.items()}


def _command(step: LoopStep) -> str:
    return " ".join(step.action.argv or [])


def series(loop: CodingLoop) -> dict[str, dict[str, list[Score]]]:
    """Each command's runs' scores, by metric, oldest first.

    A run gone on as a job, or started in the background, prints its scores
    later, read with `read_process`: those count as the run's, under its
    command (0.3.15) -- an evaluation past the command time limit was read
    nowhere before.
    """
    found: dict[str, dict[str, list[Score]]] = {}
    jobs = {item.name: " ".join(item.argv) for item in loop.processes}
    for step in loop.steps:
        if step.action.action is LoopActionKind.READ_PROCESS:
            command = jobs.get(str(step.action.process))
            if command is None:
                continue
        elif step.action.action is LoopActionKind.START_PROCESS:
            command = _command(step)
        # A run refused as a repeat quotes the earlier one's result: not a new score (0.2.77).
        elif step.action.action is not LoopActionKind.RUN or step.observation.startswith(
                ("refused", "not done again", "not run again", "waiting for")):
            continue
        else:
            command = _command(step)
        printed = scores(step.observation, step.index)
        if not printed:
            continue
        by_metric = found.setdefault(command, {})
        for name, score in printed.items():
            by_metric.setdefault(name, []).append(score)
    return found


def version_at(loop: CodingLoop, step: int) -> int:
    """Which version of the code a run at `step` measured: the loop's changes before it (0.2.77)."""
    return sum(1 for change in loop.changes if change.step < step)


def spread(runs: list[Score], versions: list[int]) -> tuple[float, int] | None:
    """How far runs of the same code differed, at most, and how many runs were repeats.

    None when no version was measured twice: then how much the evaluation itself
    varies is not known, and no change between versions can be read against it.
    """
    groups: dict[int, list[float]] = {}
    for score, version in zip(runs, versions):
        groups.setdefault(version, []).append(score.value)
    repeated = [values for values in groups.values() if len(values) > 1]
    if not repeated:
        return None
    return max(max(values) - min(values) for values in repeated), sum(len(values) for values in repeated)


def _gap(value: float, runs: list[Score]) -> str:
    """A difference of scores, in the unit they were printed in: points for percentages."""
    if any(score.shown.endswith("%") or float(score.shown.rstrip("%")) > 1 for score in runs):
        return f"{value * 100:.3g} points"
    return f"{value:.3g}"


def _flat(runs: list[Score]) -> int:
    """How many of the latest runs in a row had the latest's score."""
    count = 0
    for score in reversed(runs):
        if score.value != runs[-1].value:
            break
        count += 1
    return count


def target(request: str) -> float | None:
    """The goal the request states, as a share from 0 to 1: the last one it names."""
    found = [float(match.group(1) or match.group(2)) / 100 for match in TARGET.finditer(request)]
    found = [value for value in found if 0 < value <= 1]
    return found[-1] if found else None


def _request(loop: CodingLoop) -> str:
    return loop.followups[-1].request if loop.followups else loop.request


def latest_against_target(loop: CodingLoop) -> tuple[float, Score, Score, str] | None:
    """The goal, and the latest and best score of the evaluation run last, of the metric
    the goal is read against; None without a goal or a score."""
    goal = target(_request(loop))
    found = series(loop)
    if goal is None or not found:
        return None
    command, by_metric = max(found.items(), key=lambda item: max(
        score.step for runs in item[1].values() for score in runs))
    name = next((name for name in PREFERRED if name in by_metric), next(iter(by_metric)))
    runs = by_metric[name]
    best = max(runs, key=lambda score: (score.value, score.step))
    return goal, runs[-1], best, f"`{command[:120]}` {name}"


def _percent(value: float) -> str:
    return f"{value * 100:g}%"


def short_of_target(loop: CodingLoop, summary: str = "") -> str | None:
    """Why not to finish yet: the request's goal, not reached by the latest run --
    unless the summary already says it was not reached."""
    held = latest_against_target(loop)
    if held is None or loop.helper_of is not None or SAID_SHORT.search(summary):
        return None
    goal, latest, best, what = held
    if latest.value >= goal:
        return None
    return (f"not finished: the request asks for {_percent(goal)}, and the latest evaluation "
            f"({what}, step {latest.step}) says {latest.shown} (the best was {best.shown}, step "
            f"{best.step}). Go on toward it; or, if it cannot be reached now, finish with a "
            f"summary that starts \"Not reached:\" and says the score and what is left")


def gave_up_early(loop: CodingLoop, summary: str, undone: str | None, *,
                  calls_left: float | None, time_left: float | None) -> tuple[str, int] | None:
    """A finish that stops short of the request's goal with room and a way left: sent back (0.3.15).

    Seen in use (0.3.2, text2sql): at 4.67% of a 90% goal the model finished
    with "Not done:" and five next steps, every one in its own reach -- few-shot
    examples, the join paths in the prompt, a better regex, the evaluation run
    again. Saying so stops the target check, and "Not done:" ends the loop.
    Here such a finish is sent back to go on with what it named next, when:
    the latest score is short of the goal; a fifth of the leg's model calls and
    of its time (`calls_left`, `time_left`, shares; None when unbounded) are
    left; what it says is left names nothing outside the work (a server it
    cannot reach, a permission, a person's decision...); and the scores still
    rise -- the first time, not the same score three runs in a row; after that,
    only on a new evaluation higher than the one it was last sent back on. At
    most GOAL_HOLDS times a request. Returns what it is told, and the step of
    the score it is sent back on.
    """
    held = latest_against_target(loop)
    if held is None or loop.helper_of is not None or len(loop.goal_holds) >= GOAL_HOLDS:
        return None
    goal, latest, best, what = held
    if latest.value >= goal or not (undone or SAID_SHORT.search(summary)):
        return None
    if any(share is not None and share < ROOM_LEFT for share in (calls_left, time_left)):
        return None
    if BLOCKED.search(undone or summary):
        return None
    runs = _runs_of(loop, what)
    if loop.goal_holds:
        last = next((score for score in runs if score.step == loop.goal_holds[-1]), None)
        if latest.step <= loop.goal_holds[-1] or (last is not None and latest.value <= last.value):
            return None
    elif _flat(runs) >= FLAT_RUNS:
        return None
    room = (f"{round(calls_left * 100)}% of this run's model calls" if calls_left is not None
            else "model calls")
    next_said = next_steps(summary) or undone or ""
    told = (f"not finished: the request asks for {_percent(goal)}, and the latest evaluation ({what}, step "
            f"{latest.step}) says {latest.shown} (best {best.shown}). {room[0].upper()}{room[1:]} and time are "
            f"left, and what the summary leaves for next is work in reach here"
            f"{f': {next_said[:400]}' if next_said else ''}. Go on: do the first of it, run the evaluation "
            f"again, and keep what raises the score. Finish when the goal is reached -- or, when the score "
            f"stops rising, with \"Not reached:\", the score and what was tried")
    return told, latest.step


def next_steps(summary: str) -> str:
    """What a summary lists under "Next:" (or "다음:"), joined on one line."""
    said: list[str] = []
    inside = False
    for line in summary.splitlines():
        heading = NEXT_HEADING.match(line)
        if heading is not None:
            inside = heading.group(1) is not None
            if inside and heading.group(2).strip():
                said.append(heading.group(2).strip())
            continue
        if inside and line.strip():
            said.append(line.strip().lstrip("-*0123456789. ").strip())
    return "; ".join(item for item in said if item)


def _runs_of(loop: CodingLoop, what: str) -> list[Score]:
    """The scores of the evaluation and metric `latest_against_target` named, oldest first."""
    for command, by_metric in series(loop).items():
        for name, runs in by_metric.items():
            if what == f"`{command[:120]}` {name}":
                return runs
    return []


def measured(loop: CodingLoop) -> list[str]:
    """The scores side by side, a line per command and metric, latest commands first."""
    lines: list[str] = []
    held = latest_against_target(loop)
    if held is not None:
        goal, latest, best, what = held
        lines.append(f"goal from the request: {_percent(goal)}; {what} latest {latest.shown}, best "
                     f"{best.shown} -- {'reached' if latest.value >= goal else 'not reached'}")
    commands = list(series(loop).items())
    commands.sort(key=lambda item: max(score.step for runs in item[1].values()
                                       for score in runs), reverse=True)
    for command, by_metric in commands[:SHOWN_COMMANDS]:
        for name, runs in list(by_metric.items())[:SHOWN_METRICS]:
            shown = runs[-SHOWN_RUNS:]
            line = f"`{command[:120]}` {name}: " + " -> ".join(
                f"{score.shown} (step {score.step})" for score in shown)
            best = max(runs, key=lambda score: (score.value, score.step))
            latest = runs[-1]
            versions = [version_at(loop, score.step) for score in runs]
            varies = None if without("score-spread") else spread(runs, versions)
            moved = None if without("score-spread") else _last_move(runs, versions)
            if moved is not None and varies is not None and abs(moved) <= varies[0]:
                # P5 (0.2.77): a change no larger than repeats of one version
                # differ by is not shown to be a change -- in either direction.
                line += (f"; the last change moved it by {_gap(abs(moved), runs)}, no more than "
                         f"runs of the same code differ ({_gap(varies[0], runs)} over {varies[1]} "
                         f"repeats): not shown to be better or worse")
            elif len(runs) > 1 and best is not latest and best.value > latest.value:
                line += f"; lower than the best, {best.shown} at step {best.step}"
            elif len(runs) > 1 and latest.value > max(score.value for score in runs[:-1]):
                line += "; the best so far"
            if varies is not None and not line.endswith("not shown to be better or worse"):
                line += (f"; runs of the same code differ by up to {_gap(varies[0], runs)} "
                         f"({varies[1]} repeats)")
            flat = _flat(runs)
            if flat >= FLAT_RUNS:
                # Seen in use: 67.4% six times, edit after edit, then stopped as stuck.
                line += (f"; the same for the last {flat} runs: the changes did not move it -- "
                         f"look at which cases still fail and why, not at more of the same change")
            elif varies is None and moved is not None and 0 < abs(moved) < SMALL_MOVE:
                # A model in the evaluation (an OCR or a judge) scores the same code
                # differently run to run: a small move may be only that.
                line += (f"; the last change moved it by {_gap(abs(moved), runs)} and no version "
                         f"was measured twice: if this evaluation can vary (a model or sampling in "
                         f"it), run it again unchanged before reading a move this small as a change")
            lines.append(line)
    return lines


def unshown_change(loop: CodingLoop, summary: str) -> str | None:
    """Why not to finish yet: the summary says a score moved, by no more than one version's runs differ.

    Before a decision, the runs it takes (P5): `measured` already tells the model
    such a move is not shown to be better or worse; a finish that says it got
    better or worse anyway is told how many runs of each version would tell the
    difference -- or to say that it is within how much runs differ.
    """
    if without("score-spread") or loop.helper_of is not None or not CLAIMED.search(summary) \
            or NOISE_SAID.search(summary):
        return None
    found = series(loop)
    if not found:
        return None
    command, by_metric = max(found.items(), key=lambda item: max(
        score.step for runs in item[1].values() for score in runs))
    for name in sorted(by_metric, key=lambda name: name not in PREFERRED):
        runs = by_metric[name]
        versions = [version_at(loop, score.step) for score in runs]
        varies, moved = spread(runs, versions), _last_move(runs, versions)
        if varies is None or not moved or abs(moved) > varies[0]:
            continue
        latest = runs[-1]
        before = [score for score, version in zip(runs, versions) if version != versions[-1]][-1]
        if not _names(summary, name, (latest, before)):
            continue
        needed = repeats_for(varies[0], abs(moved))
        return (f"not finished: the summary says the score changed, but `{command[:120]}` {name} went "
                f"from {before.shown} (step {before.step}) to {latest.shown} (step {latest.step}) -- "
                f"a move of {_gap(abs(moved), runs)}, no more than runs of the same code differ "
                f"({_gap(varies[0], runs)} over {varies[1]} repeats). Telling a difference that small "
                f"takes about {needed} runs of each version (two-sided 5%, power 80%): run them "
                f"(as a job if long) before saying it changed, or say in the summary that the "
                f"difference is within how much runs of the same code differ")
    return None


def _names(summary: str, metric: str, scores: tuple[Score, ...]) -> bool:
    """Whether a summary speaks of this score: its metric's name, or one of the values printed."""
    if metric.casefold() in summary.casefold():
        return True
    # As numbers: "63%" says the run's "63.0%".
    said = {float(number) for number in re.findall(r"(?<![\d.])\d+(?:\.\d+)?", summary)}
    return any(float(score.shown.rstrip("%")) in said for score in scores)


def _last_move(runs: list[Score], versions: list[int]) -> float | None:
    """The latest version's last score less the version before it's last; None with one version."""
    if not runs or len(set(versions)) < 2:
        return None
    last = versions[-1]
    before = [score for score, version in zip(runs, versions) if version != last]
    return runs[-1].value - before[-1].value if before else None


SCORES_FILE = "scores.jsonl"
# Scores kept for one workspace, oldest first out; and commands shown a new loop.
MAXIMUM_KEPT = 5000
EARLIER_COMMANDS = 3


class ScoreLog:
    """Every score an evaluation run here printed, across loops and conversations (P5).

    A loop's scores were in its own record only: a new conversation about the
    same work began without knowing it had reached 66% the day before. Written
    as each loop ends, read by rule; `.relab/scores.jsonl`, a line a score.
    """

    def __init__(self, workspace: Path) -> None:
        self.path = state_dir(workspace) / SCORES_FILE

    def all(self) -> list[dict[str, object]]:
        try:
            lines = self.path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []
        found = []
        for line in lines:
            try:
                item = json.loads(line)
            except ValueError:
                continue
            if isinstance(item, dict) and isinstance(item.get("value"), (int, float)):
                found.append(item)
        return found

    def record(self, loop: CodingLoop) -> int:
        """Keep the scores of a loop not kept yet; how many."""
        if loop.helper_of is not None:
            return 0
        kept = self.all()
        known = {(item.get("loop_id"), item.get("step"), item.get("metric")) for item in kept}
        now = datetime.now(timezone.utc).isoformat()
        new: list[dict[str, object]] = [{"loop_id": loop.loop_id, "step": score.step, "command": command[:300],
                "metric": name, "shown": score.shown, "value": score.value, "at": now,
                "request": " ".join(_request(loop).split())[:200], "model": loop.model,
                # Which version of the code it measured (0.2.77): repeats share one.
                "version": f"{loop.loop_id}:{version_at(loop, score.step)}"}
               for command, by_metric in series(loop).items()
               for name, runs in by_metric.items() for score in runs
               if (loop.loop_id, score.step, name) not in known]
        return self._append(kept, new)

    def record_run(self, run_id: str, sequence: int, command: list[str], metrics: dict[str, float],
                   *, request: str = "", arm: str | None = None) -> int:
        """Keep a research run's scores beside the coding loops' (P5, 0.2.76): one history.

        The selection metrics its verification printed -- never a held-out
        measurement, which no model may see. Keyed as a loop's are, by run and
        event, so attaching or refreshing again keeps nothing twice.
        """
        kept = self.all()
        known = {(item.get("loop_id"), item.get("step"), item.get("metric")) for item in kept}
        now = datetime.now(timezone.utc).isoformat()
        line = " ".join(command)[:300]
        new: list[dict[str, object]] = [{"loop_id": run_id, "step": sequence, "command": line, "metric": name[:80],
                "shown": f"{value:g}", "value": value, "at": now,
                "request": " ".join(request.split())[:200], "model": None, "source": "research",
                "version": run_id,
                **({"arm": arm[:80]} if arm else {})}
               for name, value in metrics.items() if (run_id, sequence, name[:80]) not in known]
        return self._append(kept, new)

    def _append(self, kept: list[dict[str, object]], new: list[dict[str, object]]) -> int:
        if not new:
            return 0
        self.path.parent.mkdir(parents=True, exist_ok=True)
        rows = kept + new
        if len(rows) > MAXIMUM_KEPT:
            temporary = self.path.with_suffix(".tmp")
            temporary.write_text("".join(json.dumps(item, ensure_ascii=False) + "\n"
                                         for item in rows[-MAXIMUM_KEPT:]), encoding="utf-8")
            temporary.replace(self.path)
        else:
            with self.path.open("a", encoding="utf-8") as handle:
                for item in new:
                    handle.write(json.dumps(item, ensure_ascii=False) + "\n")
        return len(new)

    def by_command(self, limit: int = 8, shown: int = 12) -> list[dict[str, object]]:
        """Each evaluation's scores here, newest evaluation first: as research reads them (P5).

        One variable across versions of the code -- a command and its metric --
        with its scores oldest first, the last `shown` of them.
        """
        groups: dict[tuple[str, str], list[dict[str, object]]] = {}
        for item in self.all():
            command, metric = str(item.get("command", "")).strip(), str(item.get("metric", "")).strip()
            if command and metric:
                groups.setdefault((command, metric), []).append(item)
        ordered = sorted(groups.items(), key=lambda pair: str(pair[1][-1].get("at", "")), reverse=True)
        found = []
        for (command, metric), rows in ordered[:limit]:
            measured: dict[str, object] = {
                "command": command[:300], "metric": metric[:80],
                "shown": [str(row.get("shown") or row.get("value"))[:24] for row in rows[-shown:]],
                "runs": len(rows), "tasks": len({row.get("loop_id") for row in rows}),
                "latest_at": str(rows[-1].get("at", ""))[:40]}
            varies = _kept_spread(rows)
            if varies is not None:
                measured["spread"], measured["repeats"], measured["spread_value"] = varies
            found.append(measured)
        return found

    def earlier(self, loop_id: str) -> list[str]:
        """What evaluations here scored before this loop: best and latest, per command and metric."""
        groups: dict[tuple[str, str], list[dict[str, object]]] = {}
        for item in self.all():
            if item.get("loop_id") == loop_id:
                continue
            key = (str(item.get("command", "")), str(item.get("metric", "")))
            groups.setdefault(key, []).append(item)
        ordered = sorted(groups.items(), key=lambda pair: str(pair[1][-1].get("at", "")),
                         reverse=True)
        lines = []
        for (command, metric), rows in ordered[:EARLIER_COMMANDS]:
            best = max(rows, key=lambda item: float(item["value"]))  # type: ignore[arg-type]
            latest = rows[-1]
            loops = len({item.get("loop_id") for item in rows})
            line = (f"`{command[:120]}` {metric}: best {best.get('shown')} "
                    f"({str(best.get('at', ''))[:10]}), latest {latest.get('shown')} "
                    f"({str(latest.get('at', ''))[:10]}); {len(rows)} run(s) in {loops} "
                    f"earlier task(s)")
            varies = _kept_spread(rows)
            if varies is not None:
                line += f"; runs of the same code differed by up to {varies[0]} ({varies[1]} repeats)"
            lines.append(line)
        return lines


def _kept_spread(rows: list[dict[str, object]]) -> tuple[str, int, float] | None:
    """How far kept runs of one version differed: as printed, how many runs were repeats, and
    as a number in the unit printed -- points for percentages (0.2.77, the number 0.2.81)."""
    groups: dict[str, list[dict[str, object]]] = {}
    for row in rows:
        if row.get("version"):
            groups.setdefault(str(row["version"]), []).append(row)
    repeated = [group for group in groups.values() if len(group) > 1]
    if not repeated:
        return None
    widest = max(max(float(row["value"]) for row in group) - min(float(row["value"]) for row in group)  # type: ignore[arg-type]
                 for group in repeated)
    percent = any(str(row.get("shown", "")).endswith("%") for group in repeated for row in group)
    value = widest * 100 if percent else widest
    return (f"{value:.3g} points" if percent else f"{value:.3g}"), sum(len(group) for group in repeated), value
