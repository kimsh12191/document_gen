"""What coding loops learned the hard way, kept so the next one does not repeat it.

A loop's record already holds its failures: a check that failed and what made
it pass, the same failing step sent again, a step the policy refused. Read
from the record at the end of every loop -- by rule, with no model call -- each
becomes a lesson that names the loop and the steps it comes from, the files
and the words it concerns. A later loop is given the lessons that match its
request, its files and its project, and records which.

Lessons are kept and used without a person confirming them (decided
2026-10-04): they are what happened, not what was concluded. A person lists
and removes them with `relab code lessons`. They live in
`.relab/lessons.json`, which no loop writes any other way.
"""

import hashlib
import json
import re
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path

from pydantic import Field

from relab_core.coding_loop import CodingLoop, LoopActionKind, LoopOutcome, LoopStep
from relab_core.contracts import Contract
from relab_workspace.private_state import state_dir

LESSONS_FILE = "lessons.json"
# Lessons kept for one workspace, oldest first out; and given to one loop.
MAXIMUM_LESSONS = 300
MAXIMUM_GIVEN = 8
# Room for the change that fixed it as well as the failure (0.3.17, from 400).
MAXIMUM_TEXT = 700
# A benchmark's carried failures stay as they were measured with.
EVALUATION_TEXT = 400
# A fix as a lesson says it: the lines its changes took out and put in, at most these.
FIX_LINES = 6
FIX_CHARACTERS = 300
# Refusals worth remembering: what the workspace's rules do not allow.
# What a person says when what was done is not right yet: the one feedback a
# real task has that a loop cannot give itself (RL-10: a loop that believes it
# succeeded writes no lesson about the failure it never saw).
CORRECTION = re.compile(
    r"아직|여전히|안\s?(?:돼|되|됨|된다|됩니다)|틀렸|틀린|잘못|그게\s?아니|아니라|실패|에러가|오류가|"
    r"그대로\s?(?:야|이야|다|입니다|네)|동작하지\s?않|작동하지\s?않|"
    r"still\b|doesn'?t work|does not work|not working|didn'?t (?:fix|work)|did not (?:fix|work)|"
    r"\bwrong\b|incorrect|same (?:error|failure)|\bbroken\b", re.IGNORECASE)
# A lesson given this many times or more that did not prevent its failure at
# least half of them is no longer given.
MISSED_ENOUGH = 2
RULE_REFUSALS = ("outside the project folder", "imports", "is not taken here", "deleting",
                 "is not a program on this host", "is refused", "not run again",
                 "rewrites or publishes history")
# Where a stuck loop was told to take another approach (coding_loop `_replan`).
REPLAN_NOTE = "\n\n[ReLab] Plan "
# What a failed run's observation is followed by when lessons are recalled for it
# (coding_loop `_recalled`, `_common_lesson`): not the run's own output.
COMMON_NOTE = "\nThis error was met in other projects of yours"
RECALLED_NOTE = "\nAn earlier loop here met this error"
RECALLED_NOTES = (COMMON_NOTE, RECALLED_NOTE)
# How a run's observation sets off what the program wrote to stderr (coding_loop `_run`).
STDERR_HEADER = "--- stderr ---"
# What an output read in the wrong encoding is left with: a lesson of it says nothing.
UNREADABLE = "�"
STOPWORDS = frozenset({"this", "that", "with", "from", "into", "have", "make", "file", "files",
                       "code", "please", "should", "would", "there", "their", "what", "when",
                       "which", "about", "after", "before", "해줘", "해주세요", "그리고", "에서"})


class Lesson(Contract):
    """One thing a loop found out by failing, with where it is recorded."""

    lesson_id: str = Field(pattern=r"^lesson-[0-9a-f]{16}$")
    # `evaluation`: an attempt at the same request failed checks it could not
    # see -- only a benchmark that carries lessons between repeats says so.
    # `correction`: the person said what the loop had done was not right (P3).
    # `changed_approach`: a loop stuck on one attempt was told to take another
    # (plan B, plan C), and the other way got through -- what worked instead.
    kind: str = Field(pattern=r"^(fixed_failure|repeated_failure|refusal|evaluation|correction"
                              r"|changed_approach)$")
    text: str = Field(min_length=1, max_length=MAXIMUM_TEXT)
    loop_id: str = Field(pattern=r"^loop-[0-9a-f]{32}$")
    steps: list[int] = Field(min_length=1, max_length=8)
    project: str | None = None
    files: list[str] = Field(default_factory=list, max_length=12)
    words: list[str] = Field(default_factory=list, max_length=24)
    created_at: datetime
    # How often it was given to a loop, and how often that loop then met the
    # very failure it describes (P3): a lesson that keeps not helping is not given.
    given: int = Field(default=0, ge=0)
    missed: int = Field(default=0, ge=0)


def words_of(text: str) -> list[str]:
    """The words a lesson or a request is matched by: names and longer words, in order."""
    found = re.findall(r"[A-Za-z_][A-Za-z0-9_]{3,}|[가-힣]{2,}", text)
    seen: dict[str, None] = {}
    for word in found:
        key = word.casefold()
        if key not in STOPWORDS:
            seen.setdefault(key, None)
    return list(seen)[:24]


# A pytest failure's header: `____ test_name ____` (or `ERROR collecting x`).
FAILURE_HEADER = re.compile(r"^_{3,} (.+?) _{3,}$", re.MULTILINE)


def first_failing(output: str) -> str | None:
    """The first test a pytest run says failed, by name, when it names one."""
    header = FAILURE_HEADER.search(output)
    if header is not None:
        return header.group(1)[:120]
    listed = re.search(r"^(?:FAILED|ERROR) (\S+)", output, re.MULTILINE)
    return listed.group(1)[:120] if listed else None


def first_error(observation: str) -> str:
    """The line of a failed run's output that says what failed, cut to fit.

    What ReLab added after the output -- the lessons it recalled for the
    failure -- names errors too, and is left out (0.3.17).
    """
    for note in (*RECALLED_NOTES, REPLAN_NOTE):
        observation = observation.split(note, 1)[0]
    lines = [line.strip() for line in observation.splitlines() if line.strip()]
    # pytest's own statement of a failure: the first `E` line naming an error or
    # an assert -- it holds what came out and what was expected. The last `E`
    # line, taken before, was a fragment of the diff under it ("E ?      ^"),
    # and a repeat told only that failed the same way again.
    stated = [line for line in lines
              if re.match(r"^E\s+(\w*(Error|Exception)\b|assert\b)", line)]
    if stated:
        return stated[0][:200]
    for pattern in (r"^E\s+\S", r"Error\b|Exception\b", r"^FAILED\b", r"assert"):
        hits = [line for line in lines if re.search(pattern, line)]
        if hits:
            return hits[-1][:200] if pattern != r"^FAILED\b" else hits[0][:200]
    # A program that says why in its own words: its last line on stderr, not the
    # "exit 1" header above it (seen in a real record: a script's own check of its
    # data said what was wrong there, and the lesson kept only "exit 1").
    said = observation.rsplit(STDERR_HEADER, 1)
    told = [line.strip() for line in said[1].splitlines() if line.strip()] if len(said) == 2 else []
    if told:
        return told[-1][:200]
    hits = [line for line in lines if re.search(r"exit -?\d+", line)]
    if hits:
        return hits[-1][:200]
    return (lines[-1] if lines else "it failed")[:200]


def failure_line(step: LoopStep) -> str:
    """What a failed step says failed: a refusal's first line, else a run's error line."""
    said = step.observation.split(REPLAN_NOTE, 1)[0].strip()
    if said.startswith("refused"):
        return said.splitlines()[0][:200]
    return first_error(said)


def _command(step: LoopStep) -> str:
    return " ".join(step.action.argv or [])[:160]


def extract(loop: CodingLoop) -> list[Lesson]:
    """The lessons a finished loop's record holds."""
    now = datetime.now(timezone.utc)
    found: list[Lesson] = []

    def add(kind: str, text: str, steps: list[int], files: list[str]) -> None:
        if UNREADABLE in text:
            # Output read in the wrong encoding (before 0.3.24): the failure it names is lost.
            return
        identity = f"{loop.loop_id}{kind}{steps}".encode()
        found.append(Lesson(
            lesson_id="lesson-" + hashlib.sha256(identity).hexdigest()[:16], kind=kind,
            text=text[:MAXIMUM_TEXT], loop_id=loop.loop_id, steps=steps[:8],
            project=loop.scope, files=sorted(set(files))[:12],
            words=words_of(f"{loop.request} {text}"), created_at=now))

    runs = [step for step in loop.steps if step.action.action is LoopActionKind.RUN]
    for failed in runs:
        if failed.succeeded or failed.observation.startswith(("refused", "not done again",
                                                              "waiting for")):
            continue
        later = next((step for step in runs if step.index > failed.index and step.succeeded
                      and step.action.argv == failed.action.argv), None)
        if later is None:
            continue
        changed = [path for step in loop.steps
                   if failed.index < step.index < later.index and step.succeeded
                   for path in _written(step)]
        if not changed:
            continue
        fix = what_changed(loop, failed.index, later.index)
        add("fixed_failure",
            f"`{_command(failed)}` failed with: {first_error(failed.observation)} -- it passed "
            f"after changing {', '.join(sorted(set(changed)))}" + (f"; the change: {fix}" if fix else "") + ".",
            [failed.index, later.index], changed)
    repeated = [step for step in loop.steps if step.observation.startswith("not done again")]
    if repeated:
        first = repeated[0]
        target = first.action.path or _command(first)
        add("repeated_failure",
            f"Sending the same failing {first.action.action.value} on {target} again did not "
            f"help; read why it failed and change the step.",
            [step.index for step in repeated], [first.action.path] if first.action.path else [])
    _changed_approaches(loop, add)
    seen: set[str] = set()
    for step in loop.steps:
        said = step.observation
        if not said.startswith("refused: ") or not any(rule in said for rule in RULE_REFUSALS):
            continue
        reason = said.removeprefix("refused: ").split("\n", 1)[0][:240]
        if reason in seen:
            continue
        seen.add(reason)
        add("refusal", f"Here this is refused: {reason}", [step.index],
            [step.action.path] if step.action.path else [])
    # What the person said was not right: a follow-up or a word while it worked.
    asked = [(item.after_step, item.request) for item in loop.followups] + [
        (item.applied_after_step, item.instruction) for item in loop.steering
        if item.applied_after_step is not None]
    for after, said in sorted(asked, key=lambda pair: pair[0]):
        if not CORRECTION.search(said) or after < 1:
            continue
        before = [item for item in loop.followups if item.after_step < after]
        request = before[-1].request if before else loop.request
        started = before[-1].after_step if before else 0
        changed = sorted({path for step in loop.steps[started:after] if step.succeeded
                          for path in _written(step)})
        add("correction",
            f"After \"{_clip(request, 140)}\", the person said it was not right: "
            f"\"{_clip(said, 200)}\"" + (f" -- the files changed then: {', '.join(changed[:6])}"
                                           if changed else ""),
            [after], changed)
    return found


def _changed_approaches(loop: CodingLoop,
                        add: Callable[[str, str, list[int], list[str]], None]) -> None:
    """What got a stuck loop through after it was told to take another approach.

    "Do not repeat it" was all a stuck loop left behind (0.2.45 asks for plan B,
    plan C); the way that then worked is what the next loop at the same failure
    needs. Kept only when it got through before the next plan was asked for: a
    different command that succeeded, or files changed and the loop finished.
    """
    noted = [step for step in loop.steps if REPLAN_NOTE in step.observation]
    for place, note in enumerate(noted):
        failed = next((step for step in reversed(loop.steps[:note.index])
                       if not step.succeeded and not step.observation.startswith(
                           ("not done again", "waiting for"))), None)
        if failed is None:
            continue
        until = noted[place + 1].index if place + 1 < len(noted) else None
        after = [step for step in loop.steps
                 if step.index > note.index and (until is None or step.index < until)]
        passed = next((step for step in after if step.action.action is LoopActionKind.RUN
                       and step.succeeded and step.action.argv != failed.action.argv), None)
        changed = sorted({path for step in after
                          if passed is None or step.index < passed.index
                          for path in _written(step)})
        # Without a command that passed, the change is what worked only when ReLab's verdict
        # says the work stood (R10): a finish the model claimed is not a lesson that it worked.
        if passed is None and not (changed and until is None and loop.outcome is LoopOutcome.FINISHED
                                   and loop.assessment is not None and loop.assessment.succeeded):
            continue
        what = (f"`{_command(failed)}`" if failed.action.action is LoopActionKind.RUN
                else f"{failed.action.action.value} on {failed.action.path or 'several files'}")
        fix = what_changed(loop, note.index, passed.index if passed is not None else until)
        way = ([f"changing {', '.join(changed[:6])}" + (f" ({fix})" if fix else "")] if changed else []) + (
            [f"`{_command(passed)}` succeeded"] if passed is not None else [])
        add("changed_approach",
            f"{what} kept failing with: {_clip(failure_line(failed), 160)} -- sending it again "
            f"did not help; what worked instead: {', then '.join(way)}.",
            [failed.index, note.index] + ([passed.index] if passed is not None else []),
            changed + ([failed.action.path] if failed.action.path else []))


def what_changed(loop: CodingLoop, after: int, before: int | None) -> str:
    """The lines changed between two steps, as a lesson says what fixed it (0.3.17).

    "It passed after changing create_database.py" said where, not how -- the
    one part a later loop could use. Each change's own diff in the record says
    how: the lines taken out (-) and put in (+), context and blank lines left
    out, a few at most. A file created whole says only that it was created.
    Read from the record, with no model call; "" when nothing is there to say.
    """
    parts: list[str] = []
    for change in loop.changes:
        if change.reverted or change.step <= after or (before is not None and change.step >= before):
            continue
        if change.before_digest is None:
            parts.append(f"{change.path} created")
            continue
        lines = [line for line in (change.diff or "").splitlines()
                 if line[:1] in ("+", "-") and line[1:].strip()]
        if lines:
            parts.append(f"{change.path}: " + "; ".join(
                f"{line[0]} {_clip(line[1:].strip(), 100)}" for line in lines[:FIX_LINES]))
    return _clip(" | ".join(parts), FIX_CHARACTERS) if parts else ""


def _written(step: LoopStep) -> list[str]:
    """The files a step wrote, when it wrote any: one, or each of an edit_batch's."""
    if not step.succeeded:
        return []
    if step.action.action is LoopActionKind.EDIT_BATCH:
        return [item.path for item in step.action.edit_files or []]
    if step.action.action in (LoopActionKind.WRITE_FILE, LoopActionKind.EDIT_FILE) \
            and step.action.path is not None:
        return [step.action.path]
    return []


def _clip(text: str, limit: int) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[:limit - 3] + "..."


def missed_by(given: list[str], new: list[Lesson]) -> list[str]:
    """Of the lessons a loop was given, those whose failure it met anyway.

    By the error a lesson names: a loop given "`pytest` failed with: X" that
    then failed with X again was not helped by it.
    """
    errors = [error for lesson in new
              if lesson.kind in ("fixed_failure", "repeated_failure", "changed_approach")
              for error in [_named_error(lesson.text)] if error is not None]
    return [text for text in given
            if any(error in text for error in errors)]


def _named_error(text: str) -> str | None:
    """The error a fixed-failure lesson names, when it is specific enough to compare."""
    found = (re.search(r"failed with: (.+?) -- it passed", text)
             or re.search(r"kept failing with: (.+?) -- sending it again", text))
    error = found.group(1).strip() if found else None
    return error if error is not None and len(error) >= 12 else None


def failure_statements(output: str, limit: int = 3) -> list[tuple[str, str]]:
    """Each failed test and pytest's statement of why, distinct by why, at most `limit`.

    One failure said too little: dot_dsl expects one message for a malformed
    edge, another for a node and another for an attribute, and a lesson
    naming the first sent the next repeat to fix that one alone.
    """
    headers = list(FAILURE_HEADER.finditer(output))
    found: list[tuple[str, str]] = []
    seen: set[str] = set()
    for place, header in enumerate(headers):
        end = headers[place + 1].start() if place + 1 < len(headers) else len(output)
        lines = [line.strip() for line in output[header.end():end].splitlines()]
        stated = next((line for line in lines
                       if re.match(r"^E\s+(\w*(Error|Exception)\b|assert\b)", line)), None)
        if stated is None or stated in seen:
            continue
        seen.add(stated)
        found.append((header.group(1)[:80], stated[:160]))
        if len(found) >= limit:
            break
    return found


def stated_failures(output: str, limit: int = 3) -> list[str]:
    """`failure_statements`, a line each: "test: E AssertionError: ..."."""
    return [f"{test}: {line}" for test, line in failure_statements(output, limit)]


def evaluated(loop_id: str, request: str, check_output: str, steps: int) -> Lesson:
    """What a benchmark's hidden check said of a finished attempt, as a lesson."""
    stated = stated_failures(check_output)
    if stated:
        said = "; ".join(stated)
    else:
        said = first_error(check_output)
        test = first_failing(check_output)
        if test is not None and test not in said:
            said = f"{test}: {said}"
    return Lesson(
        lesson_id="lesson-" + hashlib.sha256(f"{loop_id}evaluation".encode()).hexdigest()[:16],
        kind="evaluation",
        # The guidance first: the failures are what a long lesson is cut in.
        text=(f"An earlier attempt at this request failed tests it could not see; match what "
              f"they expect exactly (as 'got != expected'): {said}")[:EVALUATION_TEXT],
        loop_id=loop_id, steps=[max(1, steps)], words=words_of(request),
        created_at=datetime.now(timezone.utc))


class LessonStore:
    """The lessons of one workspace, read fresh each time: a person may edit them."""

    def __init__(self, workspace: Path) -> None:
        self.path = state_dir(workspace) / LESSONS_FILE

    def all(self) -> list[Lesson]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        found = []
        for item in data if isinstance(data, list) else []:
            try:
                found.append(Lesson.model_validate(item))
            except ValueError:
                continue
        return found

    def _write(self, lessons: list[Lesson]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps([item.model_dump(mode="json") for item in lessons],
                                        ensure_ascii=False, indent=1), encoding="utf-8")
        temporary.replace(self.path)

    def add(self, new: list[Lesson]) -> list[Lesson]:
        """Keep new lessons; one with the same text as a kept one replaces it."""
        if not new:
            return []
        kept = [item for item in self.all()
                if all(item.text != added.text and item.lesson_id != added.lesson_id
                       for added in new)]
        self._write((kept + new)[-MAXIMUM_LESSONS:])
        return new

    def record_use(self, given: list[str], new: list[Lesson]) -> None:
        """Count, for the lessons a finished loop was given, that they were given, and missed."""
        if not given:
            return
        missed = set(missed_by(given, new))
        kept = self.all()
        changed = False
        for index, lesson in enumerate(kept):
            if lesson.text in given:
                kept[index] = lesson.model_copy(update={
                    "given": lesson.given + 1,
                    "missed": lesson.missed + (1 if lesson.text in missed else 0)})
                changed = True
        if changed:
            self._write(kept)

    def remove(self, lesson_id: str) -> bool:
        kept = self.all()
        left = [item for item in kept if item.lesson_id != lesson_id]
        if len(left) == len(kept):
            return False
        self._write(left)
        return True

    def relevant(self, request: str, project: str | None, files: list[str]) -> list[Lesson]:
        """The lessons for a new loop: by files named, words shared and project, best first.

        Deterministic, like research memory's retrieval: the same request against
        the same lessons gives the same lessons, in the same order.
        """
        wanted = set(words_of(request))
        named = {path.replace("\\", "/") for path in files}
        scored = []
        for lesson in self.all():
            if UNREADABLE in lesson.text:
                # Kept before output was read in its own encoding (0.3.24): it says nothing.
                continue
            if lesson.missed >= MISSED_ENOUGH and lesson.missed * 2 >= lesson.given:
                # Given, and its failure met anyway, at least half the times.
                continue
            if (lesson.project is not None and lesson.project != project
                    and lesson.project not in request
                    and not any(path.startswith(f"{lesson.project}/") for path in named)):
                # Another project's: a calculator was given text2sql's lessons
                # because both ran pytest. Only when the request names it.
                continue
            score = 3 * len(named & set(lesson.files))
            score += sum(1 for path in lesson.files if path in request)
            score += len(wanted & set(lesson.words))
            if project is not None and lesson.project == project:
                score += 1
            if lesson.kind == "refusal" and lesson.project == project:
                score += 1
            if lesson.kind == "changed_approach":
                # A way through a failure a loop was stuck on, found by doing it.
                score += 1
            if lesson.kind == "correction":
                # The person's own word on work like this: weighed as a check's.
                score += 1
            if lesson.kind == "evaluation" and set(lesson.words) == wanted:
                # The same request again: what its checks said is for this one.
                score += 2
            if score >= 2:
                scored.append((score, lesson.created_at, lesson.lesson_id, lesson))
        scored.sort(key=lambda item: (item[0], item[1], item[2]), reverse=True)
        return [item[3] for item in scored[:MAXIMUM_GIVEN]]
