"""Choosing the gateway a role calls, from what was declared.

Two modes, and which one applies is a fact about the declaration rather than a
setting:

    no routing policy   whatever the caller passes, as it always was
    a routing policy    the declared route, resolved, and nothing else

The second is fail-closed on purpose. A policy that could be bypassed because
the caller had no resolver, or because a role was left out of it, would not be a
policy -- it would be a wish plus an audit log written after the fact. Every
refusal here happens before a provider is called, so a declaration that cannot
be enforced stops the work instead of being recorded as having been ignored.

There is one thing this does *not* check, deliberately. What a provider says it
served can differ from the gateway that called it, and that is a discrepancy to
read afterwards rather than a violation of anything ReLab declared. The two
comparisons are different layers:

    declared route vs the resolved gateway   refused here, before the call
    the gateway vs what the provider served  recorded, and read later
"""

from collections.abc import Callable
from typing import TypeVar

from relab_core.gateways import GatewayResolver
from relab_core.generation import ModelGateway
from relab_core.research import ResearchSession
from relab_core.routing import (
    ModelInvocationProvenance,
    ModelRole,
    ModelRoute,
    ModelRoutingPolicy,
)

# Whatever a caller wraps a gateway in for a role: a planner, an advisor. The
# rules are the same for all of them, and none of them is a gateway.
Component = TypeVar("Component")


class RoutingUnavailable(ValueError):
    """A route was declared and nothing here can carry it out.

    Its own type because a caller may reasonably handle it -- by supplying a
    resolver -- where it would not handle a plan being invalid. It is still a
    `ValueError`, so nothing that catches those stops catching this.
    """


def gateway_for(
    session: ResearchSession, role: ModelRole, *,
    caller: ModelGateway | None = None, resolver: GatewayResolver | None = None,
) -> tuple[ModelGateway, ModelRoute | None]:
    """The gateway this role must use, for a session that exists."""
    return gateway_under(session.routing_policy, role, caller=caller, resolver=resolver)


def gateway_under(
    policy: ModelRoutingPolicy | None, role: ModelRole, *,
    caller: ModelGateway | None = None, resolver: GatewayResolver | None = None,
) -> tuple[ModelGateway, ModelRoute | None]:
    """The gateway this role must use, and the route it was declared under.

    Takes the policy rather than a session because the planner runs before one
    exists. Until a design is accepted the policy is caller-owned and travels
    with the proposal; afterwards it is session state and this is read from
    there. The rules are the same either way, which is the point of there being
    one function.

    Returns the route as well as the gateway so provenance is built from the
    declaration rather than re-derived from whatever answered. `None` for the
    route means no routing was declared, and the pair is then exactly what every
    call was before: the caller's gateway, and nothing claimed about what it
    should have been.
    """
    if policy is None:
        if caller is None:
            raise RoutingUnavailable(
                "no routing is declared here, so a gateway must be supplied")
        return caller, None

    declared = policy.route_for(role)
    if declared is None:
        # Not a gap to fill with the caller's gateway. A session that declared
        # routing declared what it routes, and a role left out of it is a role
        # nobody said how to run -- falling back would answer that question on
        # the declaration's behalf.
        raise RoutingUnavailable(
            f"the declared routing has no route for {role.value}; "
            f"it declares {sorted(item.value for item in policy.routes)}")
    if resolver is None:
        raise RoutingUnavailable(
            f"{role.value} is routed to {declared.provider}/{declared.model} "
            f"and nothing here can resolve a route to a gateway")

    resolved = resolver.resolve(declared)
    identity = getattr(resolved, "identity", None)
    if identity is None:
        raise RoutingUnavailable(
            f"the gateway resolved for {role.value} does not say which model it is, "
            f"so it cannot be checked against {declared.provider}/{declared.model}")
    if not declared.matches(identity):
        # Before the call, not after it. A resolver that returns something else
        # is a composition-root bug, and the honest place to find it is the
        # moment it happens rather than in a provenance record afterwards.
        raise RoutingUnavailable(
            f"{role.value} is routed to {declared.provider}/{declared.model} and the "
            f"resolver returned {identity.provider}/{identity.model}")
    return resolved, declared


def routed_component(
    policy: ModelRoutingPolicy | None, role: ModelRole, *,
    given: Component | None, resolver: GatewayResolver | None,
    build: Callable[[ModelGateway, ModelRoute], Component] | None, what: str,
) -> tuple[Component | None, ModelRoute | None]:
    """The planner or advisor this role must use, and the route it was declared under.

    The same rules as `gateway_under`, for the two roles whose callers construct
    something around a gateway rather than passing the gateway itself. A planner
    carries a workspace and an inspection budget; an advisor carries a timeout.
    Neither is a gateway, and both are still a model call that a declared route
    has to decide.

    So the declaration resolves the gateway and `build` wraps it. A caller that
    declared routing and brought a pre-built one instead is refused: the object
    it built is around a gateway nobody declared, and using it would be the
    bypass this whole module exists to prevent.
    """
    if policy is None:
        return given, None
    if build is None:
        raise RoutingUnavailable(
            f"{role.value} is routed by this session's declaration and nothing here "
            f"can build {what} for the declared route")
    gateway, declared = gateway_under(policy, role, resolver=resolver)
    assert declared is not None  # a declared policy resolved, so a route exists
    return build(gateway, declared), declared


def invocation(
    role: ModelRole, gateway: ModelGateway, declared: ModelRoute | None, *,
    reported_model: str | None = None,
) -> ModelInvocationProvenance | None:
    """What to record about a call that happened, or None when nothing can be.

    None for a gateway that does not say who it is. Recording a role and a
    declaration beside an unknown identity would be recording two thirds of a
    fact, and the missing third is the one a reader wants.
    """
    identity = getattr(gateway, "identity", None)
    if identity is None:
        return None
    return ModelInvocationProvenance(
        role=role, declared_route=declared, identity=identity,
        reported_model=reported_model)
