"""One account of what an arm has spent, read by everything that spends it.

There were three copies of this. `execute` counted an arm's attempts inline to
decide whether to dispatch another; the lifecycle counted them again to decide
whether to report a spent budget, under a comment that said "mirror execute's
attachment prefix"; and `_design` had a third for assessment. A comment
promising that two calculations agree is a promise, and the thing it promises
is what this module makes unnecessary.

It matters more now than it did. Adding "a measurement that broke its contract
does not spend a repeat" to two independent counters is how a session comes to
report a budget the executor does not believe in -- and the person reading it
cannot tell which of the two is wrong.

What an arm has spent is a projection, not a record: every input is already
stored. It is computed here, once, from the session, the readiness the session
was read with, and the runs themselves.
"""

from collections.abc import Callable

from relab_core.accounting import spends_experimental_slot
from relab_core.coding.patch import VerificationResult
from relab_core.lifecycle import MeasurementBlocker
from relab_core.measurement import MeasurementInvalidity
from relab_core.provider import IncidentKind, kind_of
from relab_core.research import (
    CodingRunReference,
    MeasurementImpact,
    ResearchSession,
    ResearchSessionReadiness,
    attempt_stands,
)
from relab_core.runs import CodingRun

LoadRun = Callable[[str], CodingRun]


class ArmAccount:
    """What one arm has spent, and on what.

    Deliberately not a `Contract`: nothing records this and nothing sends it
    anywhere. It is read in the same breath as it is computed, and making it a
    persisted-looking type would invite somebody to store a count whose inputs
    move underneath it.
    """

    def __init__(
        self, arm: str, standing: list[CodingRunReference],
        lost: dict[IncidentKind, list[CodingRunReference]],
        unmeasured: list[tuple[CodingRunReference, MeasurementInvalidity]],
        spent: list[CodingRunReference],
    ) -> None:
        # Attempts at the task this plan declares now. A run attached under a
        # task since revised stays in the record and stops spending a budget it
        # was never meant for.
        self.arm, self.standing = arm, standing
        # Provider calls that produced nothing, by kind, each with its own budget.
        self.lost = lost
        # Runs whose measurement broke its contract, with what it broke.
        self.unmeasured = unmeasured
        # What is left: the attempts this arm actually spent on the experiment.
        self.spent = spent

    @property
    def unmeasurable(self) -> bool:
        """Whether this arm is waiting on the instrument rather than on itself."""
        return bool(self.unmeasured)


def arm_accounts(
    session: ResearchSession, readiness: ResearchSessionReadiness, load: LoadRun,
) -> dict[str, ArmAccount]:
    """The account for every arm the plan declares, keyed by arm."""
    invalidity = {
        run.run_id: run.measurement.invalidity
        for arm in readiness.arms for run in arm.runs
        if run.measurement is not None and run.measurement.invalidity is not None
    }
    reading = {run.run_id: run.measurement
               for arm in readiness.arms for run in arm.runs}
    plan = session.plan
    accounts = {}
    for arm in (plan.arms if plan is not None else []):
        # Loaded before it is judged, because whether a run still stands now
        # depends on the ruler its reading was taken under, and only the run
        # knows that. The loads are not extra: every standing run is loaded
        # below anyway.
        candidates = [(ref, load(ref.run_id)) for ref in session.runs if ref.role == arm]
        held = [(ref, run) for ref, run in candidates
                if attempt_stands(session, ref, _verification(run))]
        standing = [ref for ref, _ in held]
        lost: dict[IncidentKind, list[CodingRunReference]] = {kind: [] for kind in IncidentKind}
        unmeasured, spent = [], []
        for ref, run in held:
            if run.provider_incident is not None:
                lost[kind_of(run.provider_incident)].append(ref)
                continue
            broken = invalidity.get(ref.run_id)
            if broken is not None:
                unmeasured.append((ref, broken))
                continue
            if spends_experimental_slot(run, reading.get(ref.run_id)):
                spent.append(ref)
        accounts[arm] = ArmAccount(arm, standing, lost, unmeasured, spent)
    return accounts


def _verification(run: CodingRun) -> "VerificationResult | None":
    """This run's reading, or None when it has not produced one."""
    return None if run.patch_evidence is None else run.patch_evidence.verification


def measurement_impact(session: ResearchSession, load: LoadRun) -> MeasurementImpact:
    """What replacing this study's ruler would retire, before anyone agrees to it.

    Read from the readings themselves rather than from the arms' accounts: this
    is about every reading the study holds, including arms that are satisfied
    and arms nobody is worried about. Replacing the instrument is not an arm's
    business, which is exactly why it has to be shown as a whole.

    An attempt with no reading is listed separately and is not retired. Its
    task still stands and the new ruler can take its first measurement, so
    replacing the instrument does not throw away work nobody has measured --
    and a person deciding this should be able to see that it does not.
    """
    retired, unmeasured, arms = [], [], []
    for reference in session.runs:
        run = load(reference.run_id)
        if _verification(run) is None:
            unmeasured.append(reference.run_id)
            continue
        retired.append(reference.run_id)
        if reference.role is not None and reference.role not in arms:
            arms.append(reference.role)
    return MeasurementImpact(
        retired_readings=retired, affected_arms=arms, unmeasured_attempts=unmeasured)


def measurement_blocker(accounts: dict[str, ArmAccount]) -> MeasurementBlocker | None:
    """One blocker for the study, because there is one instrument.

    Per study rather than per arm: the measurement is owned by the plan and
    frozen before any arm runs, which is what makes the arms comparable. An arm
    that has not hit it yet is not better off -- it is next.
    """
    found = [(account, ref, broken) for account in accounts.values()
             for ref, broken in account.unmeasured]
    if not found:
        return None
    return MeasurementBlocker(
        invalidities=list(dict.fromkeys(broken for _, _, broken in found)),
        affected_runs=[ref.run_id for _, ref, _ in found],
        affected_arms=list(dict.fromkeys(account.arm for account, _, _ in found)),
    )
