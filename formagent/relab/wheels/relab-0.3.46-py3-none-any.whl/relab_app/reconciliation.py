"""Diagnose a session against its run history, then recover only what evidence settles.

Diagnosis comes first and classifies every disagreement as active work, something
stored records can settle, or something only a person can. Recovery acts on the
middle group alone: it calls no model, applies or reverts no patch and runs no
verifier, so resuming after an interruption cannot repeat work that already happened.
"""

from pathlib import Path

from relab_app.runs import CodingRunService
from relab_app.sessions import ResearchSessionService
from relab_core.contracts import RunState
from relab_core.reconciliation import (
    ReconciliationDisposition,
    ReconciliationFinding,
    ReconciliationKind,
    ReconciliationSummary,
    SessionReconciliation,
)
from relab_core.research import ResearchSession
from relab_core.runs import RunEvent
from relab_workspace.locking import (
    session_execution_held,
    session_execution_lock,
    workspace_mutation_held,
)
from relab_workspace.patch_store import reconcilable_evidence

ABANDON_REASON = "abandoned after interruption: no proposal was recorded"
INSPECT = "inspect the run history manually"


def _finding(
    kind: ReconciliationKind, subject: str, detail: str,
    disposition: ReconciliationDisposition, action: str,
) -> ReconciliationFinding:
    return ReconciliationFinding(kind=kind, subject=subject, detail=detail,
                                 disposition=disposition, action=action)


def _manual(kind: ReconciliationKind, subject: str, detail: str) -> ReconciliationFinding:
    return _finding(kind, subject, detail, ReconciliationDisposition.MANUAL, INSPECT)


class SessionReconciler:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.research = ResearchSessionService(self.workspace)
        self.runs = CodingRunService(self.workspace)

    def diagnose(self, session_id: str) -> SessionReconciliation:
        """Read-only: classify every disagreement before anything is repaired."""
        return self._diagnose(
            session_id, executing=session_execution_held(self.workspace, session_id))

    def _diagnose(self, session_id: str, *, executing: bool) -> SessionReconciliation:
        event = self.research.store.latest(session_id)
        # A patch in flight is active work whoever started it, session or not.
        active = executing or workspace_mutation_held(self.workspace)
        findings = [*self._reference_findings(event.snapshot, active=active),
                    *self._request_findings(event.snapshot)]
        return SessionReconciliation(
            session_id=session_id, event_sequence=event.sequence,
            consistent=not findings, summary=_summarize(findings), findings=findings,
        )

    def _reference_findings(
        self, session: ResearchSession, *, active: bool,
    ) -> list[ReconciliationFinding]:
        findings = []
        for reference in session.runs:
            events = self.runs.store.events(reference.run_id)
            if not events:
                findings.append(_manual(
                    ReconciliationKind.MISSING_RUN, reference.run_id,
                    "the session references a run this workspace does not hold"))
                continue
            if Path(events[-1].snapshot.workspace).resolve() != self.workspace:
                findings.append(_manual(
                    ReconciliationKind.FOREIGN_WORKSPACE, reference.run_id,
                    "the referenced run belongs to another workspace"))
                continue
            if not any(item.sequence == reference.event_sequence for item in events):
                findings.append(_manual(
                    ReconciliationKind.MISSING_EVENT, reference.run_id,
                    f"pinned event {reference.event_sequence} is absent from the history"))
                continue
            finding = self._run_finding(reference.event_sequence, events[-1], active=active)
            if finding is not None:
                findings.append(finding)
        return findings

    def _run_finding(
        self, pinned: int, latest: RunEvent, *, active: bool,
    ) -> ReconciliationFinding | None:
        run, run_id = latest.snapshot, latest.run_id
        if (run.holdout_argv and run.holdout_verification is None
                and run.holdout_abandon_reason is None):
            if active:
                return _finding(
                    ReconciliationKind.ACTIVE_RUN, run_id,
                    "holdout measurement is unresolved and exclusion is held; let the worker finish",
                    ReconciliationDisposition.ACTIVE, "let the running worker finish")
            return _manual(
                ReconciliationKind.INTERRUPTED_HOLDOUT, run_id,
                "holdout measurement started without a recorded outcome; do not measure again")
        if run.state == RunState.RUNNING:
            if active:
                return _finding(
                    ReconciliationKind.ACTIVE_RUN, run_id,
                    "the run is executing and exclusion is held; it is not interrupted",
                    ReconciliationDisposition.ACTIVE, "let the running worker finish")
            if run.proposal is None or not run.verify_argv:
                return _finding(
                    ReconciliationKind.STALLED_GENERATION, run_id,
                    "generation started and recorded no proposal to reconcile against",
                    ReconciliationDisposition.MANUAL,
                    "confirm the worker stopped, then recover with abandon_stalled")
            evidence, reason = reconcilable_evidence(self.workspace, run)
            if evidence is None:
                return _manual(ReconciliationKind.INTERRUPTED_PATCH, run_id,
                               f"a patch started and {reason}")
            return _finding(
                ReconciliationKind.INTERRUPTED_PATCH, run_id,
                f"a patch started and its outcome was never recorded; {reason}",
                ReconciliationDisposition.RECOVERABLE, "reconcile from stored patch evidence")
        if latest.sequence > pinned:
            return _finding(
                ReconciliationKind.STALE_PIN, run_id,
                f"the run advanced to event {latest.sequence} while the pin stayed at {pinned}",
                ReconciliationDisposition.RECOVERABLE, "advance the pinned reference")
        return None

    def _request_findings(self, session: ResearchSession) -> list[ReconciliationFinding]:
        findings = []
        for request in session.requests:
            if request.run_id is not None:
                continue
            claims = self.runs.store.runs_for_request(request.request_id)
            if len(claims) > 1:
                findings.append(_manual(
                    ReconciliationKind.AMBIGUOUS_REQUEST, request.request_id,
                    f"{len(claims)} runs claim this request id"))
            elif claims:
                findings.append(_finding(
                    ReconciliationKind.ORPHANED_REQUEST, request.request_id,
                    "a run was created for this request but never attached",
                    ReconciliationDisposition.RECOVERABLE, "attach the existing run"))
            else:
                findings.append(_finding(
                    ReconciliationKind.UNCLAIMED_REQUEST, request.request_id,
                    "the request was recorded but no run was created",
                    ReconciliationDisposition.RECOVERABLE, "create and attach the run"))
        return findings

    def recover(self, session_id: str, *, abandon_stalled: bool = False) -> SessionReconciliation:
        """Apply only what records settle; a person still decides what is abandoned."""
        self.research.store.latest(session_id)  # Missing IDs must not allocate a lock file.
        with session_execution_lock(self.workspace, session_id):
            # Holding the lock is the proof that this session is not executing.
            before = self._diagnose(session_id, executing=False)
            self.research.open_session(self.research.store.latest(session_id).snapshot)
            for finding in before.findings:
                self._apply(session_id, finding, abandon_stalled=abandon_stalled)
            after = self._diagnose(session_id, executing=False)
            remaining = {(item.kind, item.subject) for item in after.findings}
            return after.model_copy(update={"findings": [
                *[item.model_copy(update={"resolved": True}) for item in before.findings
                  if (item.kind, item.subject) not in remaining],
                *after.findings,
            ]})

    def _apply(
        self, session_id: str, finding: ReconciliationFinding, *, abandon_stalled: bool,
    ) -> None:
        if finding.disposition is ReconciliationDisposition.RECOVERABLE:
            if finding.kind is ReconciliationKind.INTERRUPTED_PATCH:
                self.runs.recover(finding.subject)
            elif finding.kind in {ReconciliationKind.ORPHANED_REQUEST,
                                  ReconciliationKind.UNCLAIMED_REQUEST}:
                self.research.fulfil_requests(session_id)
        elif finding.kind is ReconciliationKind.STALLED_GENERATION and abandon_stalled:
            self._abandon(finding.subject)
        if finding.kind in {ReconciliationKind.STALE_PIN, ReconciliationKind.INTERRUPTED_PATCH,
                            ReconciliationKind.STALLED_GENERATION}:
            self._advance(session_id, finding.subject)

    def _abandon(self, run_id: str) -> None:
        """Record the caller's assertion that a stalled attempt will never finish."""
        events = self.runs.store.events(run_id)
        run = events[-1].snapshot
        if run.state != RunState.RUNNING or run.proposal is not None:
            return
        self.runs.store.append(run.model_copy(update={
            "state": RunState.FAILED, "execution_error": ABANDON_REASON,
        }), "coding.generation_abandoned", events[-1].sequence)

    def _advance(self, session_id: str, run_id: str) -> None:
        session = self.research.store.latest(session_id).snapshot
        references = [ref for ref in session.runs if ref.run_id == run_id]
        if len(references) != 1:
            return
        self.research.refresh(session_id, run_id,
                              expected_run_sequence=references[0].event_sequence)


def _summarize(findings: list[ReconciliationFinding]) -> ReconciliationSummary:
    counted = [item.disposition for item in findings]
    return ReconciliationSummary(
        active=counted.count(ReconciliationDisposition.ACTIVE),
        recoverable=counted.count(ReconciliationDisposition.RECOVERABLE),
        manual=counted.count(ReconciliationDisposition.MANUAL),
    )
