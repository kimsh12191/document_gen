"""A coding loop service's state, by what it is about (P1).

`CodingLoopService` held some fifty attributes side by side: what a caller set
(the model, Auto mode, the time limits), how this service calls its model
(tools or JSON, a conversation or one prompt), what one leg holds while it runs,
and the stores it reads and writes. Which of them a leg resets, which last the
service's life and which a caller may set could be told only by reading every
method. Here each kind is one object, its changes named:

- `CallModes`: how the model is called, as found out from it. Starts with all
  modes on; a mode a server refuses goes off for this service, and a larger
  model on the ladder starts with them on again.
- `LoopSettings`: what a caller sets -- the model and its ladder, time limits,
  Auto mode, the step kinds offered. Set before a loop runs, never changed by
  one; a helper's are its loop's, with what a helper may not do taken out.
- `LegState`: what a leg of a loop holds while it runs -- the processes and
  MCP servers it started, why it was stuck, the gateway its helpers use. How
  long each lasts is said beside it; not all end with the leg (see each).

The old attribute names stay (`service.native_tools`), as `Part` descriptors:
callers, the CLI and the benchmarks set them as before.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import TYPE_CHECKING, Generic, TypeVar, overload

from relab_app.model_modes import JSON_SCHEMA, NATIVE_TOOLS

if TYPE_CHECKING:
    from relab_app.coding_loop import ModelLadder
    from relab_app.diagnostic_session import DiagnosticSession
    from relab_app.mcp_client import McpServer, McpTool
    from relab_core.coding_loop import EditReview, LoopActionKind, ModelChangeReason
    from relab_core.generation import ModelGateway
    from relab_workspace.background import BackgroundProcess

T = TypeVar("T")


class Part(Generic[T]):
    """An attribute of the service that lives on one of its parts: `Part("calls")`."""

    def __init__(self, part: str) -> None:
        self.part = part
        self.name = ""

    def __set_name__(self, owner: type, name: str) -> None:
        self.name = name

    @overload
    def __get__(self, owner_instance: None, owner: type) -> Part[T]: ...

    @overload
    def __get__(self, owner_instance: object, owner: type) -> T: ...

    def __get__(self, owner_instance: object | None, owner: type) -> Part[T] | T:
        if owner_instance is None:
            return self
        value: T = getattr(getattr(owner_instance, self.part), self.name)
        return value

    def __set__(self, owner_instance: object, value: T) -> None:
        setattr(getattr(owner_instance, self.part), self.name, value)



@dataclass
class LoopSettings:
    """What a caller sets for this service's loops; a loop reads them and never changes them."""

    # How long one model call may take in all (`--model-timeout`), and how long
    # to wait before trying a failed one again (tests set it to 0).
    step_seconds: float
    retry_seconds: float
    # When this service's loops must stop, by the monotonic clock; None for no
    # limit. A benchmark task gets one: one task took 59 minutes.
    deadline: float | None = None
    # The model the gateway a caller passes calls, when it says; and the ladder
    # of larger ones, when one was declared (`ModelLadder`).
    model: str | None = None
    ladder: ModelLadder | None = None
    # Each model's context window in tokens, as the person declared it.
    context_windows: dict[str, int] = field(default_factory=dict)
    # How much of a window the loop keeps itself to, in tokens (`--context-budget`, 0.3.37);
    # None for all of it. Past this share of it the earlier steps are summarized, as they are
    # near the window: a model declared a million tokens was a quarter of a million into a
    # task, each call slower than the last, until a window of 128k made it fast again.
    # A read may still show what the whole window allows, and a reply is given what is left.
    context_budget: int | None = None
    # Unattended (a benchmark): the answer every question gets at once, inside
    # the leg, rather than a stop no person will see.
    unattended: str | None = None
    # The step kinds this service's loops may take; None for all.
    allowed_kinds: frozenset[LoopActionKind] | None = None
    # Offline (a benchmark): no page of the web is read. Models there asked,
    # task after task, for the benchmark's own tests from GitHub.
    offline: bool = False
    # The `references` step, offered only when asked for: measured against the
    # same eighteen large-repository runs without it (m55-refs), it changed
    # neither the searches nor the steps before the first edit, so by the rule
    # fixed beforehand it left the tool set (docs/architecture/CODE_INTELLIGENCE.md).
    references: bool = False
    # Whether a default budget is raised for a model served locally
    # (`LOCAL_STEPS`); off when the person gave a number of calls.
    local_budget: bool = True
    # Auto mode, as the person chose it: a plan is approved, and a command, a
    # page or a tool that would be asked about is done, each recorded as not
    # asked. Refusals stay refusals; questions are still asked.
    auto: bool = False
    # The compact instruction when the steps go as tools (`--compact-prompt`):
    # off until measured against the full one (P1).
    compact_prompt: bool = False
    # Which instruction (`--instruction`, 0.2.86): "modular", the default since 0.3.36 -- the
    # current instruction's own sections chosen by the task's mode and the way the call goes,
    # measured on Polyglot with two models: solve rates no lower, 9-16% fewer prompt tokens a
    # call; "current", the whole of it, as before; or a kept one -- "0.2.85" or "0.2.91", each
    # before a rewrite, word for word, to go back to and compare with.
    instruction: str = "modular"
    # ReLab's own rules -- documentation in docs/ -- read before the person's
    # (`--no-default-rules`, 0.2.102); not given where records are in the workspace.
    default_rules: bool = True
    # New code and refactorings start from an approved plan (`--plan-first`):
    # on in the editor, off for benchmarks and tests unless asked.
    plan_first: bool = False
    # Paths held out for the final evaluation (`--held-out`, 0.2.60): run against,
    # never read, searched, listed or written -- a helper is held to them too.
    held_out: tuple[str, ...] = ()
    # How long one command may run, in seconds (`--command-timeout`, 0.2.66);
    # None for ReLab's default. The editor's default is 30 minutes.
    command_seconds: float | None = None
    # Lessons given to every loop before the workspace's own (`bench --given-lessons`, P3):
    # kinds of failure other tasks' hidden checks found, measured on tasks never read.
    given_lessons: tuple[str, ...] = ()

    def for_helper(self, kinds: frozenset[LoopActionKind]) -> LoopSettings:
        """A helper's settings: its loop's, taking only `kinds`, never Auto, no ladder.

        Copied whole rather than field by field (0.2.30): a field nobody named
        was a field the helper went without -- the declared context windows
        among them, so a helper's prompt was bounded as if no window were known.
        """
        return replace(self, allowed_kinds=kinds, auto=False, ladder=None, unattended=None,
                       context_windows=dict(self.context_windows))

@dataclass
class CallModes:
    """How this service calls its model: what it offers, and how long a call may take."""

    # Offer the steps as native tool calls, when the gateway takes them; off for
    # good once a provider refuses them.
    native_tools: bool = True
    # Ask for a JSON reply under its schema; off once a call under it times out
    # or is refused.
    json_schema: bool = True
    # Send a gateway that takes tools the loop as a conversation (`--one-prompt`
    # turns it off, to compare).
    conversation: bool = True
    # Send a model asked in JSON the loop as a conversation too, when its
    # gateway takes one; off for good once it does not.
    chat_json: bool = True
    # `--one-prompt`: every call one prompt, as before conversations, to compare.
    one_prompt: bool = False
    # Which server this leg calls: the key of what servers were found not to take.
    server: str | None = None
    # The bound the last call was given: the time left, near a deadline.
    call_seconds: float = 0.0
    # The model's context window as its server said it, when the person
    # declared none (0.2.35).
    window: int | None = None

    def start(self, server: str | None, known: dict[str, str]) -> list[str]:
        """Begin calling `server` without what it was found not to take; what was left out."""
        self.server = server
        left_out: list[str] = []
        for mode, why in known.items():
            if self.turn_off(mode):
                left_out.append(f"{mode}: {why}"[:200])
        return left_out

    def turn_off(self, mode: str) -> bool:
        """Stop offering `mode`; whether it was on."""
        if mode == NATIVE_TOOLS and self.native_tools:
            self.native_tools = False
            return True
        if mode == JSON_SCHEMA and self.json_schema:
            self.json_schema = False
            return True
        return False

    def larger_model(self) -> None:
        """A larger model on the ladder is offered every mode again: it may take them."""
        self.native_tools, self.json_schema = True, True


@dataclass
class LegState:
    """What a leg of a loop holds while it runs, and how long each part lasts."""

    # Why the leg that just ended was stuck: what a ladder moves up on. Cleared
    # when a leg starts and when it moves up; set where a leg ends.
    stuck: tuple[ModelChangeReason, str] | None = None
    # Whether the leg that just ended could not reach its model, past trying
    # again; and the larger models that did not answer, not tried again (0.2.96).
    unreached: bool = False
    unreachable: set[str] = field(default_factory=set)
    # Why the last move up was not made: its server did not answer (0.2.98).
    not_moved: str | None = None
    # The turn being taken.
    turn_number: int | None = None
    # The model calls this leg has taken and may take, and when it began: the
    # room a finish short of its goal leaves (0.3.15). Set at each turn.
    budget: tuple[int, int, float] | None = None
    # The gateway this leg was handed, for its helpers.
    gateway: ModelGateway | None = None
    # What the helpers of this turn reported, by step; taken as each is read.
    explored: dict[int, tuple[str, bool]] = field(default_factory=dict)
    # The MCP servers started for this leg, their tools, and why any could not
    # start: started on first use, stopped when the leg ends.
    mcp: dict[str, McpServer] | None = None
    mcp_tools: list[McpTool] = field(default_factory=list)
    mcp_unavailable: list[str] = field(default_factory=list)
    # Background processes this leg started, by name: all stopped when it ends.
    running: dict[str, BackgroundProcess] = field(default_factory=dict)
    # While a change the person accepted is written: the change they were
    # shown, which is all that may be written.
    accepting: EditReview | None = None
    # The editor-style checks of the turn being taken; None between turns.
    diagnostic_session: DiagnosticSession | None = None
    # Folders outside the workspace the person allowed reading, for this
    # service's life: allowed in one leg, read as the next goes on (`decide`).
    outside_allowed: list[Path] = field(default_factory=list)
