"""Proposing a design, and — separately — accepting one.

These are two acts on purpose. Proposing reads the workspace and records
nothing, so a proposal a person declines leaves no trace: no session, no plan,
no event. Accepting is the act that writes, and it is the only one.

Collapsing them would mean a planner's suggestion became a recorded session
simply by being made, and "a plan a person can decline" would be untrue.
"""

from collections.abc import Callable
from pathlib import Path
from typing import Any

from relab_app.ablation import without
from relab_app.client import WorkspaceClient
from relab_app.measurements import ScoreLog
from relab_app.routing import routed_component
from relab_app.sessions import ResearchSessionService
from relab_app.skills import SkillContext, SkillRunner
from relab_coding.service import CodingService
from relab_coding.targets import rank_paths
from relab_core.coding.inspection import CodeInspectionRequest
from relab_core.gateways import GatewayResolver
from relab_core.generation import ModelGateway
from relab_core.measurement import ArtifactSource, MeasurementArtifact, MeasurementKind, local_files
from relab_core.research import ResearchPlan, ResearchSession, admitted
from relab_core.routing import ModelRole, ModelRoute, ModelRoutingPolicy
from relab_core.skills import SkillEffect, SkillOutcome
from relab_core.targets import EditTarget, RankedPaths, TargetOperation
from relab_research.planner import ResearchPlanner, plan_arguments
from relab_research.proposals import (
    MAXIMUM_SIZED_REPEATS,
    REPEATS_WHEN_IT_VARIES,
    DeclaredCheck,
    KnownFinding,
    KnownSession,
    MeasuredSeries,
    ProposedPlan,
    ResearchContext,
    ResearchIntent,
    metric_key,
    repeats_for,
    stated_difference,
)
from relab_workspace.edit_context import refuse_target
from relab_workspace.runtime_readiness import host_python_command

# Enough for a planner to see what kind of repository this is, bounded so a
# large tree cannot become an unbounded prompt.
MAXIMUM_CANDIDATE_PATHS = 64


class ResearchProposals:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.sessions = ResearchSessionService(self.workspace)
        self.client = WorkspaceClient(self.workspace)

    def context(self, goal: str | None = None) -> ResearchContext:
        """Everything the planner is allowed to know, gathered by the layer that may read.

        The goal ranks the candidate paths. Showing a planner the first files a
        repository happens to yield is showing it nothing in particular, and the
        ranking is the same deterministic, lexical one that already proposes edit
        targets -- no model, and nothing read but structure.
        """
        overview = self.client.overview()
        ranked = RankedPaths()
        try:
            inspected = CodingService().inspect(CodeInspectionRequest(path=str(self.workspace)))
            ranked = rank_paths(inspected, goal, limit=MAXIMUM_CANDIDATE_PATHS)
        except (OSError, ValueError):
            # A workspace that cannot be inspected still deserves a proposal; the
            # planner will have to state an assumption about what to edit.
            pass
        return ResearchContext(
            workspace=str(self.workspace),
            sessions=[
                KnownSession(
                    session_id=item.session_id, objective=item.objective,
                    state=item.state.value,
                    decision=None if item.decision is None else item.decision.value,
                )
                for item in overview.sessions
            ],
            candidate_paths=ranked.paths,
            related_path_count=ranked.related_count,
            recorded_artifacts=sorted(self.sessions.recorded_artifacts()),
            # Found by running the usual names, never a name a model chose.
            python_command=host_python_command(),
            directories=_top_directories(self.workspace),
            # What earlier studies here established and a person confirmed, recalled
            # through the skill the coding loop recalls with (P4).
            findings=[
                KnownFinding(memory_id=str(item["memory_id"]), finding=str(item["finding"]),
                             scope=str(item["scope"]),
                             conditions=[str(text) for text in item.get("conditions") or []][:4])
                for item in self._skill("recall", {"text": goal or "-", "findings": 12})
                .get("findings", [])
            ],
            declared_checks=[
                DeclaredCheck(argv=[str(word) for word in item["argv"]][:32],
                              why=str(item["why"])[:300])
                for item in self._skill("find_checks", {}).get("checks", [])][:16],
            # What evaluations here already scored, read as measurements of one
            # variable across the code's versions (P5): the coding loops kept them.
            measured_before=[MeasuredSeries.model_validate(item)
                             for item in ScoreLog(self.workspace).by_command()],
        )

    def _skill(self, name: str, given: dict[str, object]) -> dict[str, Any]:
        """What a READ skill answered for the planner's context; nothing when it could not.

        The same skills the coding loop invokes (P4), recorded as invoked by
        research; a context not gathered is a proposal still made.
        """
        runner = SkillRunner(SkillContext(self.workspace, caller="research",
                                          permitted={SkillEffect.READ}))
        try:
            reply = runner.invoke(name, given)
        except (KeyError, ValueError, OSError):
            return {}
        if reply.invocation.outcome is not SkillOutcome.DONE or not isinstance(reply.result, dict):
            return {}
        return reply.result

    def propose(
        self, intent: ResearchIntent, planner: ResearchPlanner | None = None, *,
        routing_policy: ModelRoutingPolicy | None = None,
        resolver: GatewayResolver | None = None,
        planner_from: Callable[[ModelGateway, ModelRoute], ResearchPlanner] | None = None,
    ) -> ProposedPlan:
        """Ask for a design. This records nothing, whatever the planner returns.

        The context is written onto the returned proposal here rather than being
        taken from it. What the planner was shown is a fact this layer holds; a
        planner reporting its own inputs would be reporting what it chose to say
        it saw, and the accepted plan records that as why the design looks so.
        """
        # A declared policy decides which model designs the study, exactly as it
        # decides which one writes the code. The planner a caller brought is not
        # used when one is declared: it was built around a gateway nobody
        # declared, and using it would be the bypass routing exists to prevent.
        designing, _ = routed_component(
            routing_policy, ModelRole.PLANNER, given=planner, resolver=resolver,
            build=planner_from, what="a planner")
        if designing is None:
            raise ValueError("designing a study needs a planner")
        context = self.context(intent.stated)
        return _enough_repeats(designing.propose(intent, context), context).model_copy(update={
            "context": context,
            # Pinned to the design it routed. A proposal read today and accepted
            # tomorrow starts the session under the routing it was designed
            # under, rather than under whatever the editor is set to by then.
            "routing_policy": routing_policy,
        })

    def _targets_are_writable(self, proposal: ProposedPlan) -> None:
        """Refuse a design whose targets this workspace cannot honour.

        Checked here for the same reason the plan is: before the session exists.
        A design naming files it means to edit that are not there, or files it
        means to create that already are, cannot execute -- and finding that out
        at the first turn leaves a person holding a session they did not ask for
        and no way back to the design that caused it.

        Every arm is reported, not just the first. A design with three impossible
        targets should be fixable in one pass rather than three.
        """
        refused = [
            f"arm {arm.arm!r}: {reason}"
            for arm in proposal.arms
            for target in arm.targets
            if (reason := refuse_target(self.workspace, target)) is not None
        ]
        if refused:
            raise ValueError("this workspace cannot honour the design: " + "; ".join(refused))

    def _measurement_is_buildable(self, proposal: ProposedPlan) -> None:
        """Refuse a measurement this workspace cannot produce, before recording one.

        The same question the targets are asked, of the artifacts that will do the
        measuring: a verifier to be created must not be there, and one to be used
        as it stands must. It is asked here for a sharper reason than convenience
        -- a measurement that cannot be built means no experiment can be run at
        all, and discovering that when the first arm reverts for a missing file
        reports it as an arm failure, which it is not.
        """
        if proposal.measurement is None:
            self._verifier_is_already_here(proposal)
            return
        refused = []
        for artifact in proposal.measurement.artifacts:
            target = EditTarget(
                path=artifact.path,
                operation=(TargetOperation.CREATE
                           if artifact.operation is ArtifactSource.CREATE
                           else TargetOperation.EDIT),
            )
            reason = refuse_target(self.workspace, target)
            if reason is not None:
                refused.append(_measurement_refusal(artifact, reason))
        if refused:
            raise ValueError(
                "this workspace cannot build the measurement: " + "; ".join(refused))
        self._provenance_is_said(proposal)

    def _provenance_is_said(self, proposal: ProposedPlan) -> None:
        """Adopting an earlier session's instrument is a claim, so it is stated.

        `USE_EXISTING` means the project's own verifier, adopted as it stands.
        `REUSE_RECORDED` means one this workspace's records show an earlier
        session made. Both are legitimate; telling them apart is the point,
        because reusing a previous experiment's ruler says the two designs are
        measured by the same thing, and that is a claim somebody should be making
        on purpose.

        A live session adopted a verifier an earlier session had created for a
        different design. It counted a test suite no arm was asked to write, so
        every arm scored the floor value and the pre-registered rules held over
        evidence that separated nothing. Nothing was wrong with the file, the
        planner, or the rules -- what was missing is that nobody had said the two
        designs shared an instrument, so nobody could be wrong about it.
        """
        assert proposal.measurement is not None
        made_here = self.sessions.recorded_artifacts()
        wrong = []
        for artifact in proposal.measurement.artifacts:
            if artifact.operation is ArtifactSource.USE_EXISTING and artifact.path in made_here:
                wrong.append(
                    f"{artifact.path!r} was created by {made_here[artifact.path]} and this "
                    f"design adopts it as the project's own; say \"reuse_recorded\" if "
                    f"measuring both designs with that instrument is meant")
            if artifact.operation is ArtifactSource.REUSE_RECORDED and artifact.path not in made_here:
                wrong.append(
                    f"{artifact.path!r} is declared as an earlier session's and no session "
                    f"here made it; say \"use_existing\" for the project's own file, or "
                    f"\"create\" to write it")
            if (artifact.operation is ArtifactSource.REUSE_RECORDED
                    and artifact.kind is MeasurementKind.VERIFIER and artifact.path in made_here):
                mismatch = (self._metrics_it_does_not_print(proposal, made_here[artifact.path])
                            or self._requirements_it_does_not_claim(
                                proposal, made_here[artifact.path]))
                if mismatch:
                    wrong.append(mismatch)
        if wrong:
            raise ValueError("the measurement's provenance is wrong: " + "; ".join(wrong))

    def _requirements_it_does_not_claim(self, proposal: ProposedPlan, maker: str) -> str | None:
        """Whether a reused verifier said it checks what this design requires.

        The session that built it asked it, before any arm ran, which
        requirements it checks, and recorded the answer. A live design asked
        to start a project anew reused a verifier that claimed REQ-ADD and
        assumed it called a `select(options)` it had never heard of; the metric
        names agreed, so the metric check let it through, and three attempts
        were measured by a ruler checking nothing they were asked to do.
        """
        wanted = sorted({item.requirement_id for item in proposal.measurement_requirements})
        if not wanted:
            return None
        session = self.sessions.store.latest(maker).snapshot
        observed = session.measurement_claim_observations
        if not observed:
            return (f"the verifier it reuses was built by {maker} and never said which "
                    f"requirements it checks; create a new verifier for "
                    f"{', '.join(wanted)}")
        claimed = set(observed[-1].claimed_requirement_ids)
        absent = [item for item in wanted if item not in claimed]
        if not absent:
            return None
        return (f"the verifier it reuses was built by {maker} to check "
                f"{', '.join(sorted(claimed)) or 'nothing it declared'}, and this design "
                f"requires {', '.join(absent)}; create a new verifier for them")

    def _metrics_it_does_not_print(self, proposal: ProposedPlan, maker: str) -> str | None:
        """Whether a reused verifier was built to print what this design reads.

        The session that built it recorded the rules it was built for, and a
        verifier ReLab built prints those metrics. A live design reused a
        verifier that prints `pass_rate` while reading `correct_cases` -- its own
        assumptions even said the verifier printed `correct_cases` -- and the
        mismatch surfaced only at calibration. It is a fact about two records, so
        it is refused here, before a session exists, at no cost.
        """
        plan = self.sessions.store.latest(maker).snapshot.plan
        if plan is None:
            return None
        printed = {rule.name for rule in plan.registry.rules}
        wanted = {rule.name for rule in proposal.registry.rules}
        absent = sorted(wanted - printed)
        if not absent:
            return None
        return (f"the verifier it reuses was built by {maker} to print "
                f"{', '.join(sorted(printed))}, and this design reads {', '.join(absent)}; "
                f"read the metrics it prints, or create a new verifier")

    def _verifier_is_already_here(self, proposal: ProposedPlan) -> None:
        """A design with no plan-owned measurement must not be a greenfield one.

        Declaring no measurement is legal, and means one thing only: the verifier
        this design runs is already in the workspace and is adopted as it stands.

        It must never quietly mean "fall back to whatever each arm named". That
        is how the original failure happened -- a design proposed a verifier
        nobody could create, every arm was accepted, and the first run reverted
        for a missing file. Refusing here keeps a missing measurement a visible
        deficiency in the design rather than an escape hatch that reproduces it.
        """
        # A set: two arms naming the same verifier is one missing file, not two.
        missing = sorted({
            path
            for arm in proposal.arms
            for path in local_files(list(arm.verify_argv))
            if not self.workspace.joinpath(*path.split("/")).is_file()
        })
        if missing:
            raise ValueError(
                "this design declares no plan-owned measurement, so its verifier must "
                f"already be here, and it is not: {', '.join(missing)}. Declare a "
                f"measurement that creates it.")

    def accept(self, proposal: ProposedPlan) -> ResearchSession:
        """Create the session this proposal describes and record its plan.

        The plan goes through `record_plan`, so every rule a hand-written plan
        must satisfy applies unchanged -- nothing here is a shortcut past the
        validator.

        It is checked *before* the session is created. A proposal that does not
        make a legal plan would otherwise leave a session behind with nothing in
        it, and an empty session nobody asked for is worse than a refusal.
        """
        arguments = plan_arguments(proposal)
        admitted(ResearchPlan(registry=proposal.registry, **arguments))  # type: ignore[arg-type]
        self._targets_are_writable(proposal)
        self._measurement_is_buildable(proposal)
        # The policy the design was proposed under becomes the session's, rather
        # than being asked for again here: accepting a proposal under different
        # routing would start a study the person never read.
        session = self.sessions.create(proposal.objective,
                                       routing_policy=proposal.routing_policy)
        return self.sessions.record_plan(
            session.session_id, proposal.registry, **arguments,  # type: ignore[arg-type]
        )


def _enough_repeats(proposal: ProposedPlan, context: ResearchContext) -> ProposedPlan:
    """A design comparing a metric this workspace saw vary, with repeats enough to tell (P5).

    The planner is told how many a varying metric needs; a design with fewer is
    given that many here, by rule, and the rationale says why -- a person
    accepting it reads what was changed and can lower it again. How many is
    sized (0.2.81) to the difference to tell: the one the request names ("1%p"),
    else the rule's tolerance, else three (0.2.79). Repeats are only raised.
    """
    if without("score-spread"):
        return proposal
    tolerances = {metric_key(rule.name): rule.tolerance for rule in proposal.registry.rules}
    asked = stated_difference(proposal.intent.stated)
    best: tuple[int, MeasuredSeries, str] | None = None
    for item in context.measured_before:
        key = metric_key(item.metric)
        if key not in tolerances or not item.varies():
            continue
        if asked is not None:
            difference, source = item.as_mine(asked), f"{asked:g} points (the request's)"
        elif tolerances[key] > 0:
            tolerance = tolerances[key]
            # A rule's tolerance on a metric printed as a share, for scores kept in points.
            difference = tolerance * 100 if item.in_points() and tolerance <= 1 else tolerance
            source = f"{tolerance:g} (the rule's tolerance)"
        else:
            difference, source = 0.0, ""
        needed = repeats_for(item.spread_number(), difference) if difference > 0 else REPEATS_WHEN_IT_VARIES
        if best is None or needed > best[0]:
            best = (needed, item, source)
    if best is None or proposal.repeats_per_arm >= best[0]:
        return proposal
    needed, item, source = best
    said = (f" Repeats per arm raised from {proposal.repeats_per_arm} to {needed} by ReLab: runs of "
            f"one version of the code here differed by up to {item.spread} on {item.metric} "
            f"(`{item.command[:120]}`)")
    if source:
        said += (f"; telling a difference of {source} from that takes about {needed} runs per arm "
                 f"(two-sided 5%, power 80%)")
        if needed >= MAXIMUM_SIZED_REPEATS:
            said += (f" -- {MAXIMUM_SIZED_REPEATS} at most here, which may still not be enough: a "
                     f"larger difference, or a steadier evaluation, would")
        said += "."
    else:
        said += ", so fewer runs cannot tell a difference from that."
    return proposal.model_copy(update={"repeats_per_arm": needed,
                                       "rationale": (proposal.rationale + said)[:4000]})

def _top_directories(workspace: Path) -> list[str]:
    """The folders at the top of the workspace, empty ones too, by name only.

    Nothing inside them is read; hidden folders (`.git`, `.relab`, `.venv`) are
    left out because no project is asked for there.
    """
    try:
        names = sorted(item.name for item in workspace.iterdir()
                       if item.is_dir() and not item.name.startswith("."))
    except OSError:
        return []
    return names[:MAXIMUM_CANDIDATE_PATHS]


def _measurement_refusal(artifact: MeasurementArtifact, reason: str) -> str:
    """Why a measurement artifact cannot be had, in the measurement's own words.

    The check is the one an arm's target gets, and so was its sentence: "this
    arm means to edit it", about a verifier no arm may touch. What is wrong is
    one of two things, and each has its own remedy.
    """
    name = f"{artifact.kind.value} {artifact.path!r}"
    if artifact.operation is ArtifactSource.CREATE and "is already here" in reason:
        return (f"{name} is to be created and is already here; declare it at a new "
                f"path -- for a new project, ask for it in a folder of its own -- or "
                f"adopt the file that is here")
    if artifact.operation is not ArtifactSource.CREATE and "is not here" in reason:
        return (f"{name} is declared as {artifact.operation.value} and is not in this "
                f"workspace; a measurement that does not exist yet has to be created")
    return f"{name}: {reason}"
