"""ReLab's own rules, read before the person's in every workspace (0.2.102).

Asked for in use: a project ReLab builds should leave its documents behind --
what it is, how to run it, how it is put together, what was decided and why --
in a `docs/` folder, without the person writing that rule into every
workspace. Given as a rules file, not as instruction text: it is a convention
the person asked for, read first so their own rules (personal, workspace,
project) come after it and win where they differ. Turned off with
`--no-default-rules` or the editor's setting; not given where records are kept
in the workspace (tests, a benchmark's throwaway workspaces).
"""

DEFAULT_RULES = "ReLab default: documentation"

DOCUMENTATION_RULES = """# 문서화 규칙 (ReLab 기본 규칙)

코드를 쓰거나 고치는 작업은 요청에 문서 이야기가 없어도 그 프로젝트 폴더(없으면 작업 공간 루트)의
`docs/`에 문서를 남긴다. 나중에 다른 사람이나 다른 에이전트가 이 문서만 보고 코드를 이해하고 실행할 수
있어야 한다. 새 프로젝트는 아래 문서를 모두 만들고, 기존 프로젝트를 고칠 때는 바뀐 내용이 닿는 문서와
`CHANGELOG.md`를 고친다(`docs/`가 없으면 README와 USER_GUIDE부터 만든다). 코드를 쓰지 않은 일(질문에
대한 답, 분석 보고)에는 만들지 않는다.

## 남길 문서
- `docs/README.md`: 무엇을 하는 프로젝트인지 세 줄 안팎으로, 바로 실행해 보는 방법(빠른 시작),
  폴더 구조, 문서 목록과 각 문서의 링크.
- `docs/USER_GUIDE.md`: 설치와 준비, 설정(옵션과 기본값), 실행 명령 예시, 입력과 출력 형식,
  자주 나는 오류와 대처. 처음 보는 사람이 이 문서만 따라 해서 돌릴 수 있게 쓴다.
- `docs/ARCHITECTURE.md`: 모듈마다 책임과 넘겨주는 데이터, 처리 흐름, 외부 서비스(모델 서버,
  API, 데이터 위치)에 연결하는 방식.
- `docs/DECISIONS.md`: 진행하며 내린 결정을 날짜와 함께. 무엇을 골랐고, 다른 안은 무엇이었고,
  왜 그렇게 했는지(측정했다면 그 값과 출처).
- `docs/CHANGELOG.md`: 바뀐 것을 날짜 순으로 한두 줄씩.
- `docs/EVALUATION.md`: 성능을 재거나 평가한 작업이면 꼭 남긴다. 전체 수치만이 아니라 유형별·
  난이도별 결과, 실패 유형(건수와 예시), 측정 조건(데이터, 모델, 설정), 다시 재는 명령, 시도한
  방법별로 수치가 어떻게 바뀌었는지.
- 필요할 때만: `docs/TROUBLESHOOTING.md`(겪은 오류와 해결).

## 쓰는 때
- 계획을 승인받으면 README와 ARCHITECTURE의 뼈대를 쓴다. 계획의 파일 목록에 이 문서들도 넣는다.
- 기능이 실제로 돌아가면 USER_GUIDE에 실행 방법을 쓴다.
- 성능을 재면 그때마다 EVALUATION에 결과를 더한다.
- 끝내기 전에 CHANGELOG와 DECISIONS를 갱신하고, 바뀐 내용이 README·USER_GUIDE·ARCHITECTURE와
  맞는지 확인한다.

## 쓰는 법
- 명령과 옵션은 실제로 돌려 본 것만 쓴다. 숫자와 측정값에는 출처(명령, 파일)를 적는다.
- API 키, 토큰, 비밀번호, 내부 서버 주소는 쓰지 않는다. `<BASE_URL>`, `<MODEL_NAME>` 같은
  자리표시를 쓰고 실제 값은 설정 파일이나 환경 변수에 둔다고 적는다.
- 짧고 구체적으로 쓴다. 코드에 이미 있는 내용을 옮겨 적지 말고, 코드만 봐서는 알기 어려운 것(왜,
  어떻게 실행하는지, 무엇에 기대는지)을 쓴다.
- 문서 언어는 요청의 언어를 따른다.
- 사람이 정한 규칙(내 공통 규칙, 작업 공간·프로젝트의 RELAB.md)이 다르게 정하면 그쪽을 따른다.
"""
