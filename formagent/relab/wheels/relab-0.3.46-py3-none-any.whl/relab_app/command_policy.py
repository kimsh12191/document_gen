"""Which commands a coding loop runs on its own, which it asks about, which never.

M3a ran only the host's Python on tests and workspace scripts, and refused the
rest; a coding agent that cannot install a package, build or lint is not one.
M3b sorts every command into three:

    run       checks that read and report: tests, linters, type checkers, a
              workspace script, read-only git, and the programs that only
              read files (rg, grep, ls, cat, head, tail, wc, find, tree) when
              every path they are given is in the workspace and none is
              protected -- what a person would run without thinking twice
    ask       anything that changes the machine or reaches out: installing a
              package, building, a package runner, network tools, git that
              writes, any other program -- shown to the person, run only if
              they allow it
    refuse    what no approval makes safe here: a shell given a command string
              (it would run anything, unseen by this policy), deleting, pushing
              or rewriting history, and a program that is not on this host

Commands are argument lists, never shell strings, and the program is resolved
on PATH before anything runs, so what was shown is what runs.
"""

import os
import re
import shutil
from enum import Enum
from pathlib import Path

from relab_core.targets import unusable_path


class CommandClass(str, Enum):
    RUN = "run"
    ASK = "ask"
    REFUSE = "refuse"


SHELLS = {"bash", "sh", "zsh", "fish", "cmd", "powershell", "pwsh"}
DELETING = {"rm", "rmdir", "del", "rd", "erase", "format", "shutdown", "mkfs"}
# Python modules that only check and report.
CHECKING_MODULES = {"pytest", "unittest", "ruff", "mypy", "flake8", "pyflakes", "pylint",
                    "black", "isort", "doctest", "compileall", "py_compile"}
CHECKING_PROGRAMS = {"pytest", "ruff", "mypy", "flake8", "pyflakes", "pylint", "eslint", "tsc"}
READING_GIT = {"status", "diff", "log", "show", "branch", "ls-files", "blame", "rev-parse",
               "grep"}
# Programs that only read, and the flags that would make one write, run code,
# or read past what a read may (another tree, hidden or ignored files).
READING_PROGRAMS = {"rg", "grep", "ls", "cat", "head", "tail", "wc", "find", "tree", "diff",
                    "cmp"}
# Their first plain argument is a pattern, not a path.
PATTERN_FIRST = {"rg", "grep"}
UNSAFE_READING_FLAGS = {
    "find": {"-delete", "-exec", "-execdir", "-ok", "-okdir", "-fprint", "-fprint0", "-fprintf",
             "-fls"},
    "rg": {"--hidden", "-.", "-u", "-uu", "-uuu", "--no-ignore", "--pre", "--search-zip", "-z",
           "-L", "--follow"},
    "grep": {"-r", "-R", "--recursive", "--dereference-recursive", "-d", "--directories", "-f",
             "--file"},
    "tree": {"-a", "-o"},
}
# Flags whose value is the next argument, so it is not read as a path.
VALUE_FLAGS = {
    "head": {"-n", "-c"}, "tail": {"-n", "-c"},
    "grep": {"-e", "-A", "-B", "-C", "-m", "--max-count", "--include", "--exclude",
             "--exclude-dir", "--color", "--colour"},
    "rg": {"-e", "--regexp", "-g", "--glob", "--iglob", "-t", "--type", "-T", "--type-not", "-A",
           "-B", "-C", "-m", "--max-count", "-M", "--max-columns", "-j", "--threads", "--color",
           "--max-depth", "-d"},
    "tree": {"-L", "-P", "-I"},
}
QUIET_GIT_OPTIONS = {"--no-pager", "-P", "--no-optional-locks"}
WRITING_GIT = {"push", "reset", "clean", "rebase", "filter-branch", "gc", "prune"}
TEST_SCRIPTS = {"test", "lint", "typecheck", "check"}


def _name(program: str) -> str:
    return os.path.basename(program).lower().removesuffix(".exe").removesuffix(".cmd") \
        .removesuffix(".bat")


def classify(argv: list[str], python: str, workspace: Path) -> tuple[CommandClass, str]:
    """What this command is, and in one sentence why."""
    if not argv or not argv[0].strip():
        return CommandClass.REFUSE, "an empty command"
    name, rest = _name(argv[0]), argv[1:]
    pythons = {"python", "python3", "py", _name(python)}
    if name in SHELLS:
        return CommandClass.REFUSE, (
            "a shell is not run: give the program and its arguments as a list, so what "
            "runs is what was shown")
    if name in DELETING:
        return CommandClass.REFUSE, "deleting is not done by command; write or edit files instead"
    if name == "git":
        # Options that change only how it prints: `git --no-pager diff` is a
        # diff, and was asked about as "git --no-pager changes the repository".
        while rest and rest[0] in QUIET_GIT_OPTIONS:
            rest = rest[1:]
        sub = rest[0] if rest else ""
        if sub in WRITING_GIT or (sub == "checkout" and "--" in rest):
            return CommandClass.REFUSE, f"git {sub} rewrites or publishes history, which is the person's to do"
        if sub in READING_GIT:
            return CommandClass.RUN, "read-only git"
        return CommandClass.ASK, f"git {sub} changes the repository"
    if name in pythons:
        if rest in (["--version"], ["-V"]):
            # Says which Python it is, and nothing else: a live build asked to
            # be allowed `python --version` before its last test run.
            return CommandClass.RUN, "python --version only says which Python this is"
        if rest[:1] == ["-c"]:
            return CommandClass.ASK, "a Python one-liner runs code nothing here has read"
        if rest[:1] == ["-m"] and len(rest) > 1:
            module = rest[1]
            if module in CHECKING_MODULES:
                return CommandClass.RUN, f"{module} only checks and reports"
            if module in {"pip", "uv", "poetry", "pipx", "ensurepip", "venv"}:
                return CommandClass.ASK, f"{module} installs or changes packages on this machine"
            # The project's own package, run as it is meant to be: the same as
            # running one of its scripts. A live loop was asked, twice, to allow
            # `python -m report_summary_agent --help` on the code it had written.
            top = module.split(".", 1)[0]
            # A folder of scripts without __init__.py too (`python -m scratch.check`, 0.3.20):
            # Python runs it as a namespace package, from this folder.
            if unusable_path(top) is None and (
                    (workspace / top / "__init__.py").is_file() or (workspace / f"{top}.py").is_file()
                    or ((workspace / top).is_dir() and any((workspace / top).glob("*.py")))):
                return CommandClass.RUN, f"{module} is this project's own code"
            return CommandClass.ASK, f"python -m {module} is not one this loop runs unasked"
        script = rest[0].replace("\\", "/") if rest else ""
        if script.endswith(".py") and unusable_path(script) is None and (workspace / script).is_file():
            return CommandClass.RUN, "a script in this workspace"
        return CommandClass.ASK, "this Python command is not a test, a check or a workspace script"
    if name in CHECKING_PROGRAMS:
        return CommandClass.RUN, f"{name} only checks and reports"
    if name in READING_PROGRAMS:
        why = _reads_outside(name, rest)
        if why is None:
            return CommandClass.RUN, f"{name} only reads files in this workspace"
        return CommandClass.ASK, why
    if name in {"npm", "pnpm", "yarn"}:
        if rest[:1] == ["test"] or (rest[:1] == ["run"] and rest[1:2] and rest[1] in TEST_SCRIPTS):
            return CommandClass.RUN, f"{name} runs the project's tests or checks"
        return CommandClass.ASK, f"{name} {' '.join(rest[:2])} installs, builds or runs scripts"
    if name == "node":
        script = rest[0].replace("\\", "/") if rest else ""
        if script.endswith((".js", ".mjs", ".cjs")) and unusable_path(script) is None \
                and (workspace / script).is_file():
            return CommandClass.RUN, "a script in this workspace"
        return CommandClass.ASK, "this node command runs code nothing here has read"
    if name in {"go", "cargo", "dotnet"} and rest[:1] == ["test"]:
        return CommandClass.RUN, f"{name} test runs the project's tests"
    return CommandClass.ASK, f"{name} is a program this loop does not run unasked"


def _reads_outside(name: str, rest: list[str]) -> str | None:
    """Why a reading program might read past the workspace's rules, or None.

    Every plain argument (after the pattern, for rg and grep) is a path, and
    must be one a read may take: relative, inside, nothing protected. A flag
    that writes, runs a program, or reaches hidden, ignored or other trees
    makes it a command to show first. `grep -r` is one: it reads `.env`.
    """
    for kind, argument in _reading_arguments(name, rest):
        if kind == "flag":
            return f"{name} {argument} may write, run something, or read hidden or ignored files"
        if _not_a_workspace_path(argument):
            return f"{name} would read {argument!r}, which is not a workspace path a read may take"
    return None


def reading_paths(argv: list[str]) -> list[str]:
    """The paths a reading program (`ls`, `cat`, `find`, `grep` ...) reads, as written; [] for others."""
    if not argv or _name(argv[0]) not in READING_PROGRAMS:
        return []
    return [argument for kind, argument in _reading_arguments(_name(argv[0]), argv[1:]) if kind == "path"]


def _reading_arguments(name: str, rest: list[str]) -> list[tuple[str, str]]:
    """A reading program's arguments that matter, in the order to judge them: ("flag", an unsafe
    flag) and ("path", a path it reads) -- every plain argument, after the pattern for rg and grep."""
    unsafe = UNSAFE_READING_FLAGS.get(name, set())
    if name == "find":
        # `find PATH... EXPRESSION`: the paths come first; the expression is
        # checked for what would write or run, before the paths are.
        for index, argument in enumerate(rest):
            if argument.startswith(("-", "(", "!")):
                rest, expression = rest[:index], rest[index:]
                break
        else:
            expression = []
        return [("flag", item) for item in expression if item in unsafe] + [("path", item) for item in rest]
    found: list[tuple[str, str]] = []
    takes_value = VALUE_FLAGS.get(name, set())
    pattern_seen = name not in PATTERN_FIRST
    skip = False
    for argument in rest:
        if skip:
            skip = False
            continue
        if argument.startswith("-") and argument != "-":
            flag, _, value = argument.partition("=")
            short = {f"-{letter}" for letter in flag[1:]} if not flag.startswith("--") else set()
            if flag in unsafe or short & unsafe:
                found.append(("flag", flag))
            if flag in ("-e", "--regexp"):
                pattern_seen = True
            if flag in takes_value and not value:
                skip = True
            continue
        if not pattern_seen:
            pattern_seen = True
            continue
        found.append(("path", argument))
    return found


def _not_a_workspace_path(argument: str) -> bool:
    path = argument.replace("\\", "/").rstrip("/")
    if path in ("", "."):
        return False
    path = path.removeprefix("./")
    return unusable_path(path) is not None


# Package managers, and the subcommands of theirs that install (0.2.21).
INSTALLERS = {"pip", "uv", "poetry", "pipx", "conda", "mamba", "npm", "pnpm", "yarn"}
INSTALLING = {"install", "add", "sync", "i"}


def installing(argv: list[str]) -> bool:
    """Whether a command installs packages: `pip install`, `python -m pip install`,
    `uv pip install`, `poetry add`, `npm install` and the like."""
    if not argv:
        return False
    name, rest = _name(argv[0]), [item for item in argv[1:] if not item.startswith("-")]
    if re.fullmatch(r"python(?:\d+(?:\.\d+)?)?|py", name) and argv[1:2] == ["-m"] and len(argv) > 2:
        name, rest = argv[2], [item for item in argv[3:] if not item.startswith("-")]
    if re.fullmatch(r"pip(?:\d+(?:\.\d+)?)?", name):
        name = "pip"
    if name not in INSTALLERS:
        return False
    if name == "uv" and rest[:1] == ["pip"]:
        rest = rest[1:]
    return bool(rest) and rest[0] in INSTALLING


def resolve(argv: list[str], python: str) -> list[str] | None:
    """The command with its program found on PATH, or None when it is not here."""
    name = _name(argv[0])
    if name in {"py", _name(python)} or re.fullmatch(r"python(?:\d+(?:\.\d+)?)?", name):
        found = shutil.which(python)
        return None if found is None else [found, *argv[1:]]
    if re.fullmatch(r"pip(?:\d+(?:\.\d+)?)?", name):
        found = shutil.which(python)
        return None if found is None else [found, "-m", "pip", *argv[1:]]
    if name in CHECKING_PROGRAMS - {"eslint", "tsc"}:
        found = shutil.which(python)
        return None if found is None else [found, "-m", name, *argv[1:]]
    found = shutil.which(argv[0])
    return None if found is None else [found, *argv[1:]]


# What an allowed command may see of the environment, beyond a verifier's:
# where a package manager keeps its caches and settings. Never a credential --
# the sandbox refuses any name that looks like one -- and nothing that may hold
# one in a URL (an index or proxy with a user and password in it).
COMMAND_ENVIRONMENT = [
    "USERPROFILE", "APPDATA", "LOCALAPPDATA", "PROGRAMDATA", "ProgramFiles", "ProgramFiles(x86)",
    "PATHEXT", "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE", "OS", "USERNAME",
]
