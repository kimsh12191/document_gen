"""Comparing the instruction's conditions on one runtime: the A/B/C harness (R09 11.4-11.5, 0.3.5).

One suite, one model, one policy -- only the instruction differs:

- A: the current full instruction;
- B: the compact one, when the steps go as tools;
- C: the modular one (`instruction_profiles`): the current sections chosen by
  the task's mode and the way the call is made.

Each condition runs the suite with the coding benchmark (`coding_bench`):
every task in a fresh copy, scored by its hidden check, never by the loop's
outcome or ReLab's own verdict, which are reported beside it. The comparison
keeps every run, the order the conditions ran in and when, and the manifest's
digests, so a result says what was compared. Failures and timeouts stay in.

What it reports per condition: the hidden checks' success rate with its 95%
interval, false completions (ReLab verified, the hidden check failed),
finishes left unverified, model calls, calls to the first change that held,
seconds, finish holds (work a check asked for again), files written beyond
the task, refused steps, tokens as the provider reported them (and how many
runs it did not), whether it reported cached tokens -- and task by task. A
sample this size shows a difference on these tasks, never one in general.
"""

import math
import statistics
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from pydantic import Field

from relab_app.coding_bench import (
    FAILURE_GROUP,
    BenchResult,
    BenchRun,
    failure,
    load_suite,
    run_suite,
)
from relab_core.contracts import Contract
from relab_core.generation import ModelGateway

# (z of a two-sided 5% + z of 80% power) squared: runs per condition to tell two rates apart.
TWO_RATES = (1.96 + 0.8416) ** 2


@dataclass(frozen=True)
class Condition:
    name: str
    instruction: str
    compact_prompt: bool
    said: str


CONDITIONS = {
    "A": Condition("A", "current", False, "the current full instruction"),
    "B": Condition("B", "current", True, "the compact instruction, with the steps as tools"),
    "C": Condition("C", "modular", False,
                   "common principles + the mode's guidance + the way's output contract"),
}


class Comparison(Contract):
    """A suite run under each condition: the runs, and what was compared with what."""

    comparison_version: str = "prompt-compare-v1"
    label: str = Field(min_length=1, max_length=120)
    suite: str = Field(min_length=1, max_length=120)
    # In the order they ran: the cache, the provider's load and the time of day are part of it.
    conditions: list[str] = Field(min_length=1, max_length=8)
    repeats: int = Field(ge=1, le=20)
    model: str | None = Field(default=None, max_length=256)
    provider: str | None = Field(default=None, max_length=40)
    reasoning_effort: str | None = Field(default=None, max_length=20)
    commit: str | None = Field(default=None, max_length=40)
    profile: str | None = Field(default=None, max_length=40)
    native_tools: bool = True
    started_at: datetime
    finished_at: datetime | None = None
    ran: dict[str, list[datetime]] = Field(default_factory=dict)
    results: dict[str, BenchResult] = Field(default_factory=dict)


def run_comparison(suite: Path, gateway: ModelGateway, *, label: str, conditions: list[str],
                   repeats: int, out: Path, about: dict[str, str | None] | None = None,
                   native_tools: bool = True, profile: str | None = None,
                   on_change: Callable[[Comparison], object] | None = None,
                   **bench: object) -> Comparison:
    """Run the suite under each condition in turn, written to `out` as it goes."""
    unknown = [name for name in conditions if name not in CONDITIONS]
    if unknown or not conditions or len(set(conditions)) != len(conditions):
        raise ValueError(f"conditions are some of {', '.join(CONDITIONS)}, each once; got {conditions}")
    # As JSON (`native_tools` off), B is A -- compact is for tools -- and C takes the full output contract.
    # The suite is read before anything is written: no tasks, no comparison folder (0.3.34).
    load_suite(suite, bench.get("only"))  # type: ignore[arg-type]
    out.mkdir(parents=True, exist_ok=True)
    described = {key: value for key, value in (about or {}).items()
                 if key in ("model", "provider", "reasoning_effort", "commit")}
    comparison = Comparison.model_validate({
        "label": label, "suite": suite.name, "conditions": conditions, "repeats": repeats,
        "profile": profile, "native_tools": native_tools, "started_at": datetime.now(timezone.utc),
        **described})
    target = out / "comparison.json"
    for name in conditions:
        condition = CONDITIONS[name]
        began = datetime.now(timezone.utc)

        def kept(result: BenchResult, name: str = name) -> None:
            comparison.results[name] = result
            target.write_text(comparison.model_dump_json(indent=2), encoding="utf-8")
            if on_change is not None:
                on_change(comparison)

        result = run_suite(suite, gateway, label=f"{label}:{name}", repeats=repeats,
                           out=out / f"{name}.json", native_tools=native_tools, about=about,
                           instruction=condition.instruction, compact_prompt=condition.compact_prompt,
                           condition=name, on_change=kept, **bench)  # type: ignore[arg-type]
        comparison.ran[name] = [began, datetime.now(timezone.utc)]
        kept(result)
    comparison.finished_at = datetime.now(timezone.utc)
    target.write_text(comparison.model_dump_json(indent=2), encoding="utf-8")
    return comparison


def wilson(solved: int, runs: int) -> list[float] | None:
    """The 95% interval of a rate from `solved` of `runs` (Wilson's); None with no runs."""
    if runs == 0:
        return None
    z = 1.96
    rate = solved / runs
    centre = (rate + z * z / (2 * runs)) / (1 + z * z / runs)
    half = z * math.sqrt(rate * (1 - rate) / runs + z * z / (4 * runs * runs)) / (1 + z * z / runs)
    return [round(max(0.0, centre - half), 3), round(min(1.0, centre + half), 3)]


def _mean(values: list[float]) -> float | None:
    return round(statistics.fmean(values), 2) if values else None


def measures(runs: list[BenchRun]) -> dict[str, object]:
    """What one condition's runs came to, by the work order's measures (11.5)."""
    solved = sum(run.solved for run in runs)
    verified = sum(run.verified is True for run in runs)
    false = sum(run.verified is True and not run.solved for run in runs)
    reported = [run for run in runs if run.prompt_tokens is not None]
    return {
        "runs": len(runs),
        "solved": solved,
        "solve_rate": round(solved / len(runs), 3) if runs else None,
        "solve_rate_95": wilson(solved, len(runs)),
        "finished": sum(run.outcome == "finished" for run in runs),
        "verified": verified,
        "false_completions": false,
        "false_completion_rate": round(false / verified, 3) if verified else None,
        "finished_unverified": sum(run.outcome == "finished" and run.verified is not True for run in runs),
        "mean_model_calls": _mean([float(run.model_calls) for run in runs]),
        "mean_first_change_call": _mean([float(run.first_change_call) for run in runs
                                         if run.first_change_call is not None]),
        "mean_seconds": _mean([run.seconds for run in runs]),
        "finish_holds": sum(run.finish_holds for run in runs),
        "extra_files": sum(run.extra_files or 0 for run in runs),
        "runs_judged_for_extra_files": sum(run.extra_files is not None for run in runs),
        "refused_steps": sum(run.refused_steps for run in runs),
        "prompt_tokens": sum(run.prompt_tokens or 0 for run in reported),
        "completion_tokens": sum(run.completion_tokens or 0 for run in reported),
        "runs_without_token_report": len(runs) - len(reported),
        "runs_with_cache_report": sum(run.cache_reported is True for run in runs),
        "prompt_characters": sum(run.prompt_characters for run in runs),
        "errors": sum(run.error is not None for run in runs),
        "failure_groups": {group: sum(1 for run in runs if not run.solved
                                      and FAILURE_GROUP.get(failure(run) or "") == group)
                           for group in sorted(set(FAILURE_GROUP.values()))},
        "instruction_digests": sorted({run.instruction_digest for run in runs if run.instruction_digest})[:6],
    }


def to_tell(comparison: Comparison) -> dict[str, dict[str, object]]:
    """Each pair of conditions whose solve rates differ, with the runs that would tell the difference (P5).

    Before reading a winner: runs per condition for a two-sided 5% test with
    80% power between the two rates seen, and the repeats of the suite that
    makes. A pair with that many runs already, or the same rate, is left out.
    """
    rates = {name: (sum(run.solved for run in result.runs), len(result.runs))
             for name, result in comparison.results.items() if result.runs}
    tasks = len({run.task for result in comparison.results.values() for run in result.runs}) or 1
    found: dict[str, dict[str, object]] = {}
    names = sorted(rates)
    for at, first in enumerate(names):
        for second in names[at + 1:]:
            (solved_a, ran_a), (solved_b, ran_b) = rates[first], rates[second]
            rate_a, rate_b = solved_a / ran_a, solved_b / ran_b
            difference = abs(rate_a - rate_b)
            if difference == 0:
                continue
            needed = math.ceil(TWO_RATES * (rate_a * (1 - rate_a) + rate_b * (1 - rate_b)) / difference ** 2)
            ran = min(ran_a, ran_b)
            if needed <= ran:
                continue
            found[f"{first}-{second}"] = {"difference": round(difference, 3), "ran": ran,
                                          "runs_needed": needed, "repeats_needed": math.ceil(needed / tasks)}
    return found


def report(comparison: Comparison) -> dict[str, object]:
    """The comparison as numbers: per condition, then task by task, with what it cannot say."""
    tasks = sorted({run.task for result in comparison.results.values() for run in result.runs})
    by_task: dict[str, dict[str, str]] = {}
    for task in tasks:
        row = {}
        for name, result in comparison.results.items():
            runs = [run for run in result.runs if run.task == task]
            row[name] = f"{sum(run.solved for run in runs)}/{len(runs)}"
        by_task[task] = row
    return {
        "label": comparison.label, "suite": comparison.suite, "model": comparison.model,
        "provider": comparison.provider, "commit": comparison.commit, "profile": comparison.profile,
        "repeats": comparison.repeats,
        # None while it runs: the numbers are then of the runs written so far.
        "finished_at": comparison.finished_at.isoformat() if comparison.finished_at else None,
        "conditions": {name: CONDITIONS[name].said for name in comparison.conditions},
        "order": comparison.conditions,
        "ran": {name: [stamp.isoformat() for stamp in stamps] for name, stamps in comparison.ran.items()},
        "by_condition": {name: measures(result.runs) for name, result in comparison.results.items()},
        "by_task": by_task,
        "to_tell": to_tell(comparison),
        "caution": ("These tasks and repeats only: a difference here is not one in general. "
                    "Solved is the hidden checks' word; ReLab's verdict and the model's are beside it. "
                    "A pair in to_tell ran fewer times than telling its difference takes: run the "
                    "comparison again with --repeats at least its repeats_needed (20 at most; past that, "
                    "more tasks) before choosing."),
    }


def read_comparison(path: Path) -> Comparison:
    """A comparison written by `run_comparison`: its folder, or its comparison.json."""
    target = path / "comparison.json" if path.is_dir() else path
    return Comparison.model_validate_json(target.read_text(encoding="utf-8"))
