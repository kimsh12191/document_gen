"""Reading code in a folder outside the workspace: read only, asked about per folder.

Found in use (0.2.24): asked to analyse code under another path of the same
server, the loop could not -- every read is a workspace path -- and said to add
the folder to the workspace or upload the files. A reference implementation
in a sibling folder is ordinary, and a person should not have to rearrange
their editor for the agent to look at it.

The rules:

- Read, list, search and outline only. Nothing outside the workspace is ever
  written: writes keep their own rules, which take workspace paths alone.
- Each folder is asked about once, like a command: `read <folder>`. Allowed
  always, the rule covers that folder and everything under it, for this
  workspace (`.relab/command_rules.json`, removable by hand).
- What nobody's prompt may reach inside the workspace -- `.git`, `.env`,
  `secrets`, `private` -- is refused outside it too, with the usual places
  keys are kept (`.ssh`, `.gnupg`, `.aws`).
"""

from __future__ import annotations

import os
import re
from pathlib import Path, PurePosixPath, PureWindowsPath

from relab_app.code_map import outline
from relab_core.targets import PROTECTED_SEGMENTS, UNSEARCHED_DIRECTORIES
from relab_workspace.inspection import matches_glob

# Where keys and credentials are kept, beyond what a workspace protects.
KEPT_SECRETS = frozenset({".ssh", ".gnupg", ".aws", ".kube", ".docker"})
# How much of one file is read, how many files a listing or search walks, how
# many it shows, and the largest file a search opens.
MAXIMUM_BYTES = 2_000_000
MAXIMUM_WALKED = 20_000
MAXIMUM_LISTED = 400
MAXIMUM_MATCHES = 200
MAXIMUM_SEARCHED_BYTES = 1_000_000


def outside_path(path: str) -> bool:
    """Whether a path a model sent is absolute: a folder of this host, not of the workspace."""
    text = path.strip()
    return (text.startswith(("/", "~/", "\\\\")) or text == "~"
            or PureWindowsPath(text).drive != "")


def resolved(path: str) -> Path:
    """The absolute path, with `~` expanded and `..` taken away."""
    return Path(os.path.expanduser(path.strip())).resolve()


def within(path: Path, folder: Path) -> bool:
    try:
        path.relative_to(folder)
    except ValueError:
        return False
    return True


def refused(target: Path) -> str | None:
    """Why a path outside the workspace may not be read, or None."""
    lowered = {part.lower() for part in target.parts}
    hit = sorted(lowered & (PROTECTED_SEGMENTS | KEPT_SECRETS))
    if hit:
        return f"{str(target)!r} is under {hit[0]!r}, which is never read"
    return None


def folder_of(target: Path) -> Path:
    """The folder a person is asked about for this path: itself, or a file's own folder."""
    return target if target.is_dir() else target.parent


def _walk(folder: Path, glob: str | None) -> tuple[list[str], bool]:
    """Files under `folder`, as POSIX paths relative to it, skipping what is never searched."""
    found: list[str] = []
    for root, directories, files in os.walk(folder):
        directories[:] = sorted(item for item in directories
                                if item not in UNSEARCHED_DIRECTORIES
                                and item.lower() not in PROTECTED_SEGMENTS | KEPT_SECRETS)
        for name in sorted(files):
            relative = PurePosixPath(Path(root, name).relative_to(folder).as_posix())
            text = str(relative)
            if any(part.lower() in PROTECTED_SEGMENTS for part in relative.parts):
                continue
            if glob is not None and not matches_glob(text, glob):
                continue
            found.append(text)
            if len(found) >= MAXIMUM_WALKED:
                return found, True
    return found, False


def read_text(target: Path) -> str:
    """A file outside the workspace, as text: UTF-8, or replaced where it is not."""
    if not target.is_file():
        raise ValueError(f"{str(target)!r} is not a file")
    with target.open("rb") as handle:
        data = handle.read(MAXIMUM_BYTES + 1)
    text = data[:MAXIMUM_BYTES].decode("utf-8", errors="replace")
    return text + ("\n[the file continues past 2 MB]" if len(data) > MAXIMUM_BYTES else "")


def listing(target: Path, glob: str | None) -> str:
    """The files under a folder outside the workspace, with their sizes."""
    if not target.is_dir():
        raise ValueError(f"{str(target)!r} is not a folder")
    paths, more = _walk(target, glob)
    shown: list[str] = []
    for path in paths[:MAXIMUM_LISTED]:
        try:
            size = (target / path).stat().st_size
        except OSError:
            continue
        shown.append(f"{target.as_posix()}/{path} ({size} bytes)")
    if not shown:
        return f"no files under {target.as_posix()}" + (f" matching {glob}" if glob else "")
    cut = more or len(paths) > MAXIMUM_LISTED
    return "\n".join(shown) + ("\n[more files exist; narrow the folder or glob]" if cut else "")


def search(target: Path, query: str, *, regex: bool, glob: str | None) -> str:
    """Lines matching `query` under a folder (or in one file) outside the workspace."""
    try:
        pattern = re.compile(query if regex else re.escape(query))
    except re.error as error:
        raise ValueError(f"not a regular expression: {error}") from error
    if target.is_file():
        root, paths = target.parent, [target.name]
    elif target.is_dir():
        root, (paths, _) = target, _walk(target, glob)
    else:
        raise ValueError(f"{str(target)!r} is not a file or folder")
    found: list[str] = []
    for path in paths:
        file = root / path
        try:
            if file.stat().st_size > MAXIMUM_SEARCHED_BYTES:
                continue
            text = file.read_bytes().decode("utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for number, line in enumerate(text.splitlines(), 1):
            if pattern.search(line):
                found.append(f"{root.as_posix()}/{path}:{number}: {line.strip()[:300]}")
                if len(found) >= MAXIMUM_MATCHES:
                    return "\n".join(found) + "\n[more matches exist]"
    return "\n".join(found) or "no matches"


def outlined(target: Path, glob: str | None, *, limit: int) -> str:
    """What the code under a folder (or in one file) outside the workspace defines."""
    if target.is_file():
        root, paths = target.parent, [target.name]
    elif target.is_dir():
        root, (paths, _) = target, _walk(target, glob)
    else:
        raise ValueError(f"{str(target)!r} is not a file or folder")
    text, cut = outline(root, paths, limit=limit)
    if not text:
        return f"no Python, JavaScript, TypeScript or Go code under {target.as_posix()}"
    return (f"(paths under {root.as_posix()})\n{text}"
            + ("\n[more files follow; outline a folder or a glob to see them]" if cut else ""))
