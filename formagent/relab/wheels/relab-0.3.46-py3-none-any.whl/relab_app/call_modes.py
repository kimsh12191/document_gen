"""What a failed model call gets, decided in one place (RL-09, from RL-05).

`CodingLoopService._steps` used to decide this inline, branch after branch,
between the call and the steps: the schema dropped after a timeout or a
refusal, a prompt too long cut short once, a rate limit waited out, an
output limit told to the model, a transport failure tried again, or the
loop ended. Each branch also kept its own budget in local counters. The
decision is the same here, read from the error's closed kinds (incident,
HTTP status, refusal) and never from its words; doing what it says -- waiting,
cutting short, ending -- stays with the loop.

The budgets are passed in, not read here, so a caller (and a test) can set
them where they have always been: `relab_app.coding_loop`.
"""

from dataclasses import dataclass
from typing import Literal

from relab_core.provider import ProviderIncident, RequestRefusal

# A provider answering with one of these refused the request as made -- tools
# it does not take, or a prompt it will not read -- which trying again does
# not change.
REFUSED_STATUSES = {400, 404, 405, 422}
# Not a timeout: a live loop spent its whole 300 seconds on every call, four
# times, before failing -- a model that cannot finish under the reply schema
# does not finish the second time either. That is handled by dropping the
# schema, once, not by waiting again.
TRANSIENT = {ProviderIncident.TRANSPORT, ProviderIncident.INCOMPLETE}


@dataclass(frozen=True)
class Decision:
    """What to do about one failed call.

    drop_schema  ask again without the reply schema (`why` says what showed it)
    squeeze      cut earlier results short as far as they go, and ask again
    too_long     end: the prompt is past the window even cut short
    wait         ask again after `seconds`
    output_limit tell the model its reply ran past the limit, and ask again
    no_images    end: the model does not take the images the request attached
    fail         end: the model could not be reached
    """

    kind: Literal["drop_schema", "squeeze", "too_long", "wait", "output_limit", "no_images", "fail"]
    seconds: float = 0.0
    why: str = ""


class Retrying:
    """One leg's budgets for failed calls, and the decision for each failure.

    `transport` and `rate_limited` are what one failing call may be tried again; once a call
    is answered they come back for the next (`answered`), within what the whole leg may spend
    (`transport_a_leg`, `rate_limited_a_leg`; left out, the same as one call's, as before
    0.3.38). Spent for the leg once, a long run on a server that drops a call now and then
    ended at its third drop, hundreds of answered calls apart.
    """

    def __init__(self, *, transport: int, rate_limited: int, retry_seconds: float,
                 growth: float, rate_limit_wait: float, transport_a_leg: int | None = None,
                 rate_limited_a_leg: int | None = None) -> None:
        self.transport_budget, self.rate_limited_budget = transport, rate_limited
        self.transport_leg = transport if transport_a_leg is None else transport_a_leg
        self.rate_limited_leg = rate_limited if rate_limited_a_leg is None else rate_limited_a_leg
        self.transport = min(transport, self.transport_leg)
        self.rate_limited = min(rate_limited, self.rate_limited_leg)
        self.retry_seconds = retry_seconds
        self.growth = growth
        self.rate_limit_wait = rate_limit_wait
        # Cut short once in a leg for a prompt the model refused as too long.
        self.squeezed = False
        # Why each call tried again in this leg failed, as the loop says it: when
        # the leg ends unreached, its account names them too (0.3.26).
        self.tried: list[str] = []

    def answered(self) -> None:
        """A call came back: the next one that fails starts its own retries, its waits from the
        first again, out of what the leg has left (0.3.38)."""
        self.transport = min(self.transport_budget, self.transport_leg)
        self.rate_limited = min(self.rate_limited_budget, self.rate_limited_leg)

    def after(self, error: Exception, *, schema: bool, json_steps: bool) -> Decision:
        """The decision for `error`; budgets it spends are spent here.

        `schema`: a reply schema is being asked for; `json_steps`: the steps
        are asked for as JSON (not tool calls), where the schema applies.
        """
        incident = getattr(error, "incident", None)
        status = getattr(error, "status", None)
        refusal = getattr(error, "refusal", None)
        if schema and json_steps:
            if incident is ProviderIncident.TIMEOUT and not getattr(error, "stalled", False):
                # Constrained decoding that never ends (see `provider_schema`).
                return Decision("drop_schema", why="a call under the reply schema ran out its time")
            if refusal is RequestRefusal.SCHEMA:
                return Decision("drop_schema", why="the server refused the reply schema")
        if refusal is RequestRefusal.IMAGES:
            # Asked again, it is refused again; without the pictures, the work
            # would go on blind to what it was asked about (0.3.29).
            return Decision("no_images")
        if refusal is RequestRefusal.CONTEXT_LENGTH:
            # Not a mode to turn off: the next call in any mode is as long.
            if self.squeezed:
                return Decision("too_long")
            self.squeezed = True
            return Decision("squeeze")
        if status == 429:
            if self.rate_limited <= 0:
                return Decision("fail")
            waited = self.rate_limited_budget - self.rate_limited
            self.rate_limited -= 1
            self.rate_limited_leg -= 1
            return Decision("wait", min(self.retry_seconds * self.growth ** (waited + 1),
                                        self.rate_limit_wait))
        if incident is ProviderIncident.OUTPUT_LIMIT:
            return Decision("output_limit")
        if self.transport > 0 and transient(error):
            # The call, not the step, is tried again: nothing was done.
            waited = self.transport_budget - self.transport
            self.transport -= 1
            self.transport_leg -= 1
            return Decision("wait", self.retry_seconds * self.growth ** waited)
        return Decision("fail")


def refused_tools(error: Exception) -> bool:
    """A request refused for its tools: a refusing status, and not for its length (RL-05).

    A body that names no kind is taken as the tools, as before: the request
    differs from a JSON one only by them.
    """
    return (getattr(error, "status", None) in REFUSED_STATUSES
            and getattr(error, "refusal", None) not in (RequestRefusal.CONTEXT_LENGTH, RequestRefusal.IMAGES))


def refusal_said(error: Exception) -> str:
    """Why a mode was turned off, from the status and the refusal's kind; never the body."""
    refusal = getattr(error, "refusal", None)
    status = getattr(error, "status", None)
    return f"HTTP {status}" + (f", {refusal.value.replace('_', ' ')}" if refusal is not None else "")


def transient(error: Exception) -> bool:
    """A failure on the way to the model, which trying again may not repeat.

    Not a request the provider refused (a 4xx other than a timeout or a rate
    limit): a missing feature or a bad key is the same the second time.
    """
    status = getattr(error, "status", None)
    if isinstance(status, int) and 400 <= status < 500 and status not in (408, 429):
        return False
    incident = getattr(error, "incident", None)
    # A streamed reply that stopped part-way: the provider stalled, and a live
    # model answered the same kind of call in seven seconds and in 293.
    if incident is ProviderIncident.TIMEOUT and getattr(error, "stalled", False):
        return True
    return incident in TRANSIENT or isinstance(error, (TimeoutError, ConnectionError))
