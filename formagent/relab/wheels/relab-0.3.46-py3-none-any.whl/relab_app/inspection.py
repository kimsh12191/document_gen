"""Performing what a planner asked to look at, and refusing the rest.

The division this file exists to hold:

    model               proposes an inspection request, and nothing more
    application         validates it against what this workspace allows   <- here
    workspace service   reads or searches; the only code that opens a file
    result              comes back bounded, and is recorded

A planner holds a `WorkspaceInspector` and can do exactly one thing with it: ask.
It has no path to a filesystem, and the reason is not that it would misbehave --
it is that a component which *could* read will, sooner or later, be given a
reason to write, and the boundary is easier to keep than to restore.

## Why refusals come back instead of raising

A planner asking for `.git/config` has made a mistake worth telling it about. It
can ask something answerable next round, having been told why. Raising would
throw away four good requests because a fifth was out of bounds, and would turn a
planner's mistake into a failed design.

What is not negotiable is that a refused request yields no content. The sentence
comes back; the bytes do not.
"""

from pathlib import Path

from relab_core.inspection import (
    InspectionRequest,
    InspectionResult,
    SearchObservation,
)
from relab_core.operations import (
    MAXIMUM_SUBJECTS,
    OperationKind,
    OperationObserver,
    WorkspaceReadDetail,
    WorkspaceSearchDetail,
    narrate,
)
from relab_workspace.code_search import CodeSearchQuery, CodeSearchService
from relab_workspace.inspection import read_workspace_file
from relab_workspace.operation_recorder import OperationRecorder


class WorkspaceInspection:
    """Reads and searches one workspace, on request, and records nothing itself.

    Recording is the session's job. This answers a question; whether the answer
    belongs in a plan's provenance is a decision made where plans are written.
    """

    def __init__(
        self, workspace: Path, *, observe: OperationObserver | None = None,
    ) -> None:
        self.workspace = workspace.resolve(strict=True)
        # Looking at a workspace is the slowest thing a planner does and the
        # only one that used to happen in silence. This can append and cannot
        # read: what it writes decides nothing, here or anywhere.
        self.observe: OperationObserver | None = (
            OperationRecorder.open(self.workspace) if observe is None else observe)

    def inspect(self, request: InspectionRequest) -> InspectionResult:
        files, searches, refused = [], [], []
        if request.reads:
            asked_for = [item.path for item in request.reads][:MAXIMUM_SUBJECTS]
            with narrate(self.observe, OperationKind.WORKSPACE_READ,
                         WorkspaceReadDetail(paths=asked_for)) as reading:
                for asked in request.reads:
                    try:
                        files.append(read_workspace_file(self.workspace, asked.path))
                    except (ValueError, OSError) as error:
                        # In the planner's own terms, and never the exception
                        # whole: a rendered path from another layer is noise to
                        # whoever reads the next prompt.
                        refused.append(f"read {asked.path!r}: {error}")
                # What came back, not what was asked for. The contents are the
                # observation's own record, which is where they are evidence.
                reading.detail = WorkspaceReadDetail(
                    paths=[item.path for item in files][:MAXIMUM_SUBJECTS],
                    bytes_read=sum(item.bytes_read for item in files),
                    truncated=any(item.truncated for item in files))
                if not files:
                    reading.failed("nothing in this request could be read")
        # The coding loop's search (P4): ripgrep's names when this host has it,
        # every query in one pass over the files, and why a search stopped short.
        answered = (CodeSearchService(self.workspace).search_many(
            [CodeSearchQuery(query=wanted.query, path=wanted.scope) for wanted in request.searches])
            if request.searches else [])
        for wanted, result in zip(request.searches, answered):
            with narrate(self.observe, OperationKind.WORKSPACE_SEARCH,
                         WorkspaceSearchDetail(query=wanted.query)) as searching:
                if result.error is not None:
                    refused.append(f"search {wanted.query!r}: {result.error}")
                    # The planner is told which rule it met. A progress line
                    # says that the search did not happen and nothing more.
                    searching.failed("the search was refused")
                    continue
                found = SearchObservation(
                    query=wanted.query, matches=result.matches,
                    files_searched=result.files_searched, truncated=result.truncated,
                    stopped_by=result.stopped_by)
                searches.append(found)
                # How much came back, never what came back.
                searching.detail = WorkspaceSearchDetail(
                    query=wanted.query, files_searched=found.files_searched,
                    matches=len(found.matches))
        return InspectionResult(files=files, searches=searches, refused=refused)
