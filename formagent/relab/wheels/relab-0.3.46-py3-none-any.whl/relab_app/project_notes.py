"""What a coding loop learned about a project, kept for the loops after it.

Each loop began knowing only what RELAB.md and the files said: how the tests
are run here, which module owns what, the trap a fix fell into -- found out
again, a step at a time, every time. A loop may now `remember` a short fact;
the facts of a project come back in every later loop's context, newest last.

They live in `.relab/notes.json`, which a loop cannot write any other way, by
project folder ("" for the workspace). A person reads and removes them with
`relab code notes`. Short and few: a note is a fact, not a log of the work.
"""

import json
from datetime import datetime, timezone
from pathlib import Path

from relab_workspace.private_state import state_dir

NOTES_FILE = "notes.json"
MAXIMUM_NOTE = 300
# Notes kept for one project; the oldest go first.
MAXIMUM_NOTES = 40


class ProjectNotes:
    """The notes of one workspace, read fresh each time: a person may edit them by hand."""

    def __init__(self, workspace: Path) -> None:
        self.path = state_dir(workspace) / NOTES_FILE

    def _read(self) -> dict[str, list[dict[str, str]]]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        if not isinstance(data, dict):
            return {}
        return {str(key): [item for item in value if isinstance(item, dict)
                           and isinstance(item.get("text"), str)]
                for key, value in data.items() if isinstance(value, list)}

    def _write(self, data: dict[str, list[dict[str, str]]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        temporary.replace(self.path)

    def notes(self, project: str | None) -> list[str]:
        """The notes for a project folder, and the workspace's own, oldest first."""
        data = self._read()
        keys = [""] + ([project] if project else [])
        return [item["text"] for key in keys for item in data.get(key, [])]

    def add(self, project: str | None, text: str, loop_id: str) -> str:
        """Keep a note; the same note twice is kept once. Returns what was kept."""
        text = " ".join(text.split())
        if not text:
            raise ValueError("a note says something")
        if len(text) > MAXIMUM_NOTE:
            raise ValueError(f"a note is at most {MAXIMUM_NOTE} characters: one fact, not a log")
        data = self._read()
        kept = [item for item in data.get(project or "", []) if item["text"] != text]
        kept.append({"text": text, "loop_id": loop_id,
                     "added_at": datetime.now(timezone.utc).isoformat(timespec="seconds")})
        data[project or ""] = kept[-MAXIMUM_NOTES:]
        self._write(data)
        return text

    def all(self) -> dict[str, list[dict[str, str]]]:
        return self._read()

    def remove(self, project: str | None, number: int) -> str | None:
        """Remove a project's note by its number, from 1; what was removed, or None."""
        data = self._read()
        kept = data.get(project or "", [])
        if not 1 <= number <= len(kept):
            return None
        removed = kept.pop(number - 1)
        data[project or ""] = kept
        self._write(data)
        return removed["text"]
