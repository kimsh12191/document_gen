"""What the editor says is wrong in the files a coding loop wrote (UX-04).

The loop runs in a process of its own and cannot see VS Code's language
servers. The editor writes what they report for the files the loop changed to
the loop's problems file, beside its steering file; the loop reads it at each
turn's end and before it finishes. Each file is listed with the digest of the
content the problems were reported for: a problem about content the file no
longer holds is old news, and is passed over rather than sent back.
"""

import hashlib
import json
from pathlib import Path

from pydantic import BaseModel, Field, ValidationError

from relab_app.steering import LOOP_ID
from relab_core.coding_loop import CodingLoop
from relab_workspace.private_state import state_dir

# At most this many problems are given to the model, errors first.
MAXIMUM_PROBLEMS = 20


class EditorProblem(BaseModel):
    line: int = Field(ge=1)
    severity: str = Field(pattern=r"^(error|warning)$")
    message: str = Field(min_length=1, max_length=2000)
    source: str | None = Field(default=None, max_length=100)


class ProblemFile(BaseModel):
    path: str = Field(min_length=1, max_length=260)
    digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    problems: list[EditorProblem] = Field(default_factory=list, max_length=200)


class ProblemReport(BaseModel):
    files: list[ProblemFile] = Field(default_factory=list, max_length=200)


def problems_path(workspace: Path, loop_id: str) -> Path:
    if not LOOP_ID.fullmatch(loop_id):
        raise ValueError(f"{loop_id!r} is not a coding loop's id")
    # The editor's diagnostics, written by the editor: in the workspace, apart from
    # the person's records, which moved out of it (0.2.62).
    return state_dir(workspace) / "editor_problems" / f"{loop_id}.problems.json"


def editor_problems(workspace: Path, loop: CodingLoop, *,
                    errors_only: bool = False) -> list[str]:
    """The problems reported for the current content of files this loop wrote, errors first.

    Nothing when the editor wrote none -- a loop run from the command line, or
    an editor that has not looked yet: absence is not a clean bill.
    """
    path = problems_path(workspace, loop.loop_id)
    if not path.is_file():
        return []
    try:
        report = ProblemReport.model_validate(json.loads(path.read_text(encoding="utf-8")))
    except (OSError, ValueError, ValidationError):
        return []
    written = {item.path for item in loop.written}
    found: list[tuple[int, str]] = []
    for entry in report.files:
        if entry.path not in written:
            continue
        target = workspace / entry.path
        try:
            current = hashlib.sha256(target.read_bytes()).hexdigest()
        except OSError:
            continue
        if current != entry.digest:
            continue
        for problem in entry.problems:
            if errors_only and problem.severity != "error":
                continue
            source = f" ({problem.source})" if problem.source else ""
            said = (f"{entry.path}:{problem.line}: {problem.severity}: "
                    f"{problem.message.strip()[:300]}{source}")
            found.append((0 if problem.severity == "error" else 1, said))
    return [said for _, said in sorted(found, key=lambda item: item[0])][:MAXIMUM_PROBLEMS]
