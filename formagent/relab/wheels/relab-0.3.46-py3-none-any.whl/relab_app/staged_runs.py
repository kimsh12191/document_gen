"""A run over many items goes small first, then larger, then whole (0.3.19).

Said in use: an evaluation over several test sets ran on all of them from its
first run, so finding out whether it worked at all took as long as the whole
evaluation. The instruction said to take two or three real inputs first; it
was not done, so it is looked for here, by rule and with no model call:

- `held_whole_run`: before a script's first run over everything -- a script
  that takes a size option (`--limit N`) run without it, or one this loop wrote
  that goes through many items and has no such option -- the run is held once,
  with "one or two items of each set first". Sent again, it runs: the whole may
  be a few items, and the model says why.
- `small_run_note`: a sized run that came out right is told the next sizes --
  a few dozen, timed, then the whole -- and that its scores are of those items.
- `sampled_scores`: finishing on scores a sized run printed, with no whole run
  after it, the summary says how many items they are of.
"""

import posixpath
import re
from collections.abc import Callable
from pathlib import Path, PureWindowsPath

from relab_app.ablation import without
from relab_app.measurements import scores
from relab_app.output_check import MODEL_CALL
from relab_core.coding_loop import CodingLoop, LoopActionKind

# How a refused whole run starts: "refused: " and this.
HELD = "run small first: "
HELD_SAID = f"refused: {HELD}"
# An option that says how many items a run takes.
SIZE_FLAG = re.compile(
    r"--(?:limit|max[-_]?(?:samples|items|examples|records|rows|cases|questions|pages|n)|"
    r"(?:n|num|number)[-_]?(?:samples|items|examples|records|rows|cases|questions|pages)|"
    r"sample[-_]?(?:size|count)|samples|subset(?:[-_]size)?|head|first|per[-_]set)$", re.IGNORECASE)
# An option's definition, argparse, click or typer, and the flags it names.
OPTION_CALL = re.compile(r"(?:add_argument|\boption|\bOption)\(([^()]*(?:\([^()]*\)[^()]*)*)\)")
FLAG = re.compile(r"""["'](-{1,2}[A-Za-z][\w-]*)["']""")
DEFAULT = re.compile(r"\bdefault\s*=\s*(-?\d+)\b")
# Code that goes through many items ...
ITEMS = re.compile(
    r"^\s*(?:async\s+)?for\s+.+\s+in\s+.*(?:glob|iterdir|listdir|walk|dataset|loader|samples|examples|"
    r"records|rows|items|lines|files|pages|questions|cases|split|sets?\b|data)"
    r"|\bload_dataset\(|\bDataLoader\(|\biterrows\(|\btqdm\(|\.jsonl\b|\bread_csv\(|\bread_json\(",
    re.IGNORECASE | re.MULTILINE)
# ... with work worth timing in it: a model, a score, a prediction, training.
WORK = re.compile(
    r"\b(?:accuracy|precision|recall|f1|bleu|rouge|exact_match|wer|cer|auc|score|metrics?|evaluat\w*|"
    r"benchmark|predict\w*|generate|inference|infer|train\w*)\b|\.forward\(|\bpipeline\(", re.IGNORECASE)
# A server is started, not run through items.
SERVER = re.compile(r"uvicorn\.run|serve_forever|\bFastAPI\(|\bFlask\(|\bstreamlit\b|\bgradio\b|\bapp\.run\(")
CHECKING = re.compile(r"^(?:check|verify|validate|test)[\w-]*\.py$", re.IGNORECASE)
# A summary that says its numbers are of some items, not all.
SAMPLE_SAID = re.compile(
    r"sample|subset|\blimit|\bfirst \d+|\b\d+\s*(?:items?|examples?|cases?|records?|rows?|questions?|pages?)\b|"
    r"of each (?:test )?set|샘플|표본|일부|부분|\d+\s*(?:개|건|문항|쪽)", re.IGNORECASE)
PYTHON_FLAGS_VALUED = frozenset({"-X", "-W"})


def script_of(argv: list[str]) -> str | None:
    """The Python script a command runs, as it names it; None for anything else."""
    words = list(argv)
    if len(words) > 2 and PureWindowsPath(words[0]).name.lower().removesuffix(".exe") == "uv" and words[1] == "run":
        words = words[2:]
        if words[0].endswith(".py"):
            return words[0]
    head = PureWindowsPath(words[0]).name.lower().removesuffix(".exe") if words else ""
    if not (head in ("python", "python3", "py") or head.startswith("python")):
        return None
    rest = words[1:]
    while rest and rest[0].startswith("-"):
        if rest[0] == "-m":
            return rest[1].replace(".", "/") + ".py" if len(rest) > 1 else None
        if rest[0] == "-c":
            return None
        rest = rest[2:] if rest[0] in PYTHON_FLAGS_VALUED else rest[1:]
    return rest[0] if rest and rest[0].endswith(".py") else None


def located(workspace: Path, cwd: str, scope: str | None, argv: list[str]) -> str | None:
    """The workspace file a command's script is, from the folder it runs in; None when not one."""
    script = script_of(argv)
    if script is None:
        return None
    path = script.replace("\\", "/").removeprefix("./")
    if Path(path).is_absolute() or ":" in path[:3]:
        return None
    if scope and path.startswith(f"{scope}/"):
        # Named from the workspace; commands run in the project folder (`_from_home`).
        path = path[len(scope) + 1:]
    base = "" if cwd in ("", ".") else cwd.strip("/")
    for candidate in (path, path.removesuffix(".py") + "/__main__.py"):
        joined = posixpath.normpath(posixpath.join(base, candidate))
        if not joined.startswith("../") and workspace.joinpath(*joined.split("/")).is_file():
            return joined
    return None


def size_option(text: str) -> tuple[frozenset[str], int | None]:
    """The flags of a script's option for how many items it takes, and its default when a number."""
    for match in OPTION_CALL.finditer(text):
        flags = FLAG.findall(match.group(1))
        if any(SIZE_FLAG.match(flag) for flag in flags):
            default = DEFAULT.search(match.group(1))
            return frozenset(flags), int(default.group(1)) if default else None
    return frozenset(), None


def sized(argv: list[str], flags: frozenset[str], default: int | None) -> int | None:
    """How many items a run takes, by its size option; None for all of them."""
    for place, word in enumerate(argv):
        value: str | None = None
        if word in flags:
            value = argv[place + 1] if place + 1 < len(argv) else None
        else:
            value = next((word.split("=", 1)[1] for flag in flags
                          if flag.startswith("--") and word.startswith(f"{flag}=")), None)
            if value is None:
                continue
        try:
            number = int(value) if value is not None else 0
        except ValueError:
            return None  # "all", "none"
        return number if number > 0 else None
    return default if default is not None and default > 0 else None


def _goes_through_items(text: str) -> bool:
    return bool(ITEMS.search(text)) and bool(WORK.search(text) or MODEL_CALL.search(text)) \
        and not SERVER.search(text)


def _read(workspace: Path, path: str) -> str | None:
    try:
        return workspace.joinpath(*path.split("/")).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


def held_whole_run(workspace: Path, loop: CodingLoop, argv: list[str], cwd: str, *,
                   is_test: Callable[[str], bool]) -> str | None:
    """Why a run over every item is held: nothing smaller of its script has run yet; None to run it."""
    if without("staged-runs") or loop.helper_of is not None:
        return None
    path = located(workspace, cwd, loop.scope, argv)
    if path is None or is_test(path) or CHECKING.match(path.rsplit("/", 1)[-1]):
        return None
    text = _read(workspace, path)
    if text is None:
        return None
    flags, default = size_option(text)
    if flags:
        if sized(argv, flags, default) is not None:
            return None
    elif path not in {item.path for item in loop.written} or not _goes_through_items(text):
        # Code the person had, with no size option: running all of it is theirs to say.
        return None
    for step in loop.steps:
        if (step.action.action not in (LoopActionKind.RUN, LoopActionKind.START_PROCESS)
                or not step.action.argv or located(workspace, cwd, loop.scope, step.action.argv) != path):
            continue
        if step.observation.startswith(HELD_SAID):
            return None  # held once already: sent again, with its reason
        if (step.action.action is LoopActionKind.RUN and step.succeeded
                and (not flags or sized(step.action.argv, flags, default) is not None)):
            return None  # ran small already
    again = ("If the whole is only a few items, or this is not a run through items, send the same "
             "command again and say why: it is held once")
    if flags:
        flag = max(flags, key=len)
        return (f"{HELD}{path} runs every item unless {flag} is given, and nothing smaller of it "
                f"has run here. Run it with {flag} 2 first -- one or two items of each test set -- "
                f"and read what it wrote; then a few dozen, timed, and only then the whole. {again}")
    return (f"{HELD}{path} goes through every item, and this would be its first run. Give it an "
            f"option for how many items to take (--limit N, of each set when there are several; "
            f"none given, all), run it with --limit 2 first and read what it wrote; then a few "
            f"dozen, timed, and only then the whole. {again}")


def small_run_note(workspace: Path, loop: CodingLoop, argv: list[str], cwd: str) -> str:
    """What a sized run that came out right is told: the next sizes, and what its scores are of."""
    if without("staged-runs") or loop.helper_of is not None:
        return ""
    path = located(workspace, cwd, loop.scope, argv)
    text = _read(workspace, path) if path else None
    if text is None:
        return ""
    flags, default = size_option(text)
    count = sized(argv, flags, default) if flags else None
    if count is None:
        return ""
    return (f"[ReLab] This ran {count} item(s) (of each set, where there are several), not the "
            f"whole. Read what it wrote; next a few dozen -- a tenth -- timed, saying how long the "
            f"whole will take; then the whole. Scores so far are of these {count} item(s).\n")


def sampled_scores(workspace: Path, loop: CodingLoop, cwd: str, summary: str = "") -> str | None:
    """Why not to finish yet: the scores last printed are of a sized run, and the summary does not say so."""
    if without("staged-runs") or loop.helper_of is not None or SAMPLE_SAID.search(summary):
        return None
    last = next((step for step in reversed(loop.steps)
                 if step.action.action is LoopActionKind.RUN and step.succeeded and step.action.argv
                 and scores(step.observation, step.index)), None)
    if last is None or last.action.argv is None:
        return None
    path = located(workspace, cwd, loop.scope, last.action.argv)
    text = _read(workspace, path) if path else None
    if text is None:
        return None
    flags, default = size_option(text)
    count = sized(last.action.argv, flags, default) if flags else None
    if count is None:
        return None
    for step in loop.steps:
        if (step.index > last.index and step.action.action in (LoopActionKind.RUN, LoopActionKind.START_PROCESS) and step.action.argv
                and located(workspace, cwd, loop.scope, step.action.argv) == path
                and sized(step.action.argv, flags, default) is None
                and not step.observation.startswith(HELD_SAID)):
            return None  # the whole was run, or goes on as a job
    names = ", ".join(sorted(scores(last.observation, last.index)))
    command = " ".join(last.action.argv)
    return (f"not finished: the scores last printed ({names}) came from `{command}` at step "
            f"{last.index} -- {count} item(s) of each set, not all of them. Say in the summary "
            f"that they are of {count} item(s), or run it whole (as a job if it takes longer than "
            f"a command may) and report those")
