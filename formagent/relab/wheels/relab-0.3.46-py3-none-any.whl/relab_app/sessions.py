"""Research session grouping and review of pinned coding evidence."""

import hashlib
import sys
import threading
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from relab_app.ablation import without
from relab_app.accounting import arm_accounts, measurement_blocker
from relab_app.measurements import ScoreLog
from relab_app.routing import gateway_for
from relab_app.runs import CodingRunService
from relab_coding.ollama import ModelTransportError
from relab_core.calibration import ControlReading, MeasurementControlRun
from relab_core.coding.sandbox import SandboxPolicy
from relab_core.contracts import RunState
from relab_core.controls import MeasurementControl
from relab_core.evaluation import (
    CodingMetrics,
    DecisionSupport,
    MetricComparison,
    MetricRegistry,
)
from relab_core.gateways import GatewayResolver
from relab_core.generation import ModelGateway, ModelIdentity
from relab_core.measurement import (
    ArtifactSource,
    ClaimDispatchDecision,
    MeasurementArtifact,
    MeasurementClaimAssessment,
    MeasurementClaimObservation,
    MeasurementKind,
    MeasurementRequirement,
    MeasurementSetup,
    MeasurementSnapshot,
    RuntimeReadiness,
    built_by_relab,
    ownership_of,
    python_readiness_argv,
)
from relab_core.operations import (
    MeasurementDetail,
    OperationKind,
    OperationObserver,
    observed,
)
from relab_core.provenance import RunConditions
from relab_core.provider import IncidentKind
from relab_core.repair import RepairHistory
from relab_core.research import (
    ArmTask,
    CodingRunReference,
    CodingTaskRequest,
    DesignProvenance,
    HoldoutRecord,
    PendingAmendment,
    PlanAmendment,
    ProposedAmendment,
    RepairProvenance,
    ResearchArmReadiness,
    ResearchConclusion,
    ResearchDecision,
    ResearchPlan,
    ResearchRunReadiness,
    ResearchSession,
    ResearchSessionAssessment,
    ResearchSessionComparison,
    ResearchSessionEvent,
    ResearchSessionHoldout,
    ResearchSessionReadiness,
    ResearchSessionRepeatability,
    ResearchSessionReview,
    SessionReopening,
    admitted,
    attempt_stands,
    task_digest,
)
from relab_core.routing import ModelRole, ModelRoutingPolicy
from relab_core.runs import RestoreReason, RunEvent
from relab_core.sensitivity import MeasurementSensitivity, SensitivityStatus
from relab_core.targets import EditTarget, TargetOperation
from relab_evaluation.adequacy import (
    assess_claims,
    claim_dispatch_policy,
    current_ruler_claims,
)
from relab_evaluation.assessment import assess_session, paired_comparisons
from relab_evaluation.coding import evaluate_coding
from relab_evaluation.comparison import compare_metrics
from relab_evaluation.fingerprints import fingerprint
from relab_evaluation.metrics import (
    MetricParseError,
    extract_coding_metrics,
    extract_holdout_metrics,
    parse_metrics,
)
from relab_evaluation.preregistration import moved_goalposts, produced_results
from relab_evaluation.readiness import assess_readiness
from relab_evaluation.repair import repair_history
from relab_evaluation.repeatability import assess_repeatability
from relab_evaluation.sensitivity import assess_sensitivity
from relab_research.proposals import (
    REPEATS_WHEN_IT_VARIES,
    MeasuredSeries,
    metric_key,
    repeats_for,
    stated_difference,
)
from relab_workspace.calibration import run_control
from relab_workspace.locking import session_execution_lock
from relab_workspace.operation_recorder import OperationRecorder
from relab_workspace.requirement_claims import probe_requirement_claims
from relab_workspace.run_store import RunStore
from relab_workspace.runtime_readiness import host_python_command, probe_runtime
from relab_workspace.service import build_verification_policy
from relab_workspace.session_store import SessionStore
from relab_workspace.worktree import isolated_worktree, workspace_revision

# Arms running at once each hold a checkout and a verifier, so the count is bounded.
MAXIMUM_PARALLEL_ARMS = 4
# A repair note is sent to the selected provider, so both bounds are explicit.
OUTPUT_TAIL_CHARACTERS = 800
REPAIR_NOTE_CHARACTERS = 2000


class ResearchSessionService:
    def __init__(
        self, workspace: Path, *, observe: OperationObserver | None = None,
    ) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.store = SessionStore(self.workspace)
        self.runs = RunStore(self.workspace)
        # Append-only. Coverage is counted here, where the records are, so no
        # surface ever counts runs itself -- a progress figure worked out by a
        # client is a second opinion about coverage, and coverage has an owner.
        self.observe: OperationObserver | None = (
            OperationRecorder.open(self.workspace) if observe is None else observe)
        # Arms may run at once; every read-modify-write of the session takes this.
        # Exclusion between processes stays the session execution lock's job.
        self._writes = threading.RLock()

    def create(
        self, objective: str, *, routing_policy: ModelRoutingPolicy | None = None,
    ) -> ResearchSession:
        """Open a session, and pin the routing it will be carried out under.

        The policy is caller-owned, like the registry: a model that could choose
        which model runs next would be choosing its own successor and the budget
        that pays for it. It is pinned at creation because the planner has
        already been called by then -- under the same policy -- and a study whose
        design and execution were routed by different declarations is one whose
        record cannot say which.
        """
        if not objective.strip():
            raise ValueError("research objective must not be blank")
        session = ResearchSession(
            session_id=f"research-{uuid4()}", workspace=str(self.workspace), objective=objective,
            routing_policy=routing_policy,
        )
        self.store.append(session, "research.created", 0)
        return session

    @staticmethod
    def open_session(session: ResearchSession) -> ResearchSession:
        """A concluded session is terminal; its decision must keep its exact evidence."""
        if session.conclusion is not None:
            raise ValueError("research session is concluded; further changes are rejected")
        return session

    def attach(self, session_id: str, run_id: str, *, role: str | None = None) -> ResearchSession:
        event = self.store.latest(session_id)
        session = self.open_session(event.snapshot)
        if role is not None:
            plan = session.plan
            if plan is None or role not in plan.arms:
                raise ValueError("a run role must be an arm declared by the recorded plan")
        existing = [ref for ref in session.runs if ref.run_id == run_id]
        if existing:
            if existing[0].role != role:
                raise ValueError("run already attached under a different role; detach is absent")
            return session
        events = self.runs.events(run_id)
        if not events:
            raise LookupError(f"coding run not found in this workspace: {run_id}")
        run_event = events[-1]
        if Path(run_event.snapshot.workspace).resolve() != self.workspace:
            raise ValueError("coding run workspace does not match research session")
        updated = session.model_copy(update={"runs": [*session.runs, CodingRunReference(
            run_id=run_id, event_sequence=run_event.sequence, role=role,
            task_digest=_declared_digest(session.plan, role),
        )]})
        self.store.append(updated, "research.run_attached", event.sequence)
        self._keep_scores(updated, run_event, role)
        return updated

    def repeat_shortfall(self, session_id: str) -> dict[str, object]:
        """Before a decision: how many runs per arm the design's varying rules need (P5, 0.2.87).

        The same reading the conclusion records as limitations, asked before it
        is taken, so a person can run what is missing instead of only reading
        afterwards that it was missing. `needed` is 0 when nothing falls short.
        """
        session = self.open_session(self.store.latest(session_id).snapshot)
        assessment = self.assess(session_id)
        said, needed = self._repeat_shortfall(session, assessment)
        counted = [len(arm.run_ids) for arm in assessment.arms if arm.run_ids]
        return {"session_id": session_id, "ran": min(counted) if counted else 0,
                "needed": needed, "limitations": said}

    def _too_few_runs(self, session: ResearchSession,
                      assessment: ResearchSessionAssessment) -> list[str]:
        return self._repeat_shortfall(session, assessment)[0]

    def _repeat_shortfall(self, session: ResearchSession,
                          assessment: ResearchSessionAssessment) -> tuple[list[str], int]:
        """Arms that ran fewer times than telling the difference needed (P5, 0.2.83).

        For each pre-registered rule that was seen to vary: how far one arm's own
        repeats differed (else how far the workspace's kept runs of one version
        did), the difference to tell (the objective's "0.5%p", else the rule's
        tolerance), and the runs per arm that takes at a two-sided 5% with 80%
        power -- against the fewest an arm here ran. Said, not refused: the
        decision stays the person's, and the record says what it could not show.
        """
        if without("score-spread"):
            return [], 0
        plan = session.plan
        counted = [len(arm.run_ids) for arm in assessment.arms if arm.run_ids]
        if plan is None or not counted:
            return [], 0
        ran = min(counted)
        kept = {metric_key(str(item["metric"])): MeasuredSeries.model_validate(item)
                for item in reversed(ScoreLog(self.workspace).by_command())}
        asked = stated_difference(session.objective)
        said: list[str] = []
        most = 0
        for rule in plan.registry.rules:
            values = [(item.minimum, item.maximum) for arm in assessment.arms
                      if arm.repeatability is not None for item in arm.repeatability.items
                      if item.name == rule.name and item.minimum is not None and item.maximum is not None]
            series = kept.get(metric_key(rule.name))
            if values:
                spread = max(high - low for low, high in values)
                largest = max(abs(high) for _, high in values)
                shown = f"{spread:.3g}"
                difference = (asked / 100 if largest <= 1 else asked) if asked is not None \
                    else rule.tolerance
            elif series is not None and series.varies():
                spread, shown = series.spread_number(), series.spread
                difference = series.as_mine(asked) if asked is not None else (
                    rule.tolerance * 100 if series.in_points() and rule.tolerance <= 1 else rule.tolerance)
            else:
                continue
            if spread <= 0:
                continue
            needed = repeats_for(spread, difference) if difference > 0 else REPEATS_WHEN_IT_VARIES
            if ran >= needed:
                continue
            most = max(most, needed)
            source = (f"{asked:g} points (the objective's)" if asked is not None
                      else f"{rule.tolerance:g} (the rule's tolerance)" if rule.tolerance > 0 else "")
            telling = (f"telling a difference of {source} from that takes about {needed} runs per arm"
                       if source else f"telling any difference from that takes at least {needed} runs per arm")
            said.append((f"{rule.name}: the arms ran {ran} time(s) each; runs of one version differed "
                         f"by up to {shown}, and {telling} (two-sided 5%, power 80%) -- a difference "
                         f"this study did not show may still be there, and one it showed may be noise")[:600])
        return said[:8], most

    def _keep_scores(self, session: ResearchSession, run_event: RunEvent, role: str | None) -> None:
        """A run's scores into the workspace's score log, beside the coding loops' (P5, 0.2.76).

        So coding and research read one history: a coding task here is told
        what a study measured, and a study what coding measured. Only the
        selection metrics of a verified run; a run without them keeps nothing,
        and a log that cannot be written leaves the session as it is.
        """
        try:
            metrics = extract_coding_metrics(run_event)
        except (ValueError, MetricParseError):
            return
        evidence = run_event.snapshot.patch_evidence
        if evidence is None or evidence.verification is None:
            return
        try:
            ScoreLog(self.workspace).record_run(
                run_event.run_id, run_event.sequence, list(evidence.verification.argv),
                dict(metrics.metrics), request=session.objective, arm=role)
        except OSError:
            return

    def refresh(
        self, session_id: str, run_id: str, *, expected_run_sequence: int,
    ) -> ResearchSession:
        """Advance one existing pin, never silently refresh another caller's reference."""
        if type(expected_run_sequence) is not int or expected_run_sequence < 1:
            raise ValueError("expected run sequence must be a positive integer")
        with self._writes:
            return self._refresh_locked(session_id, run_id, expected_run_sequence)

    def _refresh_locked(
        self, session_id: str, run_id: str, expected_run_sequence: int,
    ) -> ResearchSession:
        event = self.store.latest(session_id)
        session = self.open_session(event.snapshot)
        refs = [ref for ref in session.runs if ref.run_id == run_id]
        if len(refs) != 1:
            raise ValueError("refresh requires exactly one attached run reference")
        if refs[0].event_sequence != expected_run_sequence:
            raise ValueError("pinned run changed; reload before refreshing")
        events = self.runs.events(run_id)
        if not any(item.sequence == expected_run_sequence for item in events):
            raise ValueError("pinned coding event unavailable; inspect session history")
        latest = events[-1]
        if Path(latest.snapshot.workspace).resolve() != self.workspace:
            raise ValueError("coding run workspace does not match research session")
        if latest.sequence == expected_run_sequence:
            return session
        updated = session.model_copy(update={"runs": [
            CodingRunReference(run_id=run_id, event_sequence=latest.sequence,
                               role=ref.role, task_digest=ref.task_digest)
            if ref.run_id == run_id else ref for ref in session.runs
        ]})
        self.store.append(updated, "research.run_refreshed", event.sequence)
        self._keep_scores(updated, latest, refs[0].role)
        return updated

    def record_plan(
        self, session_id: str, registry: MetricRegistry, *,
        arms: list[str] | None = None, repeats_per_arm: int = 1,
        candidate_arm: str | None = None, baseline_arm: str | None = None,
        arm_tasks: list[ArmTask] | None = None, expected_model: ModelIdentity | None = None,
        expected_reported_model: str | None = None, data_paths: list[str] | None = None,
        require_comparable_conditions: bool = False,
        holdout_registry: MetricRegistry | None = None,
        restore_between_attempts: bool = False, isolate_attempts: bool = False,
        sandbox_backend: str | None = None, docker_image: str | None = None,
        holdout_data_paths: list[str] | None = None,
        measurement: MeasurementSetup | None = None,
        measurement_requirements: list[MeasurementRequirement] | None = None,
        measurement_controls: list[MeasurementControl] | None = None,
        provenance: DesignProvenance | None = None,
        max_transport_failures_per_arm: int = 2,
        max_generation_failures_per_arm: int = 2,
    ) -> ResearchSession:
        """Pre-register the evaluation policy; revising a recorded plan is not implemented."""
        event = self.store.latest(session_id)
        session = self.open_session(event.snapshot)
        plan = self._plan(registry, arms, repeats_per_arm, candidate_arm, baseline_arm,
                          arm_tasks, 0, expected_model, expected_reported_model,
                          data_paths, require_comparable_conditions,
                          holdout_registry, restore_between_attempts,
                          isolate_attempts, sandbox_backend, docker_image,
                          holdout_data_paths=holdout_data_paths,
                          measurement=measurement,
                          measurement_requirements=measurement_requirements,
                          measurement_controls=measurement_controls,
                          provenance=provenance,
                          max_transport_failures_per_arm=max_transport_failures_per_arm,
                          max_generation_failures_per_arm=max_generation_failures_per_arm)
        if session.plan is not None:
            if session.plan == plan:
                return session
            raise ValueError(
                "research plan already recorded; create a new session for a different policy"
            )
        updated = session.model_copy(update={"plan": plan})
        self.store.append(updated, "research.plan_recorded", event.sequence)
        return updated

    @staticmethod
    def _plan(
        registry: MetricRegistry, arms: list[str] | None, repeats_per_arm: int,
        candidate_arm: str | None, baseline_arm: str | None,
        arm_tasks: list[ArmTask] | None, revision: int,
        expected_model: ModelIdentity | None = None,
        expected_reported_model: str | None = None,
        data_paths: list[str] | None = None,
        require_comparable_conditions: bool = False,
        holdout_registry: MetricRegistry | None = None,
        restore_between_attempts: bool = False,
        isolate_attempts: bool = False,
        sandbox_backend: str | None = None, docker_image: str | None = None,
        holdout_data_paths: list[str] | None = None,
        measurement: MeasurementSetup | None = None,
        measurement_requirements: list[MeasurementRequirement] | None = None,
        measurement_controls: list[MeasurementControl] | None = None,
        provenance: DesignProvenance | None = None,
        max_transport_failures_per_arm: int = 2,
        max_generation_failures_per_arm: int = 2,
    ) -> ResearchPlan:
        # Every new or revised design comes through here, so this is where the
        # rules only a new design must meet are applied; a recorded plan is read
        # without them. See `ResearchPlan.admission_findings`.
        return admitted(ResearchPlan(
            registry=registry, arms=arms or [], repeats_per_arm=repeats_per_arm,
            candidate_arm=candidate_arm, baseline_arm=baseline_arm,
            arm_tasks=arm_tasks or [], revision=revision,
            expected_model=expected_model, expected_reported_model=expected_reported_model,
            data_paths=data_paths or [],
            require_comparable_conditions=require_comparable_conditions,
            holdout_registry=holdout_registry,
            restore_between_attempts=restore_between_attempts,
            isolate_attempts=isolate_attempts,
            sandbox_backend=sandbox_backend, docker_image=docker_image,
            holdout_data_paths=holdout_data_paths or [],
            measurement=measurement,
            # Absent stays absent. A plan that declared nothing has no contract
            # to be judged against, and an empty list here would quietly turn
            # that into "nothing is required", which is a design somebody would
            # have had to write down.
            measurement_requirements=measurement_requirements or None,
            measurement_controls=measurement_controls or None,
            provenance=provenance,
            max_transport_failures_per_arm=max_transport_failures_per_arm,
            max_generation_failures_per_arm=max_generation_failures_per_arm,
        ))

    def calibrate_measurement(self, session_id: str) -> ResearchSession:
        """Point the frozen ruler at every control that has not been run against it.

        A calibration is not an attempt. It spends no repeat, fills no arm slot,
        produces no evidence about the thing under study, and a study with no
        controls is left exactly as it was. What it costs is machine time, which
        belongs in operational accounting and not in this study's.

        One run per ruler and control, and the first stands. A second run of the
        same control against the same ruler that measured differently is a
        disagreement worth diagnosing -- a verifier that is not deterministic is
        itself a finding -- and overwriting would make "what did this ruler do
        with this control" answerable only by whichever run finished last.
        """
        with self._writes:
            event = self.store.latest(session_id)
            session = self.open_session(event.snapshot)
            plan, frozen = session.plan, session.measurement_snapshot
            if (plan is None or plan.measurement is None or not plan.measurement_controls
                    or frozen is None or frozen.snapshot_id is None):
                return session
            already = {(item.snapshot_id, item.control_id)
                       for item in session.measurement_control_runs}
            performed = []
            for control in plan.measurement_controls:
                if (frozen.snapshot_id, control.control_id) in already:
                    continue
                done = run_control(
                    self.workspace, sorted(plan.measurement.paths),
                    list(plan.measurement.verify_argv), control, frozen.snapshot_id,
                    sandbox_policy=_sandbox_policy(plan))
                if done is not None:
                    performed.append(_with_metrics(done))
            if not performed:
                return session
            updated = session.model_copy(update={
                "measurement_control_runs": [
                    *session.measurement_control_runs, *performed],
            })
            self.store.append(updated, "research.measurement_calibrated", event.sequence)
            return updated

    def sensitivity(self, session_id: str) -> MeasurementSensitivity:
        """What this design's controls have shown about the ruler in force.

        Computed on every read, like the claim assessment beside it. Runs under
        a retired ruler are not read: they happened, and they were about an
        instrument this study is no longer measured by.
        """
        session = self.open_session(self.store.latest(session_id).snapshot)
        plan, frozen = session.plan, session.measurement_snapshot
        if plan is None:
            return MeasurementSensitivity(status=SensitivityStatus.UNDECLARED)
        return assess_sensitivity(
            plan.measurement_controls, session.measurement_control_runs,
            plan.registry, None if frozen is None else frozen.snapshot_id,
            asked_to_declare=plan.asks_verifier_to_declare())

    def record_claim_observation(
        self, session_id: str, snapshot_id: str, claimed: list[str], *,
        limitations: list[str] | None = None,
    ) -> ResearchSession:
        """Keep what one frozen ruler said it was built to check.

        One per snapshot, and the first one wins. A second reading of the same
        ruler that claimed something different is a disagreement worth
        diagnosing, not a correction to apply: letting the later one overwrite
        the earlier would make "what did this ruler claim" answerable only by
        whichever run happened to finish last, which is the shape of a record
        that cannot be argued with.

        So a repeat is a no-op rather than a refusal. The caller is a probe or a
        verification that has no way to know whether somebody already asked, and
        making it find out first would put the ordering problem in the wrong
        place.
        """
        with self._writes:
            event = self.store.latest(session_id)
            session = self.open_session(event.snapshot)
            if any(item.snapshot_id == snapshot_id
                   for item in session.measurement_claim_observations):
                return session
            observed = MeasurementClaimObservation(
                snapshot_id=snapshot_id,
                claimed_requirement_ids=list(claimed),
                observed_at=datetime.now(timezone.utc),
                limitations=list(limitations or []))
            updated = session.model_copy(update={
                "measurement_claim_observations": [
                    *session.measurement_claim_observations, observed],
            })
            self.store.append(updated, "research.measurement_claims_observed", event.sequence)
            return updated

    def claim_assessment(self, session_id: str) -> MeasurementClaimAssessment:
        """What this design, as it stands now, makes of what its ruler claimed.

        Computed on every read. Half of it is the current plan, and a plan can
        change without the ruler changing -- a requirement added yesterday must
        change what the same claims mean, and a stored status would answer with
        what they used to mean.
        """
        session = self.open_session(self.store.latest(session_id).snapshot)
        frozen = session.measurement_snapshot
        observed = None if frozen is None else next(
            (item for item in session.measurement_claim_observations
             if item.snapshot_id == frozen.snapshot_id), None)
        plan = session.plan
        return assess_claims(
            None if plan is None else plan.measurement_requirements, observed,
            ownership_of(None if plan is None else plan.measurement))

    def _ruler_was_run(self, session: ResearchSession, coding: CodingRunService) -> bool:
        """Whether the verifier has actually run under the ruler in force.

        Not "has an arm been attempted". An attempt whose provider timed out,
        whose generation was refused or whose patch never applied did not reach
        the verifier at all, so it used no opportunity to declare -- and holding
        it against the instrument would blame the ruler for a provider having a
        bad afternoon.

        Read from the recording every verification makes of which ruler it ran
        under, which is the only thing that answers this.
        """
        frozen = session.measurement_snapshot
        if frozen is None or frozen.snapshot_id is None:
            return False
        for reference in session.runs:
            evidence = coding.store.load(reference.run_id).patch_evidence
            verification = None if evidence is None else evidence.verification
            if (verification is not None
                    and verification.measurement_snapshot_id == frozen.snapshot_id):
                return True
        return False

    def _observe_claims_from_runs(
        self, session_id: str, session: ResearchSession, coding: CodingRunService,
    ) -> None:
        """Take the claim a real verification heard, when the probe heard none.

        Only when there is no observation for this ruler yet. A verification
        that claimed something different from what the probe recorded is a
        disagreement worth diagnosing later, not a correction to apply now --
        the first observation of a ruler stands.
        """
        frozen = session.measurement_snapshot
        if frozen is None or frozen.snapshot_id is None:
            return
        if any(item.snapshot_id == frozen.snapshot_id
               for item in session.measurement_claim_observations):
            return
        heard, _ = current_ruler_claims(session, coding.store.load)
        if heard is None:
            return
        # The one thing the execution path may do that a projection may not.
        self.record_claim_observation(
            session_id, frozen.snapshot_id, heard.claimed_requirement_ids,
            limitations=list(heard.limitations))

    def _claims_block_dispatch(
        self, session_id: str, coding: CodingRunService,
    ) -> ClaimDispatchDecision:
        """Whether the ruler's claims stop another arm being dispatched.

        Asked before an arm runs and between arms, for the reason the
        instrument check beside it is: the verifier is frozen and shared, so an
        arm that has not reached it yet is not better off.
        """
        self._observe_claims_from_runs(
            session_id, self.open_session(self.store.latest(session_id).snapshot), coding)
        session = self.open_session(self.store.latest(session_id).snapshot)
        observed, opportunities = current_ruler_claims(session, coding.store.load)
        plan = session.plan
        return claim_dispatch_policy(
            assess_claims(None if plan is None else plan.measurement_requirements,
                          observed, ownership_of(None if plan is None
                                                 else plan.measurement)),
            current_ruler_had_verification=bool(opportunities))

    def revise_plan(
        self, session_id: str, registry: MetricRegistry, *, expected_revision: int,
        rationale: str, arms: list[str] | None = None, repeats_per_arm: int = 1,
        candidate_arm: str | None = None, baseline_arm: str | None = None,
        arm_tasks: list[ArmTask] | None = None, expected_model: ModelIdentity | None = None,
        expected_reported_model: str | None = None, data_paths: list[str] | None = None,
        require_comparable_conditions: bool = False,
        holdout_registry: MetricRegistry | None = None,
        restore_between_attempts: bool = False, isolate_attempts: bool = False,
        sandbox_backend: str | None = None, docker_image: str | None = None,
        holdout_data_paths: list[str] | None = None,
        measurement: MeasurementSetup | None = None,
        provenance: DesignProvenance | None = None,
    ) -> ResearchSession:
        """Amend a pre-registered policy explicitly; the amendment stays visible."""
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("expected plan revision must be a nonnegative integer")
        if not rationale.strip():
            raise ValueError("a plan amendment requires a nonblank rationale")
        event = self.store.latest(session_id)
        session = self.open_session(event.snapshot)
        current = session.plan
        if current is None:
            raise ValueError("no research plan to revise; record one first")
        if current.revision != expected_revision:
            raise ValueError("recorded plan changed; reload before revising")
        plan = self._plan(registry, arms, repeats_per_arm, candidate_arm, baseline_arm,
                          arm_tasks, expected_revision + 1, expected_model,
                          expected_reported_model, data_paths,
                          require_comparable_conditions, holdout_registry,
                          restore_between_attempts, isolate_attempts,
                          sandbox_backend, docker_image,
                          holdout_data_paths=holdout_data_paths,
                          measurement=measurement, provenance=provenance,
                          # Carried from the plan being revised, because nothing
                          # here can set them and a revision that reset them
                          # would be a policy nobody chose. An amendment says
                          # what it changes; everything it does not name is what
                          # the study already declared.
                          measurement_requirements=current.measurement_requirements,
                          measurement_controls=current.measurement_controls,
                          max_transport_failures_per_arm=(
                              current.max_transport_failures_per_arm),
                          max_generation_failures_per_arm=(
                              current.max_generation_failures_per_arm))
        bound = {ref.role for ref in session.runs if ref.role is not None}
        bound |= {item.arm for item in session.requests}
        dropped = sorted(bound - set(plan.arms))
        if dropped:
            raise ValueError(f"an amendment cannot drop arms that already bind runs: {dropped}")
        updated = session.model_copy(update={"plan": plan, "amendments": [
            *session.amendments, PlanAmendment(
                revision=plan.revision, rationale=rationale,
                attached_runs=len(session.runs),
            ),
        ]})
        self.store.append(updated, "research.plan_revised", event.sequence)
        return updated

    def propose_amendment(
        self, session_id: str, proposal: ProposedAmendment, *,
        source_alternative_id: str | None = None,
    ) -> ResearchSession:
        """Hold a proposed change between being shown and being decided.

        Recorded because a model wrote it. A change that can be derived again --
        the same rule over the same plan -- needs no holding; one that was
        written cannot be asked for twice and still be the same change, so what
        a person is shown is kept and what they approve is read back from here.

        One at a time. A second proposal arriving while the first is unanswered
        would leave somebody approving whichever the surface happened to draw,
        and a proposal nobody answered is not a reason to forget it.
        """
        event = self.store.latest(session_id)
        session = self.open_session(event.snapshot)
        if session.plan is None:
            raise ValueError("no research plan to propose a change to; record one first")
        if session.pending_amendment is not None:
            raise ValueError(
                "a proposed change is already waiting on a decision; answer it first")
        if session.conclusion is not None:
            raise ValueError("a concluded session takes no further proposals")
        pending = PendingAmendment(
            proposal=proposal, offered_at_event_sequence=event.sequence,
            plan_revision=session.plan.revision,
            source_alternative_id=source_alternative_id)
        updated = session.model_copy(update={"pending_amendment": pending})
        self.store.append(updated, "research.amendment_proposed", event.sequence)
        return updated

    def resolve_pending_amendment(
        self, session_id: str, *, accepted: bool, expected_revision: int,
    ) -> ResearchSession:
        """Answer the held proposal, and leave nothing waiting either way.

        Declining records that it was answered rather than nothing at all. The
        proposal's existence is already on the record, so a decline that wrote
        nothing would leave it waiting forever -- and the same change would come
        back asking for a decision somebody had already made.

        What the plan holds afterwards is the difference: an approval revises it,
        a decline leaves it exactly as it was.
        """
        event = self.store.latest(session_id)
        session = self.open_session(event.snapshot)
        pending = session.pending_amendment
        if pending is None:
            raise ValueError("there is no proposed change waiting on a decision")
        if session.plan is None or session.plan.revision != expected_revision:
            raise ValueError("recorded plan changed; reload before answering")
        if not accepted:
            self.store.append(session.model_copy(update={"pending_amendment": None}),
                              "research.amendment_declined", event.sequence)
            return self.store.latest(session_id).snapshot
        # Cleared before the revision, so the plan a person approved and the
        # absence of anything still waiting are recorded by the same act rather
        # than by two that could be interrupted between.
        self.store.append(session.model_copy(update={"pending_amendment": None}),
                          "research.amendment_accepted", event.sequence)
        return self.store.latest(session_id).snapshot

    def reopen(self, session_id: str, rationale: str) -> ResearchSession:
        """Set aside a terminal decision; the superseded conclusion stays in history."""
        if not rationale.strip():
            raise ValueError("reopening a research session requires a nonblank rationale")
        event = self.store.latest(session_id)
        session = event.snapshot
        conclusion = session.conclusion
        if conclusion is None:
            raise ValueError("research session is not concluded; there is nothing to reopen")
        updated = session.model_copy(update={"conclusion": None, "reopenings": [
            *session.reopenings, SessionReopening(
                decision=conclusion.decision, event_sequence=event.sequence,
                rationale=rationale,
            ),
        ]})
        self.store.append(updated, "research.reopened", event.sequence)
        return updated

    @staticmethod
    def _policy(
        event: ResearchSessionEvent, registry: MetricRegistry | None,
    ) -> tuple[MetricRegistry, bool]:
        """An omitted registry uses the plan of the selected snapshot, never a later one."""
        if registry is not None:
            return registry, False
        plan = event.snapshot.plan
        if plan is None:
            raise ValueError("no research plan recorded in the selected session snapshot")
        return plan.registry, True

    def _event(
        self, session_id: str, *, event_sequence: int | None = None,
    ) -> ResearchSessionEvent:
        if event_sequence is None:
            event = self.store.latest(session_id)
        else:
            if type(event_sequence) is not int or event_sequence < 1:
                raise ValueError("session event sequence must be a positive integer")
            events = [item for item in self.store.events(session_id)
                      if item.sequence == event_sequence]
            if len(events) != 1:
                raise LookupError("requested research session event unavailable")
            event = events[0]
        return event

    def compare(
        self, session_id: str, candidate_id: str, baseline_id: str,
        registry: MetricRegistry | None = None, *, event_sequence: int | None = None,
    ) -> ResearchSessionComparison:
        """Compare only the two selected pins, without refreshing or executing runs."""
        if candidate_id == baseline_id:
            raise ValueError("candidate and baseline must be distinct runs")
        event = self._event(session_id, event_sequence=event_sequence)
        rules, planned = self._policy(event, registry)
        metrics = self._metrics(event, [candidate_id, baseline_id])
        return ResearchSessionComparison(
            session_id=session_id, event_sequence=event.sequence, plan_applied=planned,
            comparison=compare_metrics(metrics[0], metrics[1], rules),
        )

    def _pinned(self, run_id: str, event_sequence: int) -> RunEvent:
        matches = [item for item in self.runs.events(run_id) if item.sequence == event_sequence]
        if len(matches) != 1:
            raise ValueError("pinned coding event unavailable; inspect session history")
        if Path(matches[0].snapshot.workspace).resolve() != self.workspace:
            raise ValueError("coding run workspace does not match research session")
        return matches[0]

    def _metrics(self, event: ResearchSessionEvent, run_ids: list[str]) -> list[CodingMetrics]:
        metrics = []
        for run_id in run_ids:
            refs = [ref for ref in event.snapshot.runs if ref.run_id == run_id]
            if len(refs) != 1:
                raise ValueError("selected runs must be attached exactly once")
            metrics.append(extract_coding_metrics(self._pinned(run_id, refs[0].event_sequence)))
        return metrics

    def repeatability(
        self, session_id: str, run_ids: list[str], registry: MetricRegistry | None = None,
        *, minimum_runs: int = 3, event_sequence: int | None = None,
    ) -> ResearchSessionRepeatability:
        if type(minimum_runs) is not int or minimum_runs < 2:
            raise ValueError("minimum_runs must be an integer of at least 2")
        if len(run_ids) != len(set(run_ids)):
            raise ValueError("repeatability requires distinct run IDs")
        event = self._event(session_id, event_sequence=event_sequence)
        rules, planned = self._policy(event, registry)
        return ResearchSessionRepeatability(
            session_id=session_id, event_sequence=event.sequence, plan_applied=planned,
            repeatability=assess_repeatability(
                self._metrics(event, run_ids), rules, minimum_runs=minimum_runs),
        )

    def readiness(
        self, session_id: str, *, event_sequence: int | None = None,
    ) -> ResearchSessionReadiness:
        """Report which planned arms the pinned evidence covers; executes nothing."""
        event, plan, pinned = self._design(session_id, event_sequence)
        return assess_readiness(session_id, event.sequence, plan, pinned)

    def assess(
        self, session_id: str, *, event_sequence: int | None = None,
    ) -> ResearchSessionAssessment:
        """Apply the pinned plan to the pinned design without ad-hoc run selection."""
        event, plan, pinned = self._design(session_id, event_sequence)
        return assess_session(session_id, event.sequence, plan, pinned)

    def request(self, session_id: str) -> ResearchSession:
        """Create and attach the runs the declared design still lacks; nothing is executed."""
        event = self.store.latest(session_id)
        session = self.open_session(event.snapshot)
        plan = session.plan
        if plan is None or not plan.arms:
            raise ValueError("requesting runs needs a plan that declares experiment arms")
        objectives = {task.arm: task.objective for task in plan.arm_tasks}
        added: list[CodingTaskRequest] = []
        for arm in plan.arms:
            filled = (
                sum(1 for ref in session.runs if ref.role == arm)
                + sum(1 for item in session.requests if item.arm == arm and item.run_id is None)
            )
            if objectives.get(arm) is None and filled < plan.repeats_per_arm:
                raise ValueError(f"arm declares no task objective: {arm}")
            # Each arm is visited once, so its persisted requests give the whole ordinal.
            added += self._requests(session, arm, objectives.get(arm) or "",
                                    plan.repeats_per_arm - filled)
        if added:
            # Record the intent before any run exists so an interruption is recoverable.
            self.store.append(
                session.model_copy(update={"requests": [*session.requests, *added]}),
                "research.tasks_requested", event.sequence,
            )
        return self.fulfil_requests(session_id)

    @staticmethod
    def _requests(
        session: ResearchSession, arm: str, objective: str, count: int,
        repair: "RepairProvenance | None" = None,
    ) -> list[CodingTaskRequest]:
        """Continue this arm's request ordinals from the requests already recorded."""
        ordinal = sum(1 for item in session.requests if item.arm == arm)
        told = _with_requirements(objective, session.plan)
        return [CodingTaskRequest(
            request_id=f"{session.session_id}/{arm}/{ordinal + index + 1}",
            arm=arm, objective=told, repair=repair,
        ) for index in range(max(0, count))]

    def fulfil_requests(self, session_id: str) -> ResearchSession:
        """Create one run per outstanding request, adopting a run an earlier call left."""
        coding = CodingRunService(self.workspace)
        while True:
            with self._writes:
                session = self._fulfil_one(session_id, coding)
            if session is not None:
                return session

    def _fulfil_one(
        self, session_id: str, coding: CodingRunService,
    ) -> ResearchSession | None:
        """Create the next outstanding request's run, or return the settled session."""
        event = self.store.latest(session_id)
        session = self.open_session(event.snapshot)
        outstanding = [item for item in session.requests if item.run_id is None]
        if not outstanding:
            return session
        pending = outstanding[0]
        run_id = coding.create(
            pending.objective, pending.request_id, once_per_request=True).run_id
        run_event = self.runs.events(run_id)[-1]
        self.store.append(session.model_copy(update={
            "runs": [*session.runs, CodingRunReference(
                run_id=run_id, event_sequence=run_event.sequence, role=pending.arm,
                task_digest=_declared_digest(session.plan, pending.arm))],
            "requests": [item.model_copy(update={"run_id": run_id})
                         if item.request_id == pending.request_id else item
                         for item in session.requests],
        }), "research.task_created", event.sequence)
        return None

    def materialise_measurement(
        self, session_id: str, gateway: ModelGateway, *,
        model_timeout_seconds: float = 60,
    ) -> ResearchSession:
        """Build the plan's measurement artifacts, then freeze them.

        A separate act from running an arm, and it must stay separate. An
        artifact that cannot be built means *no* experiment can run, and
        discovering that when the first arm reverts for a missing file reports it
        as that arm failing -- which it is not, and which sends whoever reads it
        to look at the wrong thing.

        The creation itself reuses the ordinary change pipeline: the same typed
        target, the same `PatchProposal`, the same `WorkspacePatchService`. Path
        safety, `MISSING_FILE_HASH`, the new-file diff and the provenance are
        already right there, and a second writer for measurement files would be a
        second place for all of it to drift.

        What differs is the objective the model is given. An arm is asked to make
        something work; a verifier is asked to decide whether it does, without
        being party to it.
        """
        with self._writes:
            event = self.store.latest(session_id)
            session = self.open_session(event.snapshot)
            plan = session.plan
            if plan is None or plan.measurement is None:
                raise ValueError("this session declares no measurement to build")
            if session.measurement_snapshot is not None:
                # Frozen means frozen. Changing the ruler is a plan revision.
                raise ValueError("the measurement is already frozen")
            # Before any provider call: a ruler this host cannot start costs
            # the build nothing to discover now, and everything to discover
            # after it. See `relab_workspace.runtime_readiness`.
            _refuse_unready_runtime(plan)
            # Only creation writes. Said as "not create" rather than as a list of
            # the others, so a provenance added later is adopted rather than
            # silently written over the file it names.
            created = [item for item in plan.measurement.artifacts
                       if item.operation is ArtifactSource.CREATE]
            if created:
                # One bundle, one call. The first live pilot built a verifier and
                # its reference data in two calls, and neither could know what the
                # other would contain: the verifier inlined its cases and the
                # reference file was an orphan that cost a call of its own. Files
                # that must agree about an interface are written in one reply.
                #
                # It is also what makes a failed build retryable. Two separate
                # writes left the first file on disk when the second was refused,
                # and a CREATE of a file that is already here is refused too -- so
                # the study could neither build its ruler nor revise one it never
                # froze. A multi-file patch applies whole or not at all.
                coding = CodingRunService(self.workspace)
                prefix = f"{session_id}/measurement"
                # A request id is also the patch id, which is immutable, so a
                # retry after a refused build is a new attempt with its own id.
                attempt = 1
                while self.runs.runs_for_request(f"{prefix}/{attempt}"):
                    attempt += 1
                run = coding.create(
                    _measurement_bundle_objective(plan, created), f"{prefix}/{attempt}")
                coding.generate_and_apply(
                    run.run_id,
                    [EditTarget(path=item.path, operation=TargetOperation.CREATE)
                     for item in created],
                    gateway,
                    # Structural readiness, not measurement. Running the verifier
                    # here would fail for the right reason -- the arms have not
                    # written anything yet -- and that is not a defect in the
                    # ruler. `py_compile` proves each file is there and parses,
                    # and imports nothing, so a verifier that references a
                    # not-yet-created module still passes.
                    verify_argv=[sys.executable, "-m", "py_compile",
                                 *(item.path for item in created)],
                    model_timeout_seconds=model_timeout_seconds,
                    timeout_seconds=model_timeout_seconds)
            return self._freeze_measurement(session_id)

    def revise_measurement(
        self, session_id: str, measurement: MeasurementSetup, *,
        expected_revision: int, rationale: str,
    ) -> ResearchSession:
        """Retire this study's ruler and record the one that replaces it.

        The instrument is the thing every arm is judged by, so replacing it is
        not an amendment to one arm's task -- it retires every reading in the
        study at once, including the arms that were going perfectly well. The
        impact is computed before this is called and shown to whoever approves
        it; this is the act that follows.

        It does not build the new ruler. What it does is leave the study
        without one, which is the state it was in before its first freeze and
        stops arms for the same reason: a study with no instrument measures
        nothing. `materialise_measurement` then builds the successor, and only
        a freeze issues an identity -- so nothing here can mint a ruler by
        accident.

        The retired snapshot is kept. A reading taken under it really was taken
        and the record has to go on saying so; what changes is which ruler the
        study is decided by.
        """
        if not rationale.strip():
            raise ValueError("replacing a measurement requires a nonblank rationale")
        with self._writes:
            event = self.store.latest(session_id)
            session = self.open_session(event.snapshot)
            plan = session.plan
            if plan is None:
                raise ValueError("no research plan to measure; record one first")
            retired = session.measurement_snapshot
            if retired is None:
                raise ValueError(
                    "this study has no frozen measurement to replace; materialise one")
            # A new ruler is a new file. `ArtifactSource` has no way to say
            # "change the verifier" on purpose -- editing the thing that judges
            # every arm, in place, is the one edit nobody should be able to make
            # quietly -- so a replacement that creates an artifact already on
            # disk cannot be built, and is refused here rather than three layers
            # down where it reads as a patch that would not apply.
            #
            # The retired verifier stays where it is. Two files on disk, and a
            # record saying which one is in force, is more readable than one
            # file whose history is only in the log.
            occupied = [
                item.path for item in measurement.artifacts
                if item.operation is ArtifactSource.CREATE
                and self.workspace.joinpath(*item.path.split("/")).exists()
            ]
            if occupied:
                raise ValueError(
                    "a replacement measurement creates files that are already here: "
                    + ", ".join(sorted(occupied))
                    + "; declare the corrected instrument at a new path, which leaves "
                    "the retired one readable beside it")
            # Every arm is measured by the command the measurement owns, which
            # the plan enforces. A new ruler is a new command, so the arm tasks
            # follow it. Mechanical rather than a judgement: an arm left naming
            # the retired verifier would make the plan invalid, and an arm that
            # kept its own command would not be in the comparison at all.
            retargeted = [
                task.model_copy(update={"verify_argv": list(measurement.verify_argv)})
                if task.verify_argv else task
                for task in plan.arm_tasks
            ]
            revised = self.revise_plan(
                session_id, plan.registry, expected_revision=expected_revision,
                rationale=rationale, arms=list(plan.arms),
                repeats_per_arm=plan.repeats_per_arm, candidate_arm=plan.candidate_arm,
                baseline_arm=plan.baseline_arm, arm_tasks=retargeted,
                expected_model=plan.expected_model,
                expected_reported_model=plan.expected_reported_model,
                data_paths=list(plan.data_paths),
                require_comparable_conditions=plan.require_comparable_conditions,
                holdout_registry=plan.holdout_registry,
                restore_between_attempts=plan.restore_between_attempts,
                isolate_attempts=plan.isolate_attempts,
                sandbox_backend=plan.sandbox_backend, docker_image=plan.docker_image,
                holdout_data_paths=list(plan.holdout_data_paths),
                measurement=measurement, provenance=plan.provenance)
            latest = self.store.latest(session_id)
            without = revised.model_copy(update={
                "measurement_snapshot": None,
                "superseded_measurements": [*session.superseded_measurements, retired],
            })
            self.store.append(without, "research.measurement_retired", latest.sequence)
            return without

    def _probe_claims(self, session_id: str, session: ResearchSession) -> None:
        """Ask the frozen ruler what it checks, before any arm has run.

        Only of a ruler ReLab wrote. An adopted verifier was here before this
        protocol existed and was adopted as it stands; requiring it to answer
        would be requiring it to have been written by us, which is the one thing
        adopting it says it was not. It simply goes unobserved, and the reading
        says so.

        Everything about the probe is discarded except the claim: the exit code
        is expected to be non-zero, because the arms have written nothing yet
        and there is nothing for the instrument to measure. Nothing here
        produces a reading, a metric or a verdict.
        """
        plan, frozen = session.plan, session.measurement_snapshot
        if plan is None or plan.measurement is None or frozen is None:
            return
        if frozen.snapshot_id is None:
            # A ruler frozen before identities were issued. There is nothing to
            # file an observation under, and a legacy identity is not a
            # wildcard that one could be filed against.
            return
        if not plan.measurement_requirements:
            # Nothing declared, so there is no contract to ask about.
            return
        verifier = next((item for item in plan.measurement.artifacts
                         if item.kind is MeasurementKind.VERIFIER), None)
        # Only of a ruler ReLab wrote: created now, or by an earlier session.
        if verifier is None or not built_by_relab(verifier):
            return
        claimed, limitations = probe_requirement_claims(
            self.workspace, sorted(plan.measurement.paths),
            list(plan.measurement.verify_argv),
            sandbox_policy=_sandbox_policy(plan))
        if claimed is None:
            # Unobserved, and it stays that way until a real verification is
            # heard from. An observation nobody made is not an empty one.
            return
        self.record_claim_observation(
            session_id, frozen.snapshot_id, claimed, limitations=limitations)

    def _freeze_measurement(self, session_id: str) -> ResearchSession:
        """Record the ruler as it now stands, so later readings can be compared."""
        event = self.store.latest(session_id)
        session = self.open_session(event.snapshot)
        plan = session.plan
        assert plan is not None and plan.measurement is not None
        digests = self._measurement_digests(plan.measurement.paths)
        missing = sorted(plan.measurement.paths - set(digests))
        if missing:
            # Said as a measurement failure, never as an arm's.
            raise ValueError(
                "the measurement was not built: " + ", ".join(missing))
        # Issued here and nowhere else. A freeze is the event that gives a study
        # its instrument, so it is the only thing entitled to say which one.
        frozen = session.model_copy(update={"measurement_snapshot": MeasurementSnapshot(
            snapshot_id=uuid4().hex,
            # Counted from what has been retired rather than from the ruler in
            # force, because there is no ruler in force at this moment -- that
            # is what makes this a freeze.
            revision=len(session.superseded_measurements),
            artifact_digests=digests,
            verify_argv=list(plan.measurement.verify_argv),
            plan_revision=plan.revision,
            frozen_at=datetime.now(timezone.utc),
        )})
        self.store.append(frozen, "research.measurement_frozen", event.sequence)
        # Asked here because this is the first moment there is an instrument to
        # ask, and the last before an arm could be dispatched against it.
        self._probe_claims(session_id, frozen)
        return self.store.latest(session_id).snapshot

    def _measurement_still_stands(self, session: ResearchSession) -> None:
        """No arm runs before the ruler is frozen, or after it has moved.

        Two refusals with one cause. A design that owns its measurement may not
        dispatch until that measurement is materialised and frozen -- otherwise
        the first arm defines, by running, what every later arm is compared
        against. And once frozen, an artifact whose bytes have changed means the
        comparison is between readings taken on different instruments.

        The second is the same rule as `holdout_data_changed`, widened: the thing
        being measured must not write its own answer sheet, and neither may a
        person or another process between two arms.
        """
        plan = session.plan
        if plan is None or plan.measurement is None:
            return
        snapshot = session.measurement_snapshot
        if snapshot is None:
            raise ValueError(
                "the measurement is not frozen yet; materialise it before running arms")
        moved = snapshot.disagreement(self._measurement_digests(plan.measurement.paths))
        if moved:
            raise ValueError(
                "measurement changed after freeze: " + ", ".join(moved))

    def recorded_artifacts(self) -> dict[str, str]:
        """Measurement artifacts this workspace's own sessions created, by session.

        Only the ones a session *made*. A session that adopted the project's
        verifier did not put it there, so reporting it here would turn a
        project's own file into an experiment's leftover the first time anybody
        ran an experiment against it.

        Read from the recorded plans rather than from the filesystem: what is on
        disk cannot say who wrote it, and that is exactly the question.

        And only what was made. A plan that *declares* a file to create has not
        created it: a session stopped before its measurement was built -- a host
        that could not start `python3` -- left its declaration behind and no
        file, and the next planner, told these were "artifacts earlier sessions
        built", designed a study that reused two files that did not exist. So a
        path counts once a freeze recorded it, and while it is still here to be
        reused; the freeze is the record, the tree only says whether it is gone.
        """
        made: dict[str, str] = {}
        for session_id in self.store.session_ids():
            snapshot = self.store.latest(session_id).snapshot
            plan, frozen = snapshot.plan, snapshot.measurement_snapshot
            if plan is None or plan.measurement is None or frozen is None:
                continue
            for artifact in plan.measurement.artifacts:
                if (artifact.operation is ArtifactSource.CREATE
                        and artifact.path in frozen.artifact_digests
                        and self.workspace.joinpath(*artifact.path.split("/")).is_file()):
                    made.setdefault(artifact.path, session_id)
        return made

    def _measurement_digests(self, paths: set[str]) -> dict[str, str]:
        """Each owned artifact by digest, as the tree holds it now."""
        digests = {}
        for path in sorted(paths):
            where = self.workspace.joinpath(*path.split("/"))
            if where.is_file():
                digests[path] = hashlib.sha256(where.read_bytes()).hexdigest()
        return digests

    def _lay_the_ruler(self, session: ResearchSession, tree: Path) -> None:
        """Put the frozen measurement into a checkout that cannot have inherited it.

        A worktree holds only what its revision contains, and the measurement is
        materialised into the working tree after the plan is accepted -- so it is
        untracked, and an isolated attempt checks out without the very thing that
        was going to judge it. Every arm then fails with a missing verifier, which
        looks like the arm's fault and is nobody's.

        Copying rather than committing: a research workspace is the person's
        repository, and writing history into it to satisfy an implementation
        detail is not this layer's to do. The digest is checked on the way in, so
        what lands in each tree is the frozen ruler and provably not another one
        -- which is stronger than committing it would have been, because it is
        re-established at every dispatch rather than assumed from a revision.
        """
        plan = session.plan
        snapshot = session.measurement_snapshot
        if plan is None or plan.measurement is None or snapshot is None:
            return
        for path in sorted(plan.measurement.paths):
            source = self.workspace.joinpath(*path.split("/"))
            digest = hashlib.sha256(source.read_bytes()).hexdigest()
            if digest != snapshot.artifact_digests.get(path):
                # `_measurement_still_stands` says this before any arm runs. Saying
                # it again here covers the tree changing between two dispatches.
                raise ValueError(f"measurement changed after freeze: {path}")
            target = tree.joinpath(*path.split("/"))
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())

    def execute(
        self, session_id: str, gateway: ModelGateway | None = None, *,
        resolver: GatewayResolver | None = None, attempts_per_slot: int = 1,
        repair_context: bool = True, model_timeout_seconds: float = 60,
        timeout_seconds: float = 300, expected_session_sequence: int | None = None,
        parallel_arms: int = 1,
    ) -> ResearchSession:
        """Keep the declared policy stable through generation and final pin recording.

        A session that declared routing runs on the model it declared, resolved
        here, and the gateway a caller passed is not used whatever it is. One
        that declared none runs on the caller's gateway exactly as before.

        Refusing is the answer when a declaration cannot be carried out -- no
        resolver, no route for this role, a resolver that returned something
        else. A policy that could be bypassed by a caller without a resolver
        would be a wish with an audit log, and the refusal happens before any
        provider is called.
        """
        chosen, route = gateway_for(
            self.store.latest(session_id).snapshot, ModelRole.CODING,
            caller=gateway, resolver=resolver)
        del route  # recorded on the run by `generate_and_apply`, from the gateway
        gateway = chosen
        if expected_session_sequence is not None and (
            type(expected_session_sequence) is not int or expected_session_sequence < 1
        ):
            raise ValueError("expected session sequence must be a positive integer")
        self.store.latest(session_id)  # Missing IDs must not allocate a lock file.
        with session_execution_lock(self.workspace, session_id):
            return self._execute(
                session_id, gateway, attempts_per_slot=attempts_per_slot,
                repair_context=repair_context, model_timeout_seconds=model_timeout_seconds,
                timeout_seconds=timeout_seconds, parallel_arms=parallel_arms,
                expected_session_sequence=expected_session_sequence,
            )

    def _execute(
        self, session_id: str, gateway: ModelGateway, *, attempts_per_slot: int,
        repair_context: bool, model_timeout_seconds: float, timeout_seconds: float,
        expected_session_sequence: int | None = None, parallel_arms: int = 1,
    ) -> ResearchSession:
        """Drive the declared design's runs to usable evidence under a bounded budget.

        A run is never generated twice. An unusable attempt is replaced by a new run,
        so every attempt keeps its own evidence, and each arm may spend at most
        repeats_per_arm * attempts_per_slot runs in total.
        """
        if type(attempts_per_slot) is not int or not 1 <= attempts_per_slot <= 3:
            raise ValueError("attempts_per_slot must be an integer between 1 and 3")
        if type(parallel_arms) is not int or not 1 <= parallel_arms <= MAXIMUM_PARALLEL_ARMS:
            raise ValueError(
                f"parallel_arms must be an integer between 1 and {MAXIMUM_PARALLEL_ARMS}")
        event = self.store.latest(session_id)
        if expected_session_sequence is not None and event.sequence != expected_session_sequence:
            raise ValueError("research session changed; review status before executing")
        session = self.open_session(event.snapshot)
        plan = session.plan
        if plan is None or not plan.arms:
            raise ValueError("executing runs needs a plan that declares experiment arms")
        tasks = {task.arm: task for task in plan.arm_tasks}
        for arm in plan.arms:
            task = tasks.get(arm)
            if task is None or not task.targets or not task.verify_argv:
                raise ValueError(f"arm declares no executable task: {arm}")
        self._measurement_still_stands(session)
        budget = plan.repeats_per_arm * attempts_per_slot
        # Every attempt this call could dispatch. A created file outlives the
        # attempt that made it, so what matters is whether anything runs after it.
        isolate = plan.isolate_attempts or plan.must_isolate(len(plan.arms) * budget)
        # Presence is the instruction and the reason travels with it: a
        # restoration that happens without the record saying why is one a
        # person cannot tell from their code having been lost.
        restore = (RestoreReason.PLAN_RESTORES_EACH_ATTEMPT
                   if plan.restore_between_attempts else None)
        revision = None
        if isolate:
            revision = workspace_revision(self.workspace)
        if isolate and revision is None:
            if plan.isolate_attempts:
                # Asked for by name. Silently doing something else would be
                # answering a different question than the plan asked.
                raise ValueError("isolating attempts needs a Git revision to check out")
            # Derived, and the workspace has no commit to check out -- which is the
            # ordinary state of the empty directory this capability exists for.
            # Undoing each attempt reaches the same place a checkout would: the
            # next one starts where the last began. It is the weaker of the two,
            # so it is the fallback and not the default, and it is taken rather
            # than writing a commit into somebody's repository to enable the
            # other one.
            restore = restore or RestoreReason.ARMS_SHARE_ONE_TREE
        if parallel_arms > 1:
            if not isolate:
                # Without a checkout of its own, a second arm would edit the same tree.
                raise ValueError("running arms at once needs the plan to isolate attempts")
            if restore is not None:
                # Restoring undoes an edit in the workspace, which is nobody's alone.
                raise ValueError("restoration between attempts cannot run alongside another arm")
        coding = CodingRunService(self.workspace)
        sandbox = _sandbox_policy(plan)

        def drive(arm: str) -> None:
            self._execute_arm(session_id, coding, gateway, tasks[arm], budget,
                              model_timeout_seconds, timeout_seconds,
                              repair_context=repair_context, data_paths=list(plan.data_paths),
                              restore=restore, revision=revision,
                              sandbox=sandbox,
                              holdout_paths=list(plan.holdout_data_paths),
                              allowed_losses=plan.max_transport_failures_per_arm,
                              allowed_refusals=plan.max_generation_failures_per_arm)

        # Before the first arm, not only between them. The whole value of
        # asking a ruler what it checks is that it is asked before anything is
        # spent on being measured by it.
        stopped = self._claims_block_dispatch(session_id, coding)
        if not stopped.allowed:
            raise ValueError(
                f"the measurement does not cover this study: {stopped.reason}")
        if parallel_arms == 1:
            for arm in plan.arms:
                if not self._claims_block_dispatch(session_id, coding).allowed:
                    # A verifier that has now had its chance and still declares
                    # nothing stops the study here, for the same reason a broken
                    # instrument does: another arm cannot repair a ruler.
                    break
                if self._instrument_broke(session_id, coding):
                    # Checked between arms as well as inside one. The verifier
                    # is frozen and shared, so an arm that has not reached it
                    # yet is not better off -- it is next, and dispatching it
                    # would buy another implementation measured by the same
                    # broken file.
                    break
                drive(arm)
        else:
            _drive_together(plan.arms, drive, parallel_arms)
        return self.store.latest(session_id).snapshot

    def _instrument_broke(self, session_id: str, coding: CodingRunService) -> bool:
        """Whether this study's own measurement is what is stopping it."""
        event = self.store.latest(session_id)
        return measurement_blocker(arm_accounts(
            event.snapshot, self.readiness(session_id), coding.store.load)) is not None

    def _execute_arm(
        self, session_id: str, coding: CodingRunService, gateway: ModelGateway, task: ArmTask,
        budget: int, model_timeout_seconds: float, timeout_seconds: float,
        *, repair_context: bool, data_paths: list[str], restore: RestoreReason | None,
        revision: str | None, sandbox: SandboxPolicy | None, holdout_paths: list[str],
        allowed_losses: int, allowed_refusals: int,
    ) -> None:
        while True:
            readiness = self.readiness(session_id)
            covered = next(item for item in readiness.arms if item.arm == task.arm)
            observed(self.observe, OperationKind.MEASUREMENT,
                     MeasurementDetail(arm=covered.arm, usable=covered.usable,
                                       required=covered.required),
                     session_id=session_id)
            if covered.satisfied:
                return
            event = self.store.latest(session_id)
            session = self.open_session(event.snapshot)
            # One account, shared with the lifecycle, so a session cannot report
            # a budget the executor does not believe in.
            account = arm_accounts(session, readiness, coding.store.load)[task.arm]
            everything = account.standing
            if any(coding.store.load(ref.run_id).state == RunState.RUNNING
                   or self._blocked(coding, ref.run_id) for ref in everything):
                # Waiting is not a failed attempt, even if other runs are unstarted.
                return
            if account.unmeasurable:
                # The instrument, not the arm. Every arm is measured by the same
                # frozen file, so another attempt would be measured by the one
                # that just failed its contract -- and the arm has already done
                # its part. It costs no repeat, and it stops here rather than
                # spending the rest of the budget confirming it.
                return
            lost = account.lost
            if lost[IncidentKind.POLICY]:
                # Sending the same prompt again is a way of arguing with a policy
                # boundary. It stops, and says so, rather than retrying.
                raise ValueError(
                    f"arm {task.arm!r}: the provider's content filter stopped "
                    f"{len(lost[IncidentKind.POLICY])} repl(y/ies). That is not retried "
                    f"automatically; the design or the task needs a person")
            for kind, allowed, what in (
                (IncidentKind.TRANSIENT, allowed_losses, "lost to the provider"),
                (IncidentKind.MODEL_OUTCOME, allowed_refusals,
                 "answered without proposing anything"),
            ):
                if len(lost[kind]) > allowed:
                    # Said as what it is. "The arm failed" would be a claim about
                    # the experiment, and nothing about it has been observed.
                    raise ValueError(
                        f"arm {task.arm!r} had {len(lost[kind])} provider call(s) {what}, "
                        f"past the {allowed} allowed; the design is untouched and nothing "
                        f"about it has been learned")
            # By run id: a reference is a record, not a key, and building a set of
            # them is the same mistake `EditTarget` produced earlier.
            gone = {ref.run_id for group in lost.values() for ref in group}
            attached = [ref for ref in everything if ref.run_id not in gone]
            # Attachment order defines the eligible attempts, including imported runs.
            # This also bounds dispatch when more CREATED runs were attached manually.
            eligible = attached[:budget]
            installed = [ref for ref in eligible
                         if coding.store.load(ref.run_id).state == RunState.DEPENDENCY_INSTALLED]
            if installed:
                # Continuing an approved installation finishes an attempt already counted.
                self._resume(session_id, coding, installed[0], task, timeout_seconds,
                             data_paths, sandbox=sandbox, restore=restore,
                             revision=revision, holdout_paths=holdout_paths)
                continue
            unstarted = [ref for ref in eligible
                         if coding.store.load(ref.run_id).state == RunState.CREATED]
            if not unstarted:
                if len(attached) >= budget:
                    return
                objective = task.objective
                failed = _repairs(covered) if repair_context else None
                repair = None
                if failed is not None:
                    objective = self._repair_objective(
                        coding, task.objective, session_id, task.arm, covered)
                    repair = _repair_provenance(coding, failed)
                self._request_attempt(session_id, task.arm, objective, repair)
                self.fulfil_requests(session_id)
                continue
            reference = unstarted[0]
            lost_this_call = False
            try:
                self._dispatch(coding, reference.run_id, task, gateway, revision,
                               data_paths=data_paths, sandbox=sandbox,
                               model_timeout_seconds=model_timeout_seconds,
                               timeout_seconds=timeout_seconds, session_id=session_id,
                               holdout_paths=holdout_paths)
            except ModelTransportError:
                # The call produced nothing to measure. Generation has already
                # recorded which incident it was, and the top of this loop decides
                # whether the arm may try again -- by kind, against a budget of its
                # own, and refusing a policy boundary outright. Letting this
                # propagate instead would abandon an arm on one dropped
                # connection, which is neither a research result nor a decision
                # anybody made.
                lost_this_call = True
            finally:
                # The pin must show what actually happened, including a failed attempt.
                self.refresh(session_id, reference.run_id,
                             expected_run_sequence=reference.event_sequence)
            if lost_this_call:
                continue
            if revision is None:
                self._finish_local_attempt(session_id, coding, reference.run_id, task,
                                           timeout_seconds, sandbox=sandbox, restore=restore)

    def _finish_local_attempt(
        self, session_id: str, coding: CodingRunService, run_id: str, task: ArmTask,
        timeout_seconds: float, *, sandbox: SandboxPolicy | None,
        restore: RestoreReason | None,
    ) -> None:
        if coding.store.load(run_id).state != RunState.COMPLETED:
            return
        try:
            if task.holdout_argv:
                coding.measure_holdout(run_id, list(task.holdout_argv),
                                       timeout_seconds=timeout_seconds, sandbox=sandbox)
            if restore is not None:
                coding.restore(run_id, restore)
        finally:
            # Include interrupted measurements; never restore after a raised measurement.
            self._advance_pin(session_id, run_id)

    def _resume(
        self, session_id: str, coding: CodingRunService, reference: CodingRunReference,
        task: ArmTask, timeout_seconds: float, data_paths: list[str],
        *, sandbox: SandboxPolicy | None, restore: RestoreReason | None, revision: str | None,
        holdout_paths: list[str],
    ) -> None:
        """Continue a stored dependency patch with the arm's declared verifier.

        An isolated continuation happens in its own checkout, like the attempt it
        continues, and therefore leaves the workspace alone and needs no restoring.
        """
        try:
            if revision is None:
                coding.resume_dependency(reference.run_id, verify_argv=list(task.verify_argv),
                                         timeout_seconds=timeout_seconds, data_paths=data_paths,
                                         sandbox=sandbox, holdout_paths=holdout_paths)
            else:
                self._resume_isolated(coding, reference.run_id, task, revision,
                                      data_paths=data_paths, timeout_seconds=timeout_seconds,
                                      sandbox=sandbox, session_id=session_id,
                                      holdout_paths=holdout_paths)
        finally:
            # The pin must show the resume outcome, including a failed verification.
            self.refresh(session_id, reference.run_id,
                         expected_run_sequence=reference.event_sequence)
        if revision is None:
            self._finish_local_attempt(session_id, coding, reference.run_id, task,
                                       timeout_seconds, sandbox=sandbox, restore=restore)

    def _resume_isolated(
        self, coding: CodingRunService, run_id: str, task: ArmTask, revision: str, *,
        data_paths: list[str], timeout_seconds: float, sandbox: SandboxPolicy | None,
        session_id: str, holdout_paths: list[str],
    ) -> None:
        """Apply the stored diff and measure it inside one checkout of the revision."""
        with isolated_worktree(self.workspace, revision,
                               owner=run_id, session=session_id) as tree:
            self._lay_the_ruler(self.open_session(self.store.latest(session_id).snapshot), tree)
            run = coding.resume_dependency(
                run_id, verify_argv=list(task.verify_argv), timeout_seconds=timeout_seconds,
                data_paths=data_paths, execution_root=tree, sandbox=sandbox,
                holdout_paths=holdout_paths)
            if run.state == RunState.COMPLETED and task.holdout_argv:
                # Keep the continued checkout alive until the claimed measurement ends.
                coding.measure_holdout(run_id, list(task.holdout_argv),
                                       timeout_seconds=timeout_seconds, sandbox=sandbox,
                                       execution_root=tree)

    def _request_attempt(
        self, session_id: str, arm: str, objective: str,
        repair: RepairProvenance | None = None,
    ) -> None:
        """Record one more attempt for this arm against the session as it stands now."""
        with self._writes:
            event = self.store.latest(session_id)
            session = self.open_session(event.snapshot)
            self.store.append(session.model_copy(update={"requests": [
                *session.requests, *self._requests(session, arm, objective, 1, repair),
            ]}), "research.tasks_requested", event.sequence)

    def _dispatch(
        self, coding: CodingRunService, run_id: str, task: ArmTask, gateway: ModelGateway,
        revision: str | None, *, data_paths: list[str], model_timeout_seconds: float,
        timeout_seconds: float, sandbox: SandboxPolicy | None, session_id: str,
        holdout_paths: list[str],
    ) -> None:
        """Run one attempt, in its own checkout when the plan isolates attempts."""
        # Which ruler this reading will be taken under, read now rather than
        # recorded afterwards: the session cannot say later which instrument was
        # in force at a moment that has passed.
        ruler = self._current_ruler(session_id)
        if revision is None:
            coding.generate_and_apply(
                run_id, list(task.targets), gateway, verify_argv=list(task.verify_argv),
                model_timeout_seconds=model_timeout_seconds, timeout_seconds=timeout_seconds,
                data_paths=data_paths, sandbox=sandbox, holdout_paths=holdout_paths,
                measurement_snapshot_id=ruler)
            return
        with isolated_worktree(self.workspace, revision,
                               owner=run_id, session=session_id) as tree:
            self._lay_the_ruler(self.open_session(self.store.latest(session_id).snapshot), tree)
            run = coding.generate_and_apply(
                run_id, list(task.targets), gateway, verify_argv=list(task.verify_argv),
                model_timeout_seconds=model_timeout_seconds, timeout_seconds=timeout_seconds,
                data_paths=data_paths, execution_root=tree, sandbox=sandbox,
                holdout_paths=holdout_paths, measurement_snapshot_id=ruler)
            if run.state == RunState.COMPLETED and task.holdout_argv:
                # Keep the verified checkout alive until the claimed measurement ends.
                # The caller refreshes the pin even if measurement or cleanup raises.
                coding.measure_holdout(run_id, list(task.holdout_argv),
                                       timeout_seconds=timeout_seconds, sandbox=sandbox,
                                       execution_root=tree)

    def _current_ruler(self, session_id: str) -> str | None:
        """The identity of the frozen measurement in force, if this study has one.

        None for a study measured by a verifier it adopted rather than one it
        owns: there is no freeze, so there is no identity, and inventing one
        would make an adopted instrument look versioned.
        """
        snapshot = self.store.latest(session_id).snapshot.measurement_snapshot
        return None if snapshot is None else snapshot.snapshot_id

    def _advance_pin(self, session_id: str, run_id: str) -> None:
        """Follow a run that advanced past its pin, so the session stays consistent."""
        with self._writes:
            current = [ref for ref in self.store.latest(session_id).snapshot.runs
                       if ref.run_id == run_id]
            if len(current) == 1:
                self._refresh_locked(session_id, run_id, current[0].event_sequence)

    @staticmethod
    def _blocked(coding: CodingRunService, run_id: str) -> bool:
        gate = coding.store.load(run_id).human_gate
        return gate is not None and not gate.resolved

    @staticmethod
    def _repair_objective(
        coding: CodingRunService, objective: str, session_id: str, arm: str,
        covered: ResearchArmReadiness,
    ) -> str:
        """Describe the last attempt, and whether this failure keeps happening.

        The last attempt alone was never enough: a third attempt could repeat the
        first one's mistake with nothing to say it had already failed that way.
        """
        previous = covered.runs[-1]
        run = coding.store.load(previous.run_id)
        note = [f"The previous attempt ({previous.run_id}) produced no usable evidence.",
                f"Reason: {previous.reason}"]
        evidence = run.patch_evidence
        verification = evidence.verification if evidence is not None else None
        if verification is not None:
            timing = " after timing out" if verification.timed_out else ""
            note.append(f"Verifier {' '.join(verification.argv)} "
                        f"exited {verification.exit_code}{timing}.")
            for name, text in (("stdout", verification.stdout), ("stderr", verification.stderr)):
                tail = text[-OUTPUT_TAIL_CHARACTERS:].strip()
                if tail:
                    note.append(f"Last verifier {name}:\n{tail}")
        elif run.execution_error is not None:
            note.append(f"Recorded error: {run.execution_error}")
        snapshots = {item.run_id: coding.store.load(item.run_id) for item in covered.runs}
        note.extend(_repeated_failure(
            repair_history(session_id, arm, covered.runs, snapshots)))
        body = "\n".join(note)[:REPAIR_NOTE_CHARACTERS]
        return f"{objective}\n\n{body}"

    def evaluate_holdout(self, session_id: str) -> ResearchSessionHoldout:
        """Apply the declared holdout rules to the evidence selection already chose.

        The first evaluation is recorded, so a later look can say whether the
        evidence changed after the holdout had already been seen.
        """
        event, plan, pinned = self._design(session_id, None)
        registry = plan.holdout_registry
        if registry is None:
            raise ValueError("no holdout rules are declared in the selected session snapshot")
        if plan.candidate_arm is None or plan.baseline_arm is None:
            raise ValueError("a holdout needs the plan's designated comparison arms")
        readiness = assess_readiness(session_id, event.sequence, plan, pinned)
        if not readiness.ready:
            raise ValueError("evaluate a holdout only on a covered design")
        events = {item.run_id: item for _, item in pinned}
        judged = [run.run_id for arm in readiness.arms for run in arm.runs if run.usable]
        contaminated = sorted(
            run_id for run_id in judged
            if _altered_holdout_data(events[run_id].snapshot.conditions))
        if contaminated:
            # The attempt altered the data it is about to be measured on. No reading
            # of that measurement means anything, so none is produced.
            raise ValueError(
                "held-out data was altered by the attempts being measured: "
                + ", ".join(contaminated)
            )
        # A declared holdout command means the held-out numbers come from its own
        # measurement; without one, the rules are held out but the output is shared.
        separate = any(task.holdout_argv for task in plan.arm_tasks)
        extract = extract_holdout_metrics if separate else extract_coding_metrics
        samples = {arm.arm: [extract(events[run.run_id])
                             for run in arm.runs if run.usable] for arm in readiness.arms}
        comparisons, unpaired = paired_comparisons(plan, samples, registry)
        record = event.snapshot.holdout
        if record is None:
            record = HoldoutRecord(event_sequence=event.sequence,
                                   pins=list(event.snapshot.runs))
            self.store.append(event.snapshot.model_copy(update={"holdout": record}),
                              "research.holdout_evaluated", event.sequence)
        changed = list(event.snapshot.runs) != list(record.pins)
        passed = bool(comparisons) and all(item.passed for item in comparisons) and not changed
        return ResearchSessionHoldout(
            session_id=session_id, event_sequence=event.sequence, registry=registry,
            source="holdout.stdout" if separate else "verification.stdout",
            comparisons=comparisons, unpaired_run_ids=unpaired,
            first_event_sequence=record.event_sequence,
            evidence_changed_since_first_look=changed, passed=passed,
            reason=_holdout_reason(comparisons, changed),
        )

    def conclude(
        self, session_id: str, decision: ResearchDecision, rationale: str,
    ) -> ResearchSession:
        """Bind one terminal decision to the assessment of the evidence pinned now."""
        # The repository idiom rejects look-alike inputs as invalid values, not type errors.
        if type(decision) is not ResearchDecision:
            raise ValueError("decision must be a recorded research decision")
        if not rationale.strip():
            raise ValueError("a research conclusion requires a nonblank rationale")
        event = self.store.latest(session_id)
        session = self.open_session(event.snapshot)
        assessment = None
        if decision is not ResearchDecision.ABANDONED:
            assessment = self.assess(session_id, event_sequence=event.sequence)
            if decision is ResearchDecision.ACCEPTED and not assessment.passed:
                raise ValueError(
                    f"acceptance requires a passing plan assessment: {assessment.reason}"
                )
            if (decision is ResearchDecision.INCONCLUSIVE
                    and not (assessment.passed and assessment.decision_support
                             is DecisionSupport.INCONCLUSIVE)):
                # "The study ran and decided nothing" is a claim about the
                # evidence, like acceptance, and it is gated like acceptance.
                # Two decisions here are claims and two are choices:
                #
                #     ACCEPTED       the evidence says the candidate is better
                #     INCONCLUSIVE   the evidence says neither
                #     REJECTED       a person is not adopting this candidate
                #     ABANDONED      a person is not continuing
                #
                # Recording "no difference" where the comparison did not pass,
                # where the spread exceeded its tolerance, or where nothing was
                # measured at all, says the study answered a question it never
                # asked properly. `ABANDONED` is the word for those.
                raise ValueError(
                    "recording no conclusion requires a covered design whose evidence "
                    "decides neither way: " + (assessment.support_reason
                                               or assessment.reason))
            if (decision is ResearchDecision.ACCEPTED
                    and assessment.decision_support
                    is not DecisionSupport.SUPPORTS_ACCEPTANCE):
                # Rules holding and evidence supporting a claim are different
                # things, and a live session held the first without the second:
                # ten admissible readings in which the deciding metric never
                # varied, because the verifier's only check was that the module
                # imported and both arms import.
                #
                # This refuses the claim, not the person. Rejecting or
                # abandoning stays available, and so does changing the study --
                # what is not available is recording "the candidate is better"
                # on evidence that could not have said otherwise.
                raise ValueError(
                    "acceptance requires evidence that supports it: "
                    + assessment.support_reason)
        if decision is ResearchDecision.ACCEPTED:
            moved = self.moved_goalposts(session_id)
            if moved:
                # Declaring success under rules changed after the results were in
                # hand is the one thing pre-registration exists to prevent.
                raise ValueError(
                    "acceptance requires rules that were not changed once results "
                    "existed; amended after results: "
                    + "; ".join(f"revision {item[0]} changed {', '.join(item[1])}"
                                for item in moved)
                )
            self._holdout_looked_at(session_id, session)
        updated = session.model_copy(update={"conclusion": ResearchConclusion(
            decision=decision, rationale=rationale, event_sequence=event.sequence,
            assessment=assessment,
            limitations=[] if assessment is None else self._too_few_runs(session, assessment),
        )})
        self.store.append(updated, "research.concluded", event.sequence)
        # What the study supports, negative results included, drafted for a
        # person to confirm (M6.3). A draft not made is one made by hand later
        # with `relab memory propose`: never a reason to undo the conclusion.
        try:
            from relab_app.memory_pending import PendingFindings

            PendingFindings(self.workspace).propose(session_id)
        except (OSError, ValueError, LookupError):
            pass
        return updated

    def moved_goalposts(self, session_id: str) -> list[tuple[int, list[str]]]:
        """Amendments that changed what counts as success, once results existed.

        Read from the history itself, plan by plan, so an amendment cannot be
        missed by pairing two lists of different lengths.
        """
        moved: list[tuple[int, list[str]]] = []
        previous: ResearchPlan | None = None
        for event in self.store.events(session_id):
            plan = event.snapshot.plan
            if event.kind == "research.plan_revised" and previous is not None and plan is not None:
                fields = moved_goalposts(previous, plan)
                if fields and any(self._had_results(ref) for ref in event.snapshot.runs):
                    moved.append((plan.revision, fields))
            if plan is not None:
                previous = plan
        return moved

    def _had_results(self, reference: CodingRunReference) -> bool:
        """What the session had seen at that pin, not what the run became later."""
        pinned = [item for item in self.runs.events(reference.run_id)
                  if item.sequence == reference.event_sequence]
        return bool(pinned) and produced_results(pinned[0].snapshot)

    def _holdout_looked_at(self, session_id: str, session: ResearchSession) -> None:
        """Declared holdout rules must have been looked at before success is claimed.

        Only looked at. What the held-out reading means is the person's to weigh and
        to write in the rationale -- the holdout reports, it does not overrule
        selection, and that stays true. What it may not do is go unopened, which
        would make declaring it decorative.

        The look is deliberately not taken here either. Concluding must not be the
        act that first opens the holdout, or the recorded moment of the first look
        would be a moment when the decision was already made.
        """
        plan = session.plan
        if plan is None or plan.holdout_registry is None:
            return
        if session.holdout is None:
            raise ValueError(
                "acceptance under declared holdout rules requires the holdout to have "
                f"been evaluated first: relab session holdout {session_id}"
            )

    def _design(
        self, session_id: str, event_sequence: int | None,
    ) -> tuple[ResearchSessionEvent, ResearchPlan, list[tuple[CodingRunReference, RunEvent]]]:
        event = self._event(session_id, event_sequence=event_sequence)
        plan = event.snapshot.plan
        if plan is None:
            raise ValueError("no research plan recorded in the selected session snapshot")
        pinned = [(ref, self._pinned(ref.run_id, ref.event_sequence))
                  for ref in event.snapshot.runs]
        return event, plan, [
            (ref, found) for ref, found in pinned
            if attempt_stands(
                event.snapshot, ref,
                None if found.snapshot.patch_evidence is None
                else found.snapshot.patch_evidence.verification)
        ]

    def review(
        self, session_id: str, *, event_sequence: int | None = None,
    ) -> ResearchSessionReview:
        event = self._event(session_id, event_sequence=event_sequence)
        evaluations = []
        for ref in event.snapshot.runs:
            matches = [item for item in self.runs.events(ref.run_id)
                       if item.sequence == ref.event_sequence]
            if len(matches) != 1:
                raise ValueError("pinned coding event unavailable; inspect session history")
            evaluations.append(evaluate_coding(matches[0]))
        return ResearchSessionReview(
            session=event.snapshot, event_sequence=event.sequence, evaluations=evaluations,
        )


def _drive_together(arms: list[str], drive: Callable[[str], None], workers: int) -> None:
    """Run the arms at once, then raise the first failure in declared order.

    An arm already running cannot be called back, so one failing no longer stops
    the others: each finishes and records its own evidence, and the first error in
    the plan's arm order is what the caller is told about.
    """
    with ThreadPoolExecutor(max_workers=min(workers, len(arms)),
                            thread_name_prefix="relab-arm") as pool:
        futures = [pool.submit(drive, arm) for arm in arms]
    for future in futures:
        error = future.exception()
        if error is not None:
            raise error


def _altered_holdout_data(conditions: RunConditions | None) -> bool:
    """A run with no recorded conditions altered nothing it can be blamed for here."""
    return conditions is not None and bool(conditions.holdout_data_changed)


def _holdout_reason(comparisons: list[MetricComparison], changed: bool) -> str:
    if changed:
        return ("the pinned evidence changed after the holdout had already been seen; "
                "this is no longer a holdout for that evidence")
    if not comparisons:
        return "no usable pair of runs was available to judge"
    if all(item.passed for item in comparisons):
        return "the held-out rules held on the evidence selection chose"
    return "a held-out rule did not hold on the evidence selection chose"


def _with_requirements(objective: str, plan: ResearchPlan | None) -> str:
    """An arm's objective, with what the study will measure it against.

    The coding model is shown its objective and its target file, and nothing
    else. A live arm was asked to "provide a simple, clear addition that meets
    the specification" and was never shown the specification, so it invented
    one and wrote a semantic-version class. The study's declared requirements
    are the specification the arms are judged by; they are the plan's own
    sentences and say nothing of how the verifier checks them, so telling the
    arm them keeps it independent of the ruler while telling it what to build.
    """
    requirements = [] if plan is None else plan.measurement_requirements or []
    if not requirements or not objective.strip():
        return objective
    stated = "\n".join(f"- {item.requirement_id}: {item.statement}" for item in requirements)
    return (f"{objective}\n\nThe implementation is measured against these requirements:\n"
            f"{stated}")


def _refuse_unready_runtime(plan: ResearchPlan) -> None:
    """Stop here if this host could not start the measurement's interpreter.

    Only for a command that runs a measurement-owned `.py` directly with a
    Python interpreter; anything else is not asked, rather than asked the wrong
    question. The sentence says what was observed and stops there.
    """
    if plan.measurement is None:
        return
    argv = list(plan.measurement.verify_argv)
    asked = python_readiness_argv(argv, plan.measurement.paths)
    if asked is None:
        return
    readiness, exit_code = probe_runtime(asked, sandbox_policy=_sandbox_policy(plan))
    if readiness is RuntimeReadiness.READY:
        return
    how = {
        RuntimeReadiness.START_FAILED: "it did not start",
        RuntimeReadiness.NONZERO_EXIT: f"it exited {exit_code}",
        RuntimeReadiness.TIMED_OUT: "it did not finish in time",
    }[readiness]
    # What would work instead, when one of the usual names does: a refusal
    # that says only what failed leaves a person to find the other name.
    works = host_python_command()
    remedy = ("" if works is None or works == argv[0] else
              f"; on this host Python starts as `{works}`, so ask for the design again "
              f"(new designs are told to use it) or make `{argv[0]}` available")
    raise ValueError(
        f"measurement runtime is unavailable on this host: {argv[0]} could not "
        f"execute a Python readiness probe ({how}){remedy}")


def _sandbox_policy(plan: ResearchPlan) -> SandboxPolicy | None:
    """Build the declared environment through the one place policies are made."""
    if plan.sandbox_backend is None:
        return None
    return build_verification_policy(plan.sandbox_backend, plan.docker_image)


def _repeated_failure(history: RepairHistory) -> list[str]:
    """Say when this exact failure has happened before, and how often.

    One note, not two. A second sentence gated on a higher count would never be
    reached in the ordinary case: one repeat per arm and three attempts per slot
    is three failures, and the fourth attempt that would carry it never runs. A
    threshold nothing can reach is worse than no threshold, because it reads like
    a safeguard.

    `RepairHistory.stuck_on` keeps the higher bar for the question it actually
    answers -- telling a *person* an arm is not working -- which is not the same
    question as what to tell the next attempt.

    Only the repeat is reported, not every past attempt. Listing everything tried
    would crowd out the failure itself inside the same bound.
    """
    latest = history.attempts[-1] if history.attempts else None
    if latest is None or latest.fingerprint is None:
        return []
    same = history.matching(latest.fingerprint.digest)
    if len(same) < 2:
        return []
    earlier = ", ".join(item.run_id for item in same[:-1])
    return [(f"This same failure has now occurred {len(same)} times "
             f"(earlier: {earlier}). Repeating the same approach will not change it: "
             f"try something materially different, or say plainly that this cannot "
             f"be done as asked.")]


_SUPPORTING_ROLES = {
    MeasurementKind.FIXTURE: "reusable setup or helper code the verifier uses",
    MeasurementKind.REFERENCE_DATA:
        "the static cases and expected values the verifier checks against",
}


def _measurement_bundle_objective(
    plan: ResearchPlan, created: list[MeasurementArtifact],
) -> str:
    """What the model is asked for when building the ruler rather than the thing.

    Said explicitly because the same pipeline builds both, and a model given an
    experiment's objective will helpfully implement the solution it is supposed
    to be judging.

    One objective for every file the measurement creates, because they are
    written in one reply and have to agree. Each is told its role, and only the
    verifier is given the verifier's duties: the first live pilot asked its
    reference data to print METRIC lines and claim requirements, which is the
    same instruction as the verifier's and invited the same file twice. The
    roles are what `MeasurementKind` already recorded and generation ignored.

    Files the measurement adopts are named with their role and not written.
    Their content is not shown, so a verifier written against one knows its path
    and not its interface -- a limitation, and the next thing to close if a live
    run shows it mattering.

    The reporting half is stated because a live session showed what "print a
    METRIC line" alone permits. The verifier ran `pytest` over a directory
    holding no test file, was told "no tests ran", printed `pass_rate=0.000000`
    and exited zero -- and ended with a comment explaining that exiting zero
    meant the verifier had run, not that anything had passed. It had satisfied
    every word it was given. What it was never asked for was evidence that a
    measurement had happened, so this asks, and the application refuses a
    measurement of its own that does not answer.

    Nothing checks that the verifier actually uses the files beside it. Import,
    `open`, `runpy`, a subprocess and a computed path are all ways to, and a
    static rule over any of them would refuse honest verifiers and pass
    dishonest ones. What this guarantees is that the relationship was stated to
    one call that wrote both sides of it.
    """
    measurement = plan.measurement
    if measurement is None:
        return ", ".join(item.path for item in created)
    writing = {item.path for item in created}
    arms = ", ".join(sorted(plan.arms))
    subjects = sorted({target.path for task in plan.arm_tasks for target in task.targets})
    verifier = next(item for item in measurement.artifacts
                    if item.kind is MeasurementKind.VERIFIER)
    supporting = [item for item in measurement.artifacts
                  if item.kind is not MeasurementKind.VERIFIER]
    roles = []
    for item in [verifier, *supporting]:
        state = ("write it now" if item.path in writing
                 else "already present; do not write it")
        duty = (
            "the only file that prints METRIC lines, writes the verification "
            "report and claims requirements"
            if item.kind is MeasurementKind.VERIFIER
            else f"{_SUPPORTING_ROLES[item.kind]}. It prints no METRIC line, writes "
                 f"no verification report and claims no requirement")
        roles.append(f"{item.kind.value.upper()} {item.path} ({state}): {duty}. ")
    said = (
        f"Write the measurement for this experiment: {', '.join(sorted(writing))}. "
        f"It must measure the declared behaviour independently of every arm "
        f"({arms}), and must not implement or repair any arm's solution. "
        f"It is run as: {' '.join(measurement.verify_argv)}. "
        f"The measurement is made of these files: " + "".join(roles)
    )
    if supporting:
        said += (
            "The verifier must use the supporting files above for what they hold, "
            "and must not restate their contents inline. ")
    if verifier.path not in writing:
        # A verifier adopted as it stands already has its duties, and the files
        # written here cannot take them on for it.
        return said + ("The verifier is not written here and runs as it stands; "
                       "the files written here must serve it.")
    return said + _verifier_contract(plan, subjects)


def _interface_it_calls(plan: ResearchPlan) -> str:
    """The interface every arm is asked to build, which is what the verifier calls.

    The verifier was told the requirements and never the arm objectives, which
    are where the interface is named. A live one invented its own: it called
    `predict(input)` while every arm and both control subjects defined
    `check_pair(image_bytes, ocr_text)`, so every check failed for every
    implementation and the study measured nothing. The objectives are given for
    the interface they name; how an arm means to meet them stays the arm's.
    """
    asked = [f"{task.arm}: {task.objective}" for task in plan.arm_tasks]
    if not asked:
        return ""
    return ("call exactly the modules, functions or classes and signatures the "
            "arms are asked to build, as their objectives name them -- "
            + " | ".join(asked)
            + " -- and nothing else; the verifier does not decide the interface, and "
              "takes from these only what is called, never how an arm meets it. It must ")


def _verifier_contract(plan: ResearchPlan, subjects: list[str]) -> str:
    """The verifier's duties, which no other measurement file shares."""
    return (
        f"The verifier must print each measured value as a line 'METRIC <name>=<value>' for "
        f"these rules: {', '.join(rule.name for rule in plan.registry.rules)}. "
        f"It must exercise the artifact under test ({', '.join(subjects)}) and "
        f"{_interface_it_calls(plan)}"
        f"execute at least one check of it; a run that executes no check is not a "
        f"measurement and its result is discarded. A broken implementation is still "
        f"measured: if the artifact under test is missing, cannot be imported, or lacks "
        f"a function or class a check calls, every such check is executed and counted "
        f"as failed -- never skipped, and never reported as zero executed checks. "
        f"It must also write a JSON report to the path in the environment variable "
        f"AUTOCODE_VERIFY_REPORT, of the form "
        f'{{"executed_checks": <count>, "subjects": [{{"path": "<path>", '
        f'"digest": "<sha256 of that file as bytes>"}}]}}, naming every artifact '
        f"under test that it measured. Each path is relative to the workspace root "
        f"and written with forward slashes, exactly as it is named above. Evidence "
        f"from a run without this report is not admitted. "
        + _claim_contract(plan)
    )


def _claim_contract(plan: ResearchPlan) -> str:
    """What the verifier must say about its own coverage, and when.

    "Before any check" would be the obvious wording and it is the wrong one.
    What has to be impossible is a verifier that runs, sees how it went, and
    then decides what it will claim to have covered -- so the rule is about
    what it may have *seen*, not about where in the file the write happens.

    A claim is about intended coverage. A requirement whose check fails is
    still a requirement this verifier claims to exercise: the failing is the
    measurement's answer, and folding it back into the claim would merge this
    axis with the outcome it exists to be read beside.

    Where the write happens did turn out to matter, for a different reason:
    the claim probe runs the ruler with no subject under test at all. A live
    verifier checked that `calculator.py` existed before declaring anything,
    stopped, and the probe heard nothing -- a reasonable reading of "before any
    check whose result depends on the implementation", since whether the file
    exists is one. So the boundary is drawn mechanically, at the first touch of
    a subject path, and the report is named as written twice: a declaration
    the probe can read, and the final report that keeps it unchanged.
    """
    requirements = plan.measurement_requirements
    if not requirements:
        return ""
    named = ", ".join(
        f'{item.requirement_id} ({item.statement})' for item in requirements)
    return (
        "The same report must carry \"claimed_requirements\": a list of the "
        "requirement identifiers this verifier is built to exercise, from "
        f"these: {named}. At startup, before checking whether any artifact under "
        "test exists and before statting, opening, reading, importing, hashing "
        "or otherwise inspecting any path under test, write the report with "
        "claimed_requirements alone. The artifact under test may be absent when "
        "the verifier is run to read this declaration, and the declaration must "
        "still be written. After the checks run, write the same report again "
        "with executed_checks and subjects, keeping claimed_requirements "
        "unchanged. What it claims must not depend on the implementation under "
        "test: it states what this verifier examines, not what happened when it "
        "did. A requirement whose check fails is still claimed. Claim only what "
        "this verifier actually exercises."
    )



def _declared_digest(plan: ResearchPlan | None, arm: str | None) -> str | None:
    """What this arm is being asked to do right now, as an identity.

    None when there is no plan, no role, or no task for it: there is nothing for
    a later revision to have changed, so nothing to record.
    """
    if plan is None or arm is None:
        return None
    declared = next((item for item in plan.arm_tasks if item.arm == arm), None)
    return None if declared is None else task_digest(declared)


def _repairs(covered: ResearchArmReadiness) -> "ResearchRunReadiness | None":
    """The attempt a replacement would be repairing, or None when nothing failed.

    Only the last run, and only if it failed. A successful repeat followed by
    another is the design asking for independent measurements, not a repair, and
    the two must not be confused:

        repeat 1 usable, repeat 2 requested   -> the design wants three readings
        repeat 1 failed, repeat 2 requested   -> the second is repairing the first

    Before this asked, the branch fired on `covered.runs` being non-empty. With
    two successful repeats that produced a replacement objective beginning "The
    previous attempt produced no usable evidence" -- said about a run that was
    perfectly usable, and read by a model as an instruction to fix something that
    worked. A repair note is evidence about a failure; attaching one to a success
    is not a smaller version of that, it is a false statement.
    """
    if not covered.runs:
        return None
    last = covered.runs[-1]
    return None if last.usable else last


def _repair_provenance(
    coding: CodingRunService, failed: ResearchRunReadiness,
) -> RepairProvenance:
    """Pin which attempt this one repairs, and what went wrong with it."""
    run = coding.store.load(failed.run_id)
    evidence = run.patch_evidence
    verification = evidence.verification if evidence is not None else None
    return RepairProvenance(
        source_run_id=failed.run_id,
        source_event_sequence=failed.event_sequence,
        # Nothing to fingerprint when the attempt never reached its verifier.
        failure_digest=None if verification is None else fingerprint(verification).digest,
    )


def _with_metrics(done: MeasurementControlRun) -> MeasurementControlRun:
    """Read what the ruler printed, here where the one metric parser lives.

    The runner does not do this: it may not reach the parser, and a second copy
    of it down there would be a second answer to "what number did this print".
    """
    return done.model_copy(update={
        "good": _read(done.good), "bad": _read(done.bad)})


def _read(reading: ControlReading) -> ControlReading:
    try:
        metrics = parse_metrics(reading.verification.stdout)
    except MetricParseError:
        # A ruler that printed something unreadable said something about
        # itself. Kept as a limitation rather than raised: a calibration must
        # never be able to end a study.
        return reading.model_copy(update={"limitations": [
            *reading.limitations,
            "the ruler printed no readable metric for this subject"]})
    if not metrics:
        return reading.model_copy(update={"limitations": [
            *reading.limitations, "the ruler printed no metric for this subject"]})
    return reading.model_copy(update={"metrics": metrics})
