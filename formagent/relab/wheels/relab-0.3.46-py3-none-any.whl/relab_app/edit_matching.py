"""Finding the passage an edit means when the model quoted it not quite exactly.

An edit replaces a passage found exactly once. A model that quotes it with
other indentation, or trailing spaces the file does not have, gets "found 0
times" and reads the file again to try once more -- a call spent on
whitespace. So, when the exact passage is not there:

    tolerant_span   the one place whose lines equal the quoted ones once
                    leading and trailing whitespace is set aside; the
                    replacement is re-indented by the difference
    nearest         otherwise the most similar passage and its lines, to be
                    quoted exactly next time
    occurrences     and when a passage is there more than once, the lines it
                    starts on, to quote more around the one meant

Only a unique match is applied; anything else is said back, and nothing is
written. Text here uses "\\n" line endings.
"""

import difflib

# Beyond this many lines a file is not searched for the nearest passage: the
# search compares every window, and a hint is not worth seconds.
NEAREST_LINES = 5000
NEAREST_RATIO = 0.5


def _lines(text: str) -> list[str]:
    return text.split("\n")


def _indent(line: str) -> str:
    return line[:len(line) - len(line.lstrip())]


def tolerant_span(text: str, old: str, new: str) -> tuple[int, int, str] | None:
    """The one passage matching `old` but for whitespace at line ends, and the re-indented `new`."""
    old_lines = _lines(old)
    if old.endswith("\n"):
        old_lines = old_lines[:-1]
    wanted = [line.strip() for line in old_lines]
    if not any(wanted):
        return None
    lines = _lines(text)
    found = [start for start in range(len(lines) - len(wanted) + 1)
             if all(lines[start + offset].strip() == want for offset, want in enumerate(wanted))]
    if len(found) != 1:
        return None
    start = found[0]
    begin = sum(len(line) + 1 for line in lines[:start])
    end = begin + sum(len(line) + 1 for line in lines[start:start + len(wanted)]) - 1
    if old.endswith("\n") and end < len(text):
        end += 1
    # Indented as the file has it: the difference at the first line that says something.
    first = next(offset for offset, want in enumerate(wanted) if want)
    have, said = _indent(lines[start + first]), _indent(old_lines[first])
    adjusted = []
    for line in _lines(new):
        if not line.strip():
            adjusted.append(line)
        elif line.startswith(said):
            adjusted.append(have + line[len(said):])
        else:
            adjusted.append(have + line.lstrip())
    return begin, end, "\n".join(adjusted)


def nearest(text: str, old: str) -> tuple[int, int, str] | None:
    """The passage most like `old`: its first and last line (from 1) and its text."""
    lines = _lines(text)
    if len(lines) > NEAREST_LINES:
        return None
    size = max(1, len(_lines(old.rstrip("\n"))))
    best: tuple[float, int] | None = None
    matcher = difflib.SequenceMatcher(autojunk=False)
    matcher.set_seq2(old)
    for start in range(max(1, len(lines) - size + 1)):
        matcher.set_seq1("\n".join(lines[start:start + size]))
        if matcher.real_quick_ratio() < NEAREST_RATIO or matcher.quick_ratio() < NEAREST_RATIO:
            continue
        ratio = matcher.ratio()
        if best is None or ratio > best[0]:
            best = (ratio, start)
    if best is None or best[0] < NEAREST_RATIO:
        return None
    start = best[1]
    return start + 1, min(len(lines), start + size), "\n".join(lines[start:start + size])


def occurrences(text: str, old: str, limit: int = 8) -> list[int]:
    """The lines (from 1) that the exact passage `old` starts on, the first few."""
    found: list[int] = []
    at = text.find(old)
    while at != -1 and len(found) < limit:
        found.append(text.count("\n", 0, at) + 1)
        at = text.find(old, at + 1)
    return found
