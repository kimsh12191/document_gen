"""A script written only to check something goes in scratch/, a test in tests/ (0.3.20).

Seen in use (text2sql): the project's top folder filled with `debug_one.py`,
`debug_single.py`, `quick_test_1.py`, `test_1_fast.py`, `test_one_sample.py`
and twenty more -- one new script for each try -- though the project had a
`tests/` folder and the instruction said that a script to check something goes
in `scratch/`. Said, it was not done; it is looked for here, by rule:

- `held_probe`: a new Python file at the top of the project whose name says it
  checks something (`debug_`, `quick_`, `inspect_`, ...), or a test there when
  the project keeps its tests in `tests/`, is held once with where it goes and
  how to run it from there. Written again, it is written: it may be what the
  person asked for.
- `unnamed_probes`: finishing, the scripts this loop wrote only to check
  something are named in the summary, so the person can remove them.
"""

import re
from pathlib import Path

from relab_app.ablation import without
from relab_core.coding_loop import CodingLoop, LoopActionKind

# How a held write starts: "refused: " and this.
HELD = "put it in its place: "
HELD_SAID = f"refused: {HELD}"
# A name that says the script is there to check something.
PROBE_NAME = re.compile(
    r"^(?:debug|quick|inspect|analy[sz]e|try|tmp|temp|probe|scratch|explore|sandbox|playground)(?:_|\d|\.py$)"
    r"|_(?:debug|tmp|temp|probe)\.py$", re.IGNORECASE)
TEST_NAME = re.compile(r"^(?:test_.+|.+_test|test\d*|check_.+|verify_.+|verify|check)\.py$", re.IGNORECASE)
TEST_FOLDERS = ("tests", "test")
# Where a script to check something goes.
SCRATCH = "scratch"


def in_scratch(path: str) -> bool:
    """Whether a file is in a scratch/ folder: written to check something, not handed over."""
    return SCRATCH in path.replace("\\", "/").split("/")[:-1]


def _top(path: str, scope: str | None) -> str | None:
    """The name of a file at the top of the project, or None for one in a folder of it."""
    path = path.replace("\\", "/").removeprefix("./")
    if scope:
        if not path.startswith(f"{scope}/"):
            return None
        path = path[len(scope) + 1:]
    return None if "/" in path else path


def held_probe(workspace: Path, loop: CodingLoop, path: str, request: str) -> str | None:
    """Why a new script at the top of the project goes elsewhere; None to write it there."""
    if without("probe-files") or loop.helper_of is not None:
        return None
    name = _top(path, loop.scope)
    if name is None or not name.endswith(".py") or name in request:
        return None
    if workspace.joinpath(*path.replace("\\", "/").split("/")).exists():
        return None  # a file of the project's, changed
    home = workspace.joinpath(*loop.scope.split("/")) if loop.scope else workspace
    tests = next((folder for folder in TEST_FOLDERS if (home / folder).is_dir()), None)
    probe = bool(PROBE_NAME.search(name))
    if not probe and not (tests and TEST_NAME.match(name)):
        return None
    if any(step.action.action is LoopActionKind.WRITE_FILE and step.action.path == path
           and step.observation.startswith(HELD_SAID) for step in loop.steps):
        return None  # held once already: written again, with its reason
    again = ("If it is part of what you hand over, write it again where it was and say why: it is "
             "held once")
    if probe:
        return (f"{HELD}{name} would be a new script at the top of the project, and its name says it "
                f"is there to check something. Write it as scratch/{name} -- apart from what you hand "
                f"over, named in the summary so the person can remove it -- and run it from the project "
                f"folder as `python -m scratch.{name.removesuffix('.py')}`, so the project's own imports "
                f"resolve. When a script here already does most of it, give that one an option (which "
                f"input, --limit N) instead of a new script. {again}")
    return (f"{HELD}{name} would be a test at the top of the project, and the project keeps its tests "
            f"in {tests}/. Write it as {tests}/{name} and run it with `python -m pytest {tests}/{name}` "
            f"from the project folder. {again}")


def probes_written(loop: CodingLoop) -> list[str]:
    """The scripts this loop created only to check something: in scratch/, or named so."""
    found = []
    for item in loop.written:
        if item.before_digest is not None or not item.path.endswith(".py"):
            continue
        parts = item.path.split("/")
        if in_scratch(item.path) or PROBE_NAME.search(parts[-1]):
            found.append(item.path)
    return found


def unnamed_probes(workspace: Path, loop: CodingLoop, summary: str = "") -> str | None:
    """Why not to finish yet: scripts written only to check something, not named for the person."""
    if without("probe-files") or loop.helper_of is not None:
        return None
    unnamed = [path for path in probes_written(loop)
               if workspace.joinpath(*path.split("/")).is_file()
               and path.rsplit("/", 1)[-1] not in summary
               and not (f"{SCRATCH}/" in summary and in_scratch(path))]
    if not unnamed:
        return None
    shown = ", ".join(unnamed[:8]) + (f" and {len(unnamed) - 8} more" if len(unnamed) > 8 else "")
    return (f"not finished: {len(unnamed)} script(s) this task wrote only to check something are not "
            f"named in the summary: {shown}. Name them (a folder of them, scratch/, is enough) so the "
            f"person can remove them; deleting is not yours to do")
