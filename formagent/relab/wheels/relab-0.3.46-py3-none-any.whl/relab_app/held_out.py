"""Paths held out for the final evaluation: run against, never read (0.2.60).

Asked for in use: "add private data, which cannot be looked at while
optimizing and is used only for the final evaluation -- show only what was
wrong and the scores, so the model cannot cheat." A loop optimizing a score
that can read the answers it is scored against reaches 100% by reading them.

A held-out path is not read, searched, listed, outlined or written by a loop,
nor shown in its listing; a reader program (`cat`, `head`, `grep`...) or inline
code naming one is refused. A program that only takes it as an argument --
`python evaluate.py --data private/test.json` -- runs: that is how it is used.
What such a program prints is the program's business; an evaluation that
prints the expected answers gives them away, and says so in no rule here.
"""

from fnmatch import fnmatchcase
from pathlib import PurePosixPath

# Programs whose only use of a file named to them is to show some of it.
READERS = frozenset({
    "cat", "head", "tail", "less", "more", "grep", "egrep", "fgrep", "rg", "sed", "awk",
    "type", "findstr", "wc", "sort", "uniq", "diff", "cp", "mv", "xxd", "od", "strings",
    "base64", "jq", "nl", "cut", "tr", "tac", "paste", "column", "zcat", "gzip", "tar", "zip",
    "unzip", "7z", "copy", "xcopy", "robocopy", "get-content", "gc", "select-string",
})
CODE_FLAGS = frozenset({"-c", "-e", "--eval", "--command", "-Command"})

REFUSED = ("{path} is held out for the final evaluation: an evaluation you run may use it, but "
           "it is not read, searched, listed, outlined or changed here, and not printed by a "
           "reader or inline code. Work from the data you may read, and run the evaluation for "
           "its scores")


def normal(path: str) -> str:
    return path.replace("\\", "/").strip().removeprefix("./").strip("/")


def held(path: str | None, patterns: tuple[str, ...]) -> bool:
    """Whether a workspace path is, or is under, a held-out pattern."""
    if not path or not patterns:
        return False
    given = normal(path)
    for pattern in patterns:
        wanted = normal(pattern)
        if not wanted:
            continue
        folder = wanted.removesuffix("/**").removesuffix("/*")
        if (given == folder or given.startswith(folder + "/") or fnmatchcase(given, wanted)
                or PurePosixPath(given).match(wanted)):
            return True
    return False


def _named(text: str, patterns: tuple[str, ...]) -> str | None:
    """A held-out path written in a piece of text: an argument, or inline code."""
    for pattern in patterns:
        folder = normal(pattern).removesuffix("/**").removesuffix("/*")
        if folder and "*" not in folder and folder in text.replace("\\", "/"):
            return folder
    return None


def from_folder(patterns: tuple[str, ...], scope: str | None) -> tuple[str, ...]:
    """The patterns, and those under the project folder also as named from inside it:
    commands run there, and name files from there."""
    if not scope:
        return patterns
    prefix = normal(scope) + "/"
    return patterns + tuple(normal(item)[len(prefix):] for item in patterns
                            if normal(item).startswith(prefix))


def held_command(argv: list[str], patterns: tuple[str, ...]) -> str | None:
    """Why a command may not run: it shows a held-out file, by a reader or in inline code."""
    if not patterns or not argv:
        return None
    program = PurePosixPath(argv[0].replace("\\", "/")).name.lower().removesuffix(".exe")
    for index, argument in enumerate(argv[1:], start=1):
        if argv[index - 1] in CODE_FLAGS:
            found = _named(argument, patterns)
            if found is not None:
                return REFUSED.format(path=found)
            continue
        if program in READERS and (held(argument, patterns)
                                   or _named(argument, patterns) is not None):
            return REFUSED.format(path=normal(argument))
    return None
