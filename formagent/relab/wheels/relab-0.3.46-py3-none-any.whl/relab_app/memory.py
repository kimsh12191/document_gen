"""Recording what was learned, and retrieving it the same way twice.

Two rules hold this together, and both are refusals rather than warnings:

* **A finding cites evidence this workspace records.** A citation naming a run
  event that is not here is refused, the way a decision whose request id does not
  match its gate is refused. Findings are what the next plan is built from, so an
  unsupported one is the most expensive kind of wrong thing to store.
* **Retrieval is exact, ordered and bounded, and says why each item matched.**
  Planning on a similarity search whose results drift is planning that cannot be
  reproduced, which is the property the execution half of this repository exists
  to establish.
"""

from datetime import datetime
from pathlib import Path
from uuid import uuid4

from relab_core.coding.base import utc_now
from relab_core.memory import (
    DEFAULT_RETRIEVAL_LIMIT,
    EvidenceCitation,
    MemoryDraft,
    MemoryItem,
    MemoryMatch,
    MemoryQuery,
    MemoryRetrieval,
)
from relab_workspace.memory_store import MemoryStore
from relab_workspace.run_store import RunStore

# A supersession chain longer than this is a mistake, not a history.
MAXIMUM_CHAIN = 64


class ResearchMemory:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.store = MemoryStore(self.workspace)
        self.runs = RunStore(self.workspace)

    def unresolved(self, citations: list[EvidenceCitation]) -> list[EvidenceCitation]:
        """Which of these name a run event this workspace does not record."""
        missing = []
        for citation in citations:
            events = self.runs.events(citation.run_id)
            if not events or citation.event_sequence > events[-1].sequence:
                missing.append(citation)
        return missing

    def propose(self, draft: MemoryDraft, *, created_at: datetime | None = None) -> MemoryItem:
        """Give a draft an identity and a time, without recording it.

        Extraction -- by a person reading a report now, by a model later -- produces
        a value someone can read beside the evidence before it becomes something
        the next plan reads. Neither the identity nor the time comes from whoever
        wrote the claim.
        """
        return MemoryItem(memory_id=f"memory-{uuid4()}",
                          created_at=created_at or utc_now(), **draft.model_dump())

    def remember(self, draft: MemoryDraft) -> MemoryItem:
        """Propose and record in one call, for a draft already read by a person."""
        return self.record(self.propose(draft))

    def record(self, item: MemoryItem) -> MemoryItem:
        """Record a finding whose evidence is here, and refuse one whose is not."""
        if item.superseded_by is not None:
            raise ValueError("a finding is not recorded already superseded")
        missing = self.unresolved(item.citations)
        if missing:
            named = ", ".join(f"{item.run_id}#{item.event_sequence}" for item in missing)
            raise ValueError(f"finding cites evidence this workspace does not record: {named}")
        return self.store.add(item)

    def retrieve(
        self, *, scope: str | None = None, tags: list[str] | None = None,
        include_superseded: bool = False, limit: int = DEFAULT_RETRIEVAL_LIMIT,
    ) -> MemoryRetrieval:
        """The findings that match, in a fixed order, with why each one matched.

        Scope is matched exactly and tags must all be present. Both are
        case-insensitive, and neither is fuzzy: a planner that gets different
        findings on the same question from the same store is a planner whose
        designs cannot be explained afterwards.
        """
        query = MemoryQuery(scope=scope, tags=list(tags or []),
                            include_superseded=include_superseded, limit=limit)
        wanted = [tag.strip().casefold() for tag in query.tags]
        matched = []
        for item in self.store.all():
            if item.superseded_by is not None and not query.include_superseded:
                continue
            held = {tag.strip().casefold(): tag for tag in item.tags}
            if any(tag not in held for tag in wanted):
                continue
            if query.scope is not None and item.scope.strip().casefold() != query.scope.strip().casefold():
                continue
            matched.append(MemoryMatch(
                item=item, matched_scope=query.scope is not None,
                matched_tags=[held[tag] for tag in wanted],
            ))
        # Newest first, because a later finding on the same ground is the one that
        # matters; by id after that, so the order is total and does not shuffle.
        matched.sort(key=lambda match: (match.item.created_at, match.item.memory_id),
                     reverse=True)
        return MemoryRetrieval(
            query=query, matches=matched[:query.limit],
            truncated=len(matched) > query.limit, considered=len(matched),
        )

    def relevant(self, text: str, *, limit: int = 12) -> list[MemoryItem]:
        """The findings that bear on a goal or a request, by the words they share with it.

        For a planner's or a loop's context (M6.4); `retrieve` stays the exact
        query a person asks. Still deterministic: by how many words match, then
        newest, then by id. Superseded findings are not given.
        """
        from relab_app.lessons import words_of

        wanted = set(words_of(text))
        scored = []
        for item in self.store.all():
            if item.superseded_by is not None:
                continue
            held = set(words_of(" ".join([item.finding, item.scope, *item.tags,
                                          *item.conditions])))
            shared = len(wanted & held)
            if shared >= 2:
                scored.append((shared, item.created_at, item.memory_id, item))
        scored.sort(key=lambda found: (found[0], found[1], found[2]), reverse=True)
        return [found[3] for found in scored[:limit]]

    def supersede(self, memory_id: str, replacement: str) -> MemoryItem:
        """Record that a later finding replaces an earlier one. Nothing is deleted."""
        if memory_id == replacement:
            raise ValueError("a finding cannot supersede itself")
        self.store.load(memory_id)
        self.store.load(replacement)  # a finding is not replaced by one nobody recorded
        seen = {memory_id}
        current = replacement
        for _ in range(MAXIMUM_CHAIN):
            following = self.store.load(current).superseded_by
            if following is None:
                break
            if following in seen:
                raise ValueError("that supersession would close a loop")
            seen.add(current)
            current = following
        else:
            raise ValueError("supersession chain is too long to follow")
        return self.store.supersede(memory_id, replacement)
