"""What is wrong with a file just written, checked with what the project already has.

Python is checked by the coding loop itself (compiled, then ruff when it is
here). For the rest, a write is followed by the checks that are cheap and
certain, each only when what it needs is already on this host or in the
project -- nothing is installed to run them:

    .json            parsed
    .toml            parsed, when this Python reads TOML
    .js .mjs .cjs    `node --check`: syntax only, nothing is run
    .ts .tsx         the project's own TypeScript (`node_modules/typescript`)
                     over its `tsconfig.json`, errors in the written file
    JS and TS        the project's own ESLint, when it has a flat config;
                     errors only, not warnings
    .go              `gofmt -e`: syntax only

A finding is what the step shows next to "wrote"; only a file that does not
parse marks the step as failed, as a Python syntax error does.
"""

import importlib
import json
import re
import shutil
from pathlib import Path

from relab_workspace.patcher import Patcher

JAVASCRIPT = {".js", ".mjs", ".cjs"}
TYPESCRIPT = {".ts", ".tsx", ".mts", ".cts"}
ESLINT_CONFIGS = ("eslint.config.js", "eslint.config.mjs", "eslint.config.cjs",
                  "eslint.config.ts", "eslint.config.mts", "eslint.config.cts")
CHECK_SECONDS = 90.0
MAXIMUM_LINES = 20
# `src/a.ts(3,5): error TS2322: ...`; a TS1xxx code is a syntax error.
TSC_LINE = re.compile(r"^(?P<path>.+?)\((?P<line>\d+),(?P<column>\d+)\): error TS(?P<code>\d+): "
                      r"(?P<message>.*)$")


def diagnose(workspace: Path, path: str) -> tuple[str, bool]:
    """Findings for a written file, as lines to show, and whether it does not parse."""
    suffix = Path(path).suffix.lower()
    target = workspace.joinpath(*path.split("/"))
    try:
        if suffix == ".json":
            return _json(target)
        if suffix == ".toml":
            return _toml(target)
        if suffix == ".go":
            return _gofmt(workspace, path)
        if suffix not in JAVASCRIPT | TYPESCRIPT and suffix not in {".jsx"}:
            return "", False
        found: list[str] = []
        broken = False
        if suffix in JAVASCRIPT:
            said, broken = _node_check(workspace, path)
            found += [said] if said else []
        package = _package(workspace, path)
        if package is not None and not broken:
            if suffix in TYPESCRIPT:
                said, broken = _tsc(workspace, package, path)
                found += [said] if said else []
            said = _eslint(workspace, package, path)
            found += [said] if said else []
        return "\n".join(found), broken
    except (OSError, UnicodeDecodeError):
        return "", False


def _json(target: Path) -> tuple[str, bool]:
    try:
        json.loads(target.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        return f"JSON error at line {error.lineno} column {error.colno}: {error.msg}", True
    return "", False


def _toml(target: Path) -> tuple[str, bool]:
    try:
        # By name: the oldest Python this runs on (3.10) has no tomllib.
        tomllib = importlib.import_module("tomllib")
    except ImportError:  # Python 3.10 reads no TOML without a dependency
        return "", False
    try:
        tomllib.loads(target.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as error:
        return f"TOML error: {error}", True
    return "", False


def _node_check(workspace: Path, path: str) -> tuple[str, bool]:
    node = shutil.which("node")
    if node is None:
        return "", False
    result = Patcher().measure(workspace, [node, "--check", path], timeout_seconds=CHECK_SECONDS)
    if result.timed_out or result.exit_code == 0:
        return "", False
    lines = [line for line in result.stderr.splitlines() if line.strip()]
    return "node --check found a syntax error:\n" + "\n".join(lines[:MAXIMUM_LINES]), True


def _gofmt(workspace: Path, path: str) -> tuple[str, bool]:
    gofmt = shutil.which("gofmt")
    if gofmt is None:
        return "", False
    result = Patcher().measure(workspace, [gofmt, "-l", "-e", path],
                               timeout_seconds=CHECK_SECONDS)
    if result.timed_out or result.exit_code == 0:
        return "", False
    lines = [line for line in result.stderr.splitlines() if line.strip()]
    return "gofmt found a syntax error:\n" + "\n".join(lines[:MAXIMUM_LINES]), True


def _package(workspace: Path, path: str) -> str | None:
    """The nearest folder above the file with a package.json, as a workspace path."""
    parts = path.split("/")[:-1]
    while True:
        folder = "/".join(parts)
        if workspace.joinpath(*parts, "package.json").is_file():
            return folder
        if not parts:
            return None
        parts = parts[:-1]


def _under(package: str, *rest: str) -> str:
    return "/".join([*([package] if package else []), *rest])


def _tsc(workspace: Path, package: str, path: str | list[str]) -> tuple[str, bool]:
    """The project's TypeScript errors in this file; the rest of the project as a count."""
    node = shutil.which("node")
    compiler = _under(package, "node_modules", "typescript", "bin", "tsc")
    config = _under(package, "tsconfig.json")
    if node is None or not (workspace / compiler).is_file() or not (workspace / config).is_file():
        return "", False
    result = Patcher().measure(
        workspace, [node, compiler, "--noEmit", "--pretty", "false", "-p", config],
        timeout_seconds=CHECK_SECONDS)
    if result.timed_out or result.exit_code == 0:
        return "", False
    mine, elsewhere, broken = [], 0, False
    for line in result.stdout.splitlines():
        found = TSC_LINE.match(line.strip())
        if found is None:
            continue
        if found["path"].replace("\\", "/").removeprefix("./") in ([path] if isinstance(path, str) else path):
            mine.append(f"line {found['line']}: TS{found['code']} {found['message']}")
            broken = broken or found["code"].startswith("1")
        else:
            elsewhere += 1
    if not mine and not elsewhere:
        return "", False
    said = ["TypeScript found:", *mine[:MAXIMUM_LINES]] if mine else []
    if elsewhere:
        said.append(f"and {elsewhere} error(s) in other files of the project")
    return "\n".join(said), broken


def _eslint(workspace: Path, package: str, path: str | list[str]) -> str:
    """The project's ESLint errors in this file, when it has a flat config."""
    node = shutil.which("node")
    linter = _under(package, "node_modules", "eslint", "bin", "eslint.js")
    config = next((_under(package, name) for name in ESLINT_CONFIGS
                   if (workspace / _under(package, name)).is_file()), None)
    if node is None or config is None or not (workspace / linter).is_file():
        return ""
    result = Patcher().measure(
        workspace, [node, linter, "--format", "json", "--config", config,
                    *([path] if isinstance(path, str) else path)],
        timeout_seconds=CHECK_SECONDS)
    if result.timed_out:
        return ""
    try:
        reports = json.loads(result.stdout)
    except json.JSONDecodeError:
        return ""
    errors = [f"line {item.get('line', '?')}: {item.get('message', '')}"
              f"{' (' + item['ruleId'] + ')' if item.get('ruleId') else ''}"
              for report in reports if isinstance(report, dict)
              for item in report.get("messages", []) if item.get("severity") == 2]
    return "ESLint found:\n" + "\n".join(errors[:MAXIMUM_LINES]) if errors else ""
