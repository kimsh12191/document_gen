"""Durable research origins and record-derived evidence passed back to coding."""
import re
from pathlib import Path

from relab_app.coding_loop import CodingLoopService
from relab_app.evidence import research_evidence
from relab_app.sessions import ResearchSessionService
from relab_core.coding_loop import CodingLoop, LoopOutcome
from relab_core.evidence import EngineeringDecision, StudyOrigin
from relab_core.generation import ModelGateway


def link_study(workspace: Path, session_id: str, loop_id: str) -> StudyOrigin:
    coding = CodingLoopService(workspace, observe=lambda event: None)
    loop = coding.load(loop_id)
    if loop.outcome is not LoopOutcome.ESCALATED or loop.escalation is None:
        raise ValueError("only a coding loop that proposed research can own a study")
    if loop.escalation.session_id not in (None, session_id):
        raise ValueError("that coding request already owns another study")
    research = ResearchSessionService(workspace)
    event = research.store.latest(session_id)
    session = event.snapshot
    origin = StudyOrigin(loop_id=loop_id, request=loop.request)
    if session.origin is not None and session.origin != origin:
        raise ValueError("that study already has a different coding origin")
    if session.origin is None:
        research.open_session(session)
        session.origin = origin
        research.store.append(session, "research.origin_linked", event.sequence)
    # If interrupted after appending the origin, the same call repairs this side.
    loop.escalation.session_id = session_id
    coding._save(loop)
    return origin


def study_origin(workspace: Path, session_id: str) -> StudyOrigin | None:
    return ResearchSessionService(workspace).store.latest(session_id).snapshot.origin


def hand_back(workspace: Path, session_id: str, coding: CodingLoopService,
              gateway: ModelGateway, *, loop_id: str | None = None,
              max_steps: int = 40, review_edits: bool | None = None) -> CodingLoop:
    package = research_evidence(workspace, session_id)
    origin = study_origin(workspace, session_id)
    if origin is None:
        raise ValueError("that study has no recorded coding origin")
    before = coding.load(origin.loop_id)
    if before.escalation is None or before.escalation.session_id != session_id:
        raise ValueError("the coding request and study origin do not agree")
    request = origin.request
    return coding.run(request, gateway, after=origin.loop_id, loop_id=loop_id,
                      max_steps=max_steps, _evidence=[package],
                      review_edits=(before.review_edits if review_edits is None else review_edits)
                      and not coding.auto)


def record_decisions(loop: CodingLoop) -> None:
    known = {package.package_id for package in loop.evidence}
    for line in (loop.summary or "").splitlines():
        if not line.strip().startswith("Decision:"):
            continue
        statement = line.strip()[:2000]
        named = re.findall(r"\[([^\[\]]+/evidence-\d+)\]", statement)
        if not named or any(name not in known for name in named):
            if statement not in loop.unlinked_decisions:
                loop.unlinked_decisions = (loop.unlinked_decisions + [statement])[-100:]
            continue
        decision = EngineeringDecision(statement=statement,
            evidence_package_ids=list(dict.fromkeys(named))[:4],
            files=[item.path for item in loop.written][:2000])
        if decision not in loop.decisions:
            loop.decisions = (loop.decisions + [decision])[-100:]
