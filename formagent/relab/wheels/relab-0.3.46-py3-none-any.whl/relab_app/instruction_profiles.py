"""The modular instruction: condition C of the prompt comparison (R05 7.2, R09 11.4; 0.3.5).

An experiment option (`--instruction modular`), never the default until a
comparison shows it helps (`docs/validation/PROMPT_PROFILE_EVALUATION.md`).
It adds no word to the instruction: it is the current instruction's own
sections, taken as they are and put together by what the call needs --

- the common principles, always: what the model is given, how to work, what
  it hands back, safety, and what to check before it finishes;
- the guidance of the task's mode: changing code and running programs for a
  change; questions about the code and running programs for an answer;
  questions alone for a request to change nothing (it runs nothing); changing
  code for a plan;
- the output contract of the way the call is made: the compact one's "How to
  reply" when the steps go as tools (their schemas carry the fields), the full
  one's when they go as JSON.

So the conditions differ only in which sections are sent, never in what a
section says; a change to a section changes all three alike.
"""

import re

# The sections of the instruction, by their headings.
REPLY = "How to reply"
GIVEN = "What you are given"
WORK = "How to work"
CHANGING = "Changing code"
QUESTIONS = "Questions about the code"
RUNNING = "Running programs"
HANDED = "What you hand back"
SAFETY = "Safety"
FINISHING = "Before you finish"

COMMON = (GIVEN, WORK, HANDED, SAFETY, FINISHING)
BY_MODE = {
    "change": (CHANGING, RUNNING),
    "answer": (QUESTIONS, RUNNING),
    "review": (QUESTIONS,),
    "plan": (CHANGING,),
}
MODES = tuple(BY_MODE)

HEADING = re.compile(r"^# (.+)$", re.MULTILINE)


def sections(instruction: str) -> tuple[str, dict[str, str]]:
    """An instruction as its opening text and its sections by heading, each with its heading."""
    found = list(HEADING.finditer(instruction))
    if not found:
        raise ValueError("the instruction has no sections")
    opening = instruction[:found[0].start()]
    parts: dict[str, str] = {}
    for index, match in enumerate(found):
        end = found[index + 1].start() if index + 1 < len(found) else len(instruction)
        parts[match.group(1).strip()] = instruction[match.start():end]
    return opening, parts


def modular(full: str, compact: str, *, mode: str, tools: bool) -> str:
    """The instruction for a call of this mode, made the way it is: its own sections, in their order."""
    if mode not in BY_MODE:
        raise ValueError(f"no mode {mode!r}; there are {', '.join(MODES)}")
    opening, parts = sections(full)
    _, compact_parts = sections(compact)
    wanted = {REPLY, *COMMON, *BY_MODE[mode]}
    missing = sorted(wanted - parts.keys())
    if missing:
        raise ValueError(f"the instruction has no section {', '.join(missing)}")
    chosen = [((compact_parts if tools and name == REPLY and REPLY in compact_parts else parts)[name])
              for name in parts if name in wanted]
    return opening + "".join(chosen)
