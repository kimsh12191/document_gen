"""One read API for any client: an overview of stored state and a merged timeline.

Every value here is derived from the same snapshots the other services read.
Nothing is executed, recorded or decided, and no state is cached.
"""

import math
import time
from collections.abc import Callable, Iterator
from datetime import datetime
from pathlib import Path

from relab_app.runs import CodingRunService
from relab_app.sessions import ResearchSessionService
from relab_core.agenda import WorkspaceAgenda
from relab_core.client import (
    BlockedSession,
    EvidencePointer,
    GateBoard,
    GateDetail,
    GateRequest,
    PolicyChange,
    RunSummary,
    SessionReport,
    SessionState,
    SessionSummary,
    TimelineEntry,
    WorkspaceOverview,
    WorkspaceTimeline,
)
from relab_core.operations import OperationEvent
from relab_core.research import (
    CodingRunReference,
    ResearchSession,
    ResearchSessionAssessment,
)
from relab_core.runs import CodingRun, RunEvent
from relab_evaluation.preregistration import moved_goalposts
from relab_workspace.operation_store import OperationStore
from relab_workspace.private_state import has_state, state_dir

MAXIMUM_TIMELINE_ENTRIES = 500
# What the event stores look like from outside. Cheap to take, and never trusted
# to say "nothing changed" when it could not be taken at all.
# The journal is watched like the others so a progress note wakes a follower
# as quickly as a record does.
STORE_FILES = ("runs.db", "sessions.db", "operations.db")
MAXIMUM_POLL_SECONDS = 60.0
MAXIMUM_FOLLOW_SECONDS = 3600.0


def untouched(workspace: Path) -> bool:
    """Whether ReLab has kept nothing in this workspace: no `.relab` folder at all."""
    return not has_state(workspace.resolve(strict=True))


def nothing_kept(workspace: Path, action: str) -> WorkspaceOverview | GateBoard | WorkspaceAgenda:
    """What `overview`, `gates` or `agenda` answer for an untouched workspace, creating nothing.

    The stores make their files when opened, so reading through them would be
    what creates `.relab`; with no folder there is nothing to read anyway.
    """
    where = str(workspace.resolve(strict=True))
    if action == "overview":
        return WorkspaceOverview(workspace=where, sessions=[], runs=[], gates=[])
    if action == "gates":
        return GateBoard(workspace=where, gates=[])
    if action == "agenda":
        return WorkspaceAgenda(workspace=where, entries=[], awaiting_human=0, unreadable=0)
    raise ValueError(f"no empty answer for {action!r}")


# However unchanged the stores look, a follower reads them at least this often.
FORCED_READ_SECONDS = 5.0

class WorkspaceClient:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.runs = CodingRunService(self.workspace)
        self.research = ResearchSessionService(self.workspace)
        # None when this workspace cannot hold a journal: the view loses its
        # progress lines and nothing else, which is the whole point of it.
        self.operations = OperationStore.open(self.workspace)

    def overview(self) -> WorkspaceOverview:
        """Summarize every session, run and open gate this workspace holds."""
        gates = self.runs.pending_gates()
        blocked = {gate.run_id for gate in gates.gates}
        runs = []
        for run_id in self.runs.store.run_ids():
            events = self.runs.store.events(run_id)
            run = events[-1].snapshot
            runs.append(RunSummary(
                run_id=run_id, objective=run.objective, request_id=run.request_id,
                state=run.state, event_sequence=events[-1].sequence,
            ))
        sessions = []
        for session_id in self.research.store.session_ids():
            event = self.research.store.latest(session_id)
            summary = self._summary(session_id, event.snapshot, event.sequence, blocked)
            summary.updated_at = event.timestamp
            sessions.append(summary)
        return WorkspaceOverview(workspace=str(self.workspace), sessions=sessions,
                                 runs=runs, gates=gates.gates)

    def _summary(
        self, session_id: str, session: ResearchSession, sequence: int, blocked: set[str],
    ) -> SessionSummary:
        summary = SessionSummary(
            session_id=session_id, objective=session.objective, state=SessionState.CREATED,
            event_sequence=sequence, attached_runs=len(session.runs),
            plan_revision=None if session.plan is None else session.plan.revision,
            arms=[] if session.plan is None else list(session.plan.arms),
            decision=None if session.conclusion is None else session.conclusion.decision,
        )
        summary.state = self._state(session_id, session, blocked)
        return summary

    def _state(
        self, session_id: str, session: ResearchSession, blocked: set[str],
    ) -> SessionState:
        """Terminal first, then a waiting person, then coverage; never a guess."""
        if session.conclusion is not None:
            return SessionState.CONCLUDED
        if any(ref.run_id in blocked for ref in session.runs):
            return SessionState.AWAITING_HUMAN
        if session.plan is None:
            return SessionState.CREATED
        if not session.runs:
            return SessionState.PLANNED
        # A plan with no declared arms has no coverage to report, only attachments.
        if session.plan.arms and self.research.readiness(session_id).ready:
            return SessionState.COVERED
        return SessionState.COLLECTING

    def gates(self) -> GateBoard:
        """Describe every open gate: what it asks for, and what it holds up.

        `overview` keeps the plain queue; this is the view a person decides
        from. Like everything here it reads, and resolves nothing.
        """
        waiting = self._blocked_sessions()
        details = []
        for gate in self.runs.pending_gates().gates:
            blocks = list(waiting.get(gate.run_id, {}).values())
            details.append(GateDetail(gate=gate, blocks=blocks,
                                      request=_request(self.runs.store.load(gate.run_id))))
        return GateBoard(workspace=str(self.workspace), gates=details)

    def _blocked_sessions(self) -> dict[str, dict[str, BlockedSession]]:
        """Run id to the sessions referencing it; a session appears once, at its latest role."""
        waiting: dict[str, dict[str, BlockedSession]] = {}
        for session_id in self.research.store.session_ids():
            session = self.research.store.latest(session_id).snapshot
            for ref in session.runs:
                waiting.setdefault(ref.run_id, {})[session_id] = BlockedSession(
                    session_id=session_id, objective=session.objective, role=ref.role)
        return waiting

    def report(self, session_id: str) -> SessionReport:
        """One archival record of a session: policy, evidence, decision, integrity.

        Everything here is already recorded; what this adds is reading it in one
        place and answering the one question the record does not state outright —
        whether the declared policy was changed once results existed.
        """
        event = self.research.store.latest(session_id)
        session = event.snapshot
        assessment, source, unavailable = self._assessment(session_id, session)
        changes = self._policy_changes(session_id)
        return SessionReport(
            workspace=str(self.workspace), session_id=session_id,
            objective=session.objective, event_sequence=event.sequence,
            state=self._state(session_id, session,
                              {gate.run_id for gate in self.runs.pending_gates().gates}),
            plan=session.plan, evidence=[self._pointer(ref) for ref in session.runs],
            assessment=assessment, assessment_source=source,
            assessment_unavailable=unavailable, holdout=session.holdout,
            decision=None if session.conclusion is None else session.conclusion.decision,
            rationale=None if session.conclusion is None else session.conclusion.rationale,
            limitations=[] if session.conclusion is None else list(session.conclusion.limitations),
            policy_changes=changes,
            pre_registered=not any(change.after_results for change in changes),
            rules_held=not any(change.deciding_fields for change in changes),
        )

    def _assessment(
        self, session_id: str, session: ResearchSession,
    ) -> tuple[ResearchSessionAssessment | None, str | None, str | None]:
        """A concluded session reports what it decided on, never a newer reading."""
        if session.conclusion is not None:
            if session.conclusion.assessment is None:
                return None, None, "the decision recorded no assessment"
            return session.conclusion.assessment, "conclusion", None
        try:
            return self.research.assess(session_id), "current", None
        except (ValueError, LookupError) as error:
            return None, None, str(error)

    def _pointer(self, reference: CodingRunReference) -> EvidencePointer:
        """Describe the pinned run event itself, not a newer one it may have since had."""
        pinned = self._pinned(reference)
        run = self.runs.store.load(reference.run_id) if pinned is None else pinned.snapshot
        evidence = run.patch_evidence
        return EvidencePointer(
            run_id=reference.run_id, role=reference.role,
            event_sequence=reference.event_sequence, state=run.state,
            patch_id=None if evidence is None else evidence.patch_id,
            reported_model=run.generation_reported_model, restored=run.restored,
            conditions_recorded=run.conditions is not None,
        )

    def _pinned(self, reference: CodingRunReference) -> RunEvent | None:
        return next((item for item in self.runs.store.events(reference.run_id)
                     if item.sequence == reference.event_sequence), None)

    def _policy_changes(self, session_id: str) -> list[PolicyChange]:
        """Read the history itself, so a change cannot be counted by pairing lists."""
        changes = []
        previous = None
        for event in self.research.store.events(session_id):
            if event.kind == "research.plan_revised" and event.snapshot.amendments:
                amendment = event.snapshot.amendments[-1]
                changes.append(self._change(
                    "amendment", event.sequence, amendment.rationale,
                    event.snapshot.runs, revision=amendment.revision,
                    moved=[] if previous is None or event.snapshot.plan is None
                    else moved_goalposts(previous, event.snapshot.plan)))
            elif event.kind == "research.reopened" and event.snapshot.reopenings:
                changes.append(self._change(
                    "reopening", event.sequence, event.snapshot.reopenings[-1].rationale,
                    event.snapshot.runs))
            if event.snapshot.plan is not None:
                previous = event.snapshot.plan
        return changes

    def _change(
        self, kind: str, sequence: int, rationale: str,
        references: list[CodingRunReference], *, revision: int | None = None,
        moved: list[str] | None = None,
    ) -> PolicyChange:
        with_results = sum(1 for ref in references if self._had_results(ref))
        return PolicyChange(
            kind=kind, event_sequence=sequence, revision=revision, rationale=rationale,
            attached_runs=len(references), runs_with_results=with_results,
            after_results=with_results > 0,
            # A rule changed before anything ran moved no goalpost that existed.
            deciding_fields=(list(moved or []) if with_results else []),
        )

    def _had_results(self, reference: CodingRunReference) -> bool:
        """Whether the run had produced an outcome at the event this session had seen."""
        pinned = self._pinned(reference)
        if pinned is None:
            return False
        return pinned.snapshot.result is not None or pinned.snapshot.patch_evidence is not None

    def timeline(self, *, limit: int = 100, after: str | None = None) -> WorkspaceTimeline:
        """Merge run, research and operation events by time; identifiers break ties.

        The first two are the record. The third is the journal of what was going
        on, carried here because a person watching wants one ordered account --
        never because it counts towards anything.

        Without `after` this returns the most recent `limit` entries, as it always
        has. With it, the oldest `limit` entries that follow that cursor, so a
        client reads what it has not seen instead of the whole history again.
        """
        if type(limit) is not int or not 1 <= limit <= MAXIMUM_TIMELINE_ENTRIES:
            raise ValueError(f"limit must be an integer between 1 and {MAXIMUM_TIMELINE_ENTRIES}")
        run_sessions: dict[str, set[str]] = {}
        session_ids = self.research.store.session_ids()
        for session_id in session_ids:
            for reference in self.research.store.latest(session_id).snapshot.runs:
                run_sessions.setdefault(reference.run_id, set()).add(session_id)
        entries = [
            _entry("run", event.run_id, event.sequence, event.kind, event.timestamp,
                   session_ids=sorted(run_sessions.get(event.run_id, set())))
            for run_id in self.runs.store.run_ids()
            for event in self.runs.store.events(run_id)
        ] + [
            _entry("research", event.session_id, event.sequence, event.kind, event.timestamp,
                   session_ids=[event.session_id])
            for session_id in session_ids
            for event in self.research.store.events(session_id)
        ]
        entries += [
            _entry("operation", event.operation_id, event.sequence, event.kind.value,
                   event.timestamp,
                   # Said by the records, not by the line: an attempt's study
                   # is whatever is attached to it now, which can change after
                   # the progress note was written.
                   session_ids=([event.session_id] if event.session_id else
                                sorted(run_sessions.get(event.run_id or "", set()))),
                   operation=event)
            for event in (self.operations.events() if self.operations is not None else [])
        ]
        entries.sort(key=_order)
        if after is not None:
            mark = _parse_cursor(after)
            following = [item for item in entries if _order(item) > mark]
            selected, truncated = following[:limit], len(following) > limit
        else:
            selected, truncated = entries[-limit:], len(entries) > limit
        return WorkspaceTimeline(
            workspace=str(self.workspace), truncated=truncated, entries=selected,
            next_cursor=selected[-1].cursor if selected else after,
        )

    def follow(
        self, *, after: str | None = None, limit: int = 100,
        poll_seconds: float = 1.0, max_seconds: float = 60.0,
        sleep: Callable[[float], None] = time.sleep,
        clock: Callable[[], float] = time.monotonic,
    ) -> Iterator[TimelineEntry]:
        """Yield entries as they are appended, until the deadline passes.

        This is delivery, not a push: the loop performs the same read
        `timeline` does, so a client consumes a stream of entries instead of
        holding a cursor and re-asking. It records nothing and takes no lock.

        Bootstrap with `timeline` and follow from its cursor. Without one this
        starts at the current end, delivering only what arrives from now on.
        """
        _bounded("poll interval", poll_seconds, MAXIMUM_POLL_SECONDS)
        _bounded("follow duration", max_seconds, MAXIMUM_FOLLOW_SECONDS)
        cursor = after if after is not None else self.timeline(limit=1).next_cursor
        started = clock()
        last_read = started
        seen: tuple[tuple[str, int, int], ...] | None = None
        # The first read always happens, and so does the next one while a backlog
        # is still being drained: more is already recorded, so the stores looking
        # untouched says nothing about whether this has caught up with them.
        read_regardless = True
        while True:
            # Taken before the read, so a write landing during the read is seen
            # again next time round rather than missed. A redundant read is the
            # right direction to err in; a skipped one is not.
            fingerprint = self._store_fingerprint()
            # Read now and then whatever the files look like (0.2.39): on a shared
            # filesystem a size and time cached by the client looked unchanged
            # while a coding leg, holding the journal, kept appending to it, and
            # the chat showed nothing for minutes.
            stale = clock() - last_read >= FORCED_READ_SECONDS
            if read_regardless or stale or fingerprint is None or fingerprint != seen:
                seen = fingerprint
                read_regardless = False
                last_read = clock()
                # With no cursor the store was empty when following began, so
                # everything in it is new; one page of it is all this can deliver.
                following = cursor is not None
                page = self.timeline(
                    limit=limit if following else MAXIMUM_TIMELINE_ENTRIES, after=cursor)
                yield from page.entries
                cursor = page.next_cursor if page.next_cursor is not None else cursor
                if following and page.truncated:
                    read_regardless = True
                    continue  # More is already recorded; drain it without waiting.
            if clock() - started >= max_seconds:
                return
            sleep(poll_seconds)

    def _store_fingerprint(self) -> tuple[tuple[str, int, int], ...] | None:
        """How the event stores look from outside, without opening them.

        Reading every event to discover that nothing was appended is the cost the
        cursor could not remove: it bounds what is returned, not what is read.
        This bounds what is read, by asking the filesystem a much cheaper question
        first.

        `None` means the question could not be answered, and is never taken as
        "nothing changed" -- a fingerprint that cannot be taken must cost a read,
        because the alternative is silence that looks exactly like quiet.
        """
        state = state_dir(self.workspace)
        found = []
        try:
            for name in STORE_FILES:
                # SQLite may hold a commit in a sibling journal, so those count
                # as part of how the store looks even when the main file has not
                # been rewritten yet.
                for path in (state / name, state / f"{name}-wal", state / f"{name}-journal"):
                    if path.is_symlink():
                        return None
                    if not path.exists():
                        continue
                    status = path.stat()
                    found.append((path.name, status.st_mtime_ns, status.st_size))
        except OSError:
            return None
        return tuple(found)


def _bounded(name: str, seconds: float, ceiling: float) -> None:
    if not math.isfinite(seconds) or not 0 < seconds <= ceiling:
        raise ValueError(f"{name} must be finite, positive and at most {ceiling} seconds")


def _entry(
    source: str, subject_id: str, sequence: int, kind: str, timestamp: datetime,
    *, session_ids: list[str], operation: OperationEvent | None = None,
) -> TimelineEntry:
    # The free-form identifier goes last so a separator inside it cannot split a cursor.
    cursor = f"{timestamp.isoformat()}|{source}|{sequence}|{subject_id}"
    return TimelineEntry(source=source, subject_id=subject_id, sequence=sequence,
                         kind=kind, timestamp=timestamp, cursor=cursor,
                         session_ids=session_ids, operation=operation)


def _order(entry: TimelineEntry) -> tuple[datetime, str, int, str]:
    return (entry.timestamp, entry.source, entry.sequence, entry.subject_id)


def _parse_cursor(cursor: str) -> tuple[datetime, str, int, str]:
    """A cursor a client did not get from this timeline is an error, not an empty page."""
    parts = cursor.split("|", 3)
    if len(parts) != 4 or parts[1] not in {"run", "research", "operation"} or not parts[3]:
        raise ValueError("timeline cursor is not one this workspace issued")
    try:
        return (datetime.fromisoformat(parts[0]), parts[1], int(parts[2]), parts[3])
    except ValueError as error:
        raise ValueError("timeline cursor is not one this workspace issued") from error


def _request(run: CodingRun) -> GateRequest | None:
    """A gate whose stored request is unreadable is still listed, just undescribed."""
    failure = run.result.failure if run.result is not None else None
    request = failure.dependency_install_request if failure is not None else None
    if request is None:
        return None
    return GateRequest(
        dependency=request.dependency, version_constraint=request.version_constraint,
        source_module=request.source_module, installer=request.installer,
        environment_path=request.environment.path,
        network_required=request.network_required, attempt=request.attempt,
    )
