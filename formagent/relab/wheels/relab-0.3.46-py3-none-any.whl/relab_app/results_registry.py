"""Every benchmark run, registered, and one report kept current from all of them.

Comparing runs was done by hand: result files opened two at a time, tables
written in a chat, the public leaderboard looked up again each time. Now a run
is registered as it goes -- its result file copied in, an index entry with the
suite, model, provider, effort, commit and a summary -- and the report is
rebuilt from every registered run each time one changes:

    .relab/results/index.json     one entry per run (suite + label)
    .relab/results/runs/*.json    the result files, as registered
    .relab/results/REPORT.md      the report, rebuilt; never edited by hand

Reference figures (a public leaderboard's numbers, for example) are declared
in `benchmarks/references.json` and shown beside the runs; they are numbers
someone looked up, labelled as such, never measured here.
"""

import hashlib
import json
import re
import statistics
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from relab_app.coding_bench import (
    FAILURE_GROUP,
    LOCATE_CLASSES,
    BenchResult,
    BenchRun,
    failure,
    read_result,
)
from relab_workspace.locking import state_file_lock
from relab_workspace.private_state import state_dir

RESULTS = "results"
REFERENCES = "benchmarks/references.json"
# Runs a suite's task table shows side by side, newest first.
TABLE_RUNS = 6


def current_commit(workspace: Path) -> str | None:
    """The workspace's checked-out commit, short, when it is a git repository."""
    try:
        done = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=workspace,
                              capture_output=True, encoding="utf-8", check=False, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    commit = done.stdout.strip()
    return commit if done.returncode == 0 and re.fullmatch(r"[0-9a-f]{4,40}", commit) else None


def _entry_id(suite: str, label: str) -> str:
    return hashlib.sha256(f"{suite}\x00{label}".encode()).hexdigest()[:16]


class ResultsRegistry:
    """The registered runs of one workspace, and its report."""

    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve()
        self.folder = state_dir(self.workspace) / RESULTS
        self.index_path = self.folder / "index.json"
        self.report_path = self.folder / "REPORT.md"

    def entries(self) -> list[dict[str, object]]:
        try:
            data = json.loads(self.index_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        return [item for item in data if isinstance(item, dict)] if isinstance(data, list) else []

    def register(self, result: BenchResult) -> dict[str, object]:
        """Keep a run (again, as it grows) and rebuild the report. Returns its entry."""
        suite = result.suite or "unnamed"
        entry_id = _entry_id(suite, result.label)
        (self.folder / "runs").mkdir(parents=True, exist_ok=True)
        stored = self.folder / "runs" / f"{entry_id}.json"
        stored.write_text(result.model_dump_json(indent=2), encoding="utf-8")
        summary = result.summary()
        entry: dict[str, object] = {
            "entry_id": entry_id, "suite": suite, "label": result.label,
            "model": result.model, "provider": result.provider,
            "reasoning_effort": result.reasoning_effort, "commit": result.commit,
            "started_at": result.started_at.isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "runs": summary.get("runs"), "solved": summary.get("solved"),
            "solve_rate": summary.get("solve_rate"), "mean_seconds": summary.get("mean_seconds"),
            "total_cost": summary.get("total_cost"), "failures": summary.get("failures"),
            "by_category": summary.get("by_category"), "by_repeat": summary.get("by_repeat"),
            "file": f"runs/{entry_id}.json",
        }
        # Another benchmark in this workspace registers too: one at a time, or an entry is lost.
        with state_file_lock(self.workspace, f"{RESULTS}/index.json"):
            kept = [item for item in self.entries() if item.get("entry_id") != entry_id]
            kept.append(entry)
            kept.sort(key=lambda item: str(item.get("started_at")))
            temporary = self.index_path.with_suffix(".tmp")
            temporary.write_text(json.dumps(kept, ensure_ascii=False, indent=1), encoding="utf-8")
            temporary.replace(self.index_path)
            self.rebuild()
        return entry

    def result(self, entry: dict[str, object]) -> BenchResult | None:
        try:
            return read_result(self.folder / str(entry["file"]))
        except (OSError, ValueError, KeyError):
            return None

    def rebuild(self) -> Path:
        """The report, from every registered run; written whole, replacing the last."""
        self.folder.mkdir(parents=True, exist_ok=True)
        self.report_path.write_text(render_report(self), encoding="utf-8")
        return self.report_path

    def references(self) -> dict[str, list[dict[str, object]]]:
        try:
            data = json.loads((self.workspace / REFERENCES).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return {str(key): [item for item in value if isinstance(item, dict)]
                for key, value in data.items() if isinstance(value, list)} \
            if isinstance(data, dict) else {}


def _rate(solved: object, runs: object) -> str:
    if not isinstance(solved, int) or not isinstance(runs, int) or runs == 0:
        return "-"
    return f"{solved}/{runs} ({100 * solved / runs:.0f}%)"


def _cell(text: object) -> str:
    return str(text if text not in (None, "") else "-").replace("|", "\\|").replace("\n", " ")


def render_report(registry: ResultsRegistry) -> str:
    """The report as Markdown: by suite, its runs, its tasks run by run, its categories."""
    entries = registry.entries()
    references = registry.references()
    rebuilt = datetime.now(timezone.utc).isoformat(timespec="seconds")
    lines = ["# Benchmark report", "",
             (f"Rebuilt {rebuilt} from {len(entries)} registered run(s) in `.relab/results/`. "
              f"Do not edit: `relab code report` rebuilds it."), ""]
    suites: dict[str, list[dict[str, object]]] = {}
    for entry in entries:
        suites.setdefault(str(entry.get("suite")), []).append(entry)
    for suite, runs in sorted(suites.items()):
        runs = sorted(runs, key=lambda item: str(item.get("started_at")), reverse=True)
        lines += [f"## {suite}", "",
                  "| started | label | model | effort | commit | solved | mean s | cost | failures |",
                  "|---|---|---|---|---|---|---|---|---|"]
        for entry in runs:
            failures = entry.get("failures") or {}
            named = ", ".join(f"{name} {count}" for name, count in failures.items()) \
                if isinstance(failures, dict) else ""
            cost = entry.get("total_cost")
            lines.append("| " + " | ".join(_cell(value) for value in (
                str(entry.get("started_at"))[:16].replace("T", " "), entry.get("label"),
                entry.get("model"), entry.get("reasoning_effort"), entry.get("commit"),
                _rate(entry.get("solved"), entry.get("runs")), entry.get("mean_seconds"),
                f"${cost:.2f}" if isinstance(cost, (int, float)) else None, named)) + " |")
        for reference in references.get(suite, []):
            lines.append("| reference | " + " | ".join(_cell(value) for value in (
                reference.get("name"), reference.get("model"), None, None,
                reference.get("value"), None, None, reference.get("note"))) + " |")
        lines.append("")
        shown = [(entry, registry.result(entry)) for entry in runs[:TABLE_RUNS]]
        shown = [(entry, result) for entry, result in shown if result is not None]
        if shown:
            lines += (_task_table(shown) + _category_table(shown) + _repeat_table(shown)
                      + _failure_table(shown) + _navigation_table(shown))
    if not suites:
        lines.append("No runs registered yet. `relab code bench ... --out FILE` registers "
                     "each run; `relab code results --register FILE` registers an old one.")
    return "\n".join(lines).rstrip() + "\n"


def _task_table(shown: list[tuple[dict[str, object], BenchResult | None]]) -> list[str]:
    tasks = sorted({run.task for _, result in shown if result for run in result.runs})
    head = "| task | " + " | ".join(_cell(entry.get("label")) for entry, _ in shown) + " |"
    lines = ["### Tasks, run by run", "", head, "|---|" + "---|" * len(shown)]
    for task in tasks:
        cells = []
        for _, result in shown:
            runs = [run for run in (result.runs if result else []) if run.task == task]
            if not runs:
                cells.append("")
                continue
            solved = sum(run.solved for run in runs)
            mark = "✅" if solved == len(runs) else "❌" if solved == 0 else "◐"
            why = sorted({failure(run) or "" for run in runs if not run.solved} - {""})
            cells.append(f"{mark} {solved}/{len(runs)}" + (f" ({', '.join(why)})" if why else ""))
        lines.append(f"| {task} | " + " | ".join(cells) + " |")
    return lines + [""]


def _category_table(shown: list[tuple[dict[str, object], BenchResult | None]]) -> list[str]:
    categories = sorted({run.category or "uncategorised" for _, result in shown if result
                         for run in result.runs})
    if categories == ["uncategorised"]:
        return []
    head = "| category | " + " | ".join(_cell(entry.get("label")) for entry, _ in shown) + " |"
    lines = ["### By category", "", head, "|---|" + "---|" * len(shown)]
    for category in categories:
        cells = []
        for _, result in shown:
            runs = [run for run in (result.runs if result else [])
                    if (run.category or "uncategorised") == category]
            cells.append(_rate(sum(run.solved for run in runs), len(runs)) if runs else "")
        lines.append(f"| {category} | " + " | ".join(cells) + " |")
    return lines + [""]


def _repeat_table(shown: list[tuple[dict[str, object], BenchResult | None]]) -> list[str]:
    """Solved by repeat, when any run repeated: with lessons carried, the measure of M6.5."""
    repeats = sorted({run.repeat for _, result in shown if result for run in result.runs})
    if len(repeats) < 2:
        return []
    head = "| repeat | " + " | ".join(_cell(entry.get("label")) for entry, _ in shown) + " |"
    lines = ["### By repeat", "", head, "|---|" + "---|" * len(shown)]
    for repeat in repeats:
        cells = []
        for _, result in shown:
            runs = [run for run in (result.runs if result else []) if run.repeat == repeat]
            cells.append(_rate(sum(run.solved for run in runs), len(runs)) if runs else "")
        lines.append(f"| {repeat} | " + " | ".join(cells) + " |")
    return lines + [""]


def _failure_table(shown: list[tuple[dict[str, object], BenchResult | None]]) -> list[str]:
    groups = sorted(set(FAILURE_GROUP.values()))
    head = "| failures by whose | " + " | ".join(
        _cell(entry.get("label")) for entry, _ in shown) + " |"
    lines = ["### Why runs failed", "", head, "|---|" + "---|" * len(shown)]
    for group in groups:
        cells = []
        for _, result in shown:
            count = sum(1 for run in (result.runs if result else [])
                        if not run.solved and FAILURE_GROUP.get(failure(run) or "") == group)
            cells.append(str(count))
        if any(cell != "0" for cell in cells):
            lines.append(f"| {group} | " + " | ".join(cells) + " |")
    return lines + [""]


def _median(values: list[int]) -> str:
    return "–" if not values else f"{statistics.median(values):g}"


def _navigation_table(shown: list[tuple[dict[str, object], BenchResult | None]]) -> list[str]:
    """How the locate tasks were found, run by run (M5.5): medians, and why the misses missed.

    Only the runs that recorded their navigation, of tasks that say what is
    relevant: older results, and other tasks, are left out rather than shown
    as zeros.
    """
    def scored(result: BenchResult | None) -> list[BenchRun]:
        return [run for run in (result.runs if result else []) if run.navigation is not None
                and run.category == "locate"]

    tasks = sorted({run.task for _, result in shown for run in scored(result)})
    if not tasks:
        return []
    head = " | ".join(_cell(entry.get("label")) for entry, _ in shown)
    lines = ["### Finding the way (locate tasks)", "",
             ("Per cell, medians over the task's runs: the step that first touched a relevant "
              "file, steps before the first edit, searches (references included), files read (of "
              "them irrelevant), "
              "and runs that changed files they had no need to."), "",
             f"| task | {head} |", "|---|" + "---|" * len(shown)]
    for task in tasks:
        cells = []
        for _, result in shown:
            runs = [run for run in scored(result) if run.task == task]
            found = [run.navigation for run in runs if run.navigation is not None]
            if not found:
                cells.append("")
                continue
            cut = " · list cut" if any(item.listing_cut for item in found) else ""
            cells.append(
                f"first {_median([item.first_relevant_step for item in found if item.first_relevant_step])}"
                f" · edit after {_median([item.steps_before_first_edit for item in found if item.steps_before_first_edit is not None])}"
                f" · search {_median([item.search_calls + item.references_calls for item in found])}"
                f" · read {_median([item.files_read for item in found])}"
                f" ({_median([item.irrelevant_files_read for item in found])})"
                f" · extra {sum(bool(item.unnecessary_files_modified) for item in found)}{cut}")
        lines.append(f"| {task} | " + " | ".join(cells) + " |")
    lines += ["", f"| missed because | {head} |", "|---|" + "---|" * len(shown)]
    for name in LOCATE_CLASSES:
        cells = [str(sum(run.locate == name for run in scored(result))) for _, result in shown]
        if any(cell != "0" for cell in cells):
            lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return lines + [""]
