"""Commands a person has said to run without asking again, by their shape.

A command the policy asks about (`command_policy.CommandClass.ASK`) stops the
loop until the person allows it. A loop that runs `npm install` six times, or
its own `python -m report_summary_agent` after every edit, asked six times.
So the card offers "always allow" for the command's shape -- its program and
the words that say what it does (`npm install`, `git commit`, `python -m
report_summary_agent`) -- and a rule kept here lets every later command of that
shape run as an allowed one.

What a rule can never do is reach a refused command: a shell given a string,
deleting, pushing or rewriting history are refused before any rule is read.
And a rule is the person's: written only when they press the button, listed
and removable, kept in this workspace's `.relab/command_rules.json`.
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path

from relab_workspace.private_state import state_dir

RULES_FILE = "command_rules.json"
MAXIMUM_RULES = 200


def _name(program: str) -> str:
    return os.path.basename(program).lower().removesuffix(".exe").removesuffix(".cmd") \
        .removesuffix(".bat")


def shape(argv: list[str]) -> list[str]:
    """The words of a command that say what it does, as a rule would match them.

        python -m pip install x     ->  python -m pip
        python -c "..."             ->  python -c          (any code)
        python tools/build.py       ->  python tools/build.py
        npm run build               ->  npm run build
        npm install x               ->  npm install
        git commit -m "..."         ->  git commit
        docker build .              ->  docker build
    """
    if not argv:
        return []
    name = _name(argv[0])
    rest = argv[1:]
    if name in {"python", "python3", "py"}:
        name = "python"
        if rest[:1] in (["-m"],) and len(rest) > 1:
            return [name, "-m", rest[1]]
        if rest[:1] == ["-c"]:
            return [name, "-c"]
        return [name, *rest[:1]]
    if name == "mcp":
        # A server's tool is allowed by the server and the tool.
        return [name, *rest[:2]]
    if name == "read":
        # A folder outside the workspace is allowed by the folder (0.2.24).
        return [name, *rest[:1]]
    if name == "fetch":
        # A page from the web is allowed by its site.
        from relab_app.web_fetch import host_of

        return [name, host_of(rest[0])] if rest else [name]
    if name in {"npm", "pnpm", "yarn"} and rest[:1] == ["run"] and len(rest) > 1:
        return [name, "run", rest[1]]
    word = next((item for item in rest if not item.startswith("-")), None)
    return [name] if word is None else [name, word]


def matches(argv: list[str], prefix: list[str]) -> bool:
    """Whether a command has a rule's shape: the same program, and the same leading words."""
    if not argv or not prefix:
        return False
    name = _name(argv[0])
    if name in {"python3", "py"}:
        name = "python"
    if name == "read" and prefix[0] == "read":
        # The folder allowed, and everything under it.
        if len(prefix) != 2 or len(argv) < 2:
            return False
        folder, asked = prefix[1].rstrip("/"), argv[1].rstrip("/")
        return asked == folder or asked.startswith(folder + "/")
    return shape(argv)[:len(prefix)] == prefix and name == prefix[0]


class CommandRules:
    """The rules of one workspace, read fresh each time: a person may remove one by hand."""

    def __init__(self, workspace: Path) -> None:
        self.path = state_dir(workspace) / RULES_FILE

    def rules(self) -> list[dict[str, object]]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        found = data.get("rules") if isinstance(data, dict) else None
        return [item for item in found or []
                if isinstance(item, dict) and isinstance(item.get("prefix"), list)
                and all(isinstance(word, str) and word for word in item["prefix"])
                and item["prefix"]]

    def matching(self, argv: list[str]) -> list[str] | None:
        """The rule a command falls under, or None."""
        for item in self.rules():
            found = item["prefix"]
            prefix = [str(word) for word in found] if isinstance(found, list) else []
            if matches(argv, prefix):
                return prefix
        return None

    def add(self, prefix: list[str]) -> None:
        if not prefix or not all(isinstance(word, str) and word for word in prefix):
            raise ValueError("a rule names a program and what it does")
        rules = [item for item in self.rules() if item["prefix"] != prefix]
        if len(rules) >= MAXIMUM_RULES:
            raise ValueError(f"at most {MAXIMUM_RULES} rules; remove one first")
        rules.append({"prefix": prefix, "added_at": datetime.now(timezone.utc).isoformat()})
        self._write(rules)

    def remove(self, prefix: list[str]) -> bool:
        rules = self.rules()
        kept = [item for item in rules if item["prefix"] != prefix]
        if len(kept) == len(rules):
            return False
        self._write(kept)
        return True

    def _write(self, rules: list[dict[str, object]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps({"rules": rules}, ensure_ascii=False, indent=2),
                             encoding="utf-8")
        temporary.replace(self.path)
