"""One read that places a session in its lifecycle and names its next operation.

Everything here composes the existing reports over the same stored records. It
decides nothing, records nothing and executes nothing: it says which single
operation would move the session forward, and what currently blocks it.
"""

from pathlib import Path

from relab_app.accounting import ArmAccount, arm_accounts, measurement_blocker
from relab_app.reconciliation import SessionReconciler
from relab_app.runs import CodingRunService
from relab_app.sessions import ResearchSessionService
from relab_core.contracts import RunState
from relab_core.lifecycle import (
    LifecycleAction,
    LifecyclePhase,
    MeasurementBlocker,
    MeasurementClaimBlocker,
    SessionLifecycle,
)
from relab_core.measurement import ClaimDispatchBlocker
from relab_core.reconciliation import ReconciliationDisposition, SessionReconciliation
from relab_core.research import (
    ResearchPlan,
    ResearchSession,
)
from relab_core.runs import PendingHumanGate
from relab_core.sensitivity import ControlFinding
from relab_evaluation.adequacy import claim_blocker
from relab_evaluation.repair import repair_history
from relab_evaluation.sensitivity import assess_sensitivity

# The findings that mean a control's run could not be read at all, each with
# what a person repairing the measurement needs to know. Not the sensitivity
# findings: a separation too small, or one only a model expected, is a reading,
# and what to do about a reading is not decided here. Nor `NO_READING`, which
# includes rulers never asked to declare and readings taken before that was
# recorded, and so cannot say the ruler is at fault.
_CANNOT_CALIBRATE = {
    ControlFinding.UNKNOWN_METRIC:
        "the control names a metric the registry declares no rule for",
    ControlFinding.CALIBRATION_EXECUTION_FAILED:
        "the ruler never reached its own declaration; the command may not have started",
    ControlFinding.CALIBRATION_UNOBSERVABLE:
        "the ruler ran and printed no reading for this control's metric",
}


class SessionLifecycleReader:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.research = ResearchSessionService(self.workspace)
        self.runs = CodingRunService(self.workspace)
        self.reconciler = SessionReconciler(self.workspace)

    def status(self, session_id: str, *, attempts_per_slot: int = 1) -> SessionLifecycle:
        if type(attempts_per_slot) is not int or not 1 <= attempts_per_slot <= 3:
            raise ValueError("attempts_per_slot must be an integer between 1 and 3")
        event = self.research.store.latest(session_id)
        session = event.snapshot
        reconciliation = self.reconciler.diagnose(session_id)
        attached = {reference.run_id for reference in session.runs}
        gates = [gate for gate in self.runs.pending_gates().gates if gate.run_id in attached]
        report = SessionLifecycle(
            session_id=session_id, event_sequence=event.sequence,
            attempts_per_slot=attempts_per_slot,
            # _place always replaces these; this states the position before it runs.
            phase=LifecyclePhase.PLANNING, action=LifecycleAction.NONE,
            detail="the session has not been placed in its lifecycle yet",
            reconciliation=reconciliation, gates=gates,
        )
        plan = session.plan
        # Coverage over records that disagree would be misleading, and reading a
        # damaged pin raises; reconcile first, which is what this report will say.
        if reconciliation.consistent and plan is not None and plan.arms:
            report.readiness = self.research.readiness(session_id)
            if report.readiness.ready:
                report.assessment = self.research.assess(session_id)
        self._place(report, session, plan, reconciliation, gates)
        return report

    def _place(
        self, report: SessionLifecycle, session: ResearchSession, plan: ResearchPlan | None,
        reconciliation: SessionReconciliation, gates: list[PendingHumanGate],
    ) -> None:
        """Order matters: a terminal record first, then anything that blocks progress."""
        if session.conclusion is not None:
            report.phase = LifecyclePhase.CONCLUDED
            report.action = LifecycleAction.NONE
            report.detail = (f"the session is concluded as "
                             f"{session.conclusion.decision.value}; reopen it to continue")
            return
        if reconciliation.summary.manual:
            report.phase = LifecyclePhase.NEEDS_RECOVERY
            report.action = LifecycleAction.INSPECT_HISTORY
            report.detail = "records disagree in ways only a person can settle"
            report.blockers = [f"{item.kind.value} on {item.subject}: {item.detail}"
                               for item in reconciliation.findings
                               if item.disposition is ReconciliationDisposition.MANUAL]
            return
        if reconciliation.summary.active:
            report.phase = LifecyclePhase.EXECUTING
            report.action = LifecycleAction.WAIT
            report.detail = "a worker holds exclusion; let it finish before acting"
            return
        if reconciliation.summary.recoverable:
            report.phase = LifecyclePhase.NEEDS_RECOVERY
            report.action = LifecycleAction.RECOVER
            report.detail = "stored records settle every disagreement found"
            return
        if plan is None:
            report.phase = LifecyclePhase.PLANNING
            report.action = LifecycleAction.RECORD_PLAN
            report.detail = "no evaluation policy is pre-registered yet"
            return
        if not plan.arms:
            report.phase = LifecyclePhase.PLANNING
            report.action = LifecycleAction.REVISE_PLAN
            report.detail = "the plan declares no experiment arms to cover"
            return
        if gates:
            report.phase = LifecyclePhase.AWAITING_HUMAN
            report.action = LifecycleAction.RESOLVE_GATE
            report.detail = "an attached run is waiting on a person"
            report.blockers = [f"{gate.run_id}: {gate.reason}" for gate in gates]
            return
        if plan.measurement is not None and session.measurement_snapshot is None:
            # Before anything is dispatched. A measurement built after the first
            # arm ran would be a ruler shaped by a reading it had not taken yet.
            report.phase = LifecyclePhase.DISPATCHING
            report.action = LifecycleAction.MATERIALISE_MEASUREMENT
            # Said as what happens next, because it is offered as the next step:
            # "not built yet" left a person to guess what pressing it would do.
            report.detail = ("the measurement this design declares is to be built and checked "
                             "against its controls before any arm runs")
            return
        report.measurement_sensitivity = assess_sensitivity(
            plan.measurement_controls, session.measurement_control_runs, plan.registry,
            None if session.measurement_snapshot is None
            else session.measurement_snapshot.snapshot_id,
            asked_to_declare=plan.asks_verifier_to_declare())
        uncovered = claim_blocker(session, self.runs.store.load)
        if uncovered is not None and not self._instrument_is_broken(report, session):
            # Before the arm tasks, and for the reason the instrument check is
            # before the budget: an arm with no declared task is worth fixing,
            # and fixing it would not make this study runnable. The ruler is
            # what stops it, and sending somebody to the arm first sends them
            # to the wrong thing.
            #
            # After a broken instrument, though. Both send a person to the same
            # repair, and "this measurement did not measure" is the more basic
            # of the two: a verifier that reported nothing at all did not say
            # what it checks either, and the first sentence explains the second.
            self._place_claims(report, uncovered)
            return
        if self._place_calibration(report, session):
            return
        undeclared = [arm for arm in plan.arms if not self._executable(plan, arm)]
        if undeclared and not (report.readiness is not None and report.readiness.ready):
            report.phase = LifecyclePhase.PLANNING
            report.action = LifecycleAction.DECLARE_ARM_TASKS
            report.detail = "an arm has no targets and verifier to execute"
            report.blockers = [f"{arm} declares no executable task" for arm in undeclared]
            report.blocked_arms = list(undeclared)
            return
        self._place_covered(report, session)

    def _place_covered(self, report: SessionLifecycle, session: ResearchSession) -> None:
        if report.readiness is None or not report.readiness.ready:
            report.phase = LifecyclePhase.DISPATCHING
            report.action = LifecycleAction.EXECUTE
            report.detail = "the declared design still lacks usable evidence"
            uncovered = [arm for arm in (report.readiness.arms if report.readiness else [])
                         if arm.missing]
            report.blockers = [
                f"{arm.arm} needs {arm.missing} more usable run(s)" for arm in uncovered
            ]
            report.blocked_arms = [arm.arm for arm in uncovered]
            self._place_budget(report, session)
            return
        assessment = report.assessment
        if assessment is not None and assessment.passed:
            declared = session.plan is not None and session.plan.holdout_registry is not None
            if declared and session.holdout is None:
                # Acceptance is refused until this has been looked at, so naming
                # `conclude` here would name an operation that cannot be taken.
                report.phase = LifecyclePhase.HOLDOUT
                report.action = LifecycleAction.EVALUATE_HOLDOUT
                report.detail = "the pre-registered rules held; the declared holdout is unopened"
                report.blockers = ["acceptance requires the holdout to have been evaluated"]
                return
            report.phase = LifecyclePhase.CONCLUDING
            report.action = LifecycleAction.CONCLUDE
            report.detail = "every pre-registered rule held; record a decision"
            if assessment.identical_everywhere:
                # The rules held over evidence that separates nothing. Saying only
                # that they held is true and reads as a finding, so what a person
                # is about to record a decision against is said here too.
                report.detail = (
                    "the pre-registered rules held, but "
                    + ", ".join(assessment.identical_everywhere)
                    + " took one value in every run; record a decision knowing that"
                )
                report.blockers = [assessment.reason]
            return
        report.phase = LifecyclePhase.ASSESSING
        report.action = LifecycleAction.CONCLUDE
        report.detail = "the design is covered but its pre-registered rules did not hold"
        report.blockers = [assessment.reason] if assessment is not None else []

    def _place_budget(self, report: SessionLifecycle, session: ResearchSession) -> None:
        """Read execute's own account; a status read never grants more attempts.

        The same projection the executor spends from, rather than a second
        count that agrees by inspection. They disagreed the moment an invalid
        measurement stopped spending a repeat in one of them.
        """
        if session.plan is None or report.readiness is None:
            return
        limit = session.plan.repeats_per_arm * report.attempts_per_slot
        accounts = arm_accounts(session, report.readiness, self.runs.store.load)
        broken = measurement_blocker(accounts)
        if broken is not None:
            # Before the budget, because the budget is not what stopped this and
            # saying so would send a person to change the wrong thing.
            self._place_instrument(report, broken)
            return
        pending = [arm.arm for arm in report.readiness.arms if not arm.satisfied]
        for arm in pending:
            attached = accounts[arm].standing
            states = [(ref.run_id, self.runs.store.load(ref.run_id).state)
                      for ref in attached[:limit]]
            for run_id, state in states:
                if state == RunState.DEPENDENCY_INSTALLED:
                    report.blockers.append(f"{run_id} is installed and awaits continuation")
            if len(attached) >= limit and not any(
                state in {RunState.CREATED, RunState.DEPENDENCY_INSTALLED}
                for _, state in states
            ):
                report.exhausted_arms.append(arm)
                report.blockers.append(f"{arm} has exhausted its {limit} eligible attempt(s)")
                _also_blocked(report, arm)
        # Gathered before the budget check, so that when both stop the session the
        # record still says *why* the attempts went nowhere. "Budget spent" and
        # "the same failure three times" are not equally useful to read.
        self._place_stuck(report, accounts, pending)
        if pending and len(report.exhausted_arms) == len(pending):
            report.phase = LifecyclePhase.BUDGET_EXHAUSTED
            report.action = LifecycleAction.REVIEW_BUDGET
            report.detail = "no uncovered arm can advance within the selected attempt budget"
        elif pending and len(report.stuck_arms) == len(pending):
            report.action = LifecycleAction.REVIEW_FAILURES
            report.detail = ("every uncovered arm keeps hitting the same failure; "
                             "change the task, the model, or stop")

    @staticmethod
    def _place_calibration(report: SessionLifecycle, session: ResearchSession) -> bool:
        """Calibrate before any arm, and stop when the ruler could not be run on a control.

        Which controls are pending is read per control under the ruler in
        force, not from the coarse status: a calibration interrupted after
        one control resumes at the next rather than reading as done or not.

        Once they have all run, three findings stop the study, and only those
        three. They are not judgements about sensitivity -- whether the ruler
        separates enough is still for MQ2.5 to decide -- but facts about
        whether the ruler could be run and read at all. A live study froze a
        verifier that could not import its own reference data and then spent
        six attempts on it; calibrated first, it would have stopped here with
        no arm run.
        """
        plan, frozen = session.plan, session.measurement_snapshot
        if (plan is None or not plan.measurement_controls or frozen is None
                or frozen.snapshot_id is None):
            return False
        done = {item.control_id for item in session.measurement_control_runs
                if item.snapshot_id == frozen.snapshot_id}
        pending = [item.control_id for item in plan.measurement_controls
                   if item.control_id not in done]
        if pending:
            report.phase = LifecyclePhase.DISPATCHING
            report.action = LifecycleAction.CALIBRATE_MEASUREMENT
            report.detail = "the frozen measurement has not been run against its controls yet"
            report.blockers = [f"{control} has not been calibrated" for control in pending]
            return True
        read = report.measurement_sensitivity
        unrunnable = [] if read is None else [
            item for item in read.outcomes if item.finding in _CANNOT_CALIBRATE]
        # And one reading that is not a matter of degree: the working subject
        # measured no better than the broken one. A separation short of what
        # was asked is for MQ2 to weigh; none at all, or the wrong way, is a
        # ruler that cannot tell working code from broken, and every arm it
        # measured would score the same whatever was written. A live verifier
        # called `predict(input)` while the design and both subjects defined
        # `check_pair(image_bytes, ocr_text)`: every check failed, both
        # subjects read 0.0, and six paid attempts ran that could only read 0.0.
        blind = [] if read is None else [
            item for item in read.outcomes
            if item.finding is ControlFinding.INSUFFICIENT_SEPARATION
            and item.separation is not None and item.separation <= 0]
        if not unrunnable and blind:
            report.phase = LifecyclePhase.NEEDS_MEASUREMENT_REPAIR
            report.action = LifecycleAction.REVISE_MEASUREMENT
            report.detail = (
                "no experiment was run: the measurement scored the working and the broken "
                "subject of its controls the same, so it cannot tell working code from broken, "
                "and every arm would be measured by the same file")
            report.blockers = [
                f"{item.control_id}: the working subject measured {item.good_value:g} and the "
                f"broken one {item.bad_value:g} on {item.metric}; either the verifier does "
                f"not exercise what the design declares, or this control's subjects do not "
                f"differ where it looks"
                if item.good_value is not None and item.bad_value is not None else
                f"{item.control_id}: no separation on {item.metric}"
                for item in blind]
            return True
        if not unrunnable:
            return False
        report.phase = LifecyclePhase.NEEDS_MEASUREMENT_REPAIR
        report.action = LifecycleAction.REVISE_MEASUREMENT
        # Said with the metric's name, because "printed no reading" alone sends a
        # person to read the verifier, when the usual cause is one line in it: a
        # reused verifier that prints another metric than this design reads.
        metrics = sorted({item.metric for item in unrunnable})
        report.detail = (
            f"no experiment was run: the measurement could not be read on its controls "
            f"(it produced no {', '.join(metrics)}), and every arm would be measured by "
            f"the same file")
        report.blockers = [f"{item.control_id}: {_CANNOT_CALIBRATE[item.finding]} ({item.metric})"
                           for item in unrunnable]
        return True

    def _instrument_is_broken(
        self, report: SessionLifecycle, session: ResearchSession,
    ) -> bool:
        """Whether the measurement also failed the contract it was asked to keep.

        Asked here only to decide which of two true findings to lead with. The
        blocker itself is still produced where it always was, from the same
        accounts the executor spends from, so there is one judgement and not two.
        """
        if report.readiness is None:
            return False
        return measurement_blocker(
            arm_accounts(session, report.readiness, self.runs.store.load)) is not None

    @staticmethod
    def _place_claims(report: SessionLifecycle, uncovered: MeasurementClaimBlocker) -> None:
        """Say that the ruler does not cover the study, and what kind of not.

        Same phase and same action as a broken instrument, because neither is
        repaired by running another arm. Different data, because they ask a
        person for different work: one needs a verifier that checks something,
        the other needs one that says what it checks.
        """
        report.phase = LifecyclePhase.NEEDS_MEASUREMENT_REPAIR
        report.action = LifecycleAction.REVISE_MEASUREMENT
        report.measurement_claim_blocker = uncovered
        if uncovered.blocker is ClaimDispatchBlocker.CLAIMS_INCOMPLETE:
            report.detail = ("this study\'s measurement does not claim to check "
                             "everything the design declared; running the arms again "
                             "cannot repair the ruler that measures them")
            report.blockers.append(
                "the measurement claims to check none of: "
                + ", ".join(uncovered.uncovered_requirement_ids))
            return
        report.detail = ("this study\'s measurement has run without ever saying which "
                         "requirements it checks; running the arms again cannot make "
                         "it answer")
        report.blockers.append(
            "the measurement declared no requirement coverage in "
            f"{len(uncovered.opportunity_run_ids)} verification(s)")

    @staticmethod
    def _place_instrument(report: SessionLifecycle, broken: MeasurementBlocker) -> None:
        """Say that the ruler is what stopped this, and that rerunning cannot fix it.

        The sentence a person got before this was "no uncovered arm can advance
        within the selected attempt budget", which is true of the state and
        wrong about the cause. It sends somebody to look at the budget, the
        model or the task, and the verifier is what needs changing.
        """
        report.phase = LifecyclePhase.NEEDS_MEASUREMENT_REPAIR
        report.action = LifecycleAction.REVISE_MEASUREMENT
        report.detail = ("this study's frozen measurement did not measure; running the "
                         "arms again cannot repair it, because they are all measured by "
                         "that same file")
        report.measurement_blocker = broken
        report.blockers.append(
            "the frozen measurement is invalid ("
            + ", ".join(item.value for item in broken.invalidities)
            + f") in {len(broken.affected_runs)} run(s)")
        for arm in broken.affected_arms:
            _also_blocked(report, arm)

    def _place_stuck(
        self, report: SessionLifecycle, accounts: dict[str, ArmAccount], pending: list[str],
    ) -> None:
        """Name the arms hitting one failure over and over.

        Attempts remain -- this is not the budget running out. What has run out is
        the reason to believe another identical attempt will land differently, and
        spending the rest of the budget proving that is what this prevents.

        Nothing escalates on its own. A different model is a cost nobody approved
        on a schedule nobody set, so what happens here is that a person is told.
        """
        for arm in pending:
            attached = [ref.run_id for ref in accounts[arm].standing]
            if not attached:
                continue
            runs = [item for item in (report.readiness.arms if report.readiness else [])
                    if item.arm == arm]
            if not runs:
                continue
            snapshots = {run_id: self.runs.store.load(run_id) for run_id in attached}
            history = repair_history(report.session_id, arm, runs[0].runs, snapshots)
            digest = history.stuck_on
            if digest is None:
                continue
            report.stuck_arms.append(arm)
            report.blockers.append(
                f"{arm} has hit the same failure {len(history.matching(digest))} times; "
                f"another attempt like the last will not land differently")
            _also_blocked(report, arm)

    @staticmethod
    def _executable(plan: ResearchPlan, arm: str) -> bool:
        return any(task.arm == arm and task.targets and task.verify_argv
                   for task in plan.arm_tasks)



def _also_blocked(report: SessionLifecycle, arm: str) -> None:
    """Name an arm once, however many blockers happen to be about it."""
    if arm not in report.blocked_arms:
        report.blocked_arms.append(arm)
