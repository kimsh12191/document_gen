"""Public coding benchmarks, turned into tasks of `relab code bench`'s own shape.

Our twenty tasks say how ReLab does against itself; a public suite says how it
does against other agents with the same model. This reads one such suite where
a person downloaded it and writes each problem as a task folder (`repo/`,
`check/`, `task.json`, and `solution/` for calibration), so the runner, its
traces and `bench-compare` work unchanged. Nothing is downloaded here.

Aider's polyglot benchmark (github.com/Aider-AI/polyglot-benchmark): Exercism
exercises, each a stub, its instructions and its tests. Converted as Aider's
own harness asks: the instructions (introduction, instructions, appended
notes) and the stub are shown, the tests are not, and the stub's names are to
be kept. Aider reports two numbers, the first try and a second try shown the
failing tests; a ReLab run is one try, so compare with its first.

InfiAgent-DABench (github.com/InfiAgent/InfiAgent, examples/DA-Agent/data,
0.3.39): data analysis questions on CSV files, each with closed-form answers
`@name[value]`. Converted as its `eval_closed_form.py` scores: the question,
its constraints and its answer format are shown with the CSV; the loop writes
`answer.txt`, and the hidden check reads it with the same pattern and calls an
answer right when it is the label's text, or a number within 1e-6 of it. A task
passes when every answer of its question is right ("accuracy by question");
each answer is its own test, so a check's output also counts the sub-answers.
DABench's own runs reformat a free reply with another model first; here the
format is the loop's to keep, as for any task.
"""

import json
import shutil
import tempfile
from pathlib import Path

from relab_app.coding_bench import CHECK_FOLDER, BenchTask, _check
from relab_app.project_scope import WHOLE_WORKSPACE

POLYGLOT_REQUEST = (
    "Do the exercise described in @INSTRUCTIONS.md by changing {files}. Keep the names of the "
    "existing functions and classes, and their arguments: tests you cannot see call them. Use "
    "only the standard library; do not install anything.")
INSTRUCTION_FILES = (".docs/introduction.md", ".docs/instructions.md",
                     ".docs/instructions.append.md")


def import_polyglot(source: Path, out: Path, *, language: str = "python",
                    only: list[str] | None = None) -> list[str]:
    """Write each exercise of one language as a task under `out`; their ids, in order."""
    practice = source / language / "exercises" / "practice"
    if not practice.is_dir():
        raise ValueError(f"{practice} is not there: is {source} the polyglot benchmark?")
    out.mkdir(parents=True, exist_ok=True)
    written = []
    for exercise in sorted(item for item in practice.iterdir() if item.is_dir()):
        if only is not None and exercise.name not in only:
            continue
        config = json.loads((exercise / ".meta" / "config.json").read_text(encoding="utf-8"))
        files = config.get("files", {})
        solution, tests, example = files.get("solution", []), files.get("test", []), \
            files.get("example", [])
        if not solution or not tests:
            raise ValueError(f"{exercise.name}: its config names no solution or test files")
        task_id = exercise.name.replace("-", "_")
        folder = out / task_id
        if folder.exists():
            shutil.rmtree(folder)
        for name in solution:
            _copy(exercise / name, folder / "repo" / name)
        for name in files.get("editor", []):
            _copy(exercise / name, folder / "repo" / name)
        (folder / "repo" / "INSTRUCTIONS.md").write_text("\n\n".join(
            (exercise / name).read_text(encoding="utf-8").strip()
            for name in INSTRUCTION_FILES if (exercise / name).is_file()) + "\n",
            encoding="utf-8")
        for name in tests:
            _copy(exercise / name, folder / "check" / Path(name).name)
        if len(solution) == 1 and len(example) == 1:
            _copy(exercise / example[0], folder / "solution" / solution[0])
        task = BenchTask(id=task_id, kind="exercise", request=POLYGLOT_REQUEST.format(
            files=", ".join(solution)))
        (folder / "task.json").write_text(
            json.dumps(task.model_dump(mode="json", exclude_defaults=True), indent=2) + "\n",
            encoding="utf-8")
        written.append(task_id)
    return written


DABENCH_FILES = ("da-dev-questions.jsonl", "da-dev-labels.jsonl", "da-dev-tables")
DABENCH_REQUEST = (
    "Answer the data analysis question in @QUESTION.md from the data in {data}. Work it out by "
    "running code on the data; use the Python libraries already installed and do not install "
    "anything. Then write the final answer to answer.txt at the top of the workspace, one line "
    "for each answer, exactly in the form QUESTION.md gives -- @name[value] -- rounded and spelled "
    "as it asks: answers are compared to the expected ones exactly.")
DABENCH_CHECK = '''"""The closed-form answers of DABench question {id}, scored as eval_closed_form.py scores them."""

import re
from pathlib import Path

import pytest

EXPECTED = {expected}


def given():
    found = Path(__file__).resolve().parent.parent / "answer.txt"
    text = found.read_text(encoding="utf-8") if found.is_file() else ""
    return dict(re.findall(r"@(\\w+)\\[(.*?)\\]", text))


def is_equal(response, label):
    if response == label:
        return True
    try:
        return abs(float(response) - float(label)) < 1e-6
    except Exception:  # noqa: BLE001 -- no answer, or not a number: wrong, as DABench scores it
        return False


@pytest.mark.parametrize("name", sorted(EXPECTED))
def test_answer(name):
    answers = given()
    assert name in answers, f"answer.txt has no @{{name}}[...]"
    assert is_equal(answers[name], EXPECTED[name]), f"@{{name}}[{{answers[name]}}] is not the expected one"
'''


def _dabench_data(source: Path) -> Path:
    """The folder holding DABench's questions, labels and tables: `source`, or where the repository keeps it."""
    for folder in (source, source / "data", source / "examples" / "DA-Agent" / "data"):
        if all((folder / name).exists() for name in DABENCH_FILES):
            return folder
    raise ValueError(f"no {', '.join(DABENCH_FILES)} under {source}: is it InfiAgent's DA-Agent data, "
                     f"or the InfiAgent repository?")


def _jsonl(path: Path) -> list[dict[str, object]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def import_dabench(source: Path, out: Path, *, only: list[str] | None = None,
                   level: str | None = None) -> list[str]:
    """Write each DABench question that has its labels as a task under `out`; their ids, in order.

    `only`: question ids, as DABench numbers them; `level`: easy, medium or hard.
    """
    data = _dabench_data(source)
    labels = {item["id"]: item["common_answers"] for item in _jsonl(data / "da-dev-labels.jsonl")}
    out.mkdir(parents=True, exist_ok=True)
    written = []
    for question in _jsonl(data / "da-dev-questions.jsonl"):
        number = question["id"]
        if only is not None and str(number) not in only:
            continue
        if level is not None and question.get("level") != level:
            continue
        answers = labels.get(number)
        if not isinstance(answers, list) or not answers:
            continue
        expected = {str(pair[0]): str(pair[1]) for pair in answers}
        task_id = f"dabench_{number}"
        folder = out / task_id
        if folder.exists():
            shutil.rmtree(folder)
        table = str(question["file_name"])
        _copy(data / "da-dev-tables" / table, folder / "repo" / "data" / table)
        (folder / "repo" / "QUESTION.md").write_text("\n\n".join(part for part in (
            f"# Question\n\n{question['question']}",
            f"## Constraints\n\n{question.get('constraints') or '-'}",
            f"## Answer format\n\n{question.get('format') or '-'}",
            f"## Data\n\ndata/{table}") if part) + "\n", encoding="utf-8")
        (folder / "check").mkdir(parents=True)
        (folder / "check" / "test_answer.py").write_text(
            DABENCH_CHECK.format(id=number, expected=repr(expected)), encoding="utf-8")
        (folder / "solution").mkdir()
        (folder / "solution" / "answer.txt").write_text(
            "".join(f"@{name}[{value}]\n" for name, value in expected.items()), encoding="utf-8")
        # The answer is written at the top: the whole workspace is the project, so
        # "data/<csv>" in the request does not make data/ one.
        task = BenchTask(id=task_id, kind="analysis", category=str(question.get("level") or "") or None,
                         scope=WHOLE_WORKSPACE,
                         request=DABENCH_REQUEST.format(data=f"data/{table}"))
        (folder / "task.json").write_text(
            json.dumps(task.model_dump(mode="json", exclude_defaults=True), indent=2) + "\n",
            encoding="utf-8")
        written.append(task_id)
    return written


def calibrate(folder: Path) -> dict[str, object]:
    """Whether a task's check fails on its start and passes on its solution, by exit code."""
    task = BenchTask.model_validate_json((folder / "task.json").read_text(encoding="utf-8"))
    found: dict[str, object] = {"task": task.id}
    with tempfile.TemporaryDirectory(prefix="relab-calibrate-") as scratch:
        start = Path(scratch) / "start"
        shutil.copytree(folder / "repo", start)
        found["start"] = _check(task, folder, start)[0]
        if (folder / "solution").is_dir():
            solved = Path(scratch) / "solved"
            shutil.copytree(folder / "repo", solved)
            shutil.copytree(folder / "solution", solved, dirs_exist_ok=True)
            found["solved"] = _check(task, folder, solved)[0]
    found["calibrated"] = found["start"] != 0 and found.get("solved", 0) == 0
    return found


def _copy(source: Path, target: Path) -> None:
    if not source.is_file():
        raise ValueError(f"{source} is named by its exercise and is not there")
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


__all__ = ["CHECK_FOLDER", "calibrate", "import_dabench", "import_polyglot"]
