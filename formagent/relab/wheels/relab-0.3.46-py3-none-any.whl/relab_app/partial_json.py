"""A string field read out of JSON that has only partly arrived.

A streamed step comes in pieces: `{"thought": "Reading the cli, th` before the
rest. To show a person what is being written while it is written, the value of
one field is read as far as it has come -- the last such field, since a reply
in text can hold several steps -- with JSON's escapes undone, and an escape cut
in half left out. Nothing here is believed: the step it becomes is parsed and
checked whole, as before.
"""

import re

ESCAPES = {'"': '"', "\\": "\\", "/": "/", "b": "\b", "f": "\f", "n": "\n", "r": "\r", "t": "\t"}


def partial_field(text: str, field: str) -> str | None:
    """The value so far of the last string field `field` in `text`; None when it has not begun."""
    starts = list(re.finditer(rf'"{re.escape(field)}"\s*:\s*"', text))
    if not starts:
        return None
    out: list[str] = []
    index = starts[-1].end()
    while index < len(text):
        char = text[index]
        if char == '"':
            break
        if char != "\\":
            out.append(char)
            index += 1
            continue
        if index + 1 >= len(text):
            break
        code = text[index + 1]
        if code == "u":
            digits = text[index + 2:index + 6]
            if len(digits) < 4:
                break
            try:
                out.append(chr(int(digits, 16)))
            except ValueError:
                pass
            index += 6
            continue
        out.append(ESCAPES.get(code, code))
        index += 2
    return "".join(out)
