"""Reviewing one recorded attempt's change.

Reads the run's stored proposal and asks a model whether the edit did the work or
satisfied the measurement. It writes nothing. A review is an unevidenced claim
about an artefact, and the moment it were recorded beside the evidence it would
start being read as some.
"""

from pathlib import Path

from relab_core.review import PatchReview
from relab_research.review import LLMPatchReviewer
from relab_workspace.run_store import RunStore


class PatchReviews:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.runs = RunStore(self.workspace)

    def review(self, run_id: str, reviewer: LLMPatchReviewer) -> PatchReview:
        """Review the change this run proposed. Nothing is recorded, ever.

        There is no `record` beside this, unlike every other proposing act here.
        A proposal, a finding and an amendment all have somewhere to be accepted
        *to*; a review has nowhere, on purpose. It is read by a person and then it
        is gone, which is the only way an opinion about an artefact cannot end up
        sitting next to measurements and being read as one of them.
        """
        run = self.runs.load(run_id)
        if run.proposal is None:
            raise ValueError(f"run proposed no change to review: {run_id}")
        return reviewer.review(run_id, run.objective, run.proposal)
