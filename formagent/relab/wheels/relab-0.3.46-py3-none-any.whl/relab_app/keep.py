"""Putting the code a finished study chose back where it was written.

A study in a folder without Git undoes every attempt after measuring it, so
each starts from where the last began (`arms_share_one_tree`). That is right
while the study runs and leaves nothing behind when it ends: a live study wrote
six implementations, measured every one at 1.0, and finished with an empty
project folder.

Nothing new has to be produced to fix that. Every attempt's files were kept,
before and after, by digest, so keeping a result is writing one attempt's
recorded *after* state back -- the exact bytes that were measured, not a
regeneration of them.

Which attempt is decided from the records, never sent by a client:

    accepted                   the candidate arm
    rejected, inconclusive     the baseline arm
    abandoned                  nothing; nobody decided anything worth keeping

and within the arm, the usable attempt that scored best on the first declared
rule, the latest of those that tie.

And it is written only onto the tree that attempt started from. Each file has to
be as the attempt found it -- absent where it created one -- or as it left it,
which means the result is already kept. Anything else is somebody's work since,
and nothing here overwrites that: the whole keep is refused, and nothing is
written.
"""

import hashlib
from pathlib import Path

from pydantic import Field

from relab_app.runs import CodingRunService
from relab_app.sessions import ResearchSessionService
from relab_core.contracts import Contract
from relab_core.evaluation import MetricDirection
from relab_core.research import ResearchDecision
from relab_core.snapshots import FileSnapshot
from relab_workspace.private_state import state_dir
from relab_workspace.snapshot_store import SnapshotStore


class KeptResult(Contract):
    """Which attempt was kept, and which files it wrote."""

    session_id: str = Field(min_length=1)
    arm: str = Field(min_length=1)
    run_id: str = Field(min_length=1)
    paths: list[str] = Field(default_factory=list)
    # The deciding metric's value for that attempt, as a person reads it.
    metric: str | None = None
    value: float | None = None


class ResultKeeper:
    def __init__(self, workspace: Path, sessions: ResearchSessionService | None = None,
                 runs: CodingRunService | None = None) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.sessions = sessions or ResearchSessionService(self.workspace)
        self.runs = runs or CodingRunService(self.workspace)

    def chosen(self, session_id: str) -> KeptResult | None:
        """The attempt a finished study's decision points at, or None.

        A tie keeps the best attempt of either arm -- the one already written
        for review -- since neither was shown better and what was read is what
        stays.
        """
        session = self.sessions.store.latest(session_id).snapshot
        conclusion, plan = session.conclusion, session.plan
        if conclusion is None or plan is None:
            return None
        if conclusion.decision is ResearchDecision.ACCEPTED:
            arms = [plan.candidate_arm]
        elif conclusion.decision is ResearchDecision.REJECTED:
            arms = [plan.baseline_arm]
        elif conclusion.decision is ResearchDecision.INCONCLUSIVE:
            arms = [plan.candidate_arm, plan.baseline_arm]
        else:
            return None
        return self._best(session_id, [arm for arm in arms if arm is not None])

    def _best(self, session_id: str, arms: list[str]) -> KeptResult | None:
        """The usable attempt best on the first rule; the candidate, then latest, on ties."""
        plan = self.sessions.store.latest(session_id).snapshot.plan
        if plan is None or not arms:
            return None
        rule = plan.registry.rules[0] if plan.registry.rules else None
        best: tuple[float, int, int, str, str] | None = None
        readiness = self.sessions.readiness(session_id)
        order = 0
        for found in readiness.arms:
            if found.arm not in arms:
                continue
            preferred = 1 if found.arm == plan.candidate_arm else 0
            for run in found.runs:
                order += 1
                if not run.usable or not self._keepable(run.run_id):
                    continue
                value = self._value(run.run_id, None if rule is None else rule.name)
                score = 0.0 if value is None else (
                    -value if rule is not None and rule.direction is MetricDirection.MINIMIZE
                    else value)
                if best is None or (score, preferred, order) >= best[:3]:
                    best = (score, preferred, order, run.run_id, found.arm)
        if best is None:
            return None
        run_id, arm = best[3], best[4]
        return KeptResult(
            session_id=session_id, arm=arm, run_id=run_id,
            paths=[item.path for item in self._snapshots(run_id)],
            metric=None if rule is None else rule.name,
            value=None if rule is None else self._value(run_id, rule.name))

    def kept(self, session_id: str) -> bool:
        """Whether the chosen attempt's files are already what is on disk."""
        chosen = self.chosen(session_id)
        return chosen is not None and self._on_disk(chosen.run_id)

    def preview(self, session_id: str) -> KeptResult | None:
        """Write the best attempt for review once the design is covered.

        Before anyone decides: every attempt was undone to keep the tree the
        same for the next, which left a person choosing from a report without
        the code it described. Once the arms are complete, the best of them --
        across both, the candidate on a tie -- is written where it was measured,
        so it can be opened and read first. The decision then settles which
        stays. None when the study is not ready, is decided, or it is on disk.
        """
        session = self.sessions.store.latest(session_id).snapshot
        if session.conclusion is not None or session.plan is None:
            return None
        if not self.sessions.readiness(session_id).ready:
            return None
        plan = session.plan
        best = self._best(session_id, [arm for arm in (plan.candidate_arm, plan.baseline_arm)
                                       if arm is not None])
        if best is None or self._on_disk(best.run_id):
            return None
        self._write(session_id, best.run_id)
        return best

    def withdraw_preview(self, session_id: str) -> bool:
        """Undo a review copy before more attempts run, so they start where the others did."""
        session = self.sessions.store.latest(session_id).snapshot
        if session.conclusion is not None:
            return False
        afters = self._afters(session_id)
        befores: dict[str, str | None] = {}
        for ref in session.runs:
            for item in self._snapshots(ref.run_id):
                befores.setdefault(item.path, item.before_digest)
        written = [path for path in befores
                   if self._current(path) is not None and self._current(path) in afters.get(path, set())]
        if not written:
            return False
        store = SnapshotStore(state_dir(self.workspace) / "snapshots.db")
        for path in written:
            before = befores[path]
            target = self._path(path)
            if before is None:
                target.unlink(missing_ok=True)
                continue
            content = store.get(before)
            if content is None:
                raise ValueError(f"the recorded content of {path} is no longer held here")
            target.write_bytes(content)
        return True

    def keep(self, session_id: str) -> KeptResult:
        """Write the chosen attempt's recorded files back; all of them or none."""
        chosen = self.chosen(session_id)
        if chosen is None:
            raise ValueError(
                "this study has no result to keep: it has not concluded, it was "
                "abandoned, or the arm its decision chose has no usable attempt "
                "whose files were kept")
        self._write(session_id, chosen.run_id)
        return chosen

    def _on_disk(self, run_id: str) -> bool:
        return all(self._current(item.path) == item.after_digest
                   for item in self._snapshots(run_id))

    def _afters(self, session_id: str) -> dict[str, set[str]]:
        """Every state this session's own attempts left each file in."""
        found: dict[str, set[str]] = {}
        for ref in self.sessions.store.latest(session_id).snapshot.runs:
            for item in self._snapshots(ref.run_id):
                if item.after_digest is not None:
                    found.setdefault(item.path, set()).add(item.after_digest)
        return found

    def _write(self, session_id: str, run_id: str) -> None:
        """One attempt's recorded files, onto files that hold nobody's work since.

        A file may be as the attempt found it, as it left it, or as another of
        this study's own attempts left it -- the review copy. Anything else is a
        person's, and refuses the whole write.
        """
        snapshots = self._snapshots(run_id)
        ours = self._afters(session_id)
        changed = [item.path for item in snapshots
                   if self._current(item.path) not in (item.before_digest, item.after_digest)
                   and self._current(item.path) not in ours.get(item.path, set())]
        if changed:
            raise ValueError(
                "these files changed after the study's attempt, and keeping its result "
                "would overwrite that work: " + ", ".join(changed))
        store = SnapshotStore(state_dir(self.workspace) / "snapshots.db")
        contents: list[tuple[Path, bytes | None]] = []
        for item in snapshots:
            target = self._path(item.path)
            if item.after_digest is None:
                contents.append((target, None))
                continue
            content = store.get(item.after_digest)
            if content is None:
                raise ValueError(f"the recorded content of {item.path} is no longer held here")
            contents.append((target, content))
        # Everything is read and checked before anything is written.
        for target, content in contents:
            if content is None:
                target.unlink(missing_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)

    def _keepable(self, run_id: str) -> bool:
        snapshots = self._snapshots(run_id)
        return bool(snapshots) and all(item.omitted is None for item in snapshots)

    def _snapshots(self, run_id: str) -> list[FileSnapshot]:
        evidence = self.runs.store.load(run_id).patch_evidence
        return [] if evidence is None else list(evidence.snapshots)

    def _value(self, run_id: str, metric: str | None) -> float | None:
        if metric is None:
            return None
        try:
            return self.runs.metrics(run_id).metrics.get(metric)
        except (LookupError, ValueError):
            return None

    def _path(self, relative: str) -> Path:
        target = (self.workspace / relative).resolve()
        if not target.is_relative_to(self.workspace):
            raise ValueError(f"{relative} is outside this workspace")
        return target

    def _current(self, relative: str) -> str | None:
        target = self._path(relative)
        if not target.is_file():
            return None
        return hashlib.sha256(target.read_bytes()).hexdigest()
