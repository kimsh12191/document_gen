"""Perform the operations a session's lifecycle names, and stop where a person is needed.

The driver never decides anything. It performs only the mechanical operations —
reconciling records and executing the declared design — and stops at every state
whose next operation is a judgement: resolving a gate, declaring a policy,
inspecting damaged history, or recording a conclusion.
"""

from pathlib import Path

from relab_app.lifecycle import SessionLifecycleReader
from relab_app.reconciliation import SessionReconciler
from relab_app.sessions import MAXIMUM_PARALLEL_ARMS, ResearchSessionService
from relab_core.generation import ModelGateway
from relab_core.lifecycle import LifecycleAction, SessionLifecycle
from relab_core.orchestration import DriveStep, SessionDrive

# Everything else is a judgement, and a driver that made it would be deciding.
MECHANICAL = frozenset({
    LifecycleAction.RECOVER,
    LifecycleAction.MATERIALISE_MEASUREMENT,
    LifecycleAction.CALIBRATE_MEASUREMENT,
    LifecycleAction.EXECUTE,
})
MAXIMUM_STEPS = 10


class SessionDriver:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.reader = SessionLifecycleReader(self.workspace)
        self.reconciler = SessionReconciler(self.workspace)
        self.research = ResearchSessionService(self.workspace)

    def advance(
        self, session_id: str, gateway: ModelGateway, *, max_steps: int = 3,
        attempts_per_slot: int = 1, repair_context: bool = True,
        model_timeout_seconds: float = 60, timeout_seconds: float = 300,
        parallel_arms: int = 1,
    ) -> SessionDrive:
        """Drive the session until a person is needed or the step budget runs out.

        Executing calls a model and costs whatever that provider charges, once per
        step that dispatches. The budget is the only thing that bounds that.
        """
        if type(max_steps) is not int or not 1 <= max_steps <= MAXIMUM_STEPS:
            raise ValueError(f"max_steps must be an integer between 1 and {MAXIMUM_STEPS}")
        if type(parallel_arms) is not int or not 1 <= parallel_arms <= MAXIMUM_PARALLEL_ARMS:
            raise ValueError(
                f"parallel_arms must be an integer between 1 and {MAXIMUM_PARALLEL_ARMS}")
        steps: list[DriveStep] = []
        status = self.reader.status(session_id, attempts_per_slot=attempts_per_slot)
        settled, reason = True, "the session needs no mechanical operation"
        while len(steps) < max_steps:
            if status.action not in MECHANICAL:
                reason = f"the next operation is a judgement: {status.detail}"
                steps.append(_observed(status))
                break
            before = status.event_sequence
            self._perform(session_id, status, gateway, attempts_per_slot=attempts_per_slot,
                          repair_context=repair_context,
                          model_timeout_seconds=model_timeout_seconds,
                          timeout_seconds=timeout_seconds, parallel_arms=parallel_arms)
            steps.append(_performed(status))
            status = self.reader.status(session_id, attempts_per_slot=attempts_per_slot)
            if status.event_sequence == before:
                settled, reason = False, "the operation changed nothing; stopping rather than repeating"
                break
        else:
            settled, reason = False, f"the step budget of {max_steps} was spent"
        return SessionDrive(
            session_id=session_id, max_steps=max_steps, steps=steps,
            settled=settled, stopped_because=reason, final=status,
        )

    def _perform(
        self, session_id: str, status: SessionLifecycle, gateway: ModelGateway, *,
        attempts_per_slot: int, repair_context: bool, model_timeout_seconds: float,
        timeout_seconds: float, parallel_arms: int,
    ) -> None:
        if status.action is LifecycleAction.RECOVER:
            # Only what records settle; a stalled generation still needs a person.
            self.reconciler.recover(session_id)
            return
        if status.action is LifecycleAction.MATERIALISE_MEASUREMENT:
            # Mechanical, not a judgement: the plan that declared this measurement
            # was already approved, and asking a person to press a second button
            # for a consequence of their own decision is not a gate, it is an
            # errand. A failure here is a measurement failure and is raised as
            # one, so it is never recorded as an arm that could not run.
            self.research.materialise_measurement(
                session_id, gateway, model_timeout_seconds=model_timeout_seconds)
            return
        if status.action is LifecycleAction.CALIBRATE_MEASUREMENT:
            # Local and free: the frozen ruler run on the controls' subjects in
            # a disposable root, spending no repeat and calling no model.
            self.research.calibrate_measurement(session_id)
            return
        self.research.execute(
            session_id, gateway, attempts_per_slot=attempts_per_slot,
            repair_context=repair_context, model_timeout_seconds=model_timeout_seconds,
            timeout_seconds=timeout_seconds, expected_session_sequence=status.event_sequence,
            parallel_arms=parallel_arms,
        )


def _observed(status: SessionLifecycle) -> DriveStep:
    return DriveStep(phase=status.phase, action=status.action, performed=False,
                     detail=status.detail)


def _performed(status: SessionLifecycle) -> DriveStep:
    return DriveStep(phase=status.phase, action=status.action, performed=True,
                     detail=status.detail)
