from relab_cli.main import main

raise SystemExit(main())
