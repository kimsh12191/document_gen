"""`relab chat`: the coding agent in a terminal, without the editor (0.3.8; drawn with rich, 0.3.9).

Asked in use: to work as in Cline's or Claude Code's terminal -- type a request,
watch it work, answer what it asks in place. Everything it does is a `relab
code` command, run as the editor runs it: a child process per leg (a request,
an answer, an approval), its progress read from the workspace's journal while
it runs, its record on its stdout when it ends. So a conversation begun here is
the editor's too, and stopping one with Ctrl+C is the editor's Stop: the child
ends, and the record says it was stopped, as it stood.

How it looks (0.3.9, asked in use: "as other CLI programs do"): rich draws a
banner, a line per thing the work did under the model's own words, a spinner
with the report as it is written while a leg runs, a change as a highlighted
diff in a panel, and the report as Markdown; prompt_toolkit gives the box typed
into, with history and the `/` commands completed. Neither is loaded by any
other `relab` command.

Nothing here decides anything about the work: what is shown is what the
journal and the loop's record say, and what is sent is what the person typed
or chose. The model's words are shown as its words, with any control
characters taken out, so a reply cannot drive the terminal; and as text, never
as rich's markup.
"""

from __future__ import annotations

import argparse
import contextlib
import difflib
import functools
import json
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time
import uuid
from collections.abc import Callable, Iterator
from pathlib import Path
from typing import TextIO

from rich import box
from rich.cells import cell_len
from rich.console import Console, Group, RenderableType
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.spinner import Spinner
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from relab_app.client import WorkspaceClient, untouched
from relab_cli import chat_config, chat_images
from relab_core.coding_loop import CodingLoop, LoopOutcome
from relab_core.operations import (
    ChecklistDetail,
    DraftingDetail,
    ModelCallDetail,
    OperationEvent,
    OperationState,
    PatchDetail,
    ProgressDetail,
    SteeringDetail,
    VerificationDetail,
    WorkspaceReadDetail,
    WorkspaceSearchDetail,
)

# A conversation goes on in the same loop after these, as in the editor.
FOLLOWED = frozenset({LoopOutcome.FINISHED, LoopOutcome.FAILED, LoopOutcome.BUDGET_SPENT,
                      LoopOutcome.STOPPED})
RESUMABLE = frozenset({LoopOutcome.FAILED, LoopOutcome.BUDGET_SPENT, LoopOutcome.STOPPED})
# How often the journal is read while a leg runs.
POLL_SECONDS = 0.25
# The most diff lines shown for one change before the rest is counted.
DIFF_LINES = 400
# The end of a report being written, shown under the spinner.
REPORT_TAIL = 14
LISTED = 20
# Exit codes of `relab chat -p`: done, not done, could not start, waiting on the person.
DONE, NOT_DONE, NOT_STARTED, WAITING = 0, 1, 2, 3
# The chat's own prompt; anything else asked is an answer to what a loop waits on.
MAIN_PROMPT = "› "
# Yes, in the words a person types at the prompt (0.3.9: "y" typed there was sent
# to a waiting plan as an answer, and the plan was asked for again).
YES = frozenset({"y", "yes", "ok", "네", "예", "응", "승인", "적용", "실행"})
NO = frozenset({"n", "no", "아니", "아니요", "거절"})
# An escape sequence whole, then any other control character but tab and newline.
CONTROL = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]|[\x00-\x08\x0b-\x1f\x7f\x9b]")

ACCENT = "#d7875f"
FRAME = "#5f87af"
# The name on the first screen (0.3.9, asked in use), coloured from the accent to violet;
# the small one where the terminal is narrow, the name in letters where blocks cannot be drawn.
LOGO = (
    "██████╗ ███████╗██╗      █████╗ ██████╗ ",
    "██╔══██╗██╔════╝██║     ██╔══██╗██╔══██╗",
    "██████╔╝█████╗  ██║     ███████║██████╔╝",
    "██╔══██╗██╔══╝  ██║     ██╔══██║██╔══██╗",
    "██║  ██║███████╗███████╗██║  ██║██████╔╝",
    "╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝╚═════╝ ",
)
SMALL_LOGO = ("█▀█ █▀▀ █   ▄▀█ █▄▄", "█▀▄ ██▄ █▄▄ █▀█ █▄█")
LOGO_COLORS = ((0xF0, 0xA0, 0x60), (0xD7, 0x87, 0x5F), (0xA0, 0x66, 0xD0))
MAKER = "by NLP Cell"
CODE_THEME = "monokai"
ADDED = "on #10331c"
REMOVED = "on #3b1418"
FANCY = {"bullet": "●", "branch": "⎿", "ok": "✓", "fail": "✗", "open": "△", "stop": "■", "star": "✻",
         "todo": "☐", "job": "↻", "steer": "↳", "you": "›"}
PLAIN = {"bullet": "*", "branch": "|", "ok": "v", "fail": "x", "open": "!", "stop": "#", "star": "*",
         "todo": "-", "job": "~", "steer": ">", "you": ">"}

# The commands, for /help and for completing them as they are typed.
COMMANDS: tuple[tuple[str, str, str], ...] = (
    ("/new", "a new conversation", "새 대화"),
    ("/list", "the conversations in this workspace", "이 작업 폴더의 대화 목록"),
    ("/open", "open one: /open <n|id>", "대화 열기: /open <번호|id>"),
    ("/resume", "go on with work that stopped: /resume [model]", "멈춘 작업 이어서: /resume [모델]"),
    ("/undo", "put back what the last work wrote", "마지막 작업이 쓴 파일 되돌리기"),
    ("/image", "attach a picture to the next request: /image <path> | clear",
     "다음 요청에 이미지 첨부: /image <경로> | clear"),
    ("/model", "the coding model: /model [name]", "코딩 모델: /model [이름]"),
    ("/auto", "approve without asking: /auto on|off", "묻지 않고 승인: /auto on|off"),
    ("/config", "the settings; /config set <name> <value> saves one", "설정 보기; /config set <이름> <값>으로 저장"),
    ("/help", "this list", "이 목록"),
    ("/exit", "leave (also Ctrl+D)", "끝내기 (Ctrl+D)"),
)

TEXTS: dict[str, tuple[str, str]] = {
    "noFolder": ("No such folder: {path}", "작업 폴더가 없습니다: {path}"),
    "makeFolder": ("Make it and start there? [y/N]", "이 폴더를 만들고 시작할까요? [y/N]"),
    "madeFolder": ("Made {path}", "만들었습니다: {path}"),
    "makeHint": ("To start there, make it first: mkdir \"{path}\"", "만들고 시작하려면: mkdir \"{path}\""),
    "notFolder": ("Not a folder: {path}", "폴더가 아닙니다: {path}"),
    "cannotMake": ("Could not make {path}: {why}", "만들지 못했습니다: {path} ({why})"),
    "bannerHelp": ("/help for commands · Ctrl+C stops the work · /exit to leave",
                   "/help 명령 보기 · Ctrl+C 작업 멈춤 · /exit 끝내기"),
    "noModel": ("No coding model is set: set \"codingModel\" in {path}, or type /model <name>.",
                "코딩 모델이 없습니다. {path}에 \"codingModel\"을 적거나 /model <이름>을 입력하세요."),
    "helpIntro": ("Type a request to work it through; what follows goes on in the same conversation.",
                  "요청을 입력하면 처리하고, 이어서 입력하면 같은 대화로 이어집니다."),
    "unknownCommand": ("Not a command here: {name}. /help lists them.",
                       "없는 명령입니다: {name}. /help로 목록을 보세요."),
    "working": ("Working", "작업 중"),
    "interrupt": ("Ctrl+C to stop", "Ctrl+C 멈춤"),
    "calling": ("Calling {model}", "{model} 호출 중"),
    "thinking": ("Thinking ({n} characters)", "생각 중 ({n}자)"),
    "drafting": ("Writing {path} ({n} lines)", "{path} 작성 중 ({n}줄)"),
    "running": ("Running", "실행 중"),
    "read": ("Read", "읽음"),
    "searched": ("Searched", "검색"),
    "matches": ("{n} found", "{n}건"),
    "wrote": ("Changed", "수정"),
    "writeFailed": ("Not written", "쓰지 못함"),
    "timedOut": ("took too long", "시간 초과"),
    "job": ("left running as {job}", "{job}(으)로 계속 실행"),
    "steered": ("taken up", "반영함"),
    "todo": ("to do {done}/{total}", "할 일 {done}/{total}"),
    "report": ("Report", "보고서"),
    "changed": ("Changed", "바꾼 파일"),
    "stopping": ("Stopping…", "멈추는 중…"),
    "stopped": ("Stopped. /resume goes on from here.", "멈췄습니다. /resume으로 이어서 할 수 있습니다."),
    "stoppedEarly": ("Stopped before it began.", "시작 전에 멈췄습니다."),
    "failedToRun": ("relab did not finish that (exit {code}):", "relab이 끝내지 못했습니다(종료 코드 {code}):"),
    "resumeHint": ("/resume goes on from where it ended.", "/resume으로 끝난 곳에서 이어갑니다."),
    "resumeLarger": ("/resume {model} goes on with the larger model.",
                     "/resume {model}로 더 큰 모델이 이어갑니다."),
    "nothingToResume": ("Nothing here stopped part-way.", "중간에 멈춘 작업이 없습니다."),
    "nothingToUndo": ("Nothing here to put back.", "되돌릴 작업이 없습니다."),
    "undone": ("Put back: {restored}", "되돌림: {restored}"),
    "kept": ("Left as changed since: {kept}", "그 뒤에 바뀌어 그대로 둠: {kept}"),
    "model": ("Coding model: {model}", "코딩 모델: {model}"),
    "auto": ("Auto approval: {state}", "자동 승인: {state}"),
    "on": ("on", "켬"),
    "off": ("off", "끔"),
    "ask": ("ask", "묻기"),
    "newConversation": ("A new conversation.", "새 대화입니다."),
    "noConversations": ("No conversations in this workspace yet.", "이 작업 폴더에는 아직 대화가 없습니다."),
    "listTitle": ("Conversations", "대화 목록"),
    "columns": ("#|Conversation|State|Requests|Updated", "#|대화|상태|요청|최근"),
    "openHint": ("/open <n> opens one.", "/open <번호>로 엽니다."),
    "notListed": ("No conversation {which}: /list shows them.", "{which}번 대화가 없습니다. /list로 확인하세요."),
    "opened": ("Opened: {title}", "열었습니다: {title}"),
    "configFiles": ("Settings read from", "설정 파일"),
    "missing": ("(none)", "(없음)"),
    "configApplied": ("Differing from the defaults", "기본값과 다른 설정"),
    "configNone": ("All defaults.", "모두 기본값입니다."),
    "configUsage": ("/config set [--project] <name> <value> saves one; /config unset [--project] <name> takes it out.",
                    "/config set [--project] <이름> <값>으로 저장하고, /config unset [--project] <이름>으로 지웁니다."),
    "configNames": ("Settings: {names}", "설정 이름: {names}"),
    "notASetting": ("Not a setting: {name}", "없는 설정입니다: {name}"),
    "badValue": ("{name} does not take {value}", "{name}에 쓸 수 없는 값입니다: {value}"),
    "takes": ("It takes: {what}", "쓸 수 있는 값: {what}"),
    "takesSwitch": ("on or off", "on 또는 off"),
    "takesNumber": ("a number, 0 or more", "0 이상의 숫자"),
    "takesText": ("text", "글자"),
    "takesList": ("names with commas between, or a JSON list", "쉼표로 나눈 이름, 또는 JSON 목록"),
    "takesObject": ("a JSON object, as {example}", "JSON 객체, 예: {example}"),
    "configSaved": ("Saved in {path}: {name} = {value}", "{path}에 저장했습니다: {name} = {value}"),
    "configRemoved": ("Taken out of {path}: {name}", "{path}에서 지웠습니다: {name}"),
    "configNotSaved": ("Not saved, the file was not changed: {problem}", "저장하지 못했습니다(파일은 그대로): {problem}"),
    "projectWins": ("The project's settings set {name} = {value}, which applies here.",
                    "이 프로젝트 설정의 {name} = {value}가 여기서는 우선합니다."),
    "nowApplies": ("Now: {name} = {value}", "지금 적용: {name} = {value}"),
    "nextStart": ("It applies from the next start.", "다음에 시작할 때부터 적용됩니다."),
    "applyChange": ("Apply this change to", "이 변경을 적용할까요:"),
    "createFile": ("Create", "새 파일을 만들까요:"),
    "moreLines": ("… {n} more line(s)", "… {n}줄 더"),
    "reviewChoices": ("y apply · a this and the rest · n do not · or type what to do instead",
                      "y 적용 · a 이후 모두 적용 · n 거절 · 또는 대신할 말을 입력"),
    "rejectNote": ("What instead? (Enter for nothing)", "대신 무엇을? (없으면 Enter)"),
    "runCommand": ("Run this command?", "이 명령을 실행할까요?"),
    "commandChoices": ("y run · n do not · or type what to do instead",
                       "y 실행 · n 거절 · 또는 대신할 말을 입력"),
    "commandAlways": ("A always for {rule}", "A {rule}은 항상 허용"),
    "planTitle": ("The plan, to approve before it is built", "구현 전에 승인할 계획"),
    "planFiles": ("Files", "파일"),
    "planSteps": ("Steps", "단계"),
    "planRequirements": ("Asked for, and how it is shown", "요청 사항과 확인 방법"),
    "planChoices": ("y approve and build · or type what to change", "y 승인하고 구현 · 또는 바꿀 점을 입력"),
    "questionChoice": ("Number, or your own words (Enter: answer later)",
                       "번호나 직접 입력 (Enter: 나중에 답하기)"),
    "laterHint": ("It waits: what you type next is the answer.", "기다립니다. 다음에 입력하는 말이 답이 됩니다."),
    "waitingOnce": ("It waits for you: go on with `relab chat --continue`.",
                    "답을 기다립니다. `relab chat --continue`로 이어가세요."),
    "escalated": ("It proposes a measured comparison (Research, in the editor):",
                  "측정 비교를 제안합니다(편집기의 Research 모드):"),
    "exitHint": ("Ctrl+C again, or /exit, to leave.", "나가려면 Ctrl+C를 한 번 더 누르거나 /exit를 입력하세요."),
    "answerPrompt": ("answer", "답"),
    "imageAttached": ("Picture attached: {path} ({size})", "이미지 첨부: {path} ({size})"),
    "imageQueued": ("For the next request: {path} ({size})", "다음 요청에 첨부합니다: {path} ({size})"),
    "imageTooLarge": ("Not sent: {path} is {size}, past the {most} a picture may be",
                      "보내지 않음: {path}는 {size}로 이미지 한도 {most}를 넘습니다"),
    "imageTooMany": ("Not sent: {path}, past {most} pictures a request",
                     "보내지 않음: {path} (요청당 이미지는 {most}장까지)"),
    "imageNotFound": ("Not a picture here: {path} (png, jpg, gif or webp)",
                      "이미지 파일이 아닙니다: {path} (png, jpg, gif, webp)"),
    "imageNone": (("No picture waits. /image <path> attaches one to the next request; a path in the "
                   "request does too."),
                  "기다리는 이미지가 없습니다. /image <경로>로 다음 요청에 첨부하거나, 요청에 경로를 적으면 됩니다."),
    "imageCleared": ("Pictures taken off the next request.", "다음 요청의 이미지를 뺐습니다."),
    "toolbar": ("{mode} · {model} · /help · Tab completes · Esc Enter new line",
                "{mode} · {model} · /help · Tab 완성 · Esc Enter 줄바꿈"),
    "calls": ("{n} call(s)", "호출 {n}회"),
    # ReLab's verdict, as the editor words it (apps/vscode/src/conversation/i18n.ts).
    "complete": ("Done", "완료"),
    "partial": ("Not done", "미완료"),
    "blocked": ("Blocked", "막힘"),
    "taskUnknown": ("Not known whether done", "완료 여부 불명"),
    "passed": ("the checks run passed", "지정 검사 통과"),
    "failed": ("checks failed", "검사 실패"),
    "not_run": ("not verified", "미검증"),
    "inconclusive": ("checks did not tell", "검사 결과 불명"),
    "not_applicable": ("no code to run checks on", "코드 실행 검증 비대상"),
    "verifyUnknown": ("verification not known", "검증 불명"),
    "advice": ("notes to look at", "권고 있음"),
    "repairsUsed": ("repairs used up", "복구 한도 소진"),
    "legacy": ("Ended · no verification record", "종료됨 · 검증 정보 없음"),
    "outcome.finished": ("finished", "끝남"),
    "outcome.waiting": ("waiting for you", "답을 기다림"),
    "outcome.budget_spent": ("ran out of calls", "호출 한도 소진"),
    "outcome.failed": ("failed", "실패"),
    "outcome.stopped": ("stopped", "멈춤"),
    "outcome.undone": ("undone", "되돌림"),
    "outcome.escalated": ("proposed research", "연구 제안"),
    "outcome.running": ("running", "진행 중"),
}


def plain(text: object) -> str:
    """A model's or a record's words, with nothing in them that would drive the terminal."""
    return CONTROL.sub("", str(text))


def _korean() -> bool:
    for name in ("LC_ALL", "LC_MESSAGES", "LANG"):
        given = os.environ.get(name, "")
        if given:
            return given.lower().startswith("ko")
    if sys.platform == "win32":
        try:
            import ctypes

            # Read by name: `windll` is only there on Windows, and the types are checked anywhere.
            language = getattr(ctypes, "windll").kernel32.GetUserDefaultUILanguage()  # noqa: B009
            return bool(int(language) & 0x3FF == 0x12)
        except (AttributeError, OSError):
            return False
    return False


def _tokens(count: int) -> str:
    return f"{count / 1_000_000:.1f}M".replace(".0M", "M") if count >= 1_000_000 else (
        f"{round(count / 1000)}k" if count >= 1000 else str(count))


class Screen:
    """Where it is drawn: a rich console, with the chat's words and marks."""

    def __init__(self, out: TextIO | None = None, *, korean: bool, color: bool | None = None) -> None:
        stream = out if out is not None else sys.stdout
        tty = bool(getattr(stream, "isatty", lambda: False)())
        colored = (tty and not os.environ.get("NO_COLOR")) if color is None else color
        # Text as text: a model's words are never read as rich's markup.
        self.console = Console(file=stream, force_terminal=tty or colored, no_color=not colored,
                               color_system="auto" if colored else None, highlight=False, emoji=False,
                               markup=False, width=None if tty else 100)
        self.live = tty
        self.korean = korean
        self.glyph = FANCY if (self.console.encoding or "").lower().startswith("utf") else PLAIN

    def t(self, key: str, **values: object) -> str:
        text = TEXTS[key][1 if self.korean else 0]
        return text.format(**values) if values else text

    def line(self, renderable: RenderableType | str = "", *, whole: bool = False) -> None:
        """One line; `whole` for one holding a path or a command, which is never broken to fit."""
        self.console.print(Text(renderable) if isinstance(renderable, str) else renderable, soft_wrap=whole)

    def markdown(self, text: str) -> None:
        self.console.print(Markdown(plain(text), code_theme=CODE_THEME, hyperlinks=False))

    def dim(self, text: str) -> Text:
        return Text(text, style="dim")

    def good(self, text: str) -> Text:
        return Text(text, style="green")

    def warn(self, text: str) -> Text:
        return Text(text, style="yellow")

    def bad(self, text: str) -> Text:
        return Text(text, style="red")

    def bold(self, text: str) -> Text:
        return Text(text, style="bold")

    def branch(self, *parts: str | tuple[str, str] | Text) -> None:
        """One thing the work did, under the model's words: `  ⎿  read a.py`."""
        self.line(Text.assemble((f"  {self.glyph['branch']}  ", "dim"), *parts))

    @contextlib.contextmanager
    def working(self, progress: Progress) -> Iterator[None]:
        """The spinner and the report being written, below what is printed, while a leg runs."""
        if not self.live:
            yield
            return
        with Live(get_renderable=progress.render, console=self.console, transient=True,
                  refresh_per_second=10, redirect_stdout=False, redirect_stderr=False):
            yield


class Progress:
    """What the journal says the work is doing: lines printed, and the live area under them."""

    def __init__(self, screen: Screen) -> None:
        self.screen = screen
        self.status = ""
        self.report = ""
        self.todo = ""
        self.began = time.monotonic()
        # When each command began, by its operation, for how long it took.
        self.started: dict[str, float] = {}

    def render(self) -> RenderableType:
        t = self.screen.t
        seconds = int(time.monotonic() - self.began)
        spinner = Spinner("dots", style=ACCENT, text=Text.assemble(
            (self.status or t("working"), ACCENT), (f"  {seconds}s · {t('interrupt')}", "dim")))
        if not self.report:
            return spinner
        tail = "\n".join(self.report.splitlines()[-REPORT_TAIL:])
        return Group(Panel(Markdown(tail, code_theme=CODE_THEME, hyperlinks=False), title=t("report"),
                           title_align="left", border_style="dim", box=box.ROUNDED), spinner)

    def show(self, event: OperationEvent) -> None:
        detail = event.detail
        screen, t, glyph = self.screen, self.screen.t, self.screen.glyph
        ended = event.state is not OperationState.STARTED
        if isinstance(detail, ModelCallDetail):
            if not ended:
                self.status = t("calling", model=plain(detail.model))
            elif event.state is OperationState.FAILED and event.reason:
                screen.branch((f"{glyph['open']} {plain(event.reason)}", "yellow"))
        elif isinstance(detail, ProgressDetail):
            screen.line(Text.assemble((f"{glyph['bullet']} ", ACCENT), plain(detail.said)))
        elif isinstance(detail, WorkspaceReadDetail) and ended and detail.paths:
            screen.branch((f"{t('read')} ", "dim"), (", ".join(plain(path) for path in detail.paths), "dim"))
        elif isinstance(detail, WorkspaceSearchDetail) and ended:
            screen.branch((f"{t('searched')} \"{plain(detail.query)}\" · {t('matches', n=detail.matches)}",
                           "dim"))
        elif isinstance(detail, PatchDetail) and ended:
            targets = ", ".join(plain(path) for path in detail.targets)
            if event.state is OperationState.FAILED:
                screen.branch((f"{glyph['fail']} {t('writeFailed')} ", "red"), targets,
                              (f"  {plain(event.reason or '')}", "dim"))
            else:
                screen.branch((f"{t('wrote')} ", "green"), targets)
        elif isinstance(detail, VerificationDetail):
            self._verification(event.operation_id, detail, ended)
        elif isinstance(detail, DraftingDetail):
            self._drafting(detail)
        elif isinstance(detail, ChecklistDetail):
            done = sum(1 for item in detail.items if item.done)
            now = next((item.text for item in detail.items if not item.done), "")
            said = f"{glyph['todo']} {t('todo', done=done, total=len(detail.items))}" + (
                f" · {plain(now)}" if now else "")
            if said != self.todo:
                self.todo = said
                screen.branch((said, "dim"))
        elif isinstance(detail, SteeringDetail):
            screen.branch((f"{glyph['steer']} {t('steered')}: {plain(detail.instruction)}", "dim"))

    def _verification(self, operation: str, detail: VerificationDetail, ended: bool) -> None:
        screen, t, glyph = self.screen, self.screen.t, self.screen.glyph
        command = plain(shlex.join(detail.argv))
        if not ended:
            # Said once it ends, with how it ended; until then it is what is running.
            self.started[operation] = time.monotonic()
            self.status = f"{t('running')} $ {command[:80]}"
            return
        began = self.started.pop(operation, None)
        took = f" · {time.monotonic() - began:.1f}s" if began is not None else ""
        if detail.job:
            result: tuple[str, str] = (f"{glyph['job']} {t('job', job=detail.job)}", "dim")
        elif detail.timed_out:
            result = (f"{glyph['fail']} {t('timedOut')}{took}", "red")
        elif detail.exit_code == 0:
            result = (f"{glyph['ok']} 0{took}", "green")
        else:
            result = (f"{glyph['fail']} {detail.exit_code}{took}", "red")
        screen.branch(("$ ", "dim"), command[:160], "  ", result)

    def _drafting(self, detail: DraftingDetail) -> None:
        t = self.screen.t
        if detail.report:
            # The report as it is written; the record keeps the end of a long one.
            self.report = plain(detail.report)
        elif detail.path:
            self.status = t("drafting", path=plain(detail.path), n=detail.lines)
        elif detail.thought:
            self.status = plain(detail.thought)
        elif detail.thinking_characters:
            self.status = t("thinking", n=detail.thinking_characters)


# A leg: the `relab code` arguments, the loop it is for, and the screen to show it on.
Runner = Callable[[list[str], str, "Progress"], "CodingLoop | None"]


def run_leg(workspace: Path, argv: list[str], loop_id: str, progress: Progress) -> CodingLoop | None:
    """Run one `relab code` command as the editor does, showing its progress; its loop, or None."""
    screen = progress.screen
    journal = WorkspaceClient(workspace)
    cursor = journal.timeline(limit=1).next_cursor
    command = [sys.executable, "-m", "relab_cli", *argv]
    # The child does not get the terminal's Ctrl+C: stopping is done here, as
    # the editor's Stop is, so the record can say so.
    windows = sys.platform == "win32"
    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                 env=dict(os.environ), start_new_session=not windows,
                                 creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) if windows else 0)
        try:
            with screen.working(progress):
                while True:
                    ended = child.poll() is not None
                    cursor = _show_new(journal, cursor, progress)
                    if ended:
                        break
                    time.sleep(POLL_SECONDS)
        except KeyboardInterrupt:
            screen.line(screen.warn(screen.t("stopping")))
            child.kill()
            child.wait()
            return _stopped(workspace, loop_id, screen)
        out.seek(0)
        lines = [line for line in out.read().decode("utf-8", "replace").splitlines() if line.strip()]
        if lines:
            try:
                return CodingLoop.model_validate_json(lines[-1])
            except ValueError:
                pass
        err.seek(0)
        said = err.read().decode("utf-8", "replace").strip().splitlines()
        screen.line(screen.bad(screen.t("failedToRun", code=child.returncode)))
        for line in said[-12:]:
            screen.line(screen.dim(f"  {plain(line)}"))
        return None


def _show_new(journal: WorkspaceClient, cursor: str | None, progress: Progress) -> str | None:
    timeline = journal.timeline(limit=200, after=cursor)
    for entry in timeline.entries:
        if entry.operation is not None:
            try:
                progress.show(entry.operation)
            except (AttributeError, KeyError, TypeError, ValueError):
                # A record this version does not draw costs a line, never the run.
                continue
    return timeline.next_cursor or cursor


def _stopped(workspace: Path, loop_id: str, screen: Screen) -> CodingLoop | None:
    from relab_app.coding_loop import CodingLoopService

    try:
        loop = CodingLoopService(workspace).mark_stopped(loop_id)
    except LookupError:
        screen.line(screen.t("stoppedEarly"))
        return None
    screen.line(screen.t("stopped"))
    return loop


def diff_panel(screen: Screen, path: str, before: str, after: str, title: Text, subtitle: str) -> Panel:
    """A change as it would be written: line numbers, + and -, the code highlighted for its kind."""
    lexer = Syntax.guess_lexer(plain(path), after or before)
    highlighter = Syntax("", lexer, theme=CODE_THEME)
    table = Table.grid(padding=(0, 1), expand=True)
    table.add_column(justify="right", style="dim", no_wrap=True)
    table.add_column(no_wrap=True)
    table.add_column(ratio=1, overflow="fold")
    lines = list(difflib.unified_diff(before.splitlines(), after.splitlines(), lineterm=""))[2:]
    old = new = 0
    for number, line in enumerate(lines[:DIFF_LINES]):
        text = plain(line)
        hunk = re.match(r"@@ -(\d+)(?:,\d+)? \+(\d+)", text)
        if hunk:
            old, new = int(hunk.group(1)), int(hunk.group(2))
            if number:
                table.add_row("", "", Text("⋯", style="dim"))
            continue
        code = highlighter.highlight(text[1:]) if text else Text("")
        code.rstrip()
        if text.startswith("+"):
            table.add_row(str(new), Text("+", style="green"), code, style=ADDED)
            new += 1
        elif text.startswith("-"):
            table.add_row(str(old), Text("-", style="red"), code, style=REMOVED)
            old += 1
        else:
            table.add_row(str(new), " ", code)
            old, new = old + 1, new + 1
    body: RenderableType = table
    if len(lines) > DIFF_LINES:
        body = Group(table, screen.dim(screen.t("moreLines", n=len(lines) - DIFF_LINES)))
    return Panel(body, title=title, title_align="left", subtitle=Text(subtitle, style="dim"),
                 subtitle_align="left", border_style="dim", box=box.ROUNDED)


class Chat:
    """One conversation at a time, as the editor's chat holds one."""

    def __init__(self, workspace: Path, values: dict[str, object], screen: Screen, *,
                 ask: Callable[[str], str] | None = None, runner: Runner | None = None) -> None:
        self.workspace = workspace
        self.values = values
        self.screen = screen
        self.ask = ask if ask is not None else read_message
        self.runner: Runner = runner if runner is not None else (
            lambda argv, loop_id, progress: run_leg(workspace, argv, loop_id, progress))
        self.model = chat_config.coding_model(values)
        self.auto = values.get("approvalMode") == "auto"
        self.last: CodingLoop | None = None
        self.listed: list[dict[str, object]] = []
        # Pictures `/image` gave, for the next request (0.3.29).
        self.queued: list[Path] = []

    # --- sending ------------------------------------------------------------------

    def _code(self, action: str, *positional: str, options: tuple[str, ...] | list[str] = (),
              model: str | None = None) -> list[str]:
        """A `relab code` command: its options, then `--`, so typed words are never an option."""
        used = model or self.model
        return ["code", "--workspace", str(self.workspace), action, *options,
                *chat_config.model_flags(self.values, used),
                *chat_config.loop_flags(self.values, used, auto=self.auto), "--", *positional]

    def _leg(self, argv: list[str], loop_id: str) -> CodingLoop | None:
        loop = self.runner(argv, loop_id, Progress(self.screen))
        if loop is not None:
            self.last = loop
        return loop

    def send(self, text: str) -> CodingLoop | None:
        """What was typed: the choice or answer a loop waits on, the next request, or a new one."""
        if not self.model:
            self.screen.line(self.screen.warn(self.screen.t("noModel", path=chat_config.user_path())))
            return None
        last = self.last
        waiting = last is not None and last.outcome is LoopOutcome.WAITING
        if not (waiting and text.strip().lower() in YES | NO | {"a"}):
            # Pictures named by a path, and those `/image` gave, go with words, never with a choice.
            text = self._pictures(text)
        if last is not None and last.outcome is LoopOutcome.WAITING:
            return self._leg(self.chosen(last, text), last.loop_id)
        if last is not None and last.outcome in FOLLOWED:
            return self._leg(self._code("follow", last.loop_id, text), last.loop_id)
        loop_id = f"loop-{uuid.uuid4().hex}"
        extra = ["--loop-id", loop_id, *(["--after", last.loop_id] if last is not None else [])]
        if self.values.get("reviewEdits") is True and not self.auto:
            extra.append("--review-edits")
        if self.values.get("projectOnlyReads") is True:
            extra.append("--project-only")
        return self._leg(self._code("run", text, options=extra), loop_id)

    def _pictures(self, text: str) -> str:
        """`text` with its pictures kept and named for the backend, what was done with each said."""
        attached = chat_images.attach(text, self.workspace, self.queued)
        self.queued = []
        for key, values in attached.notes:
            line = self.screen.t(key, **values)
            self.screen.line(self.screen.warn(line) if key != "imageAttached" else self.screen.dim(line))
        return attached.text

    def chosen(self, loop: CodingLoop, said: str) -> list[str]:
        """The command for what was said to a waiting loop: a choice it offered, else an answer."""
        word = said.strip()
        yes, no = word.lower() in YES, word.lower() in NO
        if loop.review is not None:
            if yes:
                return self._code("accept", loop.loop_id)
            if word.lower() == "a":
                return self._code("accept", loop.loop_id, options=["--all"])
            if no:
                return self._code("reject", loop.loop_id)
        elif loop.permission:
            if word == "A" and loop.permission_rule:
                return self._code("allow", loop.loop_id, options=["--always"])
            if yes:
                return self._code("allow", loop.loop_id)
            if no:
                return self._code("refuse", loop.loop_id)
        elif loop.plan is not None and not loop.plan_approved and yes:
            return self._code("approve", loop.loop_id)
        return self._code("answer", loop.loop_id, said)

    def converse(self, loop: CodingLoop | None, *, prompting: bool = True) -> CodingLoop | None:
        """Show how a leg ended, and while it waits on a choice, ask for it and go on."""
        while loop is not None:
            self.ended(loop)
            if loop.outcome is not LoopOutcome.WAITING or not prompting:
                return loop
            argv = self.decide(loop)
            if argv is None:
                self.screen.line(self.screen.dim(self.screen.t("laterHint")))
                return loop
            loop = self._leg(argv, loop.loop_id)
        return loop

    # --- what a leg ended with -----------------------------------------------------

    def verdict(self, loop: CodingLoop) -> Text:
        screen, t, glyph = self.screen, self.screen.t, self.screen.glyph
        assessment = loop.assessment
        if assessment is None:
            return screen.dim(t("legacy"))
        task = assessment.task_status.value
        verified = assessment.verification_status.value
        parts = [t(task) if task in ("complete", "partial", "blocked") else t("taskUnknown"),
                 t(verified) if verified in TEXTS else t("verifyUnknown")]
        if assessment.stop_reason == "finish_repair_exhausted":
            parts.append(t("repairsUsed"))
        if any(item.effect.value == "advise" and item.result.value != "pass"
               for item in assessment.findings):
            parts.append(t("advice"))
        passed = task == "complete" and verified in ("passed", "not_applicable")
        line = " · ".join(parts)
        return Text(f"{glyph['ok']} {line}", style="bold green") if passed else Text(
            f"{glyph['open']} {line}", style="bold yellow")

    def ended(self, loop: CodingLoop) -> None:
        """How a leg ended: the report or summary, ReLab's verdict with its numbers, what next."""
        screen, t, glyph = self.screen, self.screen.t, self.screen.glyph
        if loop.outcome is LoopOutcome.WAITING:
            return
        screen.line()
        if loop.outcome is not LoopOutcome.FINISHED:
            screen.line(Text(f"{glyph['stop']} {t('outcome.' + loop.outcome.value)}", style="bold yellow"))
        if loop.report or loop.summary:
            screen.markdown(loop.report or loop.summary or "")
        # The files it wrote, unless its own summary names them all already.
        said = f"{loop.summary or ''}\n{loop.report or ''}"
        changed = list(dict.fromkeys(item.path for item in loop.written))
        if changed and not all(path in said for path in changed):
            screen.line(Text.assemble((f"{t('changed')}: ", "dim"), ", ".join(plain(path) for path in changed)))
        numbers = [t("calls", n=loop.calls), f"{round(loop.seconds)}s"]
        if loop.context_tokens and loop.context_window:
            numbers.append(f"{_tokens(loop.context_tokens)}/{_tokens(loop.context_window)}")
        screen.line(Text.assemble(self.verdict(loop), ("   " + " · ".join(numbers), "dim")))
        if loop.outcome is LoopOutcome.ESCALATED and loop.escalation is not None:
            screen.line(f"{t('escalated')} {plain(loop.escalation.goal)}")
        if loop.outcome in RESUMABLE:
            screen.line(screen.dim(t("resumeLarger", model=plain(loop.next_model)) if loop.next_model
                                   else t("resumeHint")))
        screen.line(screen.dim(loop.loop_id))

    # --- what a loop waits on ------------------------------------------------------

    def decide(self, loop: CodingLoop) -> list[str] | None:
        """Ask for what the loop waits on; the command that gives it, or None for later."""
        screen, t = self.screen, self.screen.t
        prompt = f"{t('answerPrompt')} {MAIN_PROMPT}"
        if loop.review is not None:
            self._show_review(loop)
            said = self.ask(prompt).strip()
            if said.lower() in NO:
                note = self.ask(f"{t('rejectNote')} {MAIN_PROMPT}").strip()
                return self._code("reject", loop.loop_id, options=[f"--note={note}"] if note else [])
            return self.chosen(loop, said) if said else None
        if loop.permission:
            self._show_permission(loop)
        elif loop.plan is not None and not loop.plan_approved:
            self._show_plan(loop)
        elif loop.questions:
            return self._questions(loop)
        elif loop.question:
            screen.line(Text(plain(loop.question), style="bold"))
        else:
            return None
        said = self.ask(prompt).strip()
        return self.chosen(loop, said) if said else None

    def _show_review(self, loop: CodingLoop) -> None:
        from relab_app.coding_loop import CodingLoopService

        t = self.screen.t
        review = loop.review
        assert review is not None
        title = Text.assemble((f"{t('applyChange' if review.before_digest else 'createFile')} ", "bold"),
                              (plain(review.path), "bold"))
        if review.added is not None and review.removed is not None:
            title.append_text(Text.assemble("  ", (f"+{review.added}", "green"), " ",
                                            (f"−{review.removed}", "red")))
        service = CodingLoopService(self.workspace)
        _, now = service.side(loop.loop_id, review.path, "now")
        _, proposed = service.side(loop.loop_id, review.path, "proposed")
        self.screen.line(diff_panel(self.screen, review.path, now, proposed, title, t("reviewChoices")))

    def _show_permission(self, loop: CodingLoop) -> None:
        t = self.screen.t
        parts: list[RenderableType] = [Syntax(plain(shlex.join(loop.permission or [])), "bash",
                                              theme=CODE_THEME, word_wrap=True)]
        if loop.permission_reason:
            parts.append(self.screen.dim(plain(loop.permission_reason)))
        rule = loop.permission_rule or []
        choices = t("commandChoices") + (f" · {t('commandAlways', rule=plain(' '.join(rule)))}" if rule else "")
        self.screen.line(Panel(Group(*parts), title=Text(t("runCommand"), style="bold"), title_align="left",
                               subtitle=Text(choices, style="dim"), subtitle_align="left",
                               border_style="yellow", box=box.ROUNDED))

    def _show_plan(self, loop: CodingLoop) -> None:
        t = self.screen.t
        plan = loop.plan
        assert plan is not None
        files = Table.grid(padding=(0, 2))
        files.add_column(style="bold", no_wrap=True)
        files.add_column()
        for item in plan.files:
            interface = "\n".join(plain(name) for name in item.interface)
            files.add_row(plain(item.path), Text.assemble(plain(item.purpose),
                                                          ("\n" + interface if interface else "", "dim")))
        parts: list[RenderableType] = [Text(t("planFiles"), style=ACCENT), files]
        if plan.steps:
            parts += [Text(""), Text(t("planSteps"), style=ACCENT),
                      *(Text(f"{number}. {plain(step)}") for number, step in enumerate(plan.steps, 1))]
        if plan.requirements:
            parts += [Text(""), Text(t("planRequirements"), style=ACCENT),
                      *(Text.assemble(f"- {plain(item.asked)} ", ("→ " + plain(item.how), "dim"))
                        for item in plan.requirements)]
        self.screen.line(Panel(Group(*parts), title=Text(t("planTitle"), style="bold"), title_align="left",
                               subtitle=Text(t("planChoices"), style="dim"), subtitle_align="left",
                               border_style=ACCENT, box=box.ROUNDED))

    def _questions(self, loop: CodingLoop) -> list[str] | None:
        screen, t = self.screen, self.screen.t
        answers = []
        for number, question in enumerate(loop.questions, 1):
            screen.line(Text.assemble((f"{number}. ", ACCENT), (plain(question.prompt), "bold")))
            for choice, option in enumerate(question.options, 1):
                screen.line(Text.assemble((f"   {choice}) ", ACCENT), plain(option)))
            screen.line(screen.dim(f"   {t('questionChoice')}"))
            said = self.ask(f"{t('answerPrompt')} {MAIN_PROMPT}").strip()
            if not said:
                return None
            picked = int(said) if said.isdigit() else 0
            answers.append(question.options[picked - 1] if 1 <= picked <= len(question.options) else said)
        # As the editor sends them: each question with its answer.
        return self._code("answer", loop.loop_id, "\n".join(
            f"{number}. {question.prompt} → {answer}"
            for number, (question, answer) in enumerate(zip(loop.questions, answers), 1)))

    # --- commands --------------------------------------------------------------------

    def command(self, text: str) -> bool:
        """A slash command; False to leave."""
        name, _, rest = text[1:].strip().partition(" ")
        rest = rest.strip()
        screen, t = self.screen, self.screen.t
        if name in ("exit", "quit"):
            return False
        if name == "help":
            self.help()
        elif name == "new":
            self.last = None
            screen.line(t("newConversation"))
        elif name == "list":
            self.list()
        elif name == "open":
            self.open(rest)
        elif name == "resume":
            self.resume(rest or None)
        elif name == "undo":
            self.undo()
        elif name == "model":
            if rest:
                self.model = rest
            screen.line(t("model", model=self.model or "-"))
        elif name == "auto":
            if rest in ("on", "off"):
                self.auto = rest == "on"
            screen.line(t("auto", state=t("on" if self.auto else "off")))
        elif name == "config":
            self.config(rest)
        elif name == "image":
            self.image(rest)
        else:
            screen.line(t("unknownCommand", name=f"/{name}"))
        return True

    def image(self, rest: str) -> None:
        """`/image <path>...` waits for the next request; `/image clear` takes them off; alone, says them."""
        screen, t = self.screen, self.screen.t
        if rest == "clear":
            self.queued = []
            screen.line(t("imageCleared"))
            return
        for given in chat_images.paths_given(rest):
            path = chat_images.image_path(given, self.workspace)
            if path is None:
                screen.line(screen.warn(t("imageNotFound", path=given)))
                continue
            self.queued.append(path)
        if not self.queued:
            screen.line(t("imageNone"))
        for path in self.queued:
            screen.line(t("imageQueued", path=str(path), size=chat_images.size_of(path)))

    def help(self) -> None:
        screen = self.screen
        table = Table.grid(padding=(0, 3))
        table.add_column(style=ACCENT, no_wrap=True)
        table.add_column()
        for name, english, korean in COMMANDS:
            table.add_row(name, korean if screen.korean else english)
        screen.line(screen.t("helpIntro"))
        screen.line(table)

    def threads(self) -> list[dict[str, object]]:
        from relab_app.coding_loop import CodingLoopService

        # A folder ReLab never worked in has none, and is not given a record to say so.
        return [] if untouched(self.workspace) else CodingLoopService(self.workspace).threads()[:LISTED]

    def list(self) -> None:
        screen, t = self.screen, self.screen.t
        self.listed = self.threads()
        if not self.listed:
            screen.line(t("noConversations"))
            return
        table = Table(title=t("listTitle"), title_justify="left", box=box.SIMPLE_HEAD, header_style="dim")
        for index, column in enumerate(t("columns").split("|")):
            table.add_column(column, style=ACCENT if index == 0 else None, justify="right" if index in (0, 3) else "left",
                             overflow="ellipsis", no_wrap=index != 1, ratio=1 if index == 1 else None)
        for number, item in enumerate(self.listed, 1):
            outcome = f"outcome.{item.get('outcome')}"
            table.add_row(str(number), plain(item.get("title", "")),
                          t(outcome) if outcome in TEXTS else plain(item.get("outcome", "")),
                          str(item.get("loops", 1)), str(item.get("updated_at", ""))[:16].replace("T", " "))
        screen.line(table)
        screen.line(screen.dim(t("openHint")))

    def open(self, which: str) -> None:
        """A conversation as it stands, drawn at once; what is typed next goes on in it."""
        from relab_app.coding_loop import CodingLoopService

        screen, t, glyph = self.screen, self.screen.t, self.screen.glyph
        if which.isdigit():
            if not self.listed:
                self.listed = self.threads()
            index = int(which) - 1
            if not 0 <= index < len(self.listed):
                screen.line(t("notListed", which=which))
                return
            which = str(self.listed[index]["last_loop"])
        try:
            loops = CodingLoopService(self.workspace).thread(which)
        except LookupError:
            screen.line(t("notListed", which=plain(which)))
            return
        screen.line(Text(t("opened", title=plain(loops[0].request.splitlines()[0][:80])), style="bold"))
        for loop in loops:
            for request in [loop.request, *(item.request for item in loop.followups)]:
                screen.line()
                screen.line(Text.assemble((f"{glyph['you']} ", ACCENT), (plain(request), "bold")))
            self.ended(loop)
        self.last = loops[-1]
        if self.last.outcome is LoopOutcome.WAITING:
            self.converse(self.last)

    def resume(self, model: str | None) -> None:
        last = self.last
        if last is None or last.outcome not in RESUMABLE:
            self.screen.line(self.screen.t("nothingToResume"))
            return
        self.converse(self._leg(self._code("resume", last.loop_id, model=model), last.loop_id))

    def undo(self) -> None:
        from relab_app.coding_loop import CodingLoopService

        screen, t = self.screen, self.screen.t
        last = self.last
        if last is None or not last.written or last.outcome is LoopOutcome.UNDONE:
            screen.line(t("nothingToUndo"))
            return
        service = CodingLoopService(self.workspace)
        restored, kept = service.undo(last.loop_id)
        screen.line(t("undone", restored=", ".join(restored) or "-"))
        if kept:
            screen.line(screen.warn(t("kept", kept=", ".join(kept))))
        self.last = service.load(last.loop_id)

    def config(self, rest: str = "") -> None:
        """What applies, and where it comes from; `set` and `unset` change a file (0.3.12)."""
        screen, t = self.screen, self.screen.t
        action, _, rest = rest.partition(" ")
        if action in ("set", "unset"):
            self.set_config(action, rest.strip())
            return
        if action:
            screen.line(screen.dim(t("configUsage")))
            return
        table = Table.grid(padding=(0, 2))
        table.add_column(style="dim", no_wrap=True)
        # A path folded onto the next line, not cut short where it says which folder.
        table.add_column(overflow="fold")
        for path in (chat_config.user_path(), chat_config.project_path(self.workspace)):
            table.add_row(t("configFiles"), f"{path}" + ("" if path.is_file() else f" {t('missing')}"))
        differing = chat_config.shown(self.values)
        for key, value in differing:
            table.add_row(key, json.dumps(value, ensure_ascii=False))
        screen.line(table)
        if not differing:
            screen.line(screen.dim(t("configNone")))
        screen.line(screen.dim(t("configUsage")))

    def set_config(self, action: str, rest: str) -> None:
        """One setting saved in the person's file, or the project's with `--project`, and used from now."""
        screen, t = self.screen, self.screen.t
        first, _, after = rest.partition(" ")
        project = first == "--project"
        key, _, text = (after.strip() if project else rest).partition(" ")
        if not key or (action == "set" and not text.strip()):
            screen.line(screen.dim(t("configUsage")))
            return
        if key not in chat_config.DEFAULTS:
            screen.line(screen.warn(t("notASetting", name=plain(key))))
            screen.line(screen.dim(t("configNames", names=", ".join(chat_config.DEFAULTS))))
            return
        value: object | None = None
        if action == "set":
            try:
                value = chat_config.parse(key, text)
            except ValueError:
                screen.line(screen.warn(t("badValue", name=key, value=plain(text.strip()))))
                screen.line(screen.dim(t("takes", what=self._takes(key))))
                return
        path = chat_config.project_path(self.workspace) if project else chat_config.user_path()
        try:
            chat_config.write(path, key, value)
        except (OSError, ValueError) as error:
            screen.line(screen.warn(t("configNotSaved", problem=plain(str(error)))))
            return
        shown = json.dumps(value, ensure_ascii=False)
        screen.line(t("configSaved", path=path, name=key, value=shown) if action == "set"
                    else t("configRemoved", path=path, name=key), whole=True)
        values, _ = chat_config.load(self.workspace)
        applies = values[key]
        if not project and key in chat_config.read(chat_config.project_path(self.workspace))[0]:
            screen.line(screen.dim(t("projectWins", name=key, value=json.dumps(applies, ensure_ascii=False))))
        elif action == "unset":
            screen.line(screen.dim(t("nowApplies", name=key, value=json.dumps(applies, ensure_ascii=False))))
        self.values[key] = applies
        if key in ("codingModel", "model"):
            self.model = chat_config.coding_model(self.values)
        elif key == "approvalMode":
            self.auto = applies == "auto"
        elif key == "language":
            screen.korean = applies == "ko" or (applies == "auto" and _korean())
        elif key == "privateStore":
            # Where the records are kept is settled when the chat starts.
            screen.line(screen.dim(t("nextStart")))

    def _takes(self, key: str) -> str:
        t = self.screen.t
        fallback = chat_config.DEFAULTS[key]
        if key in chat_config.CHOICES:
            return ", ".join(repr(choice) if not choice else choice for choice in chat_config.CHOICES[key])
        if isinstance(fallback, bool):
            return t("takesSwitch")
        if isinstance(fallback, (int, float)):
            return t("takesNumber")
        if isinstance(fallback, str):
            return t("takesText")
        if isinstance(fallback, list):
            return t("takesList")
        example = {"modelContextWindows": '{"qwen3-coder": 131072}',
                   "modelSampling": '{"qwen3-coder": "temperature=0.6, top_p=0.95"}'}.get(
            key, '{"name": "http://host:8000/v1"}')
        return t("takesObject", example=example)

    def toolbar(self) -> str:
        t = self.screen.t
        return t("toolbar", mode="auto" if self.auto else t("ask"), model=self.model or "-")


def read_message(prompt: str) -> str:
    """One message, without a terminal to edit it in: a pasted block arrives as one.

    Windows PowerShell starts what it pipes to a program with a byte order mark
    (0.3.13), which would make a piped first line `/config` not a command.
    """
    lines = [input(prompt).lstrip("﻿")]
    while lines[-1].endswith("\\"):
        lines[-1] = lines[-1][:-1]
        lines.append(input("… "))
    while _more_typed():
        lines.append(input())
    return "\n".join(lines)


def _more_typed() -> bool:
    """Whether more of a paste is already waiting, a moment after a line."""
    if not sys.stdin.isatty():
        return False
    time.sleep(0.03)
    if sys.platform == "win32":
        import msvcrt

        return bool(msvcrt.kbhit())
    import select

    return bool(select.select([sys.stdin], [], [], 0)[0])


def config_completions(typed: str) -> list[tuple[str, str]]:
    """What `/config` may go on with, for the word being typed: `set`/`unset`, then a setting's name."""
    words = typed.split(" ")
    if words[0] != "/config":
        return []
    done, word = [item for item in words[1:-1] if item], words[-1]
    if not done:
        options = [("set", ""), ("unset", "")]
    elif done[0] in ("set", "unset") and done[1:] in ([], ["--project"]):
        options = [*([] if done[1:] else [("--project", "")]),
                   *((key, json.dumps(value, ensure_ascii=False)) for key, value in chat_config.DEFAULTS.items())]
    else:
        options = []
    return [(name, meta) for name, meta in options if name.startswith(word)]


def top_edge(width: int, hint: str) -> Text:
    """The input box's top edge for a window `width` cells wide.

    One cell short of the width, as an edge reaching the last column makes some
    terminals wrap there; the hint is left out where it cannot fit.
    """
    if cell_len(hint) > width - 6:
        hint = ""
    rest = max(2, width - 1 - 2 - cell_len(hint))
    return Text.assemble(("╭─", FRAME), (hint, "#808080"), ("─" * rest, FRAME))


def boxed_input(screen: Screen, toolbar: Callable[[], str]) -> Callable[[str], str]:
    """What is typed, on a terminal: a framed box, its history kept, `/` commands completed.

    Enter sends; Esc then Enter starts a new line, and a pasted block stays one
    message. Answers to what a loop waits on are asked in a box of their own,
    kept out of the history.
    """
    from prompt_toolkit import PromptSession
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.history import FileHistory, InMemoryHistory
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.styles import Style

    from relab_workspace.private_state import private_base

    class Commands(Completer):
        def get_completions(self, document, complete_event):  # type: ignore[no-untyped-def]
            typed = document.text_before_cursor
            if not typed.startswith("/"):
                return
            if " " in typed:
                for word, meta in config_completions(typed):
                    yield Completion(word, start_position=-len(typed.rsplit(" ", 1)[1]), display_meta=meta)
                return
            for name, english, korean in COMMANDS:
                if name.startswith(typed):
                    yield Completion(name, start_position=-len(typed),
                                     display_meta=korean if screen.korean else english)

    keys = KeyBindings()

    @keys.add("escape", "enter")
    def _(event) -> None:  # type: ignore[no-untyped-def]
        event.current_buffer.insert_text("\n")

    style = Style.from_dict({"frame": FRAME, "hint": "#808080", "arrow": f"bold {ACCENT}"})
    try:
        folder = private_base()
        folder.mkdir(parents=True, exist_ok=True)
        history: FileHistory | InMemoryHistory = FileHistory(str(folder / "chat_history"))
    except OSError:
        history = InMemoryHistory()
    # No bottom toolbar: prompt_toolkit draws one at the foot of the window, a
    # screen away from the box. What it would say is in the box's top edge.
    main: PromptSession[str] = PromptSession(
        history=history, completer=Commands(), complete_while_typing=True, key_bindings=keys, style=style,
        reserve_space_for_menu=4, prompt_continuation=lambda width, line, wrapped: [("class:frame", "│   ")])
    answers: PromptSession[str] = PromptSession(history=InMemoryHistory(), key_bindings=keys, style=style)

    def ask(prompt: str) -> str:
        if prompt == MAIN_PROMPT:
            # The edge is printed above the prompt, not drawn as part of it:
            # prompt_toolkit redraws on a resize by going up the rows it drew,
            # and a full-width edge the terminal had reflowed into more rows
            # was left in pieces stacked above the box, one more each resize.
            screen.console.print(top_edge(screen.console.width, f" {toolbar()} "), soft_wrap=True)
            return str(main.prompt([("class:frame", "│ "), ("class:arrow", prompt)]))
        return str(answers.prompt([("class:arrow", prompt)]))

    return ask


def _version() -> str:
    from importlib.metadata import PackageNotFoundError, version

    try:
        return version("relab")
    except PackageNotFoundError:
        return "dev"


def chat(args: argparse.Namespace, *, ask: Callable[[str], str] | None = None,
         runner: Runner | None = None, out: TextIO | None = None) -> int:
    """`relab chat`: talk until /exit; with `-p`, one request, and its result as the exit code."""
    workspace = Path(args.workspace).expanduser().absolute()
    values, problems = chat_config.load(workspace)
    for key, given in (("codingModel", args.model), ("provider", args.provider)):
        if given:
            values[key] = given
    if args.endpoint:
        provider = chat_config.coding_provider(values)
        values["vllmEndpoint" if provider == "vllm" else "ollamaEndpoint"] = args.endpoint
    if args.auto:
        values["approvalMode"] = "auto"
    chat_config.use_private_store(values)
    language = values.get("language")
    screen = Screen(out, korean=language == "ko" or (language == "auto" and _korean()))
    session = Chat(workspace, values, screen, ask=ask, runner=runner)
    asking = ask is not None or sys.stdin.isatty()
    if ask is None and screen.live and sys.stdin.isatty():
        session.ask = boxed_input(screen, session.toolbar)
    found = _workspace(session, workspace, asking=asking and args.once is None)
    if found is None:
        return NOT_STARTED
    session.workspace = workspace = found
    _fresh(screen, args, at_keyboard=ask is None and sys.stdin.isatty())
    for problem in problems:
        screen.line(screen.warn(f"! {plain(problem)}"))
    if args.once is not None:
        loop = session.converse(session.send(args.once), prompting=False)
        if loop is not None and loop.outcome is LoopOutcome.WAITING:
            _show_wait(session, loop)
            return WAITING
        passed = loop is not None and loop.outcome is LoopOutcome.FINISHED and (
            loop.assessment is None or loop.assessment.succeeded)
        return DONE if passed else NOT_DONE
    _banner(session, workspace)
    if args.resume_last:
        session.listed = session.threads()
        if session.listed:
            _interruptible(lambda: session.open("1"), screen)
    return _talk(session)


def logo(screen: Screen) -> Text:
    """RELAB in block letters, each column its colour along the gradient, and who made it."""
    if screen.glyph is PLAIN:
        return Text.assemble(("ReLab", f"bold {ACCENT}"), (f"  {MAKER}", "dim"))
    lines = LOGO if screen.console.width >= len(LOGO[0]) + 2 else SMALL_LOGO
    width = max(len(line) for line in lines)
    drawn = Text()
    for line in lines:
        for column, char in enumerate(line):
            at = column / max(1, width - 1) * (len(LOGO_COLORS) - 1)
            index = min(int(at), len(LOGO_COLORS) - 2)
            share = at - index
            colour = "".join(f"{round(a + (b - a) * share):02x}"
                             for a, b in zip(LOGO_COLORS[index], LOGO_COLORS[index + 1]))
            drawn.append(char, style=f"bold #{colour}")
        drawn.append("\n")
    # The maker, small beside the name: under its right edge.
    drawn.append(MAKER.rjust(width), style="dim italic")
    return drawn


def _workspace(session: Chat, workspace: Path, *, asking: bool) -> Path | None:
    """The folder to work in; one that is not there is made when the person says so (0.3.9).

    Asked in use. Only where someone can answer: `-p` and a run with no one at
    the keyboard stop and say how to make it, so a mistyped path never becomes
    a new folder that work starts in unseen.
    """
    screen, t = session.screen, session.screen.t
    if workspace.is_dir():
        return workspace.resolve()
    if workspace.exists():
        screen.line(screen.bad(t("notFolder", path=workspace)), whole=True)
        return None
    screen.line(screen.warn(t("noFolder", path=workspace)), whole=True)
    if not asking:
        screen.line(screen.dim(t("makeHint", path=workspace)), whole=True)
        return None
    try:
        said = session.ask(f"{t('makeFolder')} {MAIN_PROMPT}").strip().lower()
    except (EOFError, KeyboardInterrupt):
        said = ""
    if said not in YES:
        screen.line(screen.dim(t("makeHint", path=workspace)), whole=True)
        return None
    try:
        workspace.mkdir(parents=True)
    except OSError as error:
        screen.line(screen.bad(t("cannotMake", path=workspace, why=error.strerror or error)), whole=True)
        return None
    screen.line(screen.good(t("madeFolder", path=workspace)), whole=True)
    return workspace.resolve()


def _fresh(screen: Screen, args: argparse.Namespace, *, at_keyboard: bool) -> None:
    """A conversation at the keyboard starts on a clear screen, as `clear` leaves it (asked in use).

    What was there scrolls up, not away; `-p`, a pipe and `--no-clear` keep it.
    """
    if at_keyboard and screen.live and args.once is None and not args.no_clear:
        screen.console.clear()


def _banner(session: Chat, workspace: Path) -> None:
    screen, glyph = session.screen, session.screen.glyph
    values = session.values
    mode = "auto" if session.auto else screen.t("ask")
    screen.line(logo(screen))
    screen.line()
    screen.line(Text.assemble((f"{glyph['star']} ", ACCENT), ("ReLab ", "bold"), (_version(), "bold"),
                              (f"  ·  {session.model or '-'} · {chat_config.coding_provider(values)} · {mode}",
                               "dim")))
    screen.line(screen.dim(f"  {workspace}"), whole=True)
    screen.line(screen.dim(screen.t("bannerHelp")))
    if not session.model:
        screen.line(screen.warn(screen.t("noModel", path=chat_config.user_path())))


def _interruptible(work: Callable[[], object], screen: Screen) -> None:
    """Ctrl+C at a question leaves it waiting, as Enter does; it does not end the chat."""
    try:
        work()
    except KeyboardInterrupt:
        screen.line()
        screen.line(screen.dim(screen.t("laterHint")))


def _show_wait(session: Chat, loop: CodingLoop) -> None:
    """In one-shot use, what it waits on, said and left for `relab chat --continue`."""
    screen = session.screen
    if loop.review is not None:
        screen.line(f"{screen.t('applyChange')} {plain(loop.review.path)}")
    elif loop.permission:
        screen.line(f"{screen.t('runCommand')} $ {plain(shlex.join(loop.permission))}")
    elif loop.plan is not None and not loop.plan_approved:
        screen.line(screen.t("planTitle"))
    for question in loop.questions:
        screen.line(f"- {plain(question.prompt)}")
    if loop.question:
        screen.line(plain(loop.question))
    screen.line(screen.t("waitingOnce"))


def _said(session: Chat, text: str) -> None:
    session.converse(session.send(text))


def _talk(session: Chat) -> int:
    screen = session.screen
    interrupted = False
    while True:
        waiting = session.last is not None and session.last.outcome is LoopOutcome.WAITING
        try:
            screen.line()
            text = session.ask(f"{screen.t('answerPrompt')} {MAIN_PROMPT}" if waiting else MAIN_PROMPT).strip()
        except EOFError:
            screen.line()
            return 0
        except KeyboardInterrupt:
            if interrupted:
                return 0
            interrupted = True
            screen.line(screen.dim(screen.t("exitHint")))
            continue
        interrupted = False
        if not text:
            continue
        try:
            # A dragged path begins with "/" on Linux: a picture's path is a request, not a command.
            if text.startswith("/") and not chat_images.starts_with_image(text, session.workspace):
                if not session.command(text):
                    return 0
                continue
            _interruptible(functools.partial(_said, session, text), screen)
        except EOFError:
            screen.line()
            return 0
