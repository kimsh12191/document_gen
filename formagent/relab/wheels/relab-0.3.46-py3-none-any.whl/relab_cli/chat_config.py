"""What `relab chat` runs with: the editor's settings, read from a file (0.3.8).

The editor keeps its settings in its own storage, and builds the options of
each `relab code` command from them. A person working in a terminal has no
settings page, so the same settings are read from JSON files, under the same
names: `~/.relab/config.json` for the person, `.relab/config.json` in the
workspace for a project, the project's winning. "ReLab: Use These Settings in
the Terminal" in the editor writes the first from the settings page.

The options are built here the way the editor builds them
(`apps/vscode/src/backend/client.ts`, `asked` and `looped`), so a request
typed in a terminal runs as the same request typed in the chat would.
"""

from __future__ import annotations

import argparse
import json
import os
from collections.abc import Sequence
from pathlib import Path

# The editor's defaults (apps/vscode/src/settingsModel.ts), for the settings a
# coding loop is run with; `language` is the terminal's own.
DEFAULTS: dict[str, object] = {
    "provider": "openrouter",
    "codingProvider": "",
    "codingModel": "",
    "model": "",
    "modelLadder": [],
    "maxTaskCost": 0,
    "ladderMoveOn": "all",
    "ladderAfterFailures": 3,
    "maxModelCalls": 0,
    "codingRunHours": 6,
    "commandMinutes": 30,
    "vllmEndpoint": "",
    "vllmModelEndpoints": {},
    "modelSampling": {},
    "modelContextWindows": {},
    "contextBudget": 0,
    "ollamaEndpoint": "",
    "approvalMode": "ask",
    "reviewEdits": True,
    "compactPrompt": False,
    "planFirst": True,
    "defaultRules": True,
    "heldOutPaths": [],
    "privateStore": "",
    "projectOnlyReads": False,
    "reasoningEffort": "default",
    "openrouterProviderSort": "default",
    "modelTimeoutSeconds": 600,
    "idleTimeoutSeconds": 120,
    "language": "auto",
}

PROVIDERS = ("openrouter", "openai", "vllm", "ollama")
CHOICES: dict[str, tuple[str, ...]] = {
    "provider": PROVIDERS,
    "codingProvider": ("", *PROVIDERS),
    "approvalMode": ("ask", "auto"),
    "ladderMoveOn": ("all", "failures", "checks"),
    "reasoningEffort": ("default", "minimal", "low", "medium", "high"),
    "openrouterProviderSort": ("default", "throughput", "latency", "price"),
    "language": ("auto", "en", "ko"),
}
# The most calls a run may be given (0.3.6), as the editor clamps it.
MAXIMUM_CALLS = 500
# A loop's ladder, as the editor keeps it: five larger models at most.
MAXIMUM_LADDER = 5
FOLDER = ".relab"
NAME = "config.json"


def user_path() -> Path:
    """The person's settings: in their home, wherever the records are kept."""
    return Path.home() / FOLDER / NAME


def project_path(workspace: Path) -> Path:
    return workspace / FOLDER / NAME


def _valid(key: str, value: object) -> bool:
    fallback = DEFAULTS[key]
    if key in CHOICES:
        return value in CHOICES[key]
    if isinstance(fallback, bool):
        return isinstance(value, bool)
    if isinstance(fallback, (int, float)):
        return isinstance(value, (int, float)) and not isinstance(value, bool) and value >= 0
    if isinstance(fallback, str):
        return isinstance(value, str)
    if isinstance(fallback, list):
        return isinstance(value, list) and all(isinstance(item, str) for item in value)
    if key == "modelContextWindows":
        return isinstance(value, dict) and all(
            isinstance(count, int) and not isinstance(count, bool) and count > 0 for count in value.values())
    if key == "modelSampling":
        return isinstance(value, dict) and all(isinstance(item, str) and _samples(item) for item in value.values())
    return isinstance(value, dict) and all(isinstance(item, str) for item in value.values())


def _samples(text: str) -> bool:
    """Whether a model's sampling reads as `temperature=0.6, top_p=0.95` (0.3.38)."""
    from relab_coding.chat_gateway import parse_sampling

    try:
        return bool(parse_sampling(text))
    except ValueError:
        return False


def read(path: Path) -> tuple[dict[str, object], list[str]]:
    """One file's settings that are known and well formed, and what was not."""
    if not path.is_file():
        return {}, []
    try:
        given = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as error:
        return {}, [f"{path}: not read ({error})"]
    if not isinstance(given, dict):
        return {}, [f"{path}: not a JSON object"]
    kept: dict[str, object] = {}
    problems = []
    for key, value in given.items():
        if key not in DEFAULTS:
            problems.append(f"{path}: {key!r} is not a setting here (left out)")
        elif not _valid(key, value):
            problems.append(f"{path}: {key!r} = {value!r} is not a value it takes (left out)")
        else:
            kept[key] = value
    return kept, problems


def load(workspace: Path) -> tuple[dict[str, object], list[str]]:
    """The defaults, the person's file over them, the project's over that."""
    values = dict(DEFAULTS)
    problems: list[str] = []
    for path in (user_path(), project_path(workspace)):
        kept, said = read(path)
        values.update(kept)
        problems.extend(said)
    return values, problems


def use_private_store(values: dict[str, object]) -> None:
    """Keep records where the editor keeps them, so a conversation is in both lists.

    The editor's default is its own storage folder, which the setting written
    by the editor names; a folder already named in the environment wins.
    """
    folder = str(values.get("privateStore") or "").strip()
    if folder and not os.environ.get("RELAB_PRIVATE_HOME", "").strip():
        os.environ["RELAB_PRIVATE_HOME"] = str(Path(folder).expanduser())


def coding_model(values: dict[str, object]) -> str:
    return str(values.get("codingModel") or values.get("model") or "").strip()


def coding_provider(values: dict[str, object]) -> str:
    return str(values.get("codingProvider") or values.get("provider") or "openrouter")


def _strings(value: object) -> list[str]:
    return [item.strip() for item in value if isinstance(item, str) and item.strip()] \
        if isinstance(value, list) else []


def _served(values: dict[str, object]) -> dict[str, str]:
    given = values.get("vllmModelEndpoints")
    if not isinstance(given, dict):
        return {}
    return {name.strip(): url.strip() for name, url in given.items()
            if isinstance(url, str) and name.strip() and url.strip()}


def step_ups(model: str, base: str, ladder: list[str]) -> list[str]:
    """The larger models a stuck loop may move up to: the tiers above the one working.

    The editor also guesses the tier of a model off the list from its size;
    here a model off the list moves up to nothing, unless no base is named.
    """
    tiers = list(dict.fromkeys(item for item in [base, *ladder] if item))
    if model in tiers:
        return tiers[tiers.index(model) + 1:]
    return list(dict.fromkeys(ladder)) if not base else []


def model_flags(values: dict[str, object], model: str) -> list[str]:
    """`--model`, `--provider`, and the servers it may reach (the editor's `asked`)."""
    provider = coding_provider(values)
    endpoint = {"vllm": str(values.get("vllmEndpoint") or "").strip(),
                "ollama": str(values.get("ollamaEndpoint") or "").strip()}.get(provider, "")
    served = _served(values) if provider == "vllm" else {}
    flags = ["--model", model, "--provider", provider, *(["--endpoint", endpoint] if endpoint else [])]
    for name, url in served.items():
        flags += ["--model-endpoint", f"{name}={url}"]
    # Each model's temperature and top_p, when set (0.3.38); any provider.
    sampling = values.get("modelSampling")
    for name, said in (sampling.items() if isinstance(sampling, dict) else []):
        if isinstance(said, str) and name.strip() and said.strip():
            flags += ["--model-sampling", f"{name.strip()}={said.strip()}"]
    # The addresses the settings name, and only those, may be another machine.
    for url in dict.fromkeys(item for item in [endpoint, *served.values()] if item):
        flags += ["--allow-endpoint", url]
    return flags


def loop_flags(values: dict[str, object], model: str, *, auto: bool) -> list[str]:
    """How a loop's calls are made and bounded (the editor's `looped`)."""
    flags: list[str] = []
    ladder = _strings(values.get("modelLadder"))[:MAXIMUM_LADDER]
    for larger in step_ups(model, coding_model(values), ladder):
        flags += ["--escalate-to", larger]
    flags += ["--escalate", "auto" if auto else "ask"]
    move_on = values.get("ladderMoveOn")
    reasons = ["check"] if move_on == "checks" else ["check", "unreadable"] if move_on == "failures" else []
    for reason in reasons:
        flags += ["--escalate-on", reason]
    after = values.get("ladderAfterFailures")
    if isinstance(after, int) and 1 <= after <= 20 and after != 3:
        flags += ["--escalate-after", str(after)]
    if auto:
        flags.append("--auto")
    if values.get("compactPrompt") is True:
        flags.append("--compact-prompt")
    if values.get("defaultRules") is False:
        flags.append("--no-default-rules")
    if values.get("planFirst") is True:
        flags.append("--plan-first")
    hours = values.get("codingRunHours")
    if isinstance(hours, (int, float)) and hours > 0:
        flags += ["--time-limit", str(round(hours * 3600))]
    for path in _strings(values.get("heldOutPaths"))[:20]:
        flags += ["--held-out", path]
    minutes = values.get("commandMinutes")
    if isinstance(minutes, (int, float)) and minutes > 0:
        flags += ["--command-timeout", str(round(minutes * 60))]
    cost = values.get("maxTaskCost")
    if isinstance(cost, (int, float)) and cost > 0:
        flags += ["--max-cost", str(cost)]
    calls = values.get("maxModelCalls")
    # A number set is kept as set; 0 leaves the default, raised for a local server.
    if isinstance(calls, int) and calls > 0:
        flags += ["--max-calls", str(min(calls, MAXIMUM_CALLS)), "--calls-as-given"]
    windows = values.get("modelContextWindows")
    for name, tokens in (windows.items() if isinstance(windows, dict) else []):
        flags += ["--model-context", f"{name}={tokens}"]
    budget = values.get("contextBudget")
    if type(budget) is int and budget > 0:
        flags += ["--context-budget", str(budget)]
    flags += ["--model-timeout", str(values.get("modelTimeoutSeconds")),
              "--idle-timeout", str(values.get("idleTimeoutSeconds")),
              "--provider-sort", str(values.get("openrouterProviderSort")),
              "--reasoning-effort", str(values.get("reasoningEffort"))]
    return flags


def parse(key: str, text: str) -> object:
    """A value typed for `key` (0.3.12), as its file holds it; ValueError if it takes no such value.

    JSON where it is JSON; otherwise the text as typed, `on`/`off` for a switch,
    and a list given by commas.
    """
    fallback = DEFAULTS[key]
    text = text.strip()
    try:
        given: object = json.loads(text)
    except ValueError:
        given = text
    value: object
    if isinstance(fallback, str):
        value = given if isinstance(given, str) else text
    elif isinstance(fallback, bool):
        switch: dict[str, object] = {"on": True, "off": False}
        value = switch.get(text.lower(), given)
    elif isinstance(fallback, list):
        value = given if isinstance(given, list) else [item.strip() for item in text.split(",") if item.strip()]
    else:
        value = given
    if not _valid(key, value):
        raise ValueError(f"{key!r} does not take {text!r}")
    return value


def write(path: Path, key: str, value: object | None) -> None:
    """Set `key` in the settings file at `path`, or take it out when `value` is None.

    What else the file holds is kept as it is; a file that is not a JSON object
    is left alone (ValueError) rather than written over.
    """
    given: object = {}
    if path.is_file():
        given = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(given, dict):
            raise ValueError(f"{path}: not a JSON object")
    assert isinstance(given, dict)
    if value is None:
        given.pop(key, None)
    else:
        given[key] = value
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(given, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def shown(values: dict[str, object]) -> list[tuple[str, object]]:
    """The settings that differ from the defaults, to say what applies."""
    return [(key, value) for key, value in values.items() if value != DEFAULTS[key]]


def add_arguments(parser: argparse.ArgumentParser, providers: Sequence[str]) -> None:
    """`relab chat`'s options, here so building the parser imports nothing that draws."""
    parser.add_argument("--workspace", type=Path, default=Path("."))
    parser.add_argument("-p", "--print", dest="once", metavar="REQUEST",
                        help="Work one request through, print what it did and exit: 0 done, 1 not done, "
                             "3 waiting on you")
    parser.add_argument("-c", "--continue", dest="resume_last", action="store_true",
                        help="Open the newest conversation in this workspace")
    parser.add_argument("--model", help="The coding model, over the settings' codingModel")
    parser.add_argument("--provider", choices=list(providers))
    parser.add_argument("--endpoint", help="The vLLM or Ollama server, over the settings'")
    parser.add_argument("--auto", action="store_true",
                        help="Approve commands, changes and plans without asking (refusals stay)")
    parser.add_argument("--no-clear", action="store_true",
                        help="Keep what the terminal shows; a conversation otherwise starts on a clear screen")
