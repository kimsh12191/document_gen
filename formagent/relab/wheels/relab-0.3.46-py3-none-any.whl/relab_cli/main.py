"""Initial thin CLI adapter for the integrated coding capability."""

import argparse
import contextlib
import json
import math
import os
import sqlite3
import sys
import time
from collections.abc import Callable
from pathlib import Path

from pydantic import ValidationError

from relab_app.ablation import CHECK_STYLE_ENV, CHECK_STYLES, SWITCHES, WITHOUT_ENV
from relab_app.accounting import measurement_impact
from relab_app.agenda import WorkspaceAgendaReader
from relab_app.checkouts import WorkspaceCheckouts
from relab_app.client import WorkspaceClient, nothing_kept, untouched
from relab_app.coding_loop import BUILD_STEPS as BUILD_LOOP_STEPS
from relab_app.coding_loop import DEFAULT_STEPS as DEFAULT_LOOP_STEPS
from relab_app.coding_loop import (
    STUCK_CHECKS,
    CodingLoopService,
    ModelLadder,
    threads_elsewhere,
    window_for,
)
from relab_app.conversation import Conversation
from relab_app.conversation_api import ConversationAPI, StaleConversationAction
from relab_app.escalation import climb
from relab_app.inspection import WorkspaceInspection
from relab_app.interpretation import SessionInterpreter
from relab_app.lifecycle import SessionLifecycleReader
from relab_app.memory import ResearchMemory
from relab_app.next_action import NextActions
from relab_app.orchestration import SessionDriver
from relab_app.proposals import ResearchProposals
from relab_app.reconciliation import SessionReconciler
from relab_app.repair import RepairMemory
from relab_app.review import PatchReviews
from relab_app.run_profile import PROFILE_ENV, PROFILES
from relab_app.runs import CodingRunService
from relab_app.sessions import ResearchSessionService
from relab_coding.chat_gateway import ChatGateway
from relab_coding.ollama import OllamaGateway
from relab_coding.service import CodingService
from relab_coding.targets import propose_targets
from relab_coding.validation import validate_model
from relab_core.coding.consumer import ReceivedCodingResult
from relab_core.coding.dependency import DependencyInstallDecision, DependencyInstallPolicy
from relab_core.coding.inspection import CodeInspectionRequest
from relab_core.coding.patch import PatchProposal, PatchStatus
from relab_core.coding_loop import LoopOutcome, ModelChangeReason
from relab_core.contracts import RunState
from relab_core.conversation_actions import ConversationActionRequest
from relab_core.conversation_history import ConversationHistoryTurn
from relab_core.conversation_intent import ConversationInput
from relab_core.conversation_response import ConversationAction, ConversationResponse
from relab_core.evaluation import MetricRegistry
from relab_core.generation import (
    ModelGateway,
    ModelIdentity,
    multi_file_schema,
    single_file_schema,
)
from relab_core.lifecycle import LifecycleAction
from relab_core.measurement import MeasurementSetup
from relab_core.memory import DEFAULT_RETRIEVAL_LIMIT, MemoryDraft
from relab_core.next_action import NextActionKind, ProposedAmendment
from relab_core.operations import AMENDMENT_ROLE, PLANNER_ROLE, narrated
from relab_core.research import ArmTask, ResearchDecision
from relab_core.routing import ModelRole, ModelRoute, ModelRoutingPolicy
from relab_core.runs import RestoreReason
from relab_core.turns import TurnState
from relab_research.amendment import LLMAmendmentAdvisor
from relab_research.exploration import propose_exploration
from relab_research.extraction import LLMFindingExtractor
from relab_research.interpretation import memory_drafts
from relab_research.llm import LLMResearchPlanner
from relab_research.planner import ResearchPlanner, ScriptedPlanner
from relab_research.proposals import ProposedPlan, ResearchIntent
from relab_research.review import LLMPatchReviewer
from relab_workspace.conversation_history_store import ConversationHistoryStore
from relab_workspace.distribution import build_bundle, verify_bundle
from relab_workspace.operation_recorder import OperationRecorder
from relab_workspace.service import WorkspacePatchService

# How long one model call may take.
#
# It was 60 seconds, chosen when a call meant one file edit. Every call here now
# goes to a model that may reason first, and reasoning happens before a single
# character of the answer: a live arm generation was measured at 55 seconds, and
# a planner call spent more than 180 without finishing. A bound that is too short
# wastes the whole paid call; one that is too long only delays a failure, so the
# two mistakes are not the same size.
MODEL_TIMEOUT_SECONDS = 300.0
# A coding loop's call: streamed, so the whole may be long while each silence is short.
CODING_CALL_SECONDS = 600.0
CODING_IDLE_SECONDS = 120.0

# The app names the operation; only this adapter knows the command that performs it.
NEXT_COMMAND = {
    LifecycleAction.NONE: "nothing to do",
    LifecycleAction.RECORD_PLAN: "relab session plan SESSION_ID registry.json ...",
    LifecycleAction.REVISE_PLAN: "relab session revise-plan SESSION_ID registry.json ...",
    LifecycleAction.DECLARE_ARM_TASKS: "relab session revise-plan SESSION_ID ... --arm-task-file",
    LifecycleAction.RECOVER: "relab session recover SESSION_ID",
    LifecycleAction.INSPECT_HISTORY: "relab session diagnose SESSION_ID, then inspect manually",
    LifecycleAction.WAIT: "wait for the running worker to finish",
    LifecycleAction.RESOLVE_GATE: "relab run decide-dependency RUN_ID decision.json",
    LifecycleAction.MATERIALISE_MEASUREMENT:
        "relab session turn SESSION_ID --model MODEL (the driver builds it)",
    LifecycleAction.EXECUTE: "relab session execute SESSION_ID --model MODEL",
    LifecycleAction.REVIEW_BUDGET: "review attempt history and budget, or record a decision; no automatic retry",
    LifecycleAction.REVIEW_FAILURES: "relab session failures SESSION_ID ARM, then change the task, the model, or stop",
    LifecycleAction.REVISE_MEASUREMENT:
        "relab session measurement-impact SESSION_ID to see what it would retire, then "
        "relab session revise-measurement SESSION_ID measurement.json --rationale ...",
    LifecycleAction.EVALUATE_HOLDOUT: "relab session holdout SESSION_ID",
    LifecycleAction.CONCLUDE: "relab session conclude SESSION_ID DECISION --rationale ...",
}


# Which server serves which model, for providers on this machine (vLLM, Ollama):
# several vLLM servers, one model each, are told apart by model. Filled from
# `--model-endpoint MODEL=URL` before anything is called; `--endpoint` stays
# the server for any model not named here.
MODEL_ENDPOINTS: dict[str, str] = {}
# Each model's temperature and top_p, as the person set them (`--model-sampling`, 0.3.38);
# a model not named is sent neither, and its server's defaults hold.
MODEL_SAMPLING: dict[str, dict[str, float]] = {}
LOCAL_PROVIDERS = ("vllm", "ollama")
# Servers on another machine the person named for this command
# (`--allow-endpoint`, which the editor passes for the addresses in its
# settings). Only these are reached beyond this machine.
ALLOWED_ENDPOINTS: set[str] = set()


def _same(endpoint: str) -> str:
    # With or without the /v1 the server's API is under (0.3.34): `--endpoint http://h:8000`
    # and `--allow-endpoint http://h:8000/v1` name one server.
    return endpoint.strip().rstrip("/").lower().removesuffix("/v1").rstrip("/")


def parse_model_endpoints(values: list[str] | None) -> dict[str, str]:
    """`MODEL=URL`, repeated, into the map; a model named twice is refused."""
    found: dict[str, str] = {}
    for value in values or []:
        model, _, url = value.partition("=")
        if not model.strip() or not url.strip():
            raise ValueError(f"a model endpoint reads MODEL=URL; {value!r} does not")
        if model.strip() in found:
            raise ValueError(f"{model.strip()} is given more than one endpoint")
        found[model.strip()] = url.strip()
    return found


def parse_context_windows(values: list[str] | None) -> dict[str, int]:
    """`MODEL=TOKENS`, repeated: each model's context window."""
    found: dict[str, int] = {}
    for value in values or []:
        model, _, tokens = value.partition("=")
        if not model.strip() or not tokens.strip().isdigit() or int(tokens) < 1:
            raise ValueError(f"a context window reads MODEL=TOKENS; {value!r} does not")
        found[model.strip()] = int(tokens)
    return found


# The least a context budget may be: below it the instruction and the files in view leave a
# loop's steps almost nothing, and it summarizes each turn.
MINIMUM_CONTEXT_BUDGET = 16_000


def context_budget(args: argparse.Namespace) -> int | None:
    """`--context-budget TOKENS` (0.3.37): the room a loop keeps its prompt to; None, the window."""
    tokens = getattr(args, "context_budget", None)
    if tokens is None or tokens == 0:
        return None
    if type(tokens) is not int or tokens < MINIMUM_CONTEXT_BUDGET:
        raise ValueError(f"a context budget is at least {MINIMUM_CONTEXT_BUDGET:,} tokens, or 0 for "
                         f"the whole window; {tokens!r} is not")
    return tokens


def given_lessons(path: Path | None) -> tuple[str, ...]:
    """`--given-lessons FILE`: a JSON list of lesson texts, as `failure-kinds --out` writes it."""
    if path is None:
        return ()
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, list) or not all(isinstance(item, str) and item.strip() for item in data):
        raise ValueError(f"{path} is not a JSON list of lessons")
    return tuple(item.strip() for item in data)


LISTED_TITLE = 70


def listed_lines(items: list[dict[str, object]]) -> str:
    """`relab code list`: a line a loop, newest first, its id beside when it ran and what it was asked."""
    from datetime import datetime

    lines = ["updated (local)   outcome    steps      time  loop                                   request"]
    for item in items:
        when = datetime.fromisoformat(str(item["updated_at"])).astimezone().strftime("%Y-%m-%d %H:%M")
        minutes = float(str(item["seconds"])) / 60
        title = str(item["title"])
        title = title if len(title) <= LISTED_TITLE else title[:LISTED_TITLE - 3] + "..."
        lines.append(f"{when}  {item['outcome']:<10} {item['steps']:>5} {minutes:6.1f} min  "
                     f"{item['loop_id']}  {title}")
    return "\n".join(lines)


def records_from_settings() -> None:
    """Where the editor keeps the records, for every command (0.3.40): the person's settings file's
    `privateStore`, as `relab chat` already read it, when the environment names none.

    From use: the editor kept its loops in "Your own records" on the NAS, and `relab code lessons`
    in the terminal looked in ~/.relab and said `[]`. The file is the one in the person's home that
    "ReLab: Use Settings in Terminal" writes -- never a project's, which a repository could carry.
    """
    from relab_cli.chat_config import read, user_path
    from relab_workspace.private_state import PRIVATE_ENV, in_workspace

    if in_workspace() or os.environ.get(PRIVATE_ENV, "").strip():
        return
    values, _ = read(user_path())
    folder = str(values.get("privateStore") or "").strip()
    if folder:
        os.environ[PRIVATE_ENV] = str(Path(folder).expanduser())


def records_elsewhere(workspace: Path) -> str | None:
    """Nothing kept here for this workspace, but the editor kept its loops: where, and how to look."""
    from relab_app.loop_store import records
    from relab_workspace.private_state import PRIVATE_ENV, editor_bases, in_workspace, workspace_key

    if in_workspace() or os.environ.get(PRIVATE_ENV, "").strip():
        return None
    key = workspace_key(workspace)
    for base in editor_bases():
        if records(base / "workspaces" / key / "coding_loops"):
            return (f"[relab] No coding loop of this workspace is kept in ~/.relab; the editor keeps "
                    f"them in {base}. Look there with {PRIVATE_ENV} set to that folder, e.g. "
                    f"{PRIVATE_ENV}={base} relab code list")
    return None


def parse_model_sampling(values: list[str] | None) -> dict[str, dict[str, float]]:
    """`MODEL=temperature=0.6,top_p=0.95`, repeated: each model's sampling (0.3.38)."""
    from relab_coding.chat_gateway import parse_sampling

    found: dict[str, dict[str, float]] = {}
    for value in values or []:
        model, _, sampling = value.partition("=")
        if not model.strip() or not sampling.strip():
            raise ValueError(f"model sampling reads MODEL=temperature=N,top_p=N; {value!r} does not")
        if model.strip() in found:
            raise ValueError(f"{model.strip()} is given its sampling more than once")
        found[model.strip()] = parse_sampling(sampling)
    return found


def add_model_endpoint_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--model-endpoint", action="append", default=[], metavar="MODEL=URL",
        help="The vLLM or Ollama server for one model, when several run; repeat. "
             "Others use --endpoint")
    parser.add_argument(
        "--allow-endpoint", action="append", default=[], metavar="URL",
        help="A vLLM or Ollama server on another machine that may be reached, by http "
             "or https; repeat. Without it only this machine is reached")
    parser.add_argument(
        "--model-sampling", action="append", default=[], metavar="MODEL=SAMPLING",
        help="A model's temperature and top_p, as 'MODEL=temperature=0.6,top_p=0.95'; repeat. "
             "Without it neither is sent and the server's defaults hold")


def build_gateway(
    provider: str, model: str, endpoint: str | None, *,
    response_contract: dict[str, object] | None = None,
    stream_idle_seconds: float | None = None, provider_sort: str | None = None,
    reasoning_effort: str | None = None, chat: bool = False,
) -> ModelGateway:
    """Select a provider without duplicating the key and endpoint policy per command.

    `chat` asks for Ollama by its OpenAI-compatible endpoint, which takes tools,
    a conversation and a stream -- what a coding loop asks of a model.
    """
    if provider in LOCAL_PROVIDERS and model in MODEL_ENDPOINTS:
        endpoint = MODEL_ENDPOINTS[model]
    declared = endpoint is not None and _same(endpoint) in ALLOWED_ENDPOINTS
    if provider == "ollama" and not chat:
        return OllamaGateway(model, endpoint or "http://127.0.0.1:11434",
                             response_contract=response_contract, declared=declared)
    key_name = {"openrouter": "OPENROUTER_API_KEY", "openai": "OPENAI_API_KEY",
                "vllm": "VLLM_API_KEY"}.get(provider)
    return ChatGateway(provider, model, endpoint=endpoint,
                       api_key=os.environ.get(key_name) if key_name else None,
                       response_contract=response_contract,
                       stream_idle_seconds=stream_idle_seconds,
                       provider_sort=None if provider_sort in (None, "default") else provider_sort,
                       reasoning_effort=(None if reasoning_effort in (None, "default")
                                         else reasoning_effort),
                       sampling=MODEL_SAMPLING.get(model), declared=declared)


def loop_gateway(args: argparse.Namespace, model: str | None = None) -> ModelGateway:
    """A coding loop's gateway: streamed, so a slow reply is waited on and a stalled one is not."""
    return build_gateway(args.provider, model or args.model, args.endpoint,
                         stream_idle_seconds=args.idle_timeout, provider_sort=args.provider_sort,
                         reasoning_effort=args.reasoning_effort, chat=True)


# What `relab code stream-check` asks (0.2.98): long enough that a server streaming
# what it writes is seen doing so, short enough to be cheap.
STREAM_CHECK_ASK = ("Write the numbers 1 to 40, each on its own line, each followed by the word for "
                    "it. Nothing else.")
STREAM_CHECK_TOOL = {"type": "function", "function": {
    "name": "write_note", "description": "Write a note.",
    "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}}
# Updates of growing length a reply must arrive in to count as streamed.
STREAMED_UPDATES = 3


def _streamed(heard: list[tuple[float, str, int]], began: float, tool: bool) -> dict[str, object]:
    """How one reply arrived: in how many growing pieces, and when the first and last came."""
    from relab_coding.chat_gateway import THINKING

    lengths: list[int] = []
    times: list[float] = []
    for at, name, length in heard:
        if name == THINKING or (name != "") != tool:
            continue
        if not lengths or length > lengths[-1]:
            lengths.append(length)
            times.append(at - began)
    return {"updates": len(lengths), "streamed": len(lengths) >= STREAMED_UPDATES,
            "first_seconds": round(times[0], 2) if times else None,
            "last_seconds": round(times[-1], 2) if times else None}


def stream_check(gateway: ModelGateway, timeout_seconds: float) -> dict[str, object]:
    """Whether the server streams a reply in text and a tool call's arguments as they are written.

    Asked in use (0.2.98): the report and the code a loop writes are shown as
    they stream, and in use they came all at once -- the editor, or a server
    that sends a tool call's arguments only at the end? Two short calls, one
    in text and one through a tool, each heard piece by piece. A real call to
    the model the settings name, made only when the person asks.
    """
    from relab_coding import chat_gateway as chat

    if not hasattr(gateway, "drafting"):
        return {"streams": False, "said": "this provider is not called with a stream"}
    heard: list[tuple[float, str, int]] = []
    before = chat.DRAFTING_SECONDS
    chat.DRAFTING_SECONDS = 0.0
    gateway.drafting = lambda name, text: heard.append((time.monotonic(), name, len(text)))
    try:
        began = time.monotonic()
        gateway.complete_chat([{"role": "user", "content": STREAM_CHECK_ASK}],  # type: ignore[attr-defined]
                              timeout_seconds=timeout_seconds)
        text = _streamed(heard, began, tool=False)
        heard.clear()
        began = time.monotonic()
        gateway.complete_messages(  # type: ignore[attr-defined]
            [{"role": "user", "content": "Call write_note once, with this text: " + STREAM_CHECK_ASK}],
            tools=[STREAM_CHECK_TOOL], timeout_seconds=timeout_seconds)
        tool = _streamed(heard, began, tool=True)
    finally:
        chat.DRAFTING_SECONDS = before
        gateway.drafting = None
    said = ("text and tool arguments both arrive as they are written" if text["streamed"] and tool["streamed"]
            else "text streams, but a tool call's arguments arrive whole at the end: a report or a file "
                 "written through a tool shows only when it is done (the server's tool parser does not "
                 "stream them)" if text["streamed"]
            else "replies arrive whole: the server, or something between, does not stream")
    return {"streams": bool(text["streamed"]), "text": text, "tool_arguments": tool, "said": said}


# The names `--escalate-on` takes, for the reasons a loop moves up (0.2.74).
STEP_UP_NAMES = {"check": "repeated_check_failure", "unreadable": "unreadable_replies",
                 "stalled": "stalled", "budget": "budget_spent"}

def model_ladder(args: argparse.Namespace) -> ModelLadder:
    """`--model`, then each `--escalate-to`: the models a loop may move up through.

    Always made, with one model when no larger one is named, so a loop that
    moved up keeps its larger model when a later command names the smaller.
    """
    move_on = (None if not args.escalate_on
               else frozenset(ModelChangeReason(STEP_UP_NAMES[name]) for name in args.escalate_on))
    ladder = ModelLadder([args.model, *args.escalate_to], lambda model: loop_gateway(args, model),
                         automatic=args.escalate == "auto", max_cost=args.max_cost,
                         move_on=move_on, after_failures=args.escalate_after)
    if ladder.dropped:
        print(f"[relab] left off the model ladder, smaller than the model before it: "
              f"{', '.join(ladder.dropped)}", file=sys.stderr, flush=True)
    return ladder


def add_loop_arguments(parser: argparse.ArgumentParser) -> None:
    """What a coding loop's model calls take besides the model: how long, and where."""
    parser.set_defaults(model_timeout=CODING_CALL_SECONDS)
    parser.add_argument("--idle-timeout", type=float, default=CODING_IDLE_SECONDS,
                        help="Give up on a streamed reply after this many seconds of nothing")
    parser.add_argument("--provider-sort", choices=["default", "throughput", "latency", "price"],
                        default="default",
                        help="Which OpenRouter providers for the model to try first")
    parser.add_argument("--reasoning-effort", choices=["default", "minimal", "low", "medium", "high"],
                        default="default",
                        help="How hard a reasoning model thinks, on OpenRouter or OpenAI; "
                             "on vLLM, minimal or low turns a thinking model's thinking off; "
                             "lower is faster")
    parser.add_argument("--escalate-to", action="append", default=[], metavar="MODEL",
                        help="A larger model to move up to when the loop is stuck, smallest "
                             "first; repeat. Same provider as --model")
    parser.add_argument("--auto", action="store_true",
                        help="Auto mode: approve a plan and do a command, page or tool that would "
                             "be asked about, recording each as not asked; refusals stay")
    parser.add_argument("--escalate", choices=["ask", "auto"], default="ask",
                        help="ask: stop and offer the larger model; auto: move up by itself")
    parser.add_argument("--max-cost", type=float, metavar="USD",
                        help="Do not move up once the loop has cost this much (as reported)")
    parser.add_argument("--escalate-on", action="append", default=[], choices=sorted(STEP_UP_NAMES),
                        help="What moves up to a larger model; repeat. check: the same check "
                             "failing with changes between; unreadable: replies that are not "
                             "steps; stalled: no progress; budget: the calls ran out. Default: all")
    parser.add_argument("--escalate-after", type=int, default=STUCK_CHECKS, metavar="N",
                        help="Failures in a row of the same check that count as stuck on it "
                             f"(default {STUCK_CHECKS})")
    parser.add_argument("--plan-first", action="store_true",
                        help="Ask for an approved plan before new code or a refactoring is written")
    parser.add_argument("--no-default-rules", action="store_true",
                        help="Leave out ReLab's own rules (keep documents in docs/), read before the person's")
    parser.add_argument("--profile", choices=PROFILES, default=None,
                        help="The policy to run under, apart from where records are kept: "
                             "vscode_default, benchmark_controlled (no defaults, no personal rules, "
                             "no documentation check) or benchmark_usage_equivalent")
    parser.add_argument("--check-style", choices=CHECK_STYLES, default=None,
                        help="How the checks on how code is written speak: advise (the default) says "
                             "what to find out and accepts a reason; demand names what to put in")
    parser.add_argument("--without", action="append", default=[], metavar="CHECK",
                        choices=sorted(SWITCHES),
                        help="Turn one of ReLab's checks off, for an experiment measuring it; "
                             "repeat. Said in the loop's record. One of: " + ", ".join(sorted(SWITCHES)))
    parser.add_argument("--instruction", choices=["current", "modular", "0.2.85", "0.2.91", "0.2.92", "0.2.102"],
                        default="modular",
                        help="Which instruction the loop sends: modular (the default since 0.3.36: the "
                             "instruction's own sections chosen by the task's mode and the way the call "
                             "goes); current (the whole instruction, as before); or a kept one, word for "
                             "word, to go back to")
    parser.add_argument("--compact-prompt", action="store_true",
                        help="Send the compact instruction when the steps go as tools (P1, to "
                             "compare with the full one)")
    parser.add_argument("--calls-as-given", action="store_true",
                        help="Keep --max-calls as given; without this a default is raised for a "
                             "model served on this machine or a private network")
    parser.add_argument("--held-out", action="append", default=[], metavar="PATH",
                        help="A path or glob held out for the final evaluation: run against, never "
                             "read, searched, listed or written; repeat")
    parser.add_argument("--command-timeout", type=float, metavar="SECONDS",
                        help="How long one command may run before it is stopped (default 300)")
    parser.add_argument("--time-limit", type=float, metavar="SECONDS",
                        help="Stop by this many seconds from now, as a stop it can go on from "
                             "(the editor passes its own ceiling, less a margin)")
    parser.add_argument("--model-context", action="append", default=[], metavar="MODEL=TOKENS",
                        help="A model's context window in tokens; repeat. The loop summarizes "
                             "what it cut short once a prompt nears it, and reports the share")
    parser.add_argument("--context-budget", type=int, metavar="TOKENS",
                        help="Keep each call's prompt near this many tokens, below the window: "
                             "earlier steps are summarized near it, so a long task stays fast "
                             "on a model with a large window. A read and a reply still have "
                             "the whole window (default: the window)")


class CommandLineResolver:
    """Turns a declared route into a gateway, holding what only a root may hold.

    The composition root: endpoints and credentials live here, and the
    application that decided *which* route to use never sees them. Constructed
    per command, from the same flags that have always configured a provider,
    with the route's own provider and model overriding what was typed -- because
    a session that declared a route declared it, and a flag is not an amendment.
    """

    def __init__(self, endpoint: str | None = None,
                 response_contract: dict[str, object] | None = None) -> None:
        self.endpoint = endpoint
        self.response_contract = response_contract

    def resolve(self, route: ModelRoute) -> ModelGateway:
        return build_gateway(route.provider, route.model, self.endpoint,
                             response_contract=self.response_contract)



def parse_routes(values: list[str] | None) -> ModelRoutingPolicy | None:
    """`role=provider/model`, repeated, into the policy a session is started under.

    None when nothing was declared, which is what leaves a session in the mode
    every session was in before routing existed: whatever gateway the command
    line built.

    A role named twice is refused rather than resolved last-wins. Two
    declarations for one role means somebody meant two different things, and
    picking one silently is how a study runs on a model nobody chose.
    """
    if not values:
        return None
    routes: dict[ModelRole, ModelRoute] = {}
    for value in values:
        role, _, target = value.partition("=")
        provider, _, model = target.partition("/")
        if not role or not provider or not model:
            raise ValueError(
                f"a route reads role=provider/model; {value!r} does not")
        try:
            named = ModelRole(role.strip())
        except ValueError as error:
            allowed = ", ".join(item.value for item in ModelRole)
            raise ValueError(f"{role!r} is not a role; declare one of {allowed}") from error
        if named in routes:
            raise ValueError(f"{named.value} is declared more than once")
        routes[named] = ModelRoute(provider=provider.strip(), model=model.strip())
    return ModelRoutingPolicy(routes=routes)


def add_route_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--route", dest="routes", action="append", metavar="ROLE=PROVIDER/MODEL",
        help="Which model a role calls, repeated per role. Declaring any makes this "
             "session routed: every model-bearing role must have one, and the model "
             "flags stop deciding what runs")


def _advising(workspace: Path, gateway: ModelGateway, session_id: str) -> ModelGateway:
    """An advisor's gateway, saying that this session is asking for advice."""
    return narrated(gateway, OperationRecorder.open(workspace),
                    role=AMENDMENT_ROLE, session_id=session_id)


def add_model_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--model", required=True)
    parser.add_argument("--provider", choices=["ollama", "openai", "openrouter", "vllm"], default="openrouter")
    parser.add_argument("--endpoint")
    add_model_endpoint_argument(parser)
    parser.add_argument("--model-timeout", type=float, default=MODEL_TIMEOUT_SECONDS)
    parser.add_argument("--timeout", type=float, default=300)


def research_planner(gateway: ModelGateway, workspace: Path, *,
                     timeout_seconds: float, inspection_rounds: int) -> LLMResearchPlanner:
    """Only an explicitly requested, bounded look may precede a design.

    The gateway is wrapped here rather than inside the planner, because the
    planner asks more than once -- a bounded look, then the design -- and
    wrapping what it asks *through* narrates both without it knowing.

    No session, deliberately. A design is proposed before anything exists to
    attach it to, and a proposal somebody later accepts does not retroactively
    give the call an identity it did not have at the time.
    """
    if type(inspection_rounds) is not int or not 0 <= inspection_rounds <= 2:
        raise ValueError("inspection rounds must be an integer between 0 and 2")
    return LLMResearchPlanner(
        narrated(gateway, OperationRecorder.open(workspace), role=PLANNER_ROLE),
        timeout_seconds=timeout_seconds,
        inspector=WorkspaceInspection(workspace) if inspection_rounds else None,
        rounds=inspection_rounds,
    )


def _conversation(args: argparse.Namespace) -> int:
    """One conversational turn: something said, or one offered action taken.

    The exit code is the one the rest of this CLI gives -- 0 when nothing is left
    to do, 1 when something is -- so a conversation is not a special case for
    whatever runs it.
    """
    if args.conversation_action == "history":
        store = ConversationHistoryStore(args.workspace)
        if args.history_action == "list":
            print(json.dumps([item.model_dump(mode="json")
                              for item in store.messages(args.thread_id, limit=args.limit)]))
        elif args.history_action == "append":
            # stdin avoids placing private conversation text in process arguments.
            text = sys.stdin.read(100_001)
            print(store.append(args.thread_id, args.role, text,
                               expected_sequence=args.expected_sequence,
                               session_id=args.session).model_dump_json())
        elif args.history_action == "append-turn":
            # A bounded JSON document on stdin keeps both private texts out of argv.
            turn = ConversationHistoryTurn.model_validate_json(sys.stdin.read(1_200_101))
            print(json.dumps([item.model_dump(mode="json") for item in
                              store.append_turn(args.thread_id, turn,
                                                expected_sequence=args.expected_sequence,
                                                session_id=args.session)]))
        else:
            store.clear(args.thread_id)
            print(json.dumps({"thread_id": args.thread_id, "cleared": True}))
        return 0
    api = ConversationAPI(args.workspace)
    if args.conversation_action == "resume":
        # What a reopened surface shows. Restoring is reading the records, not
        # replaying a transcript, so there is nothing to say, nothing to send,
        # and no model to need.
        print("[relab] Reading where this session stands", file=sys.stderr, flush=True)
        return _answered(api.describe(args.session_id))
    if args.conversation_action == "explore":
        # Check the session before a potentially billable model call. The model
        # proposes paths only; the application performs the bounded inspection.
        api.describe(args.session_id)
        exploration_gateway = build_gateway(args.provider, args.model, args.endpoint)
        requested = propose_exploration(
            exploration_gateway, args.question, timeout_seconds=args.model_timeout)
        return _answered(api.explore(args.session_id, requested))
    if args.conversation_action == "interpret":
        intent_gateway = build_gateway(args.provider, args.model, args.endpoint)
        print("[relab] Interpreting intent only; no action or plan change will run",
              file=sys.stderr, flush=True)
        return _answered(api.interpret(
            ConversationInput(said=args.said, session_id=args.session), intent_gateway,
            timeout_seconds=args.model_timeout))
    if args.conversation_action == "plan-change":
        # Its own name. Every action below this point takes a gateway that may
        # be absent, and sharing one name with a required gateway makes the
        # optional case unrepresentable to a reader and to the type checker.
        drafting = build_gateway(args.provider, args.model, args.endpoint)
        print("[relab] Drafting a plan change only; approval is still required",
              file=sys.stderr, flush=True)
        return _answered(api.draft_plan_change(
            args.session_id, args.context_id, args.request, drafting,
            timeout_seconds=args.model_timeout))
    models: list[str | None] = ([None] if args.model is None
                                else [args.model, *args.escalate_to])
    gateway = (None if args.model is None
               else build_gateway(args.provider, args.model, args.endpoint))
    if args.conversation_action == "say":
        print("[relab] Answering from recorded state; saying something records nothing",
              file=sys.stderr, flush=True)
        if args.planner_file is not None and gateway is not None:
            raise ValueError("design from a model or from a prepared file, not both")
        if args.planner_file is not None and args.inspection_rounds:
            raise ValueError("inspection rounds require a model, not a prepared design")
        if args.inspection_rounds and gateway is None:
            raise ValueError("inspection rounds require a model")
        if args.planner_file is not None:
            models = [None]

        def answered(model: str | None,
                     wrap: Callable[[ModelGateway], ModelGateway]) -> ConversationResponse:
            planner: ResearchPlanner | None = None
            if args.planner_file is not None:
                planner = ScriptedPlanner(ProposedPlan.model_validate_json(
                    args.planner_file.read_text(encoding="utf-8-sig")))
            elif model is not None:
                planner = research_planner(
                    wrap(build_gateway(args.provider, model, args.endpoint)), args.workspace,
                    timeout_seconds=args.model_timeout,
                    inspection_rounds=args.inspection_rounds)
            return api.answer(
                ConversationInput(said=args.said, session_id=args.session), planner=planner)

        return _answered(_passed_over(*climb(models, answered, said=_say)))
    request = ConversationActionRequest(
        action=ConversationAction(args.action), session_id=args.session,
        event_sequence=args.event_sequence, plan_revision=args.plan_revision,
        proposal=None if args.proposal is None else json.loads(
            args.proposal.read_text(encoding="utf-8-sig")),
        approved=args.approved,
        alternative_id=args.alternative_id,
        run_id=args.run_id,
        decided_by=args.decided_by,
        decision=None if args.decision is None else ResearchDecision(args.decision),
        rationale=args.rationale)
    def acted(model: str | None,
              wrap: Callable[[ModelGateway], ModelGateway]) -> ConversationResponse:
        return api.act(request, gateway=None if model is None else wrap(
            build_gateway(args.provider, model, args.endpoint)),
            resolver=CommandLineResolver(args.endpoint))

    try:
        return _answered(_passed_over(*climb(models, acted, said=_say)))
    except StaleConversationAction as refused:
        # Nothing was done. The useful answer is not the complaint, it is where
        # the session actually stands -- which is what a surface needs in order
        # to offer again rather than leaving a person holding a dead button.
        assert request.session_id is not None
        return _answered(api.describe(request.session_id).model_copy(
            update={"refusal": str(refused)}))


def _say(line: str) -> None:
    print(f"[relab] {line}", file=sys.stderr, flush=True)


def _passed_over(response: ConversationResponse, passed: list[str]) -> ConversationResponse:
    """The answer, saying which models on the ladder were passed over, and in its proposal."""
    if not passed:
        return response
    proposal = (None if response.proposal is None
                else {**response.proposal, "passed_over": passed})
    return response.model_copy(update={"passed_over": passed, "proposal": proposal})


def _skill(args: argparse.Namespace) -> int:
    """`relab skill`: the skills this build has, run one, evaluate them, or read the record."""
    from relab_app.skill_evaluations import evaluate
    from relab_app.skills import SkillContext, SkillRunner, definitions
    from relab_core.skills import SkillEffect, SkillOutcome

    if args.skill_action == "list":
        print(json.dumps([item.model_dump(mode="json") for item in definitions()],
                         ensure_ascii=False))
        return 0
    if args.skill_action == "eval":
        results = evaluate(args.skill)
        print(json.dumps([item.model_dump(mode="json") for item in results], ensure_ascii=False))
        failed = [f"{item.skill}.{item.case}" for item in results if not item.passed]
        print(f"[relab] {len(results) - len(failed)}/{len(results)} cases passed"
              + (f"; failed: {', '.join(failed)}" if failed else ""), file=sys.stderr, flush=True)
        return 1 if failed else 0
    # Reading is what a skill may do unless the person allows more, by name.
    permitted = {SkillEffect.READ, *(SkillEffect(item) for item in getattr(args, "allow", []))}
    runner = SkillRunner(SkillContext(args.workspace, caller="cli", permitted=permitted))
    if args.skill_action == "log":
        print(json.dumps([item.model_dump(mode="json") for item in runner.invocations(args.limit)],
                         ensure_ascii=False))
        return 0
    given = json.loads(args.input) if args.input else {}
    if not isinstance(given, dict):
        raise ValueError("--input must be a JSON object")  # noqa: TRY004 -- input, said as one
    reply = runner.invoke(args.name, given)
    print(reply.model_dump_json())
    print(f"[relab] {args.name}: {reply.invocation.outcome.value} -- {reply.invocation.said}",
          file=sys.stderr, flush=True)
    return {SkillOutcome.DONE: 0, SkillOutcome.FAILED: 1}.get(reply.invocation.outcome, 2)


def _experiment_environment(args: argparse.Namespace) -> None:
    """The check style, the profile and the checks switched off, where every part reads them."""
    style = getattr(args, "check_style", None)
    if style:
        os.environ[CHECK_STYLE_ENV] = style
    profile = getattr(args, "profile", None)
    if profile:
        os.environ[PROFILE_ENV] = profile
    off = list(getattr(args, "without", None) or [])
    if off:
        # One place every part reads: the loop, its checks, and research (0.2.87).
        given = [item for item in os.environ.get(WITHOUT_ENV, "").split(",") if item.strip()]
        os.environ[WITHOUT_ENV] = ",".join(dict.fromkeys([*given, *off]))


def _code(args: argparse.Namespace) -> int:
    """The coding loop, as a command: one JSON record on stdout, progress on stderr."""
    if args.code_action == "measure-search":
        # Reads nothing of the workspace: the files are made in a temporary folder.
        from relab_app.search_measure import measure, shown

        report = measure(args.files, args.repeats)
        print(shown(report), file=sys.stderr, flush=True)
        if args.out is not None:
            args.out.write_text(json.dumps(report, indent=1), encoding="utf-8")
        print(json.dumps(report))
        return 0
    if args.code_action in ("bench", "prompt-compare"):
        # The experiment's options hold for a benchmark too: they were set only after it
        # returned, so `bench --check-style`, `--profile` and `--without` changed nothing.
        _experiment_environment(args)
    if args.code_action == "prompt-compare":
        from relab_app.coding_bench import dumps
        from relab_app.prompt_compare import report as compared
        from relab_app.prompt_compare import run_comparison
        from relab_app.results_registry import current_commit

        conditions = [item.strip() for item in args.conditions.split(",") if item.strip()]
        print(f"[relab] Comparing {', '.join(conditions)} on {args.suite}, {args.repeats} repeat(s) each",
              file=sys.stderr, flush=True)
        comparison = run_comparison(
            args.suite, loop_gateway(args), label=args.label, conditions=conditions,
            repeats=args.repeats, out=args.out, native_tools=not args.json_steps,
            profile=os.environ.get(PROFILE_ENV) or None,
            about={"model": args.model, "provider": args.provider,
                   "reasoning_effort": args.reasoning_effort, "commit": current_commit(args.workspace)},
            only=args.task or None, work=args.work, jobs=args.jobs,
            task_seconds=args.task_seconds or None, references=args.references,
            retry_provider_failures=args.retry_provider_failures,
            context_windows=parse_context_windows(args.model_context),
            context_budget=context_budget(args))
        print(f"[relab] Written: {args.out / 'comparison.json'}", file=sys.stderr, flush=True)
        print(dumps(compared(comparison)))
        return 0
    if args.code_action == "prompt-compare-report":
        from relab_app.coding_bench import dumps
        from relab_app.prompt_compare import read_comparison
        from relab_app.prompt_compare import report as compared

        print(dumps(compared(read_comparison(args.comparison))))
        return 0
    if args.code_action == "bench":
        from relab_app.coding_bench import dumps, run_suite
        from relab_app.results_registry import ResultsRegistry, current_commit

        print(f"[relab] Running the coding benchmark in {args.suite}", file=sys.stderr, flush=True)
        result = run_suite(args.suite, loop_gateway(args),
                           instruction=getattr(args, "instruction", "modular") or "modular",
                           compact_prompt=bool(getattr(args, "compact_prompt", False)),
                           label=args.label, repeats=args.repeats, only=args.task or None,
                           work=args.work, out=args.out, native_tools=not args.json_steps,
                           references=args.references,
                           jobs=args.jobs, resume=args.resume,
                           task_seconds=args.task_seconds or None,
                           about={"model": " > ".join([args.model, *args.escalate_to]),
                                  "provider": args.provider,
                                  "reasoning_effort": args.reasoning_effort,
                                  "commit": current_commit(args.workspace)},
                           on_change=ResultsRegistry(args.workspace).register,
                           carry_lessons=args.carry_lessons,
                           carry_check=not args.no_carry_check,
                           ladder=model_ladder(args) if args.escalate_to else None,
                           retry_provider_failures=args.retry_provider_failures,
                           context_windows=parse_context_windows(args.model_context),
                           context_budget=context_budget(args),
                           given_lessons=given_lessons(args.given_lessons))
        print(f"[relab] Report: {ResultsRegistry(args.workspace).report_path}",
              file=sys.stderr, flush=True)
        print(dumps(result.summary()))
        return 0
    if args.code_action == "bench-import":
        from relab_app.bench_import import calibrate, import_dabench, import_polyglot

        ids = (import_dabench(args.source, args.out, only=args.exercise or None, level=args.level)
               if args.format == "dabench" else
               import_polyglot(args.source, args.out, language=args.language, only=args.exercise or None))
        checked = [calibrate(args.out / task_id) for task_id in ids] if args.calibrate else []
        print(json.dumps({"suite": str(args.out), "tasks": ids,
                          "uncalibrated": [item for item in checked if not item["calibrated"]]}))
        return 0 if all(item["calibrated"] for item in checked) else 1
    if args.code_action == "failure-kinds":
        from relab_app.coding_bench import read_result
        from relab_app.failure_types import kind_lessons

        only = set(args.task)
        failed = [(run.task, run.check_output or "") for path in args.results for run in read_result(path).runs
                  if not run.solved and run.check_output and (not only or run.task in only)]
        kinds = kind_lessons(failed, minimum=args.minimum)
        if args.out is not None:
            args.out.write_text(json.dumps([item.text for item in kinds], ensure_ascii=False, indent=1),
                                encoding="utf-8")
        print(json.dumps([item.model_dump(mode="json") for item in kinds], ensure_ascii=False))
        return 0
    if args.code_action == "bench-compare":
        from relab_app.coding_bench import compare, dumps, read_result

        print(dumps(compare(read_result(args.before), read_result(args.after))))
        return 0
    if args.code_action in ("threads", "jobs", "scores") and untouched(args.workspace):
        # A folder ReLab never worked in has no conversations, and opening the
        # loop service would create `.relab` to say so.
        print("[]")
        return 0
    service = CodingLoopService(args.workspace)
    service.native_tools = not args.json_steps
    service.conversation = not args.one_prompt
    service.one_prompt = args.one_prompt
    service.references = args.references
    service.auto = bool(getattr(args, "auto", False))
    service.local_budget = not bool(getattr(args, "calls_as_given", False))
    service.compact_prompt = bool(getattr(args, "compact_prompt", False))
    service.instruction = getattr(args, "instruction", "modular") or "modular"
    service.default_rules = not bool(getattr(args, "no_default_rules", False))
    _experiment_environment(args)
    service.plan_first = bool(getattr(args, "plan_first", False))
    service.held_out = tuple(item for item in getattr(args, "held_out", None) or [] if item.strip())
    command_limit = getattr(args, "command_timeout", None)
    if isinstance(command_limit, (int, float)) and command_limit > 0:
        service.command_seconds = float(command_limit)
    limit = getattr(args, "time_limit", None)
    if isinstance(limit, (int, float)) and limit > 0:
        # Its own clean stop, before whoever started it gives up on the process:
        # killed at the editor's hour, a follow-up said only "refused without
        # saying why" (0.2.50 in use).
        service.deadline = time.monotonic() + limit
    if hasattr(args, "model_timeout"):
        service.step_seconds = args.model_timeout
    if hasattr(args, "escalate_to") and getattr(args, "model", None):
        service.model = args.model
        service.ladder = model_ladder(args)
    service.context_windows = parse_context_windows(getattr(args, "model_context", None))
    service.context_budget = context_budget(args)
    named = getattr(args, "model", None)
    if service.context_windows and named and window_for(service.context_windows, named) is None:
        # Said rather than silently ignored: a window set for another spelling.
        print(f"[relab] no context window is set for {named!r}; set for: "
              f"{', '.join(sorted(service.context_windows))}", file=sys.stderr, flush=True)
    if args.code_action in ("link-study", "study-origin"):
        from relab_app.evidence_handoff import link_study, study_origin
        origin = (link_study(args.workspace, args.session_id, args.loop_id)
                  if args.code_action == "link-study" else study_origin(args.workspace, args.session_id))
        print(json.dumps(origin.model_dump(mode="json") if origin is not None else None))
        return 0
    if args.code_action == "hand-back":
        from relab_app.evidence_handoff import hand_back
        loop = hand_back(args.workspace, args.session_id, service, loop_gateway(args),
                         loop_id=args.loop_id, max_steps=args.max_steps, review_edits=args.review_edits)
        print(loop.model_dump_json())
        return 0 if loop.outcome in (LoopOutcome.FINISHED, LoopOutcome.WAITING) else 1
    if args.code_action == "stream-check":
        print("[relab] Asking the model twice, briefly, to see how its replies arrive",
              file=sys.stderr, flush=True)
        streaming = stream_check(build_gateway(args.provider, args.model, args.endpoint,
                                             stream_idle_seconds=60.0, chat=True), args.model_timeout)
        print(json.dumps(streaming))
        return 0
    if args.code_action == "run":
        print("[relab] Working the request through", file=sys.stderr, flush=True)
        loop = service.run(args.request, loop_gateway(args),
                           max_steps=args.max_steps, scope=args.scope, after=args.after,
                           loop_id=args.loop_id, project_only=args.project_only,
                           review_edits=args.review_edits and not service.auto, plan_only=args.plan_only)
        print(loop.model_dump_json())
        return 0 if loop.outcome in (LoopOutcome.FINISHED, LoopOutcome.WAITING) else 1
    if args.code_action == "approve":
        print("[relab] Building the approved plan", file=sys.stderr, flush=True)
        loop = service.approve(args.loop_id,
                               loop_gateway(args),
                               max_steps=args.max_steps)
        print(loop.model_dump_json())
        return 0 if loop.outcome in (LoopOutcome.FINISHED, LoopOutcome.WAITING) else 1
    if args.code_action == "follow":
        # The person's next request, in the same loop: everything before it in view.
        print("[relab] Going on with the conversation", file=sys.stderr, flush=True)
        loop = service.follow_up(args.loop_id, args.request, loop_gateway(args),
                                 max_steps=args.max_steps)
        print(loop.model_dump_json())
        return 0 if loop.outcome in (LoopOutcome.FINISHED, LoopOutcome.WAITING) else 1
    if args.code_action == "resume":
        print("[relab] Going on from where the loop ended", file=sys.stderr, flush=True)
        loop = service.resume(args.loop_id,
                              loop_gateway(args),
                              max_steps=args.max_steps)
        print(loop.model_dump_json())
        return 0 if loop.outcome in (LoopOutcome.FINISHED, LoopOutcome.WAITING) else 1
    if args.code_action in ("allow", "refuse"):
        loop = service.decide(args.loop_id, args.code_action == "allow",
                              loop_gateway(args),
                              max_steps=args.max_steps,
                              always=getattr(args, "always", False))
        print(loop.model_dump_json())
        return 0 if loop.outcome in (LoopOutcome.FINISHED, LoopOutcome.WAITING) else 1
    if args.code_action in ("accept", "reject"):
        loop = service.review(args.loop_id, args.code_action == "accept",
                              loop_gateway(args),
                              max_steps=args.max_steps,
                              every=getattr(args, "every", False),
                              note=getattr(args, "note", None))
        print(loop.model_dump_json())
        return 0 if loop.outcome in (LoopOutcome.FINISHED, LoopOutcome.WAITING) else 1
    if args.code_action == "answer":
        print("[relab] Going on with the answer", file=sys.stderr, flush=True)
        loop = service.answer(args.loop_id, args.answer,
                              loop_gateway(args),
                              max_steps=args.max_steps)
        print(loop.model_dump_json())
        return 0 if loop.outcome in (LoopOutcome.FINISHED, LoopOutcome.WAITING) else 1
    if args.code_action == "rules":
        from relab_app.command_rules import CommandRules

        rules = CommandRules(args.workspace)
        if args.remove:
            removed = rules.remove(args.remove)
            print(json.dumps({"removed": removed, "rules": rules.rules()}))
            return 0 if removed else 1
        print(json.dumps(rules.rules()))
        return 0
    if args.code_action == "threads":
        print(json.dumps(service.threads()))
        return 0
    if args.code_action == "jobs":
        print(json.dumps(service.jobs()))
        return 0
    if args.code_action == "stats":
        from relab_app.loop_stats import said, stats

        try:
            loop = service.load(args.loop_id) if args.loop_id else service.latest()
        except LookupError:
            elsewhere = records_elsewhere(args.workspace)
            if elsewhere is not None:
                print(elsewhere, file=sys.stderr)
            raise
        numbers = stats(loop)
        print(json.dumps(numbers) if args.json else said(numbers))
        return 0
    if args.code_action == "scores":
        from relab_app.measurements import ScoreLog

        print(json.dumps(ScoreLog(args.workspace).all()[-200:], ensure_ascii=False))
        return 0
    if args.code_action in ("results", "report"):
        from relab_app.coding_bench import read_result
        from relab_app.results_registry import ResultsRegistry

        registry = ResultsRegistry(args.workspace)
        if args.code_action == "report":
            print(registry.rebuild())
            return 0
        for path in args.register:
            # An old result file, registered with what is known of how it ran.
            old = read_result(path)
            registry.register(old.model_copy(update={
                key: value for key, value in (("suite", args.suite), ("model", args.model),
                                              ("provider", args.provider))
                if value is not None and getattr(old, key) is None}))
        print(json.dumps(registry.entries(), ensure_ascii=False))
        return 0
    if args.code_action == "lessons":
        from relab_app.lessons import LessonStore

        lessons = LessonStore(args.workspace)
        if args.remove is not None:
            gone = lessons.remove(args.remove)
            print(json.dumps({"removed": args.remove if gone else None}))
            return 0 if gone else 1
        learned = lessons.all()
        if not learned:
            # Said, as `list` says it (0.3.40): `[]` read as "no lessons" while the editor kept them elsewhere.
            elsewhere = records_elsewhere(args.workspace)
            if elsewhere is not None:
                print(elsewhere, file=sys.stderr)
        print(json.dumps([item.model_dump(mode="json") for item in learned], ensure_ascii=False))
        return 0
    if args.code_action == "common-lessons":
        from relab_app.common_lessons import CommonLessons

        common = CommonLessons()
        if args.confirm is not None:
            confirmed = common.confirm(args.confirm, args.text)
            print(json.dumps({"confirmed": confirmed.model_dump(mode="json") if confirmed else None},
                             ensure_ascii=False))
            return 0 if confirmed else 1
        if args.dismiss is not None:
            gone = common.dismiss(args.dismiss)
            print(json.dumps({"dismissed": args.dismiss if gone else None}))
            return 0 if gone else 1
        print(json.dumps({"confirmed": [item.model_dump(mode="json") for item in common.all()],
                          "candidates": [item.model_dump(mode="json") for item in common.candidates()]},
                         ensure_ascii=False))
        return 0
    if args.code_action == "notes":
        from relab_app.project_notes import ProjectNotes

        notes = ProjectNotes(args.workspace)
        if args.remove is not None:
            dropped = notes.remove(args.project, args.remove)
            print(json.dumps({"removed": dropped, "notes": notes.all()}, ensure_ascii=False))
            return 0 if dropped is not None else 1
        print(json.dumps(notes.all(), ensure_ascii=False))
        return 0
    if args.code_action == "mcp":
        # The configured servers, started and asked for their tools, then stopped.
        try:
            servers = service._servers()
            print(json.dumps({
                "servers": sorted(servers),
                "tools": [{"server": item.server, "tool": item.name,
                           "description": item.description} for item in service.mcp_tools],
                "unavailable": service.mcp_unavailable}, ensure_ascii=False))
        finally:
            service._stop_mcp()
        return 0 if not service.mcp_unavailable else 1
    if args.code_action == "thread":
        print(json.dumps([item.model_dump(mode="json") for item in service.thread(args.loop_id)]))
        return 0
    if args.code_action == "list":
        if args.json:
            print(json.dumps([item.model_dump(mode="json") for item in service.loops()]))
            return 0
        listed = service.listed()
        elsewhere = records_elsewhere(args.workspace) if not listed else None
        if elsewhere is not None:
            print(elsewhere, file=sys.stderr)
        print(listed_lines(listed))
        return 0
    if args.code_action == "stopped":
        print(service.mark_stopped(args.loop_id).model_dump_json())
        return 0
    if args.code_action == "steer":
        from relab_app.steering import steer

        # Only to a loop still working: one that ended takes this as a new request.
        # One not yet recorded is just starting, and reads it before its first call.
        try:
            ended = service.load(args.loop_id).outcome is not LoopOutcome.RUNNING
        except LookupError:
            ended = False
        if ended:
            raise ValueError(f"{args.loop_id} is not running; say it as a new request")
        print(steer(args.workspace, args.loop_id, args.instruction).model_dump_json())
        return 0
    if args.code_action == "unsteer":
        from relab_app.steering import withdraw

        try:
            taken = {item.steering_id for item in service.load(args.loop_id).steering}
        except LookupError:
            taken = set()
        done = withdraw(args.workspace, args.loop_id, args.steering_id, taken)
        print(json.dumps({"steering_id": args.steering_id, "withdrawn": done}))
        return 0
    if args.code_action == "show":
        print(service.load(args.loop_id).model_dump_json())
        return 0
    if args.code_action == "side":
        existed, content = service.side(args.loop_id, args.path, args.side)
        print(json.dumps({"loop_id": args.loop_id, "path": args.path, "side": args.side,
                          "existed": existed, "content": content}))
        return 0
    if args.code_action == "storage":
        if args.compact:
            print(json.dumps({**service.storage(), "compacted": service.compact_snapshots()}))
            return 0
        print(json.dumps(service.storage()))
        return 0
    if args.code_action == "revert":
        # One file, one change, or back to a checkpoint; never a file changed since.
        if args.file is not None:
            restored, kept = service.revert_file(args.loop_id, args.file)
        elif args.change is not None:
            restored, kept = service.revert_change(args.loop_id, args.change)
        else:
            restored, kept = service.revert_to_checkpoint(args.loop_id, args.checkpoint)
    else:
        restored, kept = service.undo(args.loop_id)
    print(json.dumps({"loop_id": args.loop_id, "restored": restored, "kept": kept}))
    return 0 if not kept else 1


def _answered(answered: ConversationResponse) -> int:
    print(answered.model_dump_json())
    print(f"[relab] {answered.capability.value}", file=sys.stderr, flush=True)
    # Complete is the one answer that is not work remaining.
    return 0 if answered.turn_state is TurnState.COMPLETE else 1


def add_conversation_model_arguments(parser: argparse.ArgumentParser) -> None:
    """A model is optional here: most of what a conversation answers needs none."""
    parser.add_argument("--model", help="Model to design or drive with, when one is needed")
    parser.add_argument("--provider", choices=["ollama", "openai", "openrouter", "vllm"], default="openrouter")
    parser.add_argument("--endpoint")
    add_model_endpoint_argument(parser)
    parser.add_argument("--model-timeout", type=float, default=MODEL_TIMEOUT_SECONDS)
    parser.add_argument("--escalate-to", action="append", default=[], metavar="MODEL",
                        help="A larger model to ask when a model's reply cannot be used, "
                             "smallest first; repeat. Same provider as --model")


def add_design_arguments(parser: argparse.ArgumentParser) -> None:
    """Shared by plan and revise-plan so a recorded and an amended design cannot drift."""
    parser.add_argument("session_id")
    parser.add_argument("registry", type=Path)
    parser.add_argument("--arm", action="append", default=[],
                        help="Declare an experiment arm; repeat for several arms")
    parser.add_argument("--repeats", type=int, default=1,
                        help="Usable runs required per declared arm")
    parser.add_argument("--candidate-arm", help="Declared arm compared by session assess")
    parser.add_argument("--baseline-arm", help="Declared arm compared against")
    parser.add_argument("--arm-task", action="append", default=[], metavar="ARM=OBJECTIVE",
                        help="Coding objective session request uses for that arm")
    parser.add_argument("--arm-task-file", type=Path,
                        help="JSON ArmTask list; required to declare targets and verify_argv")
    parser.add_argument("--expected-provider", choices=["ollama", "openai", "openrouter", "vllm"],
                        help="Require every usable run to come from this provider")
    parser.add_argument("--expected-model",
                        help="Require every usable run to come from this requested model")
    parser.add_argument("--expected-reported-model",
                        help="Also require this provider-reported label; needs the pair above")
    parser.add_argument("--data-path", action="append", default=[],
                        help="File identifying this study's data; digested into run conditions")
    parser.add_argument("--require-comparable-conditions", action="store_true",
                        help="Fail the assessment when compared runs did not share conditions")
    parser.add_argument("--holdout-registry", type=Path,
                        help="Rules kept out of selection and judged only by session holdout")
    parser.add_argument("--holdout-data-path", action="append", default=[],
                        help="File the holdout measurement reads; must not be selection data")
    parser.add_argument("--restore-between-attempts", action="store_true",
                        help="Undo each verified attempt so the next one starts where it did")
    parser.add_argument("--isolate-attempts", action="store_true",
                        help="Run each attempt in its own checkout of the current revision")
    parser.add_argument("--sandbox-backend", choices=["local_process", "docker"],
                        help="Where a verifier runs; only Docker can deny it a network")
    parser.add_argument("--docker-image", help="Image for the Docker sandbox backend")


def read_arm_tasks(pairs: list[str], path: Path | None) -> list[ArmTask]:
    """Parse ARM=OBJECTIVE options, or a JSON list that also declares execution intent."""
    if path is not None:
        if pairs:
            raise ValueError("--arm-task and --arm-task-file are mutually exclusive")
        return [ArmTask.model_validate(item)
                for item in json.loads(path.read_text(encoding="utf-8-sig"))]
    tasks = []
    for pair in pairs:
        arm, separator, objective = pair.partition("=")
        if not separator:
            raise ValueError(f"--arm-task requires ARM=OBJECTIVE: {pair}")
        tasks.append(ArmTask(arm=arm, objective=objective))
    return tasks


def read_expected_model(provider: str | None, model: str | None) -> ModelIdentity | None:
    if (provider is None) != (model is None):
        raise ValueError("--expected-provider and --expected-model must be given together")
    if provider is None or model is None:
        return None
    # Validate rather than cast: the contract owns the provider literal.
    return ModelIdentity.model_validate({"provider": provider, "model": model})


def read_registry(path: Path) -> MetricRegistry:
    return MetricRegistry.model_validate_json(path.read_text(encoding="utf-8-sig"))


REPORTED_FIELDS = 8
SHOWN_INPUT = 120


def _given(value: object) -> str:
    """What the field actually held, which is the half pydantic's message omits.

    "String should match pattern ..." names the rule and not the thing that broke
    it, and the rule alone is rarely enough to find the field that sent it.
    """
    shown = value if isinstance(value, str) else repr(value)
    if len(shown) > SHOWN_INPUT:
        shown = shown[:SHOWN_INPUT] + "..."
    return shown


def refusal(error: Exception) -> str:
    """One readable sentence per rejected field, and no documentation URL.

    A `ValidationError` is a `ValueError`, so it reached the same handler as every
    other refusal and was printed whole: several lines per field, each ending in a
    link to errors.pydantic.dev. Surfaces that keep the last line of stderr — the
    editor sidebar does — showed the link and dropped the reason, which made a
    schema disagreement look like an outage. The cause belongs on one line.
    """
    if not isinstance(error, ValidationError):
        return str(error)
    reported = error.errors()
    lines = [f"{error.error_count()} field(s) were refused:"]
    for entry in reported[:REPORTED_FIELDS]:
        said = str(entry["msg"]).removeprefix("Value error, ")
        if not entry["loc"]:
            # A rule over the whole design: its input is the whole design, and
            # printing it buried the one sentence that said what was wrong.
            lines.append(f"  {said}")
            continue
        where = ".".join(str(part) for part in entry["loc"])
        lines.append(f"  {where}: {said} (given: {_given(entry.get('input'))})")
    if len(reported) > REPORTED_FIELDS:
        lines.append(f"  ... and {len(reported) - REPORTED_FIELDS} more")
    return "\n".join(lines)


def speak_utf8() -> None:
    """Write both streams as UTF-8, whatever the console's locale is.

    On Windows these default to the system code page -- cp949 on a Korean
    install. The CLI's stdout is a machine-readable JSON report and its reader
    decodes UTF-8, so a Korean objective left here as cp949 bytes arrives as
    replacement characters: a research goal, stated by a person in their own
    words, destroyed between the two halves of their own tool. What is worse than
    the display is the round trip, since a proposal read back and re-recorded
    would carry the damage into the record.

    An encoding is not the console's business to decide for a stream that exists
    to be parsed. stderr follows because the same reader decodes it, and a
    refusal naming a path or a value has the same problem.

    stdin too, for the same reason in the other direction. The editor writes
    chat text to it as UTF-8, and read as cp949 every Korean message became
    surrogates and was refused -- "ReLab answered, but could not save this chat
    turn" on each one, while the English text ReLab wrote itself saved fine.
    """
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            # Not every stream is a TextIOWrapper: a captured one need not be, and
            # failing to speak UTF-8 is not a reason to refuse to run.
            with contextlib.suppress(ValueError, OSError):
                reconfigure(encoding="utf-8")


def main() -> int:
    speak_utf8()
    parser = argparse.ArgumentParser(prog="relab")
    commands = parser.add_subparsers(dest="command", required=True)
    session = commands.add_parser("session", help="Group coding evidence under a research objective")
    session.add_argument("--workspace", type=Path, default=Path("."))
    session_actions = session.add_subparsers(dest="session_action", required=True)
    session_actions.add_parser("create").add_argument("objective")
    attach = session_actions.add_parser("attach")
    attach.add_argument("session_id")
    attach.add_argument("run_id")
    attach.add_argument("--role", help="Arm declared by the recorded plan; omit to leave a run "
                        "outside the experiment design")
    refresh = session_actions.add_parser("refresh", help="Explicitly advance an attached run pin")
    refresh.add_argument("session_id")
    refresh.add_argument("run_id")
    refresh.add_argument("--expected-run-sequence", type=int, required=True)
    review = session_actions.add_parser("review")
    review.add_argument("session_id")
    review.add_argument("--event-sequence", type=int)
    add_design_arguments(session_actions.add_parser(
        "plan", help="Pre-register the evaluation policy; does not judge evidence"))
    revise = session_actions.add_parser(
        "revise-plan", help="Amend a recorded policy; the amendment stays visible")
    add_design_arguments(revise)
    revise.add_argument("--expected-revision", type=int, required=True)
    revise.add_argument("--rationale", required=True)
    impact = session_actions.add_parser(
        "measurement-impact",
        help="What replacing this study's measurement would retire; changes nothing")
    impact.add_argument("session_id")
    revise_measurement = session_actions.add_parser(
        "revise-measurement",
        help="Retire this study's frozen measurement and declare its replacement")
    revise_measurement.add_argument("session_id")
    revise_measurement.add_argument(
        "measurement", type=Path,
        help="JSON MeasurementSetup declaring the corrected instrument at a new path")
    revise_measurement.add_argument("--expected-revision", type=int, required=True)
    revise_measurement.add_argument("--rationale", required=True)
    reopen = session_actions.add_parser(
        "reopen", help="Set aside a terminal decision; history keeps the original")
    reopen.add_argument("session_id")
    reopen.add_argument("--rationale", required=True)
    readiness = session_actions.add_parser(
        "readiness", help="Report planned-arm coverage; executes nothing")
    readiness.add_argument("session_id")
    readiness.add_argument("--event-sequence", type=int)
    assess = session_actions.add_parser(
        "assess", help="Apply the pinned plan to the pinned design; executes nothing")
    assess.add_argument("session_id")
    assess.add_argument("--event-sequence", type=int)
    task_request = session_actions.add_parser(
        "request", help="Create and attach the runs the declared design lacks; runs no model")
    task_request.add_argument("session_id")
    execute = session_actions.add_parser(
        "execute", help="Run the declared design's unstarted runs through a selected model")
    execute.add_argument("session_id")
    execute.add_argument("--expected-session-sequence", type=int,
                         help="Require the session event number reviewed before execution")
    add_model_arguments(execute)
    execute.add_argument("--attempts", type=int, default=1,
                         help="Runs allowed per design slot, 1-3; unusable attempts are replaced")
    # An ablation hatch, not a feature. A replacement for a failed attempt is
    # given that failure's evidence because the application can see the attempt
    # failed -- asking a person to remember a flag for it would make repair
    # something they switch on rather than something ReLab does.
    execute.add_argument("--no-repair-context", dest="repair_context",
                         action="store_false", default=True,
                         help="Withhold the failed attempt's evidence from its replacement; "
                              "for comparing against repair rather than for ordinary use")
    execute.add_argument("--parallel-arms", type=int, default=1,
                         help="Arms to run at once, 1-4; above 1 the plan must isolate attempts")
    session_turn = session_actions.add_parser(
        "turn", help="Do what is ours to do, then say where that leaves the session")
    session_turn.add_argument("session_id")
    add_model_arguments(session_turn)
    session_turn.add_argument("--max-steps", type=int, default=3)
    session_turn.add_argument("--attempts", type=int, default=1)
    session_turn.add_argument("--parallel-arms", type=int, default=1)
    session_turn.add_argument("--no-repair-context", dest="repair_context",
                        action="store_false", default=True)
    session_turn.add_argument(
        "--advisor-model", help="Ask a model what the policy should become at a conclusion")
    advance = session_actions.add_parser(
        "advance", help="Perform the operations the lifecycle names, stopping at a judgement")
    advance.add_argument("session_id")
    add_model_arguments(advance)
    advance.add_argument("--max-steps", type=int, default=3)
    advance.add_argument("--attempts", type=int, default=1)
    advance.add_argument("--parallel-arms", type=int, default=1)
    advance.add_argument("--no-repair-context", dest="repair_context",
                        action="store_false", default=True)
    holdout = session_actions.add_parser(
        "holdout", help="Judge the declared holdout rules on the chosen evidence, once")
    holdout.add_argument("session_id")
    status = session_actions.add_parser(
        "status", help="Where the session stands and the one operation it needs next")
    status.add_argument("session_id")
    status.add_argument("--attempts", type=int, default=1,
                        help="Evaluate the same 1-3 attempts per slot as session execute")
    session_failures = session_actions.add_parser(
        "failures", help="Why an arm has no usable evidence; records nothing")
    session_failures.add_argument("session_id")
    session_failures.add_argument("arm")
    interpret = session_actions.add_parser(
        "interpret", help="What these records support and what they do not; records nothing")
    interpret.add_argument("session_id")
    session_next = session_actions.add_parser(
        "next", help="The one thing to do next, and who may do it; records nothing")
    session_next.add_argument("session_id")
    session_next.add_argument("--attempts", type=int, default=1,
                              help="Evaluate the same 1-3 attempts per slot as session execute")
    session_next.add_argument(
        "--model", help="Ask a model what the policy should become, instead of the rules")
    session_next.add_argument(
        "--provider", choices=["ollama", "openai", "openrouter", "vllm"], default="openrouter")
    session_next.add_argument("--endpoint")
    add_model_endpoint_argument(session_next)
    session_next.add_argument("--model-timeout", type=float, default=MODEL_TIMEOUT_SECONDS)
    session_amend = session_actions.add_parser(
        "amend", help="Record a proposed amendment; every field it omits stays as recorded")
    session_amend.add_argument("session_id")
    session_amend.add_argument("amendment", type=Path)
    session_amend.add_argument("--expected-revision", type=int, required=True)
    diagnose = session_actions.add_parser(
        "diagnose", help="Compare session references with run history; changes nothing")
    diagnose.add_argument("session_id")
    session_recover = session_actions.add_parser(
        "recover", help="Reconcile records after an interruption; runs no model or patch")
    session_recover.add_argument("session_id")
    session_recover.add_argument(
        "--abandon-stalled", action="store_true",
        help="Assert the worker stopped and record a stalled generation as failed")
    conclude = session_actions.add_parser(
        "conclude", help="Record one terminal decision bound to the current assessment")
    conclude.add_argument("session_id")
    conclude.add_argument("decision", choices=[item.value for item in ResearchDecision])
    conclude.add_argument("--rationale", required=True)
    session_compare = session_actions.add_parser("compare", help="Compare pinned run metrics")
    session_compare.add_argument("session_id")
    session_compare.add_argument("candidate_id")
    session_compare.add_argument("baseline_id")
    session_compare.add_argument("registry", nargs="?", type=Path,
        help="Omit to apply the plan pre-registered in the selected session snapshot")
    session_compare.add_argument("--event-sequence", type=int)
    session_repeat = session_actions.add_parser("repeatability", help="Check pinned metric ranges")
    session_repeat.add_argument("session_id")
    # One list keeps both forms unambiguous: REGISTRY RUN... or --from-plan RUN...
    session_repeat.add_argument("rest", nargs="+", metavar="REGISTRY RUN_ID",
        help="Registry path followed by run IDs, or only run IDs with --from-plan")
    session_repeat.add_argument("--from-plan", action="store_true",
        help="Apply the plan pre-registered in the selected session snapshot")
    session_repeat.add_argument("--minimum-runs", type=int, default=3)
    session_repeat.add_argument("--event-sequence", type=int)
    for name in ("show", "events"):
        session_actions.add_parser(name).add_argument("session_id")
    session_actions.add_parser(
        "shortfall", help="How many runs per arm the varying rules need, before a decision"
    ).add_argument("session_id")
    more = session_actions.add_parser(
        "more-repeats", help="Raise the design's runs per arm, as an amendment that says why")
    more.add_argument("session_id")
    more.add_argument("--to", type=int, required=True, dest="repeats")
    more.add_argument("--rationale", required=True)
    model = commands.add_parser(
        "model", help="Check a selected model; this calls the provider you select")
    model_actions = model.add_subparsers(dest="model_action", required=True)
    validate = model_actions.add_parser(
        "validate", help="Probe one bounded edit and report contract conformance")
    add_model_arguments(validate)
    client = commands.add_parser(
        "client", help="Read models for a client UI; changes and decides nothing")
    client.add_argument("--workspace", type=Path, default=Path("."))
    client_actions = client.add_subparsers(dest="client_action", required=True)
    client_actions.add_parser("overview", help="Sessions, runs and open gates in one report")
    client_actions.add_parser(
        "home", help="The conversation list in one read: the overview and the coding threads")
    client_agenda = client_actions.add_parser(
        "agenda", help="Where every session stands, most in need of someone first")
    client_agenda.add_argument("--attempts", type=int, default=1)

    client_actions.add_parser(
        "gates", help="Open gates with what each asks for and the sessions it holds up")
    client_report = client_actions.add_parser(
        "report", help="One session's policy, evidence, decision and pre-registration")
    client_report.add_argument("session_id")
    client_timeline = client_actions.add_parser(
        "timeline", help="Run and research events merged in time order")
    client_timeline.add_argument("--limit", type=int, default=100)
    client_timeline.add_argument("--after", help="Cursor from a previous timeline reply")
    client_follow = client_actions.add_parser(
        "follow", help="Stream entries as they are appended, one JSON object per line")
    client_follow.add_argument("--limit", type=int, default=100)
    client_follow.add_argument("--after", help="Cursor to resume from; default is the current end")
    client_follow.add_argument("--poll-seconds", type=float, default=1.0)
    client_follow.add_argument("--for-seconds", type=float, default=60.0,
                               help="How long to follow before ending the stream")
    research_parser = commands.add_parser(
        "research", help="Propose a design from a stated goal, and accept one explicitly")
    research_parser.add_argument("--workspace", type=Path, default=Path("."))
    research_actions = research_parser.add_subparsers(dest="research_action", required=True)
    research_evidence_parser = research_actions.add_parser(
        "evidence", help="A concluded study's evidence package, from its records; records nothing")
    research_evidence_parser.add_argument("session_id")
    research_evidence_parser.add_argument("--if-concluded", action="store_true")
    research_evidence_parser.add_argument("--at-sequence", type=int)
    research_propose = research_actions.add_parser(
        "propose", help="Propose a design; this records nothing, whatever it returns")
    research_propose.add_argument("intent", help="What you want to find out, in your words")
    research_propose.add_argument(
        "--planner-file", type=Path,
        help="Return this prepared proposal instead of asking a model")
    research_propose.add_argument("--model", help="Model to ask for a design")
    research_propose.add_argument(
        "--escalate-to", action="append", default=[], metavar="MODEL",
        help="A larger model to ask when a design's reply cannot be used; repeat")
    add_route_argument(research_propose)
    research_propose.add_argument(
        "--provider", choices=["ollama", "openai", "openrouter", "vllm"], default="openrouter")
    research_propose.add_argument("--endpoint")
    add_model_endpoint_argument(research_propose)
    research_propose.add_argument("--model-timeout", type=float, default=MODEL_TIMEOUT_SECONDS)
    research_propose.add_argument(
        "--inspection-rounds", type=int, default=0,
        help="Explicitly allow 0-2 bounded workspace inspection model calls before design")
    research_accept = research_actions.add_parser(
        "accept", help="Record a proposal as a session and its plan; the only act that writes")
    research_accept.add_argument("proposal", type=Path)
    conversation = commands.add_parser(
        "conversation", help="Say one thing; the answer comes from recorded state")
    conversation.add_argument("--workspace", type=Path, default=Path("."))
    conversation_actions = conversation.add_subparsers(
        dest="conversation_action", required=True)
    conversation_say = conversation_actions.add_parser(
        "say", help="Say something about a session, or state a goal with no session")
    conversation_say.add_argument("said", help="What you want to say, in your words")
    # Which session, not what state it is in. There is no argument for a turn
    # state, a gate or a refusal, because there is no field for one to reach.
    conversation_say.add_argument("--session", help="The session this is about, if any")
    conversation_say.add_argument(
        "--planner-file", type=Path,
        help="Return this prepared design instead of asking a model")
    add_conversation_model_arguments(conversation_say)
    conversation_say.add_argument(
        "--inspection-rounds", type=int, default=0,
        help="Explicitly allow 0-2 bounded workspace inspection model calls before design")
    conversation_resume = conversation_actions.add_parser(
        "resume", help="Where a session stands, with nobody having said anything")
    conversation_resume.add_argument("session_id")
    conversation_explore = conversation_actions.add_parser(
        "explore", help="Ask for one read-only workspace inspection round")
    conversation_explore.add_argument("session_id")
    conversation_explore.add_argument("question")
    add_model_arguments(conversation_explore)
    conversation_interpret = conversation_actions.add_parser(
        "interpret", help="Classify a request into one non-authoritative conversation intent")
    conversation_interpret.add_argument("said", help="What you want to do, in your words")
    conversation_interpret.add_argument("--session", help="The session this is about, if any")
    add_model_arguments(conversation_interpret)
    conversation_plan_change = conversation_actions.add_parser(
        "plan-change", help="Draft one approval-gated plan change from an exploration context")
    conversation_plan_change.add_argument("session_id")
    conversation_plan_change.add_argument("context_id")
    conversation_plan_change.add_argument("request", help="What you want changed in the plan")
    add_model_arguments(conversation_plan_change)
    conversation_history = conversation_actions.add_parser(
        "history", help="Explicit, non-authoritative conversation text storage")
    conversation_history_actions = conversation_history.add_subparsers(
        dest="history_action", required=True)
    for history_action in ("list", "append", "append-turn", "clear"):
        history_command = conversation_history_actions.add_parser(history_action)
        history_command.add_argument("thread_id")
        if history_action == "list":
            history_command.add_argument("--limit", type=int, default=50,
                                         help="Most recent 1-50 entries, returned oldest first")
        if history_action == "append":
            history_command.add_argument("--role", choices=["user", "assistant"],
                                         required=True)
            history_command.add_argument("--expected-sequence", type=int, required=True)
            history_command.add_argument("--session")
        if history_action == "append-turn":
            history_command.add_argument("--expected-sequence", type=int, required=True)
            history_command.add_argument("--session", required=True)
    conversation_act = conversation_actions.add_parser(
        "act", help="Do one of the things an answer offered")
    conversation_act.add_argument(
        "action", choices=[item.value for item in ConversationAction],
        help="One of the actions an answer offered; nothing else is a word here")
    conversation_act.add_argument("--session")
    # What the answer read when it offered this. An action that arrives after the
    # session moved on is refused rather than applied to a state nobody saw.
    conversation_act.add_argument("--event-sequence", type=int)
    conversation_act.add_argument("--plan-revision", type=int)
    conversation_act.add_argument(
        "--proposal", type=Path, help="The design being accepted, as it is to be recorded")
    # A judgement, for the actions that are one. Each takes the judgement its own
    # decision needs: approving a policy change and concluding a study are not
    # the same act, and one flag standing for both would make them look like one.
    approval = conversation_act.add_mutually_exclusive_group()
    approval.add_argument("--approve", dest="approved", action="store_true", default=None,
                          help="Record the proposed amendment as it was shown")
    approval.add_argument("--decline", dest="approved", action="store_false", default=None,
                          help="Record nothing; the plan stays as it is")
    conversation_act.add_argument(
        "--alternative", dest="alternative_id",
        help="Which of the alternatives an answer listed, by the id it listed; "
             "the change it resolves to is read from the records, not from here")
    conversation_act.add_argument(
        "--run", dest="run_id",
        help="Which waiting run this gate answer is about, from the ones offered")
    conversation_act.add_argument(
        "--decided-by", help="Who took this gate decision; recorded as given")
    conversation_act.add_argument(
        "--decision", choices=[item.value for item in ResearchDecision],
        help="The terminal decision this session reaches")
    conversation_act.add_argument(
        "--rationale", help="Why. Required for a conclusion, which must be arguable later")
    add_conversation_model_arguments(conversation_act)
    # The chat's options only: what draws it is imported when it runs, so no other
    # command -- the editor runs many -- loads a terminal library.
    from relab_cli.chat_config import add_arguments as chat_arguments

    chat_arguments(commands.add_parser(
        "chat", help="The coding agent in this terminal: type a request, watch it work, answer in place"),
        ["ollama", "openai", "openrouter", "vllm"])
    code = commands.add_parser(
        "code", help="Work a request through as a coding agent: read, search, write, run")
    code.add_argument("--workspace", type=Path, default=Path("."))
    code.add_argument(
        "--json-steps", action="store_true",
        help="Ask for steps as JSON even where the provider takes native tool calls")
    code.add_argument(
        "--references", action="store_true",
        help="Offer the references step (a Python name's definitions and uses); off by default, "
             "as it measured no better than search (docs/architecture/CODE_INTELLIGENCE.md)")
    code.add_argument(
        "--one-prompt", action="store_true",
        help="Send each call as one prompt rather than the loop's conversation so far")
    code_actions = code.add_subparsers(dest="code_action", required=True)
    code_link = code_actions.add_parser("link-study", help="Record a study's coding origin")
    code_link.add_argument("session_id")
    code_link.add_argument("loop_id")
    code_origin = code_actions.add_parser("study-origin", help="Read a study's coding origin")
    code_origin.add_argument("session_id")
    code_handback = code_actions.add_parser("hand-back", help="Continue coding with concluded research evidence")
    code_handback.add_argument("session_id")
    code_handback.add_argument("--loop-id")
    handback_review = code_handback.add_mutually_exclusive_group()
    handback_review.add_argument("--review-edits", dest="review_edits", action="store_true")
    handback_review.add_argument("--no-review-edits", dest="review_edits", action="store_false")
    code_handback.set_defaults(review_edits=None)
    code_handback.add_argument("--max-calls", dest="max_steps", type=int, default=DEFAULT_LOOP_STEPS)
    add_model_arguments(code_handback)
    add_loop_arguments(code_handback)
    stream = code_actions.add_parser(
        "stream-check", help="Whether the model's server streams text and tool arguments as they are written")
    add_model_arguments(stream)
    code_run = code_actions.add_parser("run", help="Work one request through to the end")
    code_run.add_argument("request", help="What to do, in your words")
    code_run.add_argument("--plan-only", action="store_true",
                          help="Read and propose a plan without writing or executing commands")
    code_run.add_argument("--max-calls", "--max-steps", dest="max_steps", type=int,
                          default=DEFAULT_LOOP_STEPS,
                          help="Model calls this leg may make (a call may carry several steps)")
    code_run.add_argument(
        "--project-only", action="store_true",
        help="Read, search and list only inside the project folder")
    code_run.add_argument(
        "--scope", help="The project folder: nothing is written outside it, and its code "
                        "imports nothing from another folder of the workspace")
    code_run.add_argument(
        "--loop-id", help="The id to record this loop under, so a caller can find it if stopped")
    code_run.add_argument(
        "--review-edits", action="store_true",
        help="Show each change to a file and wait for it to be accepted before writing it")
    code_run.add_argument(
        "--after", help="The loop this one follows in the same conversation: its project "
                        "folder is kept and what it did is shown")
    add_model_arguments(code_run)
    add_loop_arguments(code_run)
    code_answer = code_actions.add_parser(
        "answer", help="Answer the question a loop is waiting on, and let it go on")
    code_answer.add_argument("loop_id")
    code_answer.add_argument("answer", help="The answer, in your words")
    code_answer.add_argument("--max-calls", "--max-steps", dest="max_steps", type=int, default=DEFAULT_LOOP_STEPS)
    add_model_arguments(code_answer)
    add_loop_arguments(code_answer)
    code_approve = code_actions.add_parser(
        "approve", help="Approve the code plan a loop is waiting on, and let it build")
    code_approve.add_argument("loop_id")
    code_approve.add_argument("--max-calls", "--max-steps", dest="max_steps", type=int, default=BUILD_LOOP_STEPS)
    add_model_arguments(code_approve)
    add_loop_arguments(code_approve)
    for verb, said in (("allow", "Run the command a loop is waiting on, and let it go on"),
                       ("refuse", "Do not run the command a loop is waiting on; it goes on without")):
        decided = code_actions.add_parser(verb, help=said)
        decided.add_argument("loop_id")
        if verb == "allow":
            decided.add_argument(
                "--always", action="store_true",
                help="Also keep a rule: commands of this one's shape run without asking")
        decided.add_argument("--max-calls", "--max-steps", dest="max_steps", type=int, default=DEFAULT_LOOP_STEPS)
        add_model_arguments(decided)
        add_loop_arguments(decided)
    for verb, said in (("accept", "Write the change a loop is waiting on, and let it go on"),
                       ("reject", "Do not write the change a loop is waiting on; it goes on")):
        verdict = code_actions.add_parser(verb, help=said)
        verdict.add_argument("loop_id")
        if verb == "accept":
            verdict.add_argument(
                "--all", dest="every", action="store_true",
                help="Also accept every later change of this loop without showing it")
        else:
            verdict.add_argument("--note", help="What you would have instead, for the model")
        verdict.add_argument("--max-calls", "--max-steps", dest="max_steps", type=int,
                              default=DEFAULT_LOOP_STEPS)
        add_model_arguments(verdict)
        add_loop_arguments(verdict)
    code_resume = code_actions.add_parser(
        "resume", help="Go on with a loop that failed, ran out of steps or was stopped")
    code_resume.add_argument("loop_id")
    code_resume.add_argument("--max-calls", "--max-steps", dest="max_steps", type=int,
                             help="A fresh step budget (default: as for a request, more after a plan)")
    add_model_arguments(code_resume)
    add_loop_arguments(code_resume)
    code_follow = code_actions.add_parser(
        "follow", help="The next request in a conversation, gone on with in the same loop, "
                       "with every step and answer before it")
    code_follow.add_argument("loop_id")
    code_follow.add_argument("request")
    code_follow.add_argument("--max-calls", "--max-steps", dest="max_steps", type=int,
                             help="A step budget (default: as for a request)")
    add_model_arguments(code_follow)
    add_loop_arguments(code_follow)
    code_bench = code_actions.add_parser(
        "bench", help="Run the coding benchmark: each task in a fresh copy, scored by hidden "
                      "tests (spends model calls)")
    code_bench.add_argument("suite", type=Path, help="A folder of tasks, e.g. benchmarks/coding")
    code_bench.add_argument("--label", required=True, help="What this run is, e.g. the change tried")
    code_bench.add_argument("--repeats", type=int, default=1)
    code_bench.add_argument("--task", action="append", default=[], help="Only this task; repeat")
    code_bench.add_argument("--out", type=Path, help="Where to write every run, as JSON")
    code_bench.add_argument("--work", type=Path, help="Keep each run's workspace here")
    code_bench.add_argument("--jobs", type=int, default=1, help="Tasks to run at once")
    code_bench.add_argument("--task-seconds", type=float, default=900.0,
                            help="Stop a task after this many seconds in all (0: no limit)")
    code_bench.add_argument("--carry-lessons", action="store_true",
                            help="Carry each task's lessons, and its failed check, from one "
                                 "repeat to the next; the report shows solved by repeat")
    code_bench.add_argument("--no-carry-check", action="store_true",
                            help="With --carry-lessons: carry only the lessons the loops wrote, "
                                 "not the failed hidden check (memory without the test's feedback)")
    code_bench.add_argument("--retry-provider-failures", type=int, default=0, metavar="N",
                            help="Run again, up to N times, the runs the provider failed "
                                 "(rate limited, not reached); a rerun is recorded as one")
    code_bench.add_argument("--given-lessons", type=Path, metavar="FILE",
                            help="A JSON list of lessons given to every run's loop (from "
                                 "failure-kinds), recorded with the result"),
    code_bench.add_argument("--resume", action="store_true",
                            help="Keep the runs --out already holds, and run only the rest")
    add_model_arguments(code_bench)
    add_loop_arguments(code_bench)
    code_prompts = code_actions.add_parser(
        "prompt-compare", help="Run a suite under the instruction's conditions -- A current, B compact, "
                               "C modular -- with one model and policy, and compare (spends model calls)")
    code_prompts.add_argument("suite", type=Path, help="A folder of tasks, e.g. benchmarks/coding")
    code_prompts.add_argument("--label", required=True, help="What this comparison is")
    code_prompts.add_argument("--conditions", default="A,B,C", help="Which, in the order to run them")
    code_prompts.add_argument("--repeats", type=int, default=3)
    code_prompts.add_argument("--out", type=Path, required=True,
                              help="A folder: each condition's runs, and comparison.json")
    code_prompts.add_argument("--task", action="append", default=[], help="Only this task; repeat")
    code_prompts.add_argument("--work", type=Path, help="Keep each run's workspace here")
    code_prompts.add_argument("--jobs", type=int, default=1, help="Tasks to run at once")
    code_prompts.add_argument("--task-seconds", type=float, default=900.0,
                              help="Stop a task after this many seconds in all (0: no limit)")
    code_prompts.add_argument("--retry-provider-failures", type=int, default=0, metavar="N",
                              help="Run again, up to N times, the runs the provider failed")
    add_model_arguments(code_prompts)
    add_loop_arguments(code_prompts)
    code_prompts_report = code_actions.add_parser(
        "prompt-compare-report", help="The numbers of a prompt comparison already run")
    code_prompts_report.add_argument("comparison", type=Path, help="Its folder, or its comparison.json")
    code_import = code_actions.add_parser(
        "bench-import", help="Turn a downloaded public benchmark into bench tasks (nothing is "
                             "downloaded)")
    code_import.add_argument("format", choices=["polyglot", "dabench"],
                             help="polyglot: github.com/Aider-AI/polyglot-benchmark; dabench: "
                                  "github.com/InfiAgent/InfiAgent (examples/DA-Agent/data)")
    code_import.add_argument("source", type=Path, help="Where the benchmark was downloaded")
    code_import.add_argument("out", type=Path, help="The suite folder to write")
    code_import.add_argument("--language", default="python", help="polyglot: which language")
    code_import.add_argument("--exercise", action="append", default=[],
                             help="Only this exercise, by its folder name (dabench: the question's id); "
                                  "repeat")
    code_import.add_argument("--level", choices=["easy", "medium", "hard"],
                             help="dabench: only the questions of this level")
    code_import.add_argument("--calibrate", action="store_true",
                             help="Check each task fails as it starts and passes on its solution")
    code_kinds = code_actions.add_parser(
        "failure-kinds", help="Kinds of failure benchmark results' hidden checks found, met in more "
                              "than one task, as lessons for other tasks (no model call)")
    code_kinds.add_argument("results", type=Path, nargs="+", help="Benchmark results (bench --out)")
    code_kinds.add_argument("--task", action="append", default=[], help="Only this task's runs; repeat")
    code_kinds.add_argument("--minimum", type=int, default=2, help="Tasks a kind is met in to be a lesson")
    code_kinds.add_argument("--out", type=Path, help="Write the lessons here, for bench --given-lessons")
    code_compare = code_actions.add_parser(
        "bench-compare", help="Solve rate and cost of two benchmark results, task by task")
    code_compare.add_argument("before", type=Path)
    code_compare.add_argument("after", type=Path)
    code_rules = code_actions.add_parser(
        "rules", help="Commands allowed to run without asking, by shape; or remove one")
    code_rules.add_argument("--remove", nargs="+", metavar="WORD",
                            help="The rule to remove, e.g. --remove npm install")
    code_actions.add_parser("threads", help="The coding conversations here, newest first")
    code_actions.add_parser("jobs", help="The jobs loops here started that were running, as they are now")
    code_actions.add_parser("scores", help="The scores evaluation runs here printed, across tasks, newest last")
    code_stats = code_actions.add_parser(
        "stats", help="Where a loop's turns and time went, in numbers only: nothing it read or wrote")
    code_stats.add_argument("loop_id", nargs="?",
                            help="Its id, from `relab code list`; the loop written last when left out")
    code_stats.add_argument("--json", action="store_true", help="As JSON")
    code_actions.add_parser(
        "mcp", help="The MCP servers in .relab/mcp.json: start each, list its tools, stop it")
    code_results = code_actions.add_parser(
        "results", help="The registered benchmark runs; or register old result files")
    code_results.add_argument("--register", type=Path, nargs="+", default=[], metavar="FILE",
                              help="Register these result files (bench --out ...)")
    code_results.add_argument("--suite", help="Their suite, when the files do not say")
    code_results.add_argument("--model", help="Their model, when the files do not say")
    code_results.add_argument("--provider", help="Their provider, when the files do not say")
    code_actions.add_parser(
        "report", help="Rebuild .relab/results/REPORT.md from every registered run")
    code_lessons = code_actions.add_parser(
        "lessons", help="What coding loops here found out by failing, kept for later loops; "
                        "or remove one")
    code_lessons.add_argument("--remove", metavar="LESSON_ID", help="Remove this lesson")
    code_common = code_actions.add_parser(
        "common-lessons", help="Failures met in more than one of your workspaces, offered as lessons "
                               "for all of them; the ones you confirmed")
    code_common.add_argument("--confirm", metavar="ID", help="Keep this candidate as a common lesson")
    code_common.add_argument("--text", help="With --confirm: the lesson's own words, instead of the one offered")
    code_common.add_argument("--dismiss", metavar="ID",
                             help="Take out this common lesson, or set this candidate aside")
    code_notes = code_actions.add_parser(
        "notes", help="What coding loops kept about each project for later tasks; or remove one")
    code_notes.add_argument("--remove", type=int, metavar="N",
                            help="Remove the project's note N, counted from 1")
    code_notes.add_argument("--project", help="The project folder; the workspace's own when left out")
    code_thread = code_actions.add_parser(
        "thread", help="Every loop of the conversation a loop belongs to, oldest first")
    code_thread.add_argument("loop_id")
    code_list = code_actions.add_parser(
        "list", help="The coding loops recorded here, newest first: when, how each ended, its id, its request")
    code_list.add_argument("--json", action="store_true", help="Every record whole, oldest first")
    code_steer = code_actions.add_parser(
        "steer", help="Say something to a running loop; it reads it at its next turn's end")
    code_steer.add_argument("loop_id")
    code_steer.add_argument("instruction")
    code_unsteer = code_actions.add_parser(
        "unsteer", help="Take back something said to a running loop, before it reads it")
    code_unsteer.add_argument("loop_id")
    code_unsteer.add_argument("steering_id")
    code_stopped = code_actions.add_parser(
        "stopped", help="Record that a loop was stopped part-way, and show it as it stood")
    code_stopped.add_argument("loop_id")
    code_show = code_actions.add_parser("show", help="One recorded loop, step by step")
    code_show.add_argument("loop_id")
    code_side = code_actions.add_parser(
        "side", help="What a file a loop wrote held before its first write or after its last")
    code_side.add_argument("loop_id")
    code_side.add_argument("path")
    code_side.add_argument("--side", choices=["before", "after", "now", "proposed"], required=True,
                           help="before/after: a file the loop wrote; now/proposed: the change "
                                "it waits on")
    code_undo = code_actions.add_parser(
        "undo", help="Put back every file a loop wrote, unless it has changed since")
    code_undo.add_argument("loop_id")
    code_revert = code_actions.add_parser(
        "revert", help="Put back one file, one change, or everything after a checkpoint, "
                       "unless it has changed since")
    code_revert.add_argument("loop_id")
    reverting = code_revert.add_mutually_exclusive_group(required=True)
    reverting.add_argument("--file", help="A file the loop wrote, put back as it was before it")
    reverting.add_argument("--change", type=int, help="One change, by its number")
    reverting.add_argument("--checkpoint", type=int, help="Back to this checkpoint")
    measuring = code_actions.add_parser(
        "measure-search",
        help="Time ReLab's code search on this machine, on files it makes in a temporary folder")
    measuring.add_argument("--files", type=int, nargs="+", default=[10_000, 30_000],
                           help="How many files to search, each count measured in turn")
    measuring.add_argument("--repeats", type=int, default=5, help="Samples of each case")
    measuring.add_argument("--out", type=Path, help="Also write the report here, as JSON")
    storing = code_actions.add_parser(
        "storage", help="What the coding loops keep on disk; read only unless --compact")
    storing.add_argument(
        "--compact", action="store_true",
        help="Compress the file contents kept before compression; removes nothing")
    skill = commands.add_parser(
        "skill", help="Existing procedures under a typed name, with what each may change")
    skill.add_argument("--workspace", type=Path, default=Path("."))
    skill_actions = skill.add_subparsers(dest="skill_action", required=True)
    skill_actions.add_parser("list", help="The skills this build has, and the effect of each")
    skill_run = skill_actions.add_parser(
        "run", help="Run one skill; only reading is permitted unless --allow says more")
    skill_run.add_argument("name")
    skill_run.add_argument("--input", help="The skill's input, as a JSON object")
    skill_run.add_argument("--allow", action="append", default=[], choices=["record", "mutate"],
                           help="Also permit this effect; repeat")
    skill_eval = skill_actions.add_parser(
        "eval", help="Run each skill's own evaluation cases (no model, temporary workspaces)")
    skill_eval.add_argument("skill", nargs="?")
    skill_log = skill_actions.add_parser("log", help="The latest skill invocations here")
    skill_log.add_argument("--limit", type=int, default=50)
    memory = commands.add_parser(
        "memory", help="What was learned from the evidence here, and where it is believed")
    memory.add_argument("--workspace", type=Path, default=Path("."))
    memory_actions = memory.add_subparsers(dest="memory_action", required=True)
    memory_record = memory_actions.add_parser(
        "record", help="Record a written finding; one citing absent evidence is refused")
    memory_record.add_argument("draft", type=Path, help="A finding, as a JSON document")
    memory_list = memory_actions.add_parser(
        "list", help="Retrieve findings exactly, in a fixed order, with why each matched")
    memory_list.add_argument("--scope", help="Only findings believed in exactly this scope")
    memory_list.add_argument("--tag", action="append", default=[],
                             help="Only findings carrying every tag given")
    memory_list.add_argument("--limit", type=int, default=DEFAULT_RETRIEVAL_LIMIT)
    memory_list.add_argument("--include-superseded", action="store_true",
                             help="Also show findings a later one replaced")
    memory_draft = memory_actions.add_parser(
        "draft", help="Findings a session's claims would make; records nothing")
    memory_draft.add_argument("session_id")
    memory_draft.add_argument(
        "--scope", help="Where you believe these hold; nothing invents it for you")
    memory_draft.add_argument(
        "--model", help="Ask a model where these hold, instead of saying so yourself")
    memory_draft.add_argument(
        "--provider", choices=["ollama", "openai", "openrouter", "vllm"], default="openrouter")
    memory_draft.add_argument("--endpoint")
    add_model_endpoint_argument(memory_draft)
    memory_draft.add_argument("--model-timeout", type=float, default=MODEL_TIMEOUT_SECONDS)
    memory_draft.add_argument("--tag", action="append", default=[])
    memory_actions.add_parser(
        "pending", help="Findings drafted when sessions concluded, waiting to be confirmed")
    memory_propose = memory_actions.add_parser(
        "propose", help="Draft a concluded session's findings for confirming (done on conclude)")
    memory_propose.add_argument("session_id")
    memory_confirm = memory_actions.add_parser(
        "confirm", help="Record a drafted finding; its evidence must be here")
    memory_confirm.add_argument("draft_id")
    memory_confirm.add_argument("--scope", help="Where it holds, if not the suggested scope")
    memory_dismiss = memory_actions.add_parser(
        "dismiss", help="Do not record a drafted finding; it is kept as dismissed")
    memory_dismiss.add_argument("draft_id")
    memory_supersede = memory_actions.add_parser(
        "supersede", help="Record that a later finding replaces an earlier one; deletes nothing")
    memory_supersede.add_argument("memory_id")
    memory_supersede.add_argument("replacement")
    checkouts = commands.add_parser(
        "checkouts", help="Checkouts isolated attempts left behind; removes only settled ones")
    checkouts.add_argument("--workspace", type=Path, default=Path("."))
    checkout_actions = checkouts.add_subparsers(dest="checkout_action", required=True)
    checkout_actions.add_parser("list", help="What each checkout is; removes nothing")
    checkout_clean = checkout_actions.add_parser(
        "clean", help="Remove the settled checkouts, keeping every other one")
    checkout_clean.add_argument("--name", help="Ask for one checkout; it is still checked")
    bundle = commands.add_parser(
        "bundle", help="Build or check an offline distribution bundle; reaches no index")
    bundle_actions = bundle.add_subparsers(dest="bundle_action", required=True)
    bundle_build = bundle_actions.add_parser(
        "build", help="Build the wheel and collect the dependency wheels named")
    bundle_build.add_argument("--into", type=Path, required=True)
    bundle_build.add_argument("--source", type=Path, default=Path("."))
    bundle_build.add_argument("--find-links", type=Path, action="append", default=[],
                              help="A directory of dependency wheels; repeatable")
    bundle_verify = bundle_actions.add_parser(
        "verify", help="Re-read a bundle from its files and check it against its manifest")
    bundle_verify.add_argument("directory", type=Path)
    inspect = commands.add_parser("inspect", help="Inspect workspace files and Python symbols")
    inspect.add_argument("path", nargs="?", default=".")
    inspect.add_argument("--max-files", type=int, default=2000)
    inspect.add_argument("--max-symbol-bytes", type=int, default=1_000_000)
    ranking = commands.add_parser(
        "targets", help="Rank existing files against an objective; suggests, never edits")
    ranking.add_argument("objective")
    ranking.add_argument("path", nargs="?", default=".")
    ranking.add_argument("--limit", type=int, default=5)
    ranking.add_argument("--max-files", type=int, default=2000)
    ranking.add_argument("--max-symbol-bytes", type=int, default=1_000_000)
    apply = commands.add_parser("apply", help="Apply a proposal and verify; revert on failure")
    apply.add_argument("proposal", type=Path)
    apply.add_argument("--workspace", type=Path, default=Path("."))
    apply.add_argument("--timeout", type=float, default=300)
    apply.add_argument("--verify", nargs=argparse.REMAINDER, required=True)
    run = commands.add_parser("run", help="Record and inspect coding-task outcomes")
    run.add_argument("--workspace", type=Path, default=Path("."))
    actions = run.add_subparsers(dest="action", required=True)
    create = actions.add_parser("create")
    create.add_argument("objective")
    create.add_argument("--request-id", required=True)
    generate = actions.add_parser("generate", help="Use a selected model to edit explicit Python files")
    generate.add_argument("run_id")
    generate.add_argument("target")
    generate.add_argument("--additional-target", action="append", default=[])
    generate.add_argument("--data-path", action="append", default=[])
    add_model_arguments(generate)
    generate.add_argument("--verify", nargs=argparse.REMAINDER, required=True)
    record = actions.add_parser("record", help="Import a result; does not execute or verify code")
    record.add_argument("run_id")
    record.add_argument("result", type=Path)
    decide = actions.add_parser("decide-dependency", help="Record approval/rejection; does not install")
    decide.add_argument("run_id")
    decide.add_argument("decision", type=Path)
    check = actions.add_parser("check-dependency", help="Inspect an approved target; does not install")
    check.add_argument("run_id")
    check.add_argument("policy", type=Path)
    install = actions.add_parser("install-dependency", help="Install an approved wheel; no resume")
    install.add_argument("run_id")
    install.add_argument("policy", type=Path)
    install.add_argument("--timeout", type=float, default=300)
    resume = actions.add_parser("resume-dependency", help="Apply stored resume diff and verify")
    resume.add_argument("run_id")
    resume.add_argument("--timeout", type=float, default=300)
    resume.add_argument("--data-path", action="append", default=[])
    resume.add_argument("--verify", nargs=argparse.REMAINDER, required=True)
    run_apply = actions.add_parser("apply", help="Execute a patch against a created run")
    run_apply.add_argument("run_id")
    run_apply.add_argument("proposal", type=Path)
    run_apply.add_argument("--timeout", type=float, default=300)
    run_apply.add_argument("--data-path", action="append", default=[])
    run_apply.add_argument("--verify", nargs=argparse.REMAINDER, required=True)
    compare = actions.add_parser("compare", help="Compare verified metrics against a baseline")
    compare.add_argument("candidate_id")
    compare.add_argument("baseline_id")
    compare.add_argument("registry", type=Path)
    repeat = actions.add_parser("repeatability", help="Check observed metric ranges across runs")
    repeat.add_argument("registry", type=Path)
    repeat.add_argument("run_ids", nargs="+")
    repeat.add_argument("--minimum-runs", type=int, default=3)
    run_review = actions.add_parser(
        "review", help="Ask whether a change did the work or satisfied the check; records nothing")
    run_review.add_argument("run_id")
    add_model_arguments(run_review)
    actions.add_parser("gates", help="List runs awaiting a person; resolves nothing")
    abandon = actions.add_parser("abandon-holdout", help="Record an interrupted measurement as abandoned")
    abandon.add_argument("run_id")
    abandon.add_argument("--expected-sequence", type=int, required=True)
    abandon.add_argument("--reason", required=True)
    abandon.add_argument("--worker-stopped", action="store_true", required=True)
    actions.add_parser("restore", help="Undo a verified run's edit; evidence is kept"
                       ).add_argument("run_id")
    recorded = actions.add_parser(
        "snapshot", help="What a file held either side of this run's recorded patch")
    recorded.add_argument("run_id")
    recorded.add_argument("path", help="A path this run's patch touched")
    recorded.add_argument("--side", choices=("before", "after"), required=True)
    for action in ("show", "events", "recover", "evaluate", "metrics"):
        actions.add_parser(action).add_argument("run_id")
    args = parser.parse_args()
    try:
        MODEL_ENDPOINTS.clear()
        MODEL_ENDPOINTS.update(parse_model_endpoints(getattr(args, "model_endpoint", None)))
        MODEL_SAMPLING.clear()
        MODEL_SAMPLING.update(parse_model_sampling(getattr(args, "model_sampling", None)))
        records_from_settings()
        ALLOWED_ENDPOINTS.clear()
        ALLOWED_ENDPOINTS.update(_same(item) for item in getattr(args, "allow_endpoint", None) or [])
        if args.command == "chat":
            from relab_cli.chat import chat

            return chat(args)
        if args.command == "model":
            print(f"[relab] Probing {args.provider} with one bounded request",
                  file=sys.stderr, flush=True)
            validation = validate_model(
                build_gateway(args.provider, args.model, args.endpoint, ),
                timeout_seconds=args.model_timeout)
            print(validation.model_dump_json())
            return 0 if validation.conforms else 1
        if args.command == "client":
            print(f"[relab] Reading workspace {args.client_action}", file=sys.stderr, flush=True)
            if args.client_action == "home":
                # One process for the list instead of two: each start of Python
                # and of ReLab's modules is most of what reading the list costs.
                home: dict[str, object]
                if untouched(args.workspace):
                    home = {"overview": nothing_kept(args.workspace, "overview").model_dump(mode="json"),
                            "threads": []}
                else:
                    home = {"overview": WorkspaceClient(args.workspace).overview().model_dump(mode="json"),
                            "threads": CodingLoopService(args.workspace).threads()}
                # The person's conversations in their other workspaces, read only
                # (0.2.75): a folder opened for the next experiment listed nothing.
                home["elsewhere"] = threads_elsewhere(args.workspace)
                print(json.dumps(home))
                return 0
            if args.client_action in ("overview", "gates", "agenda") and untouched(args.workspace):
                # Opening the stores creates them: a Cline window with ReLab
                # merely installed got a `.relab` of three empty databases, and
                # Cline then reported it as part of the project.
                print(nothing_kept(args.workspace, args.client_action).model_dump_json())
                return 0
            reader = WorkspaceClient(args.workspace)
            if args.client_action == "agenda":
                agenda = WorkspaceAgendaReader(args.workspace).agenda(
                    attempts_per_slot=args.attempts)
                print(f"[relab] {agenda.awaiting_human} session(s) waiting on you, "
                      f"{agenda.unreadable} unreadable", file=sys.stderr, flush=True)
                print(agenda.model_dump_json())
                # Nothing needing anyone is the one answer that is not work remaining.
                return 0 if agenda.settled else 1
            if args.client_action == "overview":
                print(reader.overview().model_dump_json())
            elif args.client_action == "gates":
                print(reader.gates().model_dump_json())
            elif args.client_action == "report":
                print(reader.report(args.session_id).model_dump_json())
            elif args.client_action == "follow":
                try:
                    for entry in reader.follow(
                        after=args.after, limit=args.limit,
                        poll_seconds=args.poll_seconds, max_seconds=args.for_seconds,
                    ):
                        print(entry.model_dump_json(), flush=True)
                except KeyboardInterrupt:
                    # Ending a stream on purpose is not a failure of the query.
                    print("[relab] Stream ended", file=sys.stderr, flush=True)
            else:
                print(reader.timeline(limit=args.limit, after=args.after).model_dump_json())
            return 0
        if args.command == "research":
            if args.research_action == "evidence":
                from relab_app.evidence import research_evidence

                print("[relab] Reading a concluded study's evidence; nothing is recorded",
                      file=sys.stderr, flush=True)
                if args.if_concluded:
                    evidence_session = ResearchSessionService(args.workspace).store.latest(args.session_id).snapshot
                    if evidence_session.conclusion is None or evidence_session.conclusion.decision.value == "abandoned":
                        print("null")
                        return 0
                print(research_evidence(args.workspace, args.session_id, args.at_sequence).model_dump_json())
                return 0
            research_service = ResearchProposals(args.workspace)
            if args.research_action == "propose":
                print("[relab] Proposing a design; nothing is recorded",
                      file=sys.stderr, flush=True)
                if (args.planner_file is None) == (args.model is None):
                    raise ValueError(
                        "propose a design from a model or from a prepared file, not both")
                scripted: ResearchPlanner | None = None
                if args.planner_file is not None:
                    if args.inspection_rounds:
                        raise ValueError("inspection rounds require a model, not a prepared design")
                    scripted = ScriptedPlanner(ProposedPlan.model_validate_json(
                        args.planner_file.read_text(encoding="utf-8-sig")))
                declared = parse_routes(args.routes)

                def designed(model: str | None,
                             wrap: Callable[[ModelGateway], ModelGateway]) -> ProposedPlan:
                    designing = scripted if model is None else research_planner(
                        wrap(build_gateway(args.provider, model, args.endpoint)),
                        args.workspace, timeout_seconds=args.model_timeout,
                        inspection_rounds=args.inspection_rounds)
                    return research_service.propose(
                        ResearchIntent(stated=args.intent), designing,
                        routing_policy=declared,
                        resolver=CommandLineResolver(args.endpoint),
                        # The declared route decides which model designs the study.
                        # The planner above is what a session with no declaration
                        # still uses, and is refused by the application when one was
                        # declared -- it wraps a gateway nobody named.
                        planner_from=lambda gateway, route: research_planner(
                            gateway, args.workspace, timeout_seconds=args.model_timeout,
                            inspection_rounds=args.inspection_rounds))

                # A ladder applies to a design nobody routed: a declared route is the route.
                models = ([None] if args.planner_file is not None
                          else [args.model] if declared is not None
                          else [args.model, *args.escalate_to])
                proposed, passed = climb(models, designed, said=_say)
                if passed:
                    proposed = proposed.model_copy(update={"passed_over": passed})
                print(proposed.model_dump_json())
                return 0
            print("[relab] Recording the accepted proposal", file=sys.stderr, flush=True)
            accepted = ProposedPlan.model_validate_json(
                args.proposal.read_text(encoding="utf-8-sig"))
            print(research_service.accept(accepted).model_dump_json())
            return 0
        if args.command == "conversation":
            return _conversation(args)
        if args.command == "code":
            return _code(args)
        if args.command == "skill":
            return _skill(args)
        if args.command == "memory":
            research_memory = ResearchMemory(args.workspace)
            if args.memory_action == "record":
                print("[relab] Recording a finding; its evidence must be here",
                      file=sys.stderr, flush=True)
                written = research_memory.remember(MemoryDraft.model_validate_json(
                    args.draft.read_text(encoding="utf-8-sig")))
                print(written.model_dump_json())
                return 0
            if args.memory_action == "draft":
                print("[relab] Drafting findings; nothing is recorded",
                      file=sys.stderr, flush=True)
                if (args.scope is None) == (args.model is None):
                    raise ValueError(
                        "state the scope yourself or ask a model for one, not both")
                read = SessionInterpreter(args.workspace).interpret(args.session_id)
                if args.model is not None:
                    drafted = LLMFindingExtractor(
                        build_gateway(args.provider, args.model, args.endpoint,
                                      ),
                        timeout_seconds=args.model_timeout).extract(read)
                else:
                    drafted = memory_drafts(read, args.scope, tags=args.tag)
                for item in drafted:
                    print(item.model_dump_json())
                if not drafted:
                    print(f"[relab] {read.reason}", file=sys.stderr, flush=True)
                return 0 if drafted else 1
            if args.memory_action in ("pending", "confirm", "dismiss", "propose"):
                from relab_app.memory_pending import PendingFindings

                pending = PendingFindings(args.workspace)
                if args.memory_action == "propose":
                    shown = pending.propose(args.session_id)
                elif args.memory_action == "confirm":
                    shown = [pending.confirm(args.draft_id, scope=args.scope)]
                elif args.memory_action == "dismiss":
                    shown = [pending.dismiss(args.draft_id)]
                else:
                    shown = pending.pending()
                print(json.dumps([item.model_dump(mode="json") for item in shown],
                                 ensure_ascii=False))
                return 0
            if args.memory_action == "supersede":
                print("[relab] Recording a replacement; nothing is deleted",
                      file=sys.stderr, flush=True)
                print(research_memory.supersede(
                    args.memory_id, args.replacement).model_dump_json())
                return 0
            retrieved = research_memory.retrieve(
                scope=args.scope, tags=args.tag, limit=args.limit,
                include_superseded=args.include_superseded)
            print(retrieved.model_dump_json())
            # A truncated retrieval is a report saying there is more to read, not a
            # failure: what came back is true, and is not all of it.
            return 1 if retrieved.truncated else 0
        if args.command == "checkouts":
            print(f"[relab] Reading checkouts: {args.checkout_action}",
                  file=sys.stderr, flush=True)
            checkout_reader = WorkspaceCheckouts(args.workspace)
            if args.checkout_action == "list":
                listed = checkout_reader.report()
                print(listed.model_dump_json())
                return 0 if not listed.findings else 1
            cleaned = checkout_reader.clean(name=args.name)
            print(cleaned.model_dump_json())
            return 0 if not cleaned.kept else 1
        if args.command == "bundle":
            if args.bundle_action == "build":
                print("[relab] Building an offline bundle; no index is contacted",
                      file=sys.stderr, flush=True)
                manifest = build_bundle(args.source, args.into, find_links=args.find_links)
                print(manifest.model_dump_json())
                return 0 if manifest.self_sufficient else 1
            checked = verify_bundle(args.directory)
            print(checked.model_dump_json())
            return 0 if checked.intact and checked.bundle.self_sufficient else 1
        if args.command == "session":
            research = ResearchSessionService(args.workspace)
            print(f"[relab] Research session: {args.session_action}", file=sys.stderr, flush=True)
            if args.session_action == "create":
                print(research.create(args.objective).model_dump_json())
            elif args.session_action == "attach":
                print(research.attach(
                    args.session_id, args.run_id, role=args.role).model_dump_json())
            elif args.session_action == "refresh":
                print(research.refresh(args.session_id, args.run_id,
                    expected_run_sequence=args.expected_run_sequence).model_dump_json())
            elif args.session_action == "review":
                print(research.review(args.session_id,
                    event_sequence=args.event_sequence).model_dump_json())
            elif args.session_action == "plan":
                print(research.record_plan(args.session_id, read_registry(args.registry),
                    arms=args.arm, repeats_per_arm=args.repeats,
                    candidate_arm=args.candidate_arm, baseline_arm=args.baseline_arm,
                    arm_tasks=read_arm_tasks(args.arm_task, args.arm_task_file),
                    expected_model=read_expected_model(
                        args.expected_provider, args.expected_model),
                    expected_reported_model=args.expected_reported_model,
                    data_paths=args.data_path,
                    require_comparable_conditions=args.require_comparable_conditions,
                    holdout_registry=(None if args.holdout_registry is None
                                      else read_registry(args.holdout_registry)),
                    holdout_data_paths=args.holdout_data_path,
                    restore_between_attempts=args.restore_between_attempts,
                    isolate_attempts=args.isolate_attempts,
                    sandbox_backend=args.sandbox_backend,
                    docker_image=args.docker_image,
                    ).model_dump_json())
            elif args.session_action == "measurement-impact":
                print(measurement_impact(
                    research.store.latest(args.session_id).snapshot,
                    CodingRunService(args.workspace).store.load).model_dump_json())
            elif args.session_action == "revise-measurement":
                print("[relab] Retiring this study's measurement; readings taken under it "
                      "stay recorded and stop being evidence", file=sys.stderr, flush=True)
                print(research.revise_measurement(
                    args.session_id,
                    MeasurementSetup.model_validate_json(
                        args.measurement.read_text(encoding="utf-8-sig")),
                    expected_revision=args.expected_revision,
                    rationale=args.rationale).model_dump_json())
            elif args.session_action == "revise-plan":
                print(research.revise_plan(args.session_id, read_registry(args.registry),
                    expected_revision=args.expected_revision, rationale=args.rationale,
                    arms=args.arm, repeats_per_arm=args.repeats,
                    candidate_arm=args.candidate_arm, baseline_arm=args.baseline_arm,
                    arm_tasks=read_arm_tasks(args.arm_task, args.arm_task_file),
                    expected_model=read_expected_model(
                        args.expected_provider, args.expected_model),
                    expected_reported_model=args.expected_reported_model,
                    data_paths=args.data_path,
                    require_comparable_conditions=args.require_comparable_conditions,
                    holdout_registry=(None if args.holdout_registry is None
                                      else read_registry(args.holdout_registry)),
                    holdout_data_paths=args.holdout_data_path,
                    restore_between_attempts=args.restore_between_attempts,
                    isolate_attempts=args.isolate_attempts,
                    sandbox_backend=args.sandbox_backend,
                    docker_image=args.docker_image,
                    ).model_dump_json())
            elif args.session_action == "shortfall":
                print(json.dumps(research.repeat_shortfall(args.session_id)))
            elif args.session_action == "more-repeats":
                design_now = research.store.latest(args.session_id).snapshot.plan
                if design_now is None:
                    raise ValueError("a session with no design_now plan has no repeats to raise")
                if args.repeats <= design_now.repeats_per_arm:
                    raise ValueError(f"the design already asks for {design_now.repeats_per_arm} runs per "
                                     f"arm; more repeats means more than that")
                repeats_amender = NextActions(args.workspace)
                raised_design = repeats_amender.checked(design_now, ProposedAmendment(
                    repeats_per_arm=args.repeats, rationale=args.rationale))
                print(repeats_amender.amend(args.session_id, raised_design,
                                     expected_revision=design_now.revision).model_dump_json())
            elif args.session_action == "reopen":
                print(research.reopen(args.session_id, args.rationale).model_dump_json())
            elif args.session_action == "request":
                print(research.request(args.session_id).model_dump_json())
            elif args.session_action == "execute":
                print(f"[relab] Executing declared runs through {args.provider}",
                      file=sys.stderr, flush=True)
                print(research.execute(args.session_id,
                    build_gateway(args.provider, args.model, args.endpoint,
                                  response_contract=multi_file_schema()),
                    # A session that declared routing runs on what it declared,
                    # and the gateway above is not used. Passing both is how one
                    # command serves sessions of either kind without the person
                    # running it having to know which this is.
                    resolver=CommandLineResolver(
                        args.endpoint, response_contract=multi_file_schema()),
                    attempts_per_slot=args.attempts, repair_context=args.repair_context,
                    expected_session_sequence=args.expected_session_sequence,
                    model_timeout_seconds=args.model_timeout, parallel_arms=args.parallel_arms,
                    timeout_seconds=args.timeout).model_dump_json())
            elif args.session_action == "conclude":
                print(research.conclude(args.session_id, ResearchDecision(args.decision),
                                        args.rationale).model_dump_json())
            elif args.session_action == "assess":
                assessment = research.assess(
                    args.session_id, event_sequence=args.event_sequence)
                print(assessment.model_dump_json())
                return 0 if assessment.passed else 1
            elif args.session_action == "turn":
                print(f"[relab] Taking one turn through {args.provider}",
                      file=sys.stderr, flush=True)
                taken = Conversation(args.workspace).turn(
                    args.session_id,
                    build_gateway(args.provider, args.model, args.endpoint,
                                  response_contract=multi_file_schema()),
                    max_steps=args.max_steps, attempts_per_slot=args.attempts,
                    parallel_arms=args.parallel_arms,
                    repair_context=args.repair_context,
                    model_timeout_seconds=args.model_timeout,
                    timeout_seconds=args.timeout,
                    advisor=None if args.advisor_model is None else LLMAmendmentAdvisor(
                        _advising(args.workspace, build_gateway(
                            args.provider, args.advisor_model, args.endpoint),
                            args.session_id),
                        timeout_seconds=args.model_timeout),
                    resolver=CommandLineResolver(args.endpoint),
                    advisor_from=lambda gateway, route: LLMAmendmentAdvisor(
                        _advising(args.workspace, gateway, args.session_id),
                        timeout_seconds=args.model_timeout,
                        declared_route=route))
                print(f"[relab] {taken.state.value}: {taken.detail}",
                      file=sys.stderr, flush=True)
                print(taken.model_dump_json())
                # A turn that left nothing to do is the one that is not work remaining.
                return 0 if taken.next.kind is NextActionKind.NONE else 1
            elif args.session_action == "advance":
                print(f"[relab] Driving the session through {args.provider}",
                      file=sys.stderr, flush=True)
                drive = SessionDriver(args.workspace).advance(
                    args.session_id,
                    build_gateway(args.provider, args.model, args.endpoint,
                                  response_contract=multi_file_schema()),
                    max_steps=args.max_steps, attempts_per_slot=args.attempts,
                    parallel_arms=args.parallel_arms,
                    repair_context=args.repair_context,
                    model_timeout_seconds=args.model_timeout,
                    timeout_seconds=args.timeout)
                print(drive.model_dump_json())
                return 0 if drive.settled else 1
            elif args.session_action == "holdout":
                held = research.evaluate_holdout(args.session_id)
                print(held.model_dump_json())
                return 0 if held.passed else 1
            elif args.session_action == "status":
                lifecycle = SessionLifecycleReader(args.workspace).status(
                    args.session_id, attempts_per_slot=args.attempts)
                command = NEXT_COMMAND[lifecycle.action]
                if lifecycle.action is LifecycleAction.EXECUTE:
                    command += f" --attempts {lifecycle.attempts_per_slot}"
                    command += f" --expected-session-sequence {lifecycle.event_sequence}"
                print(f"[relab] {lifecycle.phase.value}: {command}",
                      file=sys.stderr, flush=True)
                print(lifecycle.model_dump_json())
                return 0 if lifecycle.action is LifecycleAction.NONE else 1
            elif args.session_action == "next":
                advisor = None if args.model is None else LLMAmendmentAdvisor(
                    _advising(args.workspace, build_gateway(
                        args.provider, args.model, args.endpoint), args.session_id),
                    timeout_seconds=args.model_timeout)
                named = NextActions(args.workspace).decide(
                    args.session_id, attempts_per_slot=args.attempts, advisor=advisor,
                    resolver=CommandLineResolver(args.endpoint),
                    advisor_from=lambda gateway, route: LLMAmendmentAdvisor(
                        _advising(args.workspace, gateway, args.session_id),
                        timeout_seconds=args.model_timeout,
                        declared_route=route))
                print(f"[relab] {named.turn_state.value}: {named.detail}",
                      file=sys.stderr, flush=True)
                print(named.model_dump_json())
                # Nothing left to do is the one answer that is not work remaining.
                return 0 if named.kind is NextActionKind.NONE else 1
            elif args.session_action == "amend":
                next_actions = NextActions(args.workspace)
                amendment = ProposedAmendment.model_validate_json(
                    args.amendment.read_text(encoding="utf-8-sig"))
                current = research.store.latest(args.session_id).snapshot.plan
                if current is None:
                    raise ValueError("no research plan to amend; record one first")
                # Say what it moves before recording it, read from the plan on
                # record rather than from the document.
                weighed = next_actions.checked(current, amendment)
                print("[relab] Recording an amendment; it stays visible",
                      file=sys.stderr, flush=True)
                amended = next_actions.amend(args.session_id, weighed,
                                             expected_revision=args.expected_revision)
                if weighed.bars_acceptance:
                    print("[relab] This amendment bars acceptance of this session: "
                          + ", ".join(weighed.moves_deciding_rules),
                          file=sys.stderr, flush=True)
                print(amended.model_dump_json())
                return 1 if weighed.bars_acceptance else 0
            elif args.session_action == "failures":
                explained = RepairMemory(args.workspace).explain(args.session_id, args.arm)
                print(f"[relab] {explained.summary}", file=sys.stderr, flush=True)
                print(explained.model_dump_json())
                # Nothing failed is the one answer that is not work remaining.
                return 1 if explained.explains_anything else 0
            elif args.session_action == "interpret":
                read = SessionInterpreter(args.workspace).interpret(args.session_id)
                print(f"[relab] {read.reason}", file=sys.stderr, flush=True)
                print(read.model_dump_json())
                # Nothing to carry forward is a report saying so, not a failure.
                return 0 if read.carries_findings else 1
            elif args.session_action in {"diagnose", "recover"}:
                reconciler = SessionReconciler(args.workspace)
                reconciliation = (reconciler.diagnose(args.session_id)
                                  if args.session_action == "diagnose"
                                  else reconciler.recover(
                                      args.session_id,
                                      abandon_stalled=args.abandon_stalled))
                print(reconciliation.model_dump_json())
                return 0 if reconciliation.consistent else 1
            elif args.session_action == "readiness":
                coverage = research.readiness(
                    args.session_id, event_sequence=args.event_sequence)
                print(coverage.model_dump_json())
                return 0 if coverage.ready else 1
            elif args.session_action == "repeatability":
                # An omitted registry selects the plan pinned in the session snapshot.
                selected: MetricRegistry | None = None
                run_ids: list[str] = args.rest
                if not args.from_plan:
                    selected, run_ids = read_registry(Path(args.rest[0])), args.rest[1:]
                    if not run_ids:
                        raise ValueError("repeatability requires at least one explicit run ID")
                session_ranges = research.repeatability(args.session_id, run_ids, selected,
                    minimum_runs=args.minimum_runs, event_sequence=args.event_sequence)
                print(session_ranges.model_dump_json())
                return 0 if session_ranges.repeatability.passed else 1
            elif args.session_action == "compare":
                chosen = read_registry(args.registry) if args.registry is not None else None
                session_report = research.compare(args.session_id, args.candidate_id,
                    args.baseline_id, chosen, event_sequence=args.event_sequence)
                print(session_report.model_dump_json())
                return 0 if session_report.comparison.passed else 1
            elif args.session_action == "events":
                research.store.latest(args.session_id)
                print(json.dumps([item.model_dump(mode="json")
                                  for item in research.store.events(args.session_id)]))
            else:
                print(research.store.latest(args.session_id).snapshot.model_dump_json())
            return 0
        if args.command == "run":
            service = CodingRunService(args.workspace)
            if args.action == "create":
                snapshot = service.create(args.objective, args.request_id)
            elif args.action == "generate":
                targets = [args.target, *args.additional_target]
                label = "Ollama" if args.provider == "ollama" else args.provider
                print(f"[relab] Generating edit for {len(targets)} file(s) through {label}",
                      file=sys.stderr, flush=True)
                snapshot = service.generate_and_apply(
                    args.run_id, targets,
                    build_gateway(args.provider, args.model, args.endpoint,
                                  response_contract=multi_file_schema()
                                  if len(targets) > 1 else single_file_schema()),
                    verify_argv=args.verify, data_paths=args.data_path,
                    model_timeout_seconds=args.model_timeout, timeout_seconds=args.timeout,
                )
                print(snapshot.model_dump_json())
                return 0 if snapshot.state == RunState.COMPLETED else 1
            elif args.action == "apply":
                proposal = PatchProposal.model_validate_json(
                    args.proposal.read_text(encoding="utf-8-sig")
                )
                print(f"[relab] Executing patch for {args.run_id}", file=sys.stderr, flush=True)
                snapshot = service.apply(
                    args.run_id, proposal, verify_argv=args.verify,
                    timeout_seconds=args.timeout, data_paths=args.data_path,
                )
                print(f"[relab] Finished: {snapshot.state.value}", file=sys.stderr, flush=True)
                print(snapshot.model_dump_json())
                return 0 if snapshot.state == RunState.COMPLETED else 1
            elif args.action == "record":
                received = ReceivedCodingResult.model_validate_json(
                    args.result.read_text(encoding="utf-8-sig")
                )
                print("[relab] Recording supplied coding result", file=sys.stderr, flush=True)
                snapshot = service.record(args.run_id, received)
            elif args.action == "decide-dependency":
                decision = DependencyInstallDecision.model_validate_json(
                    args.decision.read_text(encoding="utf-8-sig")
                )
                print("[relab] Recording dependency decision; no installation", file=sys.stderr,
                      flush=True)
                snapshot = service.decide_dependency(args.run_id, decision)
            elif args.action == "resume-dependency":
                print("[relab] Resuming stored dependency patch", file=sys.stderr, flush=True)
                snapshot = service.resume_dependency(
                    args.run_id, verify_argv=args.verify, timeout_seconds=args.timeout,
                    data_paths=args.data_path,
                )
                print(snapshot.model_dump_json())
                return 0 if snapshot.state == RunState.COMPLETED else 1
            elif args.action == "install-dependency":
                policy = DependencyInstallPolicy.model_validate_json(
                    args.policy.read_text(encoding="utf-8-sig")
                )
                print("[relab] Installing approved dependency", file=sys.stderr, flush=True)
                snapshot = service.install_dependency(
                    args.run_id, policy, timeout_seconds=args.timeout,
                )
                print(snapshot.model_dump_json())
                return 0 if snapshot.state == RunState.DEPENDENCY_INSTALLED else 1
            elif args.action == "check-dependency":
                policy = DependencyInstallPolicy.model_validate_json(
                    args.policy.read_text(encoding="utf-8-sig")
                )
                print("[relab] Checking dependency target; no installation", file=sys.stderr,
                      flush=True)
                print(service.check_dependency(args.run_id, policy).model_dump_json())
                return 0
            elif args.action == "recover":
                print("[relab] Reconciling stored patch evidence", file=sys.stderr, flush=True)
                snapshot = service.recover(args.run_id)
            elif args.action == "repeatability":
                registry = MetricRegistry.model_validate_json(
                    args.registry.read_text(encoding="utf-8-sig")
                )
                print("[relab] Checking repeated-run metric ranges", file=sys.stderr, flush=True)
                report = service.repeatability(
                    args.run_ids, registry, minimum_runs=args.minimum_runs,
                )
                print(report.model_dump_json())
                return 0 if report.passed else 1
            elif args.action == "compare":
                registry = MetricRegistry.model_validate_json(
                    args.registry.read_text(encoding="utf-8-sig")
                )
                print("[relab] Comparing verified metrics", file=sys.stderr, flush=True)
                comparison = service.compare(args.candidate_id, args.baseline_id, registry)
                print(comparison.model_dump_json())
                return 0 if comparison.passed else 1
            elif args.action == "abandon-holdout":
                snapshot = service.abandon_holdout(
                    args.run_id, expected_sequence=args.expected_sequence,
                    reason=args.reason, worker_stopped=args.worker_stopped)
                print(snapshot.model_dump_json())
                return 0
            elif args.action == "restore":
                print("[relab] Undoing a verified edit; evidence is kept", file=sys.stderr,
                      flush=True)
                snapshot = service.restore(args.run_id, RestoreReason.ASKED_FOR)
            elif args.action == "review":
                print("[relab] Reviewing a change; nothing is recorded",
                      file=sys.stderr, flush=True)
                reviewed = PatchReviews(args.workspace).review(
                    args.run_id,
                    LLMPatchReviewer(
                        build_gateway(args.provider, args.model, args.endpoint,
                                      ),
                        timeout_seconds=args.model_timeout))
                if reviewed.unresolved_citations:
                    print(f"[relab] {reviewed.unresolved_citations} finding(s) pointed at "
                          "lines this change never added, and were dropped",
                          file=sys.stderr, flush=True)
                print(reviewed.model_dump_json())
                # A concern is something for a person to weigh, not a failure.
                return 1 if reviewed.concerned else 0
            elif args.action == "gates":
                print("[relab] Listing open human gates", file=sys.stderr, flush=True)
                print(service.pending_gates().model_dump_json())
                return 0
            elif args.action == "metrics":
                print("[relab] Reading metrics from verified stdout", file=sys.stderr, flush=True)
                print(service.metrics(args.run_id).model_dump_json())
                return 0
            elif args.action == "evaluate":
                print("[relab] Evaluating recorded coding evidence", file=sys.stderr, flush=True)
                print(service.evaluate(args.run_id).model_dump_json())
                return 0
            elif args.action == "events":
                service.store.load(args.run_id)
                print(json.dumps([event.model_dump(mode="json")
                                  for event in service.store.events(args.run_id)]))
                return 0
            elif args.action == "snapshot":
                print(service.recorded_content(
                    args.run_id, args.path, side=args.side).model_dump_json())
                return 0
            else:
                snapshot = service.store.load(args.run_id)
            print(snapshot.model_dump_json())
            return 0
        if args.command == "apply":
            if not args.verify:
                raise ValueError("--verify requires an executable and must be the last option")
            if not math.isfinite(args.timeout) or args.timeout <= 0:
                raise ValueError("--timeout must be a finite positive number")
            print("[relab] Reading and validating proposal", file=sys.stderr, flush=True)
            proposal = PatchProposal.model_validate_json(args.proposal.read_text(encoding="utf-8-sig"))
            print("[relab] Applying with mandatory verification", file=sys.stderr, flush=True)
            evidence = WorkspacePatchService().apply(
                args.workspace, proposal, verify_argv=args.verify, timeout_seconds=args.timeout
            )
            print(f"[relab] Finished: {evidence.status.value}", file=sys.stderr, flush=True)
            print(evidence.model_dump_json())
            return 0 if evidence.status == PatchStatus.APPLIED else 1
        if args.command == "targets":
            print("[relab] Ranking inspected files; no file is changed", file=sys.stderr,
                  flush=True)
            plan = propose_targets(CodingService().inspect(CodeInspectionRequest(
                path=args.path, max_files=args.max_files,
                max_symbol_bytes=args.max_symbol_bytes,
            )), args.objective, limit=args.limit)
            print(plan.model_dump_json())
            return 0 if plan.proposals else 1
        result = CodingService().inspect(CodeInspectionRequest(
            path=args.path, max_files=args.max_files, max_symbol_bytes=args.max_symbol_bytes
        ))
    except (ValueError, OSError, LookupError, sqlite3.Error) as error:
        print(refusal(error), file=sys.stderr)
        return 2
    print(result.model_dump_json())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
