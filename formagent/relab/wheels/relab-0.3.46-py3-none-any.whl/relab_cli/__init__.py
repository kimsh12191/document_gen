"""ReLab command-line application adapter."""
