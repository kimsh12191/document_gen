"""Images given to `relab chat` by their path, wherever they are (0.3.29).

Asked for in use: the backend shows a model the images a request names with
`@path`, but only inside the workspace, and a terminal has no picture to paste.
On a server reached by SSH, a picture is a file: uploaded, or dragged onto the
editor's terminal, which types its path. So a path to an image in what is typed
-- quoted, with spaces, `~`, absolute, outside the workspace -- or given with
`/image <path>` is copied where the editor keeps the pictures pasted into its
chat (the person's records, `attachments/`) and named `@relab-image:<name>`, as
the editor names them: the backend attaches it the same way. `@path` inside the
workspace is left as it is; the backend reads it there.

What will not reach the model is said before anything is sent: a picture past
the size the backend shows, or past the number it shows at once.
"""

from __future__ import annotations

import re
import secrets
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path

from relab_app.coding_loop import IMAGE_TYPES, MAXIMUM_IMAGE_BYTES, MAXIMUM_IMAGES
from relab_workspace.private_state import state_dir

# A word that may be a path: quoted (it may hold spaces), or up to the next space.
WORD = re.compile(r"""'([^']+)'|"([^"]+)"|(\S+)""")


@dataclass
class Attached:
    """What one message carries: the text to send, and what was said about its pictures."""

    text: str
    names: list[str] = field(default_factory=list)
    notes: list[tuple[str, dict[str, object]]] = field(default_factory=list)


def image_path(word: str, workspace: Path) -> Path | None:
    """The image file a typed word names, or None: a word that is not one is the person's words."""
    given = word.removeprefix("@")
    if given.startswith("relab-image:") or Path(given).suffix.lower() not in IMAGE_TYPES:
        return None
    path = Path(given.removeprefix("file://")).expanduser()
    if not path.is_absolute():
        path = workspace / path
    return path if path.is_file() else None


def inside(path: Path, workspace: Path) -> bool:
    try:
        path.resolve().relative_to(workspace.resolve())
    except ValueError:
        return False
    return True


def keep(path: Path, workspace: Path) -> str:
    """Copy a picture to the person's attachments, under a name of its own; the name."""
    folder = state_dir(workspace) / "attachments"
    folder.mkdir(parents=True, exist_ok=True)
    suffix = ".jpg" if path.suffix.lower() == ".jpeg" else path.suffix.lower()
    name = f"cli-{int(time.time() * 1000)}-{secrets.token_hex(3)}{suffix}"
    shutil.copyfile(path, folder / name)
    return name


def starts_with_image(text: str, workspace: Path) -> bool:
    """A message whose first word is a picture's path -- `/home/me/a.png what is this?` -- not a command."""
    found = WORD.match(text.strip())
    return found is not None and image_path(next(group for group in found.groups() if group), workspace) is not None


def attach(text: str, workspace: Path, queued: list[Path] | None = None) -> Attached:
    """`text` with each picture it names by a path outside the workspace kept and named, and those queued.

    A picture inside the workspace named with `@` is left for the backend; one
    named by a bare path there is named with `@` so the backend reads it.
    """
    result = Attached(text=text)
    pictures: list[tuple[str | None, Path]] = []
    for found in WORD.finditer(text):
        word = next(group for group in found.groups() if group)
        path = image_path(word, workspace)
        if path is not None:
            pictures.append((found.group(0), path))
    pictures += [(None, path) for path in queued or []]
    sent = 0
    for raw, path in pictures:
        size = path.stat().st_size
        if size > MAXIMUM_IMAGE_BYTES:
            result.notes.append(("imageTooLarge", {"path": str(path), "size": _size(size),
                                                   "most": _size(MAXIMUM_IMAGE_BYTES)}))
            continue
        if sent >= MAXIMUM_IMAGES:
            result.notes.append(("imageTooMany", {"path": str(path), "most": MAXIMUM_IMAGES}))
            continue
        sent += 1
        if raw is not None and inside(path, workspace):
            relative = path.resolve().relative_to(workspace.resolve()).as_posix()
            if " " not in relative:
                # The backend reads it where it is, as it reads any `@path`.
                result.text = result.text.replace(raw, f"@{relative}", 1)
                result.notes.append(("imageAttached", {"path": relative, "size": _size(size)}))
                continue
        name = keep(path, workspace)
        result.names.append(name)
        reference = f"@relab-image:{name}"
        result.text = (result.text.replace(raw, reference, 1) if raw is not None
                       else f"{result.text}\n{reference}")
        result.notes.append(("imageAttached", {"path": str(path), "size": _size(size)}))
    return result


def paths_given(rest: str) -> list[str]:
    """The paths after `/image`, quoted or not; a Windows path's backslashes kept."""
    return [next(group for group in found.groups() if group) for found in WORD.finditer(rest)]


def size_of(path: Path) -> str:
    return _size(path.stat().st_size)


def _size(count: int) -> str:
    return f"{count / 1024 / 1024:.1f} MB" if count >= 1024 * 1024 else f"{max(1, count // 1024)} KB"
