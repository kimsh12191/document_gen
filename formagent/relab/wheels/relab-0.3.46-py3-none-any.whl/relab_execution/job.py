"""A job: a program that goes on after whoever started it has ended (P5).

A background process is stopped with the run that started it: on Windows it
is in a job object that dies with the CLI, elsewhere the run stops it in a
`finally`. Training a model for a day outlives any run, so a job is started
apart -- its own session, no kill-on-close job -- under this small runner,
which waits for it and writes its exit code to a file. A later run, in
another process, reads the log as it grew and the exit file when there is one:
nothing of the job is held in memory.

    python -m relab_execution.job EXIT_FILE -- PROGRAM ARGUMENT...

The program's output goes where the runner's does: the log it was started with.
"""

import os
import subprocess
import sys
from pathlib import Path

from relab_core.coding.sandbox import SandboxPolicy, SandboxRequest
from relab_execution.sandbox import _bounded_workspace, _safe_environment

# Windows: a new process group, a console of its own that is never shown, and out of
# the starting process's job. A console it lacked altogether (DETACHED_PROCESS) gave
# every console program it started a new window: a test run opened dozens (0.2.82).
_NO_WINDOW = 0x08000000
_DETACHED = 0x00000200 | _NO_WINDOW
_BREAKAWAY = 0x01000000
# What the runner starts shares its hidden console; said, should it ever have none.
_CHILD_FLAGS = _NO_WINDOW if sys.platform == "win32" else 0


def start_job(argv: list[str], *, workspace: Path, log: Path, exit_file: Path,
              policy: SandboxPolicy, environment: dict[str, str] | None = None,
              out_file: Path | None = None, err_file: Path | None = None) -> int:
    """Start `argv` as a job in the workspace, output to `log`; its runner's pid.

    With `out_file` and `err_file`, what it prints to each is also kept apart in
    them (0.2.70): a command started this way reads as one run the usual way --
    its stdout and stderr -- and, past its time, goes on as a job.
    """
    if not argv or not all(argv):
        raise ValueError("a job needs a command")
    _root, cwd = _bounded_workspace(workspace, ".")
    given = dict(environment or {})
    policy = policy.model_copy(update={"environment_allowlist": [
        *policy.environment_allowlist, *(name for name in given
                                         if name not in policy.environment_allowlist)]})
    safe = _safe_environment(
        SandboxRequest(id="job", argv=argv, timeout_seconds=1.0, environment=given), policy)
    log.parent.mkdir(parents=True, exist_ok=True)
    exit_file.parent.mkdir(parents=True, exist_ok=True)
    exit_file.unlink(missing_ok=True)
    # The runner is this Python, where this package is installed; the program it
    # runs gets the environment unchanged -- no path of ReLab's own.
    apart = [] if out_file is None or err_file is None else [
        "--out", str(out_file), "--err", str(err_file)]
    command = [sys.executable, "-m", "relab_execution.job", str(exit_file), *apart, "--", *argv]
    # Appended: a command started this way has its first line, the command, written already.
    with log.open("ab") as output:
        if sys.platform == "win32":
            try:
                process = subprocess.Popen(
                    command, cwd=cwd, env=safe, stdin=subprocess.DEVNULL, stdout=output,
                    stderr=subprocess.STDOUT, creationflags=_DETACHED | _BREAKAWAY)
            except OSError:
                # A job that does not allow breaking away: started inside it.
                process = subprocess.Popen(
                    command, cwd=cwd, env=safe, stdin=subprocess.DEVNULL, stdout=output,
                    stderr=subprocess.STDOUT, creationflags=_DETACHED)
        else:
            process = subprocess.Popen(
                command, cwd=cwd, env=safe, stdin=subprocess.DEVNULL, stdout=output,
                stderr=subprocess.STDOUT, start_new_session=True)
    return process.pid


def alive(pid: int) -> bool:
    """Whether a process with this pid runs; a pid may be reused, so a job's exit file
    is asked first, and this only when there is none."""
    if sys.platform == "win32":
        import ctypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        try:
            code = ctypes.c_ulong()
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(code)):
                return False
            return code.value == 259  # STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    # A child of this process that ended and was not waited for is a zombie.
    try:
        reaped, _ = os.waitpid(pid, os.WNOHANG)
    except ChildProcessError:
        return True
    return reaped == 0


def exit_code(exit_file: Path) -> int | None:
    """The job's exit code, once its runner wrote it."""
    try:
        return int(exit_file.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _apart(program: list[str], out_file: Path, err_file: Path) -> int:
    """Run `program`, its stdout and stderr each kept in its own file and both in this
    runner's own output, the log, as they come."""
    import threading

    process = subprocess.Popen(program, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, creationflags=_CHILD_FLAGS)
    lock = threading.Lock()
    log = sys.stdout.buffer

    def copy(stream: "object", path: Path) -> None:
        with path.open("ab") as kept:
            for chunk in iter(stream.readline, b""):  # type: ignore[attr-defined]
                kept.write(chunk)
                kept.flush()
                with lock:
                    log.write(chunk)
                    log.flush()

    threads = [threading.Thread(target=copy, args=(process.stdout, out_file)),
               threading.Thread(target=copy, args=(process.stderr, err_file))]
    for thread in threads:
        thread.start()
    code = process.wait()
    for thread in threads:
        thread.join()
    return code


def main(argv: list[str]) -> int:
    given = list(argv)
    out_file = err_file = None
    if len(given) >= 6 and given[1] == "--out" and given[3] == "--err":
        out_file, err_file = Path(given[2]), Path(given[4])
        given = [given[0], *given[5:]]
    if len(given) < 3 or given[1] != "--":
        print("usage: python -m relab_execution.job EXIT_FILE [--out FILE --err FILE] -- PROGRAM ...",
              file=sys.stderr)
        return 2
    exit_file = Path(given[0])
    try:
        code = (subprocess.call(given[2:], stdin=subprocess.DEVNULL, creationflags=_CHILD_FLAGS)
                if out_file is None or err_file is None
                else _apart(given[2:], out_file, err_file))
    except OSError as error:
        print(f"{given[2]!r} could not be started: {error}", file=sys.stderr, flush=True)
        code = 127
    temporary = exit_file.with_suffix(".tmp")
    temporary.write_text(str(code), encoding="utf-8")
    temporary.replace(exit_file)
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
