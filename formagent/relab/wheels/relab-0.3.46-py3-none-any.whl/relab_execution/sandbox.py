"""Policy-enforced process and container sandbox adapters (doc/ROADMAP.md v0.6).

`verify_argv` in `autocode/core/patcher.py` runs through here from this
gate on, instead of a raw `subprocess.run` call. See
`autocode/schema/sandbox.py`'s module docstring for the real secret-leak
bug this closes, independently, at this layer too.
"""

import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Protocol

from relab_core.coding.sandbox import (
    NetworkPolicy,
    SandboxBackend,
    SandboxPolicy,
    SandboxRequest,
    SandboxResult,
    SandboxStatus,
    is_secret_environment_name,
)
from relab_execution.output_text import output_text

_POLL_INTERVAL_SECONDS = 0.1


def _text(data: bytes) -> str:
    """What a verifier printed, as text mode read it: in its encoding, with its newlines."""
    return output_text(data).replace("\r\n", "\n").replace("\r", "\n")


# After the tree is killed, a surviving descendant must not hold the run open forever.
_TERMINATION_TIMEOUT_SECONDS = 5.0

# None of these are secret-shaped (see SECRET_NAME_PATTERN) -- they are the
# baseline a subprocess needs to function at all on its HOST OS. Without
# them (an entirely empty environment), Windows subprocesses that import
# `asyncio` fail hard: `_overlapped`'s Winsock initialization needs
# `SystemRoot` and raises `OSError: [WinError 10106]` on every attempt,
# regardless of what the verify command actually does -- no repair loop
# can fix that by rewriting the target code.
#
# Deliberately NOT applied to the Docker backend: a container brings its
# own environment, and forwarding a Windows host's `PATH`/`ComSpec` into a
# Linux image breaks it rather than helping.
LOCAL_VERIFY_ENV_ALLOWLIST = [
    "PATH",
    # Set when a command runs with a virtual environment activated (0.2.21).
    "VIRTUAL_ENV",
    "SystemRoot",
    "SYSTEMROOT",
    "windir",
    "WINDIR",
    "ComSpec",
    "TEMP",
    "TMP",
    "HOME",
    "LANG",
]


class SandboxPolicyError(ValueError):
    pass


def build_sandbox_policy(
    *,
    backend: SandboxBackend = SandboxBackend.LOCAL_PROCESS,
    network: NetworkPolicy | None = None,
    docker_image: str | None = None,
) -> SandboxPolicy:
    """The single place a verification `SandboxPolicy` is constructed.

    `network=None` means "the safest option this backend can actually
    enforce": `DENY` under Docker, where it is real, and `INHERIT` under
    local process, where `LocalProcessSandbox` would otherwise (correctly)
    refuse the whole request -- it cannot guarantee network denial and
    says so rather than pretending. That asymmetry is the honest default,
    and it is why `SandboxPolicy`'s own schema default stays fail-closed
    at `DENY` while local runs pass `INHERIT` explicitly.
    """

    if network is None:
        network = (
            NetworkPolicy.DENY if backend is SandboxBackend.DOCKER else NetworkPolicy.INHERIT
        )
    allowlist = (
        [] if backend is SandboxBackend.DOCKER else list(LOCAL_VERIFY_ENV_ALLOWLIST)
    )
    return SandboxPolicy(
        backend=backend,
        network=network,
        environment_allowlist=allowlist,
        docker_image=docker_image,
    )


class Sandbox(Protocol):
    def run(
        self, request: SandboxRequest, *, policy: SandboxPolicy, workspace: Path
    ) -> SandboxResult: ...


class CancellationToken:
    """Thread-safe cooperative cancellation boundary."""

    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()


class LocalProcessSandbox:
    def run(
        self,
        request: SandboxRequest,
        *,
        policy: SandboxPolicy,
        workspace: Path,
        cancellation: CancellationToken | None = None,
        live_log: Path | None = None,
    ) -> SandboxResult:
        if policy.backend is not SandboxBackend.LOCAL_PROCESS:
            raise SandboxPolicyError("local sandbox requires backend=local_process")
        if policy.network is NetworkPolicy.DENY:
            return _rejected(
                request, policy.backend, "local process cannot guarantee network denial; use Docker"
            )
        if cancellation is not None and cancellation.cancelled:
            return SandboxResult(
                request_id=request.id, backend=policy.backend, status=SandboxStatus.CANCELLED
            )

        # No recovery directory is created here any more. One used to be
        # (`.autocode/sandbox-recovery/<id>`): created before the run,
        # deleted after it, and **never written to or read by anything** in
        # the package -- a whole mechanism's worth of schema
        # (`recovery_id`, `cleaned_up`, `SandboxPolicy.cleanup`,
        # `RECOVERY_ID_PATTERN`) resting on an empty directory. Removed
        # before 1.0 rather than frozen. It also removed a real hazard: that
        # `mkdir` was one of the routes by which an exception could escape
        # `Patcher._verify()` and leave a patch applied but un-reverted.
        _root, cwd = _bounded_workspace(workspace, request.cwd)
        environment = _safe_environment(request, policy)

        if live_log is None:
            exit_code, stdout, stderr, timed_out, cancelled = _run_polling(
                request.argv, cwd, environment, request.timeout_seconds, cancellation
            )
        else:
            exit_code, stdout, stderr, timed_out, cancelled = _run_live(
                request.argv, cwd, environment, request.timeout_seconds, cancellation, live_log
            )

        if cancelled:
            status = SandboxStatus.CANCELLED
        elif timed_out:
            status = SandboxStatus.TIMED_OUT
        elif exit_code != 0:
            status = SandboxStatus.FAILED
        else:
            status = SandboxStatus.SUCCEEDED

        return SandboxResult(
            request_id=request.id,
            backend=policy.backend,
            status=status,
            exit_code=exit_code,
            stdout=stdout,
            stderr=stderr,
        )


class DockerSandbox:
    def run(
        self, request: SandboxRequest, *, policy: SandboxPolicy, workspace: Path
    ) -> SandboxResult:
        if policy.backend is not SandboxBackend.DOCKER or not policy.docker_image:
            raise SandboxPolicyError("Docker sandbox requires backend=docker and docker_image")
        root, _ = _bounded_workspace(workspace, request.cwd)
        environment = _safe_environment(request, policy)

        argv = ["docker", "run", "--rm"]
        if policy.network is NetworkPolicy.DENY:
            argv += ["--network", "none"]
        argv += [
            "--mount",
            f"type=bind,src={root},dst=/workspace",
            "--workdir",
            f"/workspace/{request.cwd}",
        ]
        for name, value in environment.items():
            argv += ["--env", f"{name}={value}"]
        argv += [policy.docker_image, *request.argv]

        exit_code, stdout, stderr, timed_out, _cancelled = _run_polling(
            argv, root, None, request.timeout_seconds, None
        )
        status = (
            SandboxStatus.TIMED_OUT
            if timed_out
            else SandboxStatus.SUCCEEDED
            if exit_code == 0
            else SandboxStatus.FAILED
        )
        return SandboxResult(
            request_id=request.id,
            backend=policy.backend,
            status=status,
            exit_code=exit_code,
            stdout=stdout,
            stderr=stderr,
        )


def _run_polling(
    argv: list[str],
    cwd: Path,
    env: dict[str, str] | None,
    timeout_seconds: float,
    cancellation: CancellationToken | None,
) -> tuple[int | None, str, str, bool, bool]:
    """Run `argv`, polling so a `CancellationToken` can kill it mid-flight
    rather than only being checked before the process starts."""

    try:
        process = subprocess.Popen(
            argv,
            cwd=cwd,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            # Bytes: what it printed is read in the encoding it printed it in (`output_text`).
            # Give the verifier its own POSIX session so its descendants can be
            # signalled as one group. Windows rejects the flag and has no
            # equivalent at spawn time; _terminate walks the tree there instead.
            start_new_session=sys.platform != "win32",
        )
    except OSError as error:
        # Found live: an unspawnable argv[0] (e.g. a bad verify-command
        # path) used to raise straight out of here, unwinding through
        # LocalProcessSandbox.run() and Patcher._verify() before
        # Patcher.apply() ever reached its own revert-on-failure branch --
        # an already-applied patch was left on disk, un-reverted, with no
        # PatchEvidence recorded at all (AGENTS.md rule 3/5: every
        # mutation must be verified and every attempt auditable). A
        # failed-to-start process is exactly as much a verification
        # failure as a nonzero exit code -- report it as one instead of
        # raising, so the caller's normal revert path always runs.
        return None, "", f"failed to start process: {error}", False, False
    started = time.monotonic()
    while True:
        try:
            out, err = process.communicate(timeout=_POLL_INTERVAL_SECONDS)
            return process.returncode, _text(out), _text(err), False, False
        except subprocess.TimeoutExpired:
            pass
        if cancellation is not None and cancellation.cancelled:
            stdout, stderr = _terminate(process)
            return None, stdout, stderr, False, True
        if time.monotonic() - started > timeout_seconds:
            stdout, stderr = _terminate(process)
            return None, stdout, stderr, True, False


def _run_live(
    argv: list[str],
    cwd: Path,
    env: dict[str, str] | None,
    timeout_seconds: float,
    cancellation: CancellationToken | None,
    live_log: Path,
) -> tuple[int | None, str, str, bool, bool]:
    """`_run_polling`, with what the program prints also appended to `live_log` as it
    comes (0.2.66): a person watching a long run sees it move, as in a terminal.

    The result is the same -- stdout and stderr kept apart, whole -- and the log
    is a copy for watching: nothing reads it back to decide anything.
    """
    try:
        process = subprocess.Popen(
            argv, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            start_new_session=sys.platform != "win32",
        )
    except OSError as error:
        return None, "", f"failed to start process: {error}", False, False
    lock = threading.Lock()
    kept: dict[str, list[str]] = {"out": [], "err": []}
    with live_log.open("a", encoding="utf-8") as log:

        def pump(stream: "object", name: str) -> None:
            for raw in iter(stream.readline, b""):  # type: ignore[attr-defined]
                # A line at a time: no character of UTF-8 or CP949 spans a line's end.
                line = _text(raw)
                kept[name].append(line)
                with lock:
                    log.write(line)
                    log.flush()

        readers = [threading.Thread(target=pump, args=(process.stdout, "out"), daemon=True),
                   threading.Thread(target=pump, args=(process.stderr, "err"), daemon=True)]
        for reader in readers:
            reader.start()
        started = time.monotonic()
        timed_out = cancelled = False
        while True:
            try:
                process.wait(timeout=_POLL_INTERVAL_SECONDS)
                break
            except subprocess.TimeoutExpired:
                pass
            if cancellation is not None and cancellation.cancelled:
                cancelled = True
            elif time.monotonic() - started > timeout_seconds:
                timed_out = True
            if cancelled or timed_out:
                _kill_tree(process)
                break
        for reader in readers:
            reader.join(timeout=_TERMINATION_TIMEOUT_SECONDS)
        if any(reader.is_alive() for reader in readers):
            kept["err"].append("verifier output was abandoned: a descendant process survived termination")
    code = None if cancelled or timed_out else process.returncode
    return code, "".join(kept["out"]), "".join(kept["err"]), timed_out, cancelled


def _kill_tree(process: "subprocess.Popen[bytes]") -> None:
    """Kill a started program and what it started, as far as this platform allows."""
    if sys.platform == "win32":
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(process.pid)],
                       capture_output=True, check=False)
    else:
        try:
            group = os.getpgid(process.pid)
            if group == process.pid and group != os.getpgid(0):
                os.killpg(group, signal.SIGKILL)
        except (OSError, ProcessLookupError):
            pass
    process.kill()


def _terminate(process: "subprocess.Popen[bytes]") -> tuple[str, str]:
    """Kill the verifier and what it started, then collect output without hanging.

    A verifier that spawns children used to leave them running after a timeout:
    they could keep writing to the workspace after the patch was reverted, and a
    descendant holding the output pipes could block collection indefinitely.
    Neither backend can guarantee the kill — a descendant that re-parents itself,
    detaches, or is not killable by this user can still survive — so this narrows
    the window rather than isolating the workspace.
    """
    if sys.platform == "win32":
        # taskkill walks the tree by parent process id at kill time.
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(process.pid)],
                       capture_output=True, check=False)
    else:
        try:
            # Its own group, as it was started with one; never this process's.
            group = os.getpgid(process.pid)
            if group == process.pid and group != os.getpgid(0):
                os.killpg(group, signal.SIGKILL)
        except (OSError, ProcessLookupError):
            # The group is already gone, or this user may not signal it.
            pass
    process.kill()
    try:
        stdout, stderr = process.communicate(timeout=_TERMINATION_TIMEOUT_SECONDS)
        return _text(stdout), _text(stderr)
    except subprocess.TimeoutExpired:
        # A survivor still holds the pipes; report that instead of blocking the run.
        return "", "verifier output was abandoned: a descendant process survived termination"


def _bounded_workspace(workspace: Path, relative: str) -> tuple[Path, Path]:
    root = workspace.resolve(strict=True)
    cwd = (root / relative).resolve(strict=True)
    if cwd != root and root not in cwd.parents:
        raise SandboxPolicyError("sandbox cwd escapes workspace boundary")
    return root, cwd


def _safe_environment(request: SandboxRequest, policy: SandboxPolicy) -> dict[str, str]:
    forbidden = set(policy.secret_names)
    # Check every allowlisted name, not only ones present in this request:
    # the fallback-to-host-env branch below sources a value for ANY
    # allowlisted name, whether or not the request supplied one, so the
    # secret check must cover that whole surface, not just the request's.
    for name in policy.environment_allowlist:
        if name in forbidden or is_secret_environment_name(name):
            raise SandboxPolicyError(f"secret environment variable is forbidden: {name}")
    for name in request.environment:
        if name not in policy.environment_allowlist:
            raise SandboxPolicyError(f"environment variable is not allowlisted: {name}")

    environment: dict[str, str] = {}
    for name in policy.environment_allowlist:
        if name in request.environment:
            environment[name] = request.environment[name]
        elif name in os.environ:
            environment[name] = os.environ[name]
    return environment


def _rejected(request: SandboxRequest, backend: SandboxBackend, reason: str) -> SandboxResult:
    return SandboxResult(
        request_id=request.id, backend=backend, status=SandboxStatus.REJECTED, error=reason
    )
