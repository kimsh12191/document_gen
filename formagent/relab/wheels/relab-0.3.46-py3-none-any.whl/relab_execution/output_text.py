"""What a program printed, as text, in the encoding it printed it in (0.3.24).

Found in a real record (text2sql, 10/26): on Korean Windows a Python program
writes to a pipe in the system's encoding, CP949, and every command's output
was read as UTF-8 -- each Korean line came back as replacement characters, in
what the model saw and in the lessons kept from it. UTF-8 is tried first, as
most programs print it; output that is not UTF-8 is read in the system's
encoding. On a system whose encoding is UTF-8 nothing changes.
"""

import codecs
import locale

# A UTF-8 character is at most four bytes: a read that starts or stops inside one cuts fewer.
_UTF8_CUT = 3


def output_text(data: bytes) -> str:
    """`data` as UTF-8 if it is UTF-8, else in the system's encoding.

    A read from the middle of a log can start or stop inside a character; that
    character is left out rather than taken for another encoding.
    """
    lead = 0
    while lead < min(_UTF8_CUT, len(data)) and data[lead] & 0xC0 == 0x80:
        lead += 1
    try:
        # Not final: a character cut at the end is held back, not an error.
        return codecs.getincrementaldecoder("utf-8")().decode(data[lead:], final=False)
    except UnicodeDecodeError:
        pass
    try:
        return data.decode(locale.getpreferredencoding(False), errors="replace")
    except LookupError:
        return data.decode("utf-8", errors="replace")
