"""A program that keeps running while something else goes on: a dev server, a watcher.

A sandboxed run waits for its command to end, which a server never does. This
starts one under the same rules -- an argument list, the workspace as its
directory, an allowlisted environment with no secret in it -- and writes what
it prints, stdout and stderr together, to a log file that can be read as it
grows. It stops the process and everything it started when asked, and when
the program that started it goes away:

- on Windows the process is put in a job object that kills its members when
  the last handle to it closes, which is when this process ends, however it
  ends -- a stop button that kills the CLI kills the dev server with it;
- elsewhere it gets its own session, so its group is signalled as one, and
  whoever started it stops it in a `finally`; `kill_tree` is there for a pid
  recorded by a process that did not get to.

Neither can promise a descendant that detaches itself is gone.
"""

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from relab_core.coding.sandbox import SandboxPolicy, SandboxRequest
from relab_execution.output_text import output_text
from relab_execution.sandbox import _bounded_workspace, _safe_environment

_POLL_SECONDS = 0.1
# Once something has been printed, this long without more is taken as the
# program having said what it says on starting.
_QUIET_SECONDS = 1.5


class BackgroundProcess:
    """One started program, its output in `log`, read from where it was last read."""

    def __init__(self, argv: list[str], *, workspace: Path, log: Path,
                 policy: SandboxPolicy, environment: dict[str, str] | None = None) -> None:
        if not argv or not all(argv):
            raise ValueError("a background process needs a command")
        _root, cwd = _bounded_workspace(workspace, ".")
        given = dict(environment or {})
        policy = policy.model_copy(update={"environment_allowlist": [
            *policy.environment_allowlist, *(name for name in given
                                             if name not in policy.environment_allowlist)]})
        environment = _safe_environment(
            SandboxRequest(id="background", argv=argv, timeout_seconds=1.0, environment=given),
            policy)
        log.parent.mkdir(parents=True, exist_ok=True)
        self.log = log
        self._read = 0
        # A statement, not an expression: mypy checks only this platform's branch.
        flags = 0
        if sys.platform == "win32":
            flags = subprocess.CREATE_NEW_PROCESS_GROUP
        with log.open("wb") as output:
            self._process = subprocess.Popen(
                argv, cwd=cwd, env=environment, stdin=subprocess.DEVNULL,
                stdout=output, stderr=subprocess.STDOUT,
                start_new_session=sys.platform != "win32",
                creationflags=flags)
        if sys.platform == "win32":
            _join_job(self._process)

    @property
    def pid(self) -> int:
        return self._process.pid

    def exit_code(self) -> int | None:
        """None while it runs."""
        return self._process.poll()

    def wait(self, seconds: float) -> None:
        """Wait up to `seconds`: until it ends, or has printed and then gone quiet."""
        deadline = time.monotonic() + seconds
        seen, quiet_since = self._size(), time.monotonic()
        while time.monotonic() < deadline and self.exit_code() is None:
            time.sleep(_POLL_SECONDS)
            size = self._size()
            if size != seen:
                seen, quiet_since = size, time.monotonic()
            elif size > self._read and time.monotonic() - quiet_since >= _QUIET_SECONDS:
                return

    def new_output(self, limit: int) -> tuple[str, bool]:
        """What it printed since the last read, at most its last `limit` characters.

        The second value says whether earlier output was left out to fit.
        """
        try:
            with self.log.open("rb") as handle:
                handle.seek(self._read)
                data = handle.read()
        except OSError:
            return "", False
        self._read += len(data)
        text = output_text(data)
        return (text, False) if len(text) <= limit else (text[-limit:], True)

    def stop(self) -> None:
        """Stop it and what it started; quietly, when it has already ended."""
        if self.exit_code() is None:
            kill_tree(self.pid)
        try:
            self._process.wait(timeout=5.0)
        except subprocess.TimeoutExpired:
            self._process.kill()

    def _size(self) -> int:
        try:
            return self.log.stat().st_size
        except OSError:
            return 0


def kill_tree(pid: int) -> None:
    """Kill a process and its descendants, by pid; nothing happens if it is gone.

    On POSIX a whole process group is killed only when `pid` leads one of its
    own -- as every program `start_background` starts does -- and never the
    group this process is in. Any other pid is killed alone: a pid read from a
    record may by now belong to something else, and its group was once this
    test run's own, runner and all (CI lost every log of the shard it was in).
    """
    if sys.platform == "win32":
        # taskkill walks the tree by parent process id at kill time.
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                       capture_output=True, check=False)
        return
    try:
        group = os.getpgid(pid)
        if group == pid and group != os.getpgid(0):
            os.killpg(group, signal.SIGKILL)
        else:
            os.kill(pid, signal.SIGKILL)
    except (OSError, ProcessLookupError):
        pass


# One job for every background process this process starts; the handle is
# never closed by hand, so it closes -- and the job's members die -- when this
# process exits.
_JOB: int | None = None


def _join_job(process: "subprocess.Popen[bytes]") -> None:
    """Put a process in the kill-on-close job; best effort, as a missing API is not a reason to fail."""
    global _JOB
    if sys.platform != "win32":
        return
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        if _JOB is None:
            # A handle, not an int: the default return type would cut it to 32 bits.
            kernel32.CreateJobObjectW.restype = wintypes.HANDLE
            kernel32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
            job = kernel32.CreateJobObjectW(None, None)
            if not job:
                return

            class IoCounters(ctypes.Structure):
                _fields_ = [(name, ctypes.c_ulonglong) for name in (
                    "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                    "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]

            class BasicLimits(ctypes.Structure):
                _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64),
                            ("PerJobUserTimeLimit", ctypes.c_int64),
                            ("LimitFlags", wintypes.DWORD),
                            ("MinimumWorkingSetSize", ctypes.c_size_t),
                            ("MaximumWorkingSetSize", ctypes.c_size_t),
                            ("ActiveProcessLimit", wintypes.DWORD),
                            ("Affinity", ctypes.c_size_t),
                            ("PriorityClass", wintypes.DWORD),
                            ("SchedulingClass", wintypes.DWORD)]

            class ExtendedLimits(ctypes.Structure):
                _fields_ = [("BasicLimitInformation", BasicLimits),
                            ("IoInfo", IoCounters),
                            ("ProcessMemoryLimit", ctypes.c_size_t),
                            ("JobMemoryLimit", ctypes.c_size_t),
                            ("PeakProcessMemoryUsed", ctypes.c_size_t),
                            ("PeakJobMemoryUsed", ctypes.c_size_t)]

            limits = ExtendedLimits()
            limits.BasicLimitInformation.LimitFlags = 0x2000  # KILL_ON_JOB_CLOSE
            kernel32.SetInformationJobObject.argtypes = [
                wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
            if not kernel32.SetInformationJobObject(job, 9, ctypes.byref(limits),
                                                    ctypes.sizeof(limits)):
                kernel32.CloseHandle(job)
                return
            _JOB = job
        kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        kernel32.AssignProcessToJobObject(_JOB, int(process._handle))  # type: ignore[attr-defined,unused-ignore]
    except (OSError, AttributeError, ValueError):
        return
