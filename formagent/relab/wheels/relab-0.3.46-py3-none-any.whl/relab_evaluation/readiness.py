"""Coverage of a pre-registered design by pinned evidence; not a research verdict."""

from relab_core.evaluation import EvaluationVerdict
from relab_core.measurement import ownership_of
from relab_core.research import (
    CodingRunReference,
    ResearchArmReadiness,
    ResearchPlan,
    ResearchRunReadiness,
    ResearchSessionReadiness,
)
from relab_core.runs import RunEvent
from relab_evaluation.coding import evaluate_coding
from relab_evaluation.measurement import read_measurement
from relab_evaluation.metrics import extract_coding_metrics


def _classify(
    plan: ResearchPlan, reference: CodingRunReference, event: RunEvent,
) -> ResearchRunReadiness:
    """Report why evidence cannot serve the plan instead of failing the whole report."""
    report = ResearchRunReadiness(
        run_id=reference.run_id, event_sequence=event.sequence, role=reference.role,
        usable=False, reason="",
    )
    # The measurement is asked before the arm is judged, whatever the exit. A
    # live session's verifier could not import its own reference data, printed
    # `correctness_rate=0.0`, reported zero checks and exited 1 -- and because
    # the contract was read only for verifications that passed, six attempts
    # were recorded as the arm's code failing and the budget spent on a ruler
    # that measured nothing.
    #
    # A managed verifier that wrote no report breaks the same contract, and is
    # stopped on for the reason it cannot be read: it cannot say whether the
    # arm was wrong or the ruler broke. A ruler that dies on an arm's
    # unimportable file instead of reporting the failure would measure the
    # next five arms no better. What a non-zero exit is not, by itself, is a
    # breach: a ruler that ran its checks and found the implementation wrong
    # measured exactly what it should, and that stays the arm's failure.
    #
    # No verification at all -- a patch that never applied, a generation that
    # never finished -- never reached the measurement, and is left to the
    # coding verdict below.
    evidence = event.snapshot.patch_evidence
    failed = None if evidence is None else evidence.verification
    if failed is not None and not failed.passed:
        reading = read_measurement(
            failed, ownership=ownership_of(plan.measurement),
            required_subjects=list(event.snapshot.generation_targets))
        if reading.invalidity is not None:
            report.measurement = reading
            report.reason = f"{reading.invalidity.value}: {reading.reason}"
            return report
    evaluation = evaluate_coding(event)
    if evaluation.verdict != EvaluationVerdict.VERIFIED:
        report.reason = f"{evaluation.verdict.value}: {evaluation.reason}"
        return report
    mismatch = _model_mismatch(plan, event)
    if mismatch is not None:
        report.reason = mismatch
        return report
    # Asked before the metrics are read, because an invalid measurement means
    # there is no number to read rather than a number that came out badly. A
    # live session printed `pass_rate=0.0` from a verifier that executed no
    # check, and reading it first is how that became a score the arm had earned.
    evidence = event.snapshot.patch_evidence
    assert evidence is not None  # `evaluate_coding` verified it above.
    report.measurement = read_measurement(
        evidence.verification, ownership=ownership_of(plan.measurement),
        required_subjects=list(event.snapshot.generation_targets))
    invalidity = report.measurement.invalidity
    if invalidity is not None:
        report.reason = f"{invalidity.value}: {report.measurement.reason}"
        return report
    try:
        measured = extract_coding_metrics(event)
    except ValueError as error:
        # Unusable metric output is a coverage gap here, not an input error.
        report.reason = str(error)
        return report
    absent = [rule.name for rule in plan.registry.rules if rule.name not in measured.metrics]
    if absent:
        report.reason = f"pinned evidence lacks planned metrics: {', '.join(absent)}"
        return report
    report.usable = True
    report.reason = "verified evidence reports every planned metric"
    return report


def _model_mismatch(plan: ResearchPlan, event: RunEvent) -> str | None:
    """Evidence from an undeclared model cannot serve a plan that names one."""
    expected = plan.expected_model
    if expected is None:
        return None
    identity = event.snapshot.generation_model
    if identity is None:
        return "pinned evidence records no model identity, and the plan declares one"
    if identity != expected:
        return (f"evidence came from {identity.provider}/{identity.model}, not the declared "
                f"{expected.provider}/{expected.model}")
    declared = plan.expected_reported_model
    reported = event.snapshot.generation_reported_model
    if declared is not None and reported != declared:
        return f"the provider reported {reported!r}, not the declared {declared!r}"
    return None


def assess_readiness(
    session_id: str, event_sequence: int, plan: ResearchPlan,
    pinned: list[tuple[CodingRunReference, RunEvent]],
) -> ResearchSessionReadiness:
    if not plan.arms:
        raise ValueError("the recorded research plan declares no experiment arms")
    undeclared = {reference.role for reference, _ in pinned
                   if reference.role is not None} - set(plan.arms)
    if undeclared:
        # Attachment rejects unknown roles, so a stored one means damaged history.
        raise ValueError(f"pinned roles are not declared by the plan: {sorted(undeclared)}")
    classified = [(reference, _classify(plan, reference, event)) for reference, event in pinned]
    arms = []
    for arm in plan.arms:
        runs = [report for reference, report in classified if reference.role == arm]
        usable = sum(1 for report in runs if report.usable)
        arms.append(ResearchArmReadiness(
            arm=arm, required=plan.repeats_per_arm, usable=usable,
            missing=max(0, plan.repeats_per_arm - usable),
            satisfied=usable >= plan.repeats_per_arm, runs=runs,
        ))
    return ResearchSessionReadiness(
        session_id=session_id, event_sequence=event_sequence, plan=plan, arms=arms,
        unassigned=[report for reference, report in classified if reference.role is None],
        ready=all(arm.satisfied for arm in arms),
    )
