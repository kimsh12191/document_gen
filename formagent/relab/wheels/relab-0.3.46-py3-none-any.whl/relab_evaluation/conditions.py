"""Whether runs shared the conditions that must not vary between them.

Code is excluded from the requirement by default, and for a reason: arms differ in
code by design, and a verified patch is not reverted, so a shared working tree
legitimately evolves between attempts. What must not vary there is the data, the
interpreter and the platform.

That reason stops applying when the plan isolates attempts. Each attempt is then a
fresh checkout of one committed revision, so the tree does not evolve between them
and the starting revision becomes a condition like any other -- `require_revision`
asks whether the isolation the plan declared actually held.
"""

from relab_core.provenance import ConditionsComparison, RunConditions

REQUIRED_FIELDS = ("declared data", "interpreter", "platform", "sandbox")


def compare_conditions(
    scope: str, entries: list[tuple[str, RunConditions | None]], *,
    require_targets: bool = False, require_revision: bool = False,
) -> ConditionsComparison:
    """Report what differed; an unrecorded condition is a gap, never an agreement.

    `require_targets` asks whether the runs started from the same content in the
    files they edit, and were measured by the same command. Repeats of one arm must
    both; different arms edit different files and verify them differently by design,
    so they must not be asked to.

    `require_revision` asks whether they started from the same committed code, which
    only a plan that isolates attempts is entitled to expect.
    """
    if not scope.strip():
        raise ValueError("a conditions comparison needs a nonblank scope")
    missing = [run_id for run_id, conditions in entries if conditions is None]
    present = [(run_id, item) for run_id, item in entries if item is not None]
    reasons = []
    if missing:
        reasons.append(f"no conditions were recorded for: {', '.join(sorted(missing))}")
    observed = {
        "declared data": {_digest_key(item) for _, item in present},
        "interpreter": {item.python_version for _, item in present},
        "platform": {item.platform for _, item in present},
        "sandbox": {f"{item.sandbox_backend}:{item.docker_image or ''}"
                    for _, item in present},
        "starting target state": {_target_key(item) for _, item in present},
        "verification command": {"\x00".join(item.verification_argv) for _, item in present},
    }
    # Arms verify different files by design, so both of these are asked of repeats
    # within one arm and never of the design as a whole.
    per_arm = ("starting target state", "verification command")
    required = (*REQUIRED_FIELDS, *per_arm) if require_targets else REQUIRED_FIELDS
    for field in required:
        if len(observed[field]) > 1:
            reasons.append(f"{field} differs across the compared runs")
    if require_revision:
        reasons.extend(_revision_reasons(present))
    unstable = sorted(run_id for run_id, item in present if item.data_changed)
    if unstable:
        # Not a disagreement between runs: each of these runs cannot say what it
        # read, so comparing them to anything is comparing something unknown.
        reasons.append("declared data changed while these runs ran: " + ", ".join(unstable))
    return ConditionsComparison(
        scope=scope, run_ids=[run_id for run_id, _ in entries],
        comparable=not reasons, reasons=reasons,
        missing_run_ids=sorted(missing),
        dirty_run_ids=sorted(run_id for run_id, item in present if item.code_dirty),
        changed_data_run_ids=sorted(run_id for run_id, item in present if item.data_changed),
        code_revisions=sorted({item.code_revision for _, item in present
                               if item.code_revision is not None}),
    )


def _revision_reasons(present: list[tuple[str, RunConditions]]) -> list[str]:
    """Three distinct ways a starting revision fails to say what ran, kept distinct."""
    reasons = []
    unknown = sorted(run_id for run_id, item in present if item.code_revision is None)
    if unknown:
        reasons.append("no starting code revision was recorded for: " + ", ".join(unknown))
    dirty = sorted(run_id for run_id, item in present if item.code_dirty)
    if dirty:
        # An isolated attempt checks out a revision, so a dirty tree means the
        # attempt did not start where the plan said it would, and the revision it
        # recorded does not identify the code that actually ran.
        reasons.append("the tree was not clean, so its revision does not identify what ran, "
                       "for: " + ", ".join(dirty))
    if len({item.code_revision for _, item in present if item.code_revision is not None}) > 1:
        reasons.append("starting code revision differs across the compared runs")
    return reasons


def _target_key(conditions: RunConditions) -> str:
    """Absence is part of the starting state, so it is spelled out rather than omitted."""
    return "\n".join(f"{path}={digest or 'absent'}" for path, digest
                      in sorted(conditions.target_digests.items()))


def _digest_key(conditions: RunConditions) -> str:
    """One stable string per declared-data state, so sets compare it directly."""
    return "\n".join(f"{path}={digest}" for path, digest
                     in sorted(conditions.data_digests.items()))
