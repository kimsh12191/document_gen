"""Projecting a repair history into something a person can read.

Pure and deterministic: the same history explains the same way every time, and
nothing here decides anything. The summary is assembled from counts the history
already holds, so it cannot say more than the record does.
"""

from relab_core.explanation import FailureExplanation
from relab_core.memory import MAXIMUM_CITATIONS, EvidenceCitation
from relab_core.repair import RepairAttempt, RepairHistory


def explain_failures(history: RepairHistory) -> FailureExplanation:
    """What this arm's failed attempts amount to, as an account of the record."""
    attempts = list(history.attempts)
    latest = attempts[-1] if attempts else None
    fingerprint = None if latest is None else latest.fingerprint
    same = [] if fingerprint is None else history.matching(fingerprint.digest)
    stuck = fingerprint is not None and history.stuck_on == fingerprint.digest
    # Counted only among attempts that failed the same way: two identical edits
    # that failed differently would say nothing about repetition.
    edit = None if latest is None else latest.patch_digest
    repeated_edits = 0 if edit is None else sum(
        1 for item in same if item.patch_digest == edit)
    return FailureExplanation(
        session_id=history.session_id, arm=history.arm,
        summary=_summary(history.arm, attempts, fingerprint is not None, len(same),
                         repeated_edits, stuck),
        current_failure=fingerprint, repeat_count=len(same), stuck=stuck,
        repeated_edits=repeated_edits, attempts=attempts,
        evidence=[EvidenceCitation(run_id=item.run_id, event_sequence=item.event_sequence)
                  for item in attempts][:MAXIMUM_CITATIONS],
    )


def _summary(
    arm: str, attempts: list[RepairAttempt], fingerprinted: bool,
    repeats: int, repeated_edits: int, stuck: bool,
) -> str:
    """One line, assembled from counts rather than adjectives."""
    if not attempts:
        return f"arm '{arm}' has no failed attempts"
    total = f"arm '{arm}' has {len(attempts)} failed attempt(s)"
    if not fingerprinted:
        # It failed before a verifier ran, so there is no failure to compare.
        return f"{total}; the most recent one never reached its verifier"
    if repeats < 2:
        return f"{total}, each failing differently"
    # The sharper reading when it is available: the same edit, not merely the
    # same outcome, is a model restating itself rather than a hard problem.
    how = (f"from the same edit {repeated_edits} times" if repeated_edits > 1
           else "from different edits")
    if stuck:
        return (f"{total}; the most recent failure has now occurred {repeats} times "
                f"({how}), so repeating this approach has stopped being a plan")
    return (f"{total}; the most recent failure has occurred {repeats} times ({how})")
