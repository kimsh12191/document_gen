"""AutoResearch line-oriented metrics (Apache-2.0); integrated snapshot extraction.

Parser migrated from AutoResearch 825bb80; see docs/reference/RESEARCH_METRICS.md.
"""

import math
import re

from relab_core.evaluation import CodingMetrics, EvaluationVerdict
from relab_core.runs import RunEvent
from relab_evaluation.coding import evaluate_coding

_METRIC_PATTERN = re.compile(r"^METRIC\s+(?P<name>[A-Za-z_][A-Za-z0-9_.-]*)=(?P<value>[^\s]+)\s*$")


class MetricParseError(ValueError):
    """A declared metric is malformed, repeated or non-finite."""


def parse_metrics(output: str) -> dict[str, float]:
    """Preserve the legacy parser's line recognition and finite-float semantics."""
    metrics: dict[str, float] = {}
    for line in output.splitlines():
        if not line.startswith("METRIC"):
            continue
        match = _METRIC_PATTERN.fullmatch(line.strip())
        if match is None:
            # The shape, not only the offending line. This message is the run's
            # recorded reason, so it reaches the next attempt's prompt -- and a
            # model told "invalid metric line: METRIC score: 0.0" has been told
            # its line is wrong and nothing about what a right one looks like.
            # Observed live: a model wrote `name: value`, was rejected, and had
            # no way to learn the separator from what came back.
            raise MetricParseError(
                f'invalid metric line (expected "METRIC <name>=<number>"): {line}')
        name = match.group("name")
        if name in metrics:
            raise MetricParseError(f"duplicate metric: {name}")
        try:
            value = float(match.group("value"))
        except ValueError as error:
            raise MetricParseError(f"invalid metric value for {name}") from error
        if not math.isfinite(value):
            raise MetricParseError(f"metric must be finite: {name}")
        metrics[name] = value
    return metrics


def extract_coding_metrics(event: RunEvent) -> CodingMetrics:
    evaluation = evaluate_coding(event)
    if evaluation.verdict != EvaluationVerdict.VERIFIED:
        raise ValueError("metrics require verified local coding evidence")
    evidence = event.snapshot.patch_evidence
    assert evidence is not None and evidence.verification is not None
    metrics = parse_metrics(evidence.verification.stdout)
    if not metrics:
        raise MetricParseError("no METRIC records in verified stdout")
    return CodingMetrics(
        run_id=event.run_id, event_sequence=event.sequence, patch_id=evidence.patch_id,
        metrics=metrics,
    )


def extract_holdout_metrics(event: RunEvent) -> CodingMetrics:
    """Read the second measurement, which selection never sees.

    The attempt must still be verified: a held-out number from an unverified
    run says nothing, exactly as for the selection metrics.
    """
    evaluation = evaluate_coding(event)
    if evaluation.verdict != EvaluationVerdict.VERIFIED:
        raise ValueError("holdout metrics require verified local coding evidence")
    measurement = event.snapshot.holdout_verification
    if measurement is None:
        raise ValueError(f"no holdout measurement recorded for {event.run_id}")
    if not measurement.passed or measurement.exit_code != 0 or measurement.timed_out:
        raise ValueError(f"the holdout measurement did not succeed for {event.run_id}")
    evidence = event.snapshot.patch_evidence
    assert evidence is not None
    metrics = parse_metrics(measurement.stdout)
    if not metrics:
        raise MetricParseError("no METRIC records in the holdout measurement")
    return CodingMetrics(
        run_id=event.run_id, event_sequence=event.sequence, patch_id=evidence.patch_id,
        source="holdout.stdout", metrics=metrics,
    )
