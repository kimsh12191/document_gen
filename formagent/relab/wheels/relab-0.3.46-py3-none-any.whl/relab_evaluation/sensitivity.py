"""Whether the ruler actually told the broken subject from the working one.

The question MQ1 cannot ask. A verifier that imports a module and declares both
requirements reaches `FULLY_CLAIMED`, because a claim is a sentence and it wrote
one. Point it at a working calculator and a broken one and it prints the same
number for both, and that is what this reads.

    MQ1   did it say it checks this
    MQ2   did it separate something it ought to separate

## Why `compare_metrics` is not reused

That rule asks whether a candidate is no worse than a baseline:

    MAXIMIZE:  candidate - baseline >= -tolerance

so two identical readings satisfy it. Here two identical readings are *the
finding*: a ruler that measures nothing produces them, and a rule that passes
them would report the blindest possible instrument as calibrated. The research
comparison and the calibration comparison ask opposite questions of the same
two numbers, and sharing an implementation would eventually make one of them
answer the other's.

## What a demonstration is, and is not

`DEMONSTRATED` says: for the controls this design declared, the ruler showed
the separation those controls asked for. It does not say the measurement is
good, or that it would separate anything else, or that the controls were the
right ones. The word is kept that narrow on purpose -- the same discipline that
named `FULLY_CLAIMED` instead of `ADEQUATE` one axis over.

And a separation only counts when somebody other than the model that wrote the
verifier established what it should be. A model that wrote the ruler, both
subjects and the expected direction could have written all four to agree; the
run still happens and the numbers are still recorded, and what it cannot do is
earn the word. That is `ExpectationAuthority`, and it is checked here.
"""

from relab_core.calibration import ControlReading, MeasurementControlRun
from relab_core.controls import MeasurementControl
from relab_core.evaluation import MetricDirection, MetricRegistry
from relab_core.sensitivity import (
    ControlFinding,
    ControlOutcome,
    MeasurementSensitivity,
    SensitivityStatus,
)


def assess_sensitivity(
    controls: list[MeasurementControl] | None,
    runs: list[MeasurementControlRun],
    registry: MetricRegistry,
    snapshot_id: str | None,
    *, asked_to_declare: bool = False,
) -> MeasurementSensitivity:
    """What this design's controls have shown about the ruler currently in force.

    Computed on every read, like the claim assessment beside it, and for the
    same reason: half of it is the current design, and a control declared
    yesterday changes what the same runs mean.

    Runs under a retired ruler are not read. They happened, and they were about
    an instrument this study is no longer measured by -- the same rule M2
    already keeps for readings.

    `asked_to_declare` says whether this ruler was built under the claim
    contract, which is what lets a missing declaration mean the ruler never
    reached its first step. A ruler adopted as it stands was never asked, and
    its silence says nothing about how far it got.

    The status stays coarse. What differs between the ways a control ends is in
    each outcome's `finding`, and that is what a policy should read.
    """
    if not controls:
        return MeasurementSensitivity(status=SensitivityStatus.UNDECLARED)
    directions = {rule.name: rule.direction for rule in registry.rules}
    under = {item.control_id: item for item in runs if item.snapshot_id == snapshot_id}
    outcomes = [_outcome(control, under.get(control.control_id), directions,
                         asked_to_declare=asked_to_declare)
                for control in controls]
    if all(item.finding is ControlFinding.UNTESTED for item in outcomes):
        return MeasurementSensitivity(
            status=SensitivityStatus.UNTESTED,
            undemonstrated_requirement_ids=_requirements(outcomes, shown=False),
            outcomes=outcomes)
    shown = _requirements(outcomes, shown=True)
    missing = _requirements(outcomes, shown=False)
    return MeasurementSensitivity(
        status=(SensitivityStatus.DEMONSTRATED if not missing
                else SensitivityStatus.NOT_DEMONSTRATED),
        demonstrated_requirement_ids=shown,
        undemonstrated_requirement_ids=missing,
        outcomes=outcomes)


_UNTESTED = "this control has not been run against the ruler in force"


def _requirements(outcomes: list[ControlOutcome], *, shown: bool) -> list[str]:
    """The requirements whose controls did, or did not, show what they asked for.

    A requirement counts as shown when *some* control for it did. It counts as
    not shown when none did, which is why the two lists are computed against
    each other rather than independently.
    """
    demonstrated = {item.requirement_id for item in outcomes if item.demonstrated}
    named = list(dict.fromkeys(item.requirement_id for item in outcomes))
    return [name for name in named
            if (name in demonstrated) == shown]


def _outcome(
    control: MeasurementControl,
    run: MeasurementControlRun | None,
    directions: dict[str, MetricDirection],
    *, asked_to_declare: bool,
) -> ControlOutcome:
    """One control read against what the ruler did with it."""
    metric = control.expectation.metric
    asked = control.expectation.minimum_separation

    def outcome(
        finding: ControlFinding, *, good: float | None = None, bad: float | None = None,
        separation: float | None = None, reason: str | None = None,
    ) -> ControlOutcome:
        return ControlOutcome(
            control_id=control.control_id, requirement_id=control.requirement_id,
            metric=metric, required_separation=asked,
            good_value=good, bad_value=bad, separation=separation, finding=finding,
            demonstrated=finding is ControlFinding.DEMONSTRATED, reason=reason)

    if run is None:
        return outcome(ControlFinding.UNTESTED, reason=_UNTESTED)
    direction = directions.get(metric)
    if direction is None:
        return outcome(ControlFinding.UNKNOWN_METRIC,
                       reason=f"the registry declares no rule named {metric}")
    # A number from a ruler that says it checked nothing is not a reading. A
    # live verifier could not import its own reference data, printed
    # `correctness_rate=0.0` for every subject and reported zero checks; read
    # by its number alone that was two equal readings -- an insufficient
    # separation -- and nothing stopped the arms. It is the contract an arm's
    # reading is held to, applied where the ruler was asked to keep it and the
    # count was actually read.
    if asked_to_declare:
        # Observed as absent, or observed as zero; never a reading from before
        # the count was read (`None`), which is not scored retroactively.
        unmeasured = [reading for reading in (run.good, run.bad)
                      if reading.executed_checks_observed is not None
                      and reading.declared is not None
                      and not reading.verification.executed_checks]
        if unmeasured:
            finding = (ControlFinding.CALIBRATION_EXECUTION_FAILED
                       if any(not reading.declared for reading in unmeasured)
                       else ControlFinding.CALIBRATION_UNOBSERVABLE)
            which = "both subjects" if len(unmeasured) == 2 else "one subject"
            return outcome(finding, reason=(
                f"the ruler reported no executed check for {which}, so what it "
                f"printed for {metric} is not a reading"))
    good = run.good.metrics.get(metric)
    bad = run.bad.metrics.get(metric)
    if good is None or bad is None:
        # A ruler that printed nothing for a subject told us something, and it
        # is not a separation. How far it got decides what it told us.
        which = "both subjects" if good is None and bad is None else "one subject"
        silent = [reading for reading, value in ((run.good, good), (run.bad, bad))
                  if value is None]
        return outcome(_no_reading(silent, asked_to_declare=asked_to_declare),
                       good=good, bad=bad,
                       reason=f"the ruler printed no {metric} for {which}")
    # In the direction the registry declares, so "better" means what the study
    # says it means rather than what a larger number looks like.
    separation = good - bad if direction is MetricDirection.MAXIMIZE else bad - good
    if separation < asked:
        return outcome(
            ControlFinding.INSUFFICIENT_SEPARATION, good=good, bad=bad, separation=separation,
            reason=(f"the ruler separated the subjects by {separation:g}, and this "
                    f"control asked for {asked:g}"))
    if not control.provenance.expectation_authority.earns_demonstration:
        # It separated them. Whether that means the ruler is sensitive is a
        # different question, and one nobody but the verifier's own author has
        # answered.
        return outcome(
            ControlFinding.SEPARATION_OBSERVED_BUT_UNTRUSTED,
            good=good, bad=bad, separation=separation,
            reason=("the expected relation was proposed by a model and by nothing "
                    "else, so a separation under it shows agreement rather than "
                    "sensitivity"))
    return outcome(ControlFinding.DEMONSTRATED, good=good, bad=bad, separation=separation)


def _no_reading(silent: list[ControlReading], *, asked_to_declare: bool) -> ControlFinding:
    """How far a ruler that printed nothing got, from what it left behind.

    Only the silent subjects are read: a reading with a number in it already
    says the ruler ran. One that never declared, when it was asked to, is the
    stronger statement and wins -- that subject's run did not get as far as
    the ruler's own first step, whatever happened to the other.
    """
    if any(reading.declared is None for reading in silent):
        return ControlFinding.NO_READING
    if all(reading.declared for reading in silent):
        return ControlFinding.CALIBRATION_UNOBSERVABLE
    if asked_to_declare:
        return ControlFinding.CALIBRATION_EXECUTION_FAILED
    return ControlFinding.NO_READING
