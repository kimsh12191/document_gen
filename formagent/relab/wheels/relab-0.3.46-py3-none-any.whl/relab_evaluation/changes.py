"""Reading a recorded patch into the few numbers a person wants at a glance.

Counting from the diff rather than from the files. The workspace holds what is
there now, which for a reverted attempt is not what the attempt wrote -- and the
attempt is the thing being described. The record is the only place that still
knows.
"""

from relab_core.changes import MAXIMUM_CHANGED_FILES, FileChange, RunChange
from relab_core.runs import CodingRun

# git's own marker for the side of a rename or creation that does not exist.
_ABSENT = "/dev/null"


def describe_change(run: CodingRun, *, arm: str | None = None) -> RunChange | None:
    """What this run wrote, or None when it never got as far as writing anything.

    None is an ordinary answer. A run whose provider call was lost, or whose
    reply could not become a patch, has no change to describe -- and saying so
    beats a card reporting zero files changed, which reads as "it ran and did
    nothing" rather than "it never ran".
    """
    evidence = run.patch_evidence
    if evidence is None:
        return None
    counted = _counts(evidence.diff)
    # `touched_files` is what the policy saw; the diff is what it saw it in. They
    # agree, and where they do not the recorded list is the authority on which
    # paths were involved at all.
    kept = {item.path for item in evidence.snapshots if item.readable}
    files = [FileChange(path=path, added=counted.get(path, (0, 0))[0],
                        removed=counted.get(path, (0, 0))[1],
                        comparable=path in kept)
             for path in evidence.touched_files[:MAXIMUM_CHANGED_FILES]]
    verification = evidence.verification
    return RunChange(
        run_id=run.run_id, arm=arm, files=files, patch_status=evidence.status,
        # Read from the run and not from the patch. The patch says how applying
        # it ended; only the run knows whether the edit was afterwards taken
        # back out, and that is the half a person is actually asking about.
        restored_after_measurement=run.restored, restore_reason=run.restore_reason,
        verified=None if verification is None else verification.passed)


def _counts(diff: str) -> dict[str, tuple[int, int]]:
    """Added and removed line counts per path, read from a unified diff.

    Header lines are not content: `+++` and `---` name the sides of a file and
    would otherwise be counted as one added and one removed line in every file
    that appears, which is wrong by exactly the number of files.
    """
    counts: dict[str, tuple[int, int]] = {}
    path: str | None = None
    for line in diff.splitlines():
        if line.startswith("+++ "):
            path = _path(line[4:])
            if path is not None:
                counts.setdefault(path, (0, 0))
            continue
        if line.startswith("--- "):
            # The source side. Kept as the path only when the target side is
            # absent, which is how a deletion names the file it is about.
            continue
        if path is None:
            continue
        added, removed = counts[path]
        if line.startswith("+"):
            counts[path] = (added + 1, removed)
        elif line.startswith("-"):
            counts[path] = (added, removed + 1)
    return counts


def _path(side: str) -> str | None:
    """The repository path from one side of a diff header, or None when absent."""
    named = side.strip()
    if not named or named == _ABSENT:
        return None
    # `a/` and `b/` are git's prefixes for the two sides, not part of the path.
    return named[2:] if named[:2] in {"a/", "b/"} else named
