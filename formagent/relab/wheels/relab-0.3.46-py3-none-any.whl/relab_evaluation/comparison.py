"""Deterministic absolute-tolerance checks over explicitly selected metrics."""

from decimal import Decimal, localcontext

from relab_core.evaluation import (
    CodingMetrics,
    MetricComparison,
    MetricComparisonItem,
    MetricDirection,
    MetricRegistry,
)


def compare_metrics(
    candidate: CodingMetrics, baseline: CodingMetrics, registry: MetricRegistry,
) -> MetricComparison:
    items: list[MetricComparisonItem] = []
    for rule in registry.rules:
        current = candidate.metrics.get(rule.name)
        previous = baseline.metrics.get(rule.name)
        item = MetricComparisonItem(
            name=rule.name, passed=False, reason="missing required metric",
            candidate_value=current, baseline_value=previous,
        )
        if current is not None and previous is not None:
            # Enough precision for the entire decimal exponent span of finite
            # binary64 inputs; preserve boundary equality without float subtraction.
            with localcontext() as context:
                context.prec = 700
                delta = Decimal(str(current)) - Decimal(str(previous))
                tolerance = Decimal(str(rule.tolerance))
                item.passed = (delta >= -tolerance if rule.direction == MetricDirection.MAXIMIZE
                               else delta <= tolerance)
                item.delta = str(delta)
            item.reason = "within tolerance" if item.passed else "regression exceeds tolerance"
        items.append(item)
    return MetricComparison(
        registry=registry, candidate=candidate, baseline=baseline,
        passed=all(item.passed for item in items), items=items,
    )
