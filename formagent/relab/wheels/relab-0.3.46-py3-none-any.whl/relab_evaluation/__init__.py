"""Pure evaluation capabilities; no filesystem or process ownership."""
