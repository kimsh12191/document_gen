"""Deterministic interpretation of the latest persisted coding-run event."""

from relab_core.coding.patch import PatchStatus
from relab_core.contracts import RunState
from relab_core.evaluation import CodingEvaluation, EvaluationVerdict
from relab_core.runs import RunEvent

# Every event that carries a finished attempt's evidence. Measuring a holdout or
# undoing the edit afterwards changes the workspace, not what was applied and verified.
COMPLETION_EVENTS = frozenset({
    "coding.patch_finished",
    "coding.dependency_resume_finished",
    "coding.patch_recovered",
    "coding.patch_restored",
    "coding.holdout_measured",
    "coding.holdout_abandoned",
})


def evaluate_coding(event: RunEvent) -> CodingEvaluation:
    run = event.snapshot
    report = CodingEvaluation(
        run_id=run.run_id, event_sequence=event.sequence,
        verdict=EvaluationVerdict.UNVERIFIED, reason="no local patch verification evidence",
    )
    if event.run_id != run.run_id:
        report.reason = "event and snapshot identity mismatch"
        return report
    if run.state in {
        RunState.CREATED, RunState.RUNNING, RunState.AWAITING_HUMAN,
        RunState.AWAITING_DEPENDENCY, RunState.DEPENDENCY_INSTALLED,
    }:
        report.verdict = EvaluationVerdict.PENDING
        report.reason = f"run remains {run.state.value}; coding verification is not complete"
        return report
    evidence = run.patch_evidence
    if evidence is None:
        if run.state in {RunState.FAILED, RunState.CANCELLED}:
            report.verdict = EvaluationVerdict.FAILED
            report.reason = f"run is {run.state.value}; this is not a research quality score"
        return report
    report.patch_id = evidence.patch_id
    if (
        event.kind not in COMPLETION_EVENTS
        or run.proposal is None or evidence.patch_id != run.proposal.request_id
        or evidence.diff != run.proposal.diff
    ):
        report.reason = "patch evidence does not match a recognized completion event and proposal"
        return report
    verification = evidence.verification
    if verification is not None:
        report.executed_checks = verification.executed_checks
        report.passed_checks = verification.passed_checks
        report.failed_checks = verification.failed_checks
        if verification.argv != run.verify_argv:
            report.reason = "verification command differs from recorded execution intent"
            return report
    if run.state == RunState.FAILED and evidence.status != PatchStatus.APPLIED:
        report.verdict = EvaluationVerdict.FAILED
        report.reason = f"patch outcome: {evidence.status.value}"
        return report
    if run.state != RunState.COMPLETED or evidence.status != PatchStatus.APPLIED:
        report.reason = "run state and patch outcome are inconsistent"
        return report
    if verification is None:
        report.reason = "applied patch lacks verification"
        return report
    if (
        not verification.passed or verification.exit_code != 0 or verification.timed_out
        or verification.executed_checks == 0
        or (verification.failed_checks is not None and verification.failed_checks > 0)
        or (verification.executed_checks is not None and verification.passed_checks is not None
            and verification.passed_checks != verification.executed_checks)
    ):
        report.reason = "verification evidence is incomplete or contradictory"
        return report
    report.verdict = EvaluationVerdict.VERIFIED
    report.reason = (
        "recorded verifier succeeded (exit-code-only; check count not reported)"
        if verification.executed_checks is None else "recorded verifier checks passed"
    )
    return report
