"""Whether a measurement happened, as distinct from what it said.

A live session ran six attempts at a calculator. Every patch applied, every
verifier exited zero, and every one printed:

    METRIC pass_rate=0.000000

The verifier ran `pytest` over a directory holding no test file, was told "no
tests ran", and reported the floor value. Both arms scored it, the
pre-registered rules held -- 0.0 is not worse than 0.0 -- and the session was
concluded on evidence that had measured nothing at all.

Nothing in that chain was broken. Each step did what it was built to do, and
the one question nobody asked was whether a measurement had taken place. This
module asks it, before a number becomes evidence.

## Two facts, kept apart

    reported_subjects   what the verifier says it measured -- a claim, and for
                        a verifier ReLab asked a model to write, a model's claim
    measured_digests    what the workspace held at those paths when the command
                        started -- ReLab's own observation

They are compared here and never merged. A match establishes that the artifact
the verifier named is the artifact that was there: protocol consistency. It is
*not* evidence that the code ran -- a verifier can hash a file it never imports
-- and proving execution needs coverage or import tracing, which is a different
capability and deliberately not this one.

## Who is held to the contract

    MANAGED   ReLab asked a model to write this verifier, under a stated
              contract, so the contract is enforced and a breach is invalid
    ADOPTED   the project's own, or an earlier session's. ReLab states no
              contract for it, so nothing is enforced and what could not be
              seen is recorded as a limitation

Ownership and observability are independent. An adopted verifier that reports
its checks is good evidence, and a scale with one axis could not say so.
"""

from relab_core.coding.patch import VerificationResult
from relab_core.measurement import (
    MeasurementInvalidity,
    MeasurementObservability,
    MeasurementOwnership,
    MeasurementReading,
)

UNREPORTED_CHECKS = "the verifier did not report how many checks it executed"
UNREPORTED_SUBJECTS = "the verifier did not report which artifacts it measured"


def read_measurement(
    verification: VerificationResult | None, *,
    ownership: MeasurementOwnership,
    required_subjects: list[str],
) -> MeasurementReading:
    """What this verification can be said to have measured.

    `required_subjects` is what the attempt declared it was writing. They are
    the artifacts a measurement of this attempt has to be about, and the same
    paths whose digests were observed at the verification boundary.
    """
    if verification is None:
        return MeasurementReading(
            ownership=ownership, observability=MeasurementObservability.UNREPORTED,
            invalidity=MeasurementInvalidity.REPORT_MISSING,
            reason="no verification ran, so nothing was measured")
    reported = {subject.path: subject.digest for subject in verification.reported_subjects}
    observed = MeasurementObservability.REPORTED if (
        verification.executed_checks is not None or reported
    ) else MeasurementObservability.UNREPORTED
    breach = (_managed_breach(verification, reported, required_subjects)
              if ownership is MeasurementOwnership.MANAGED else None)
    invalidity, reason = breach if breach is not None else (
        None, _said(observed, verification))
    return MeasurementReading(
        ownership=ownership, observability=observed,
        executed_checks=verification.executed_checks,
        subjects=list(verification.reported_subjects),
        limitations=_limitations(verification, reported, required_subjects),
        invalidity=invalidity, reason=reason)


def _managed_breach(
    verification: VerificationResult, reported: dict[str, str], required: list[str],
) -> tuple[MeasurementInvalidity, str] | None:
    """The contract ReLab stated when it asked for this verifier, checked.

    In order, because the first unmet condition is the one to act on: a
    verifier that wrote no report cannot also be missing a subject in any way
    worth telling somebody about.
    """
    executed = verification.executed_checks
    if executed is None:
        return (MeasurementInvalidity.REPORT_MISSING, (
            "this measurement is ReLab's own and reported nothing about what it did; "
            "a verifier that only exits zero has confirmed that it started"))
    if executed == 0:
        return (MeasurementInvalidity.NO_CHECKS_EXECUTED,
                "the verifier executed no checks, so it measured nothing to report")
    absent = [path for path in required if path not in reported]
    if absent:
        return (MeasurementInvalidity.SUBJECT_UNREPORTED, (
            f"the verifier ran {executed} check(s) and did not say they were of "
            f"{', '.join(sorted(absent))}"))
    wrong = [
        f"{path}: measured {_short(verification.measured_digests.get(path))}, "
        f"reported {_short(reported[path])}"
        for path in required
        if reported[path] != verification.measured_digests.get(path)
    ]
    if wrong:
        return (MeasurementInvalidity.SUBJECT_MISMATCH, (
            "the verifier named an artifact this workspace was not holding when it ran: "
            + "; ".join(sorted(wrong))))
    return None


def _limitations(
    verification: VerificationResult, reported: dict[str, str], required: list[str],
) -> list[str]:
    """What this reading cannot tell anyone. Facts, not a verdict.

    Recorded whatever the ownership, because an opaque measurement is opaque
    either way -- for a managed one these accompany a refusal, and for an
    adopted one they are the whole of what there is to say.
    """
    limits = []
    if verification.executed_checks is None:
        limits.append(UNREPORTED_CHECKS)
    if not reported:
        limits.append(UNREPORTED_SUBJECTS)
    elif (absent := [path for path in required if path not in reported]):
        limits.append("the verifier did not report measuring "
                      + ", ".join(sorted(absent)))
    return limits


def _said(observed: MeasurementObservability, verification: VerificationResult) -> str:
    """What was seen, in the terms this reading is allowed to speak in."""
    if observed is MeasurementObservability.UNREPORTED:
        return ("an adopted verifier ran and reported nothing about what it did; "
                "its result stands as far as this workspace can tell")
    counted = ("an unreported number of" if verification.executed_checks is None
               else str(verification.executed_checks))
    named = (", ".join(sorted(item.path for item in verification.reported_subjects))
             or "no named artifact")
    return f"the verifier reported {counted} check(s) over {named}"


def _short(digest: str | None) -> str:
    """Enough of a digest to compare by eye, or the absence that was observed."""
    return "nothing" if digest is None else digest[:12]
