"""Deciding when two failures are the same failure.

The hard part is everything that differs between two runs of the *same* problem:
each isolated attempt runs in its own checkout, so paths differ; run ids are in
those paths; addresses, timestamps and durations differ every time. None of that
is the failure, and leaving any of it in would make every failure unique and the
whole idea useless.

The normalisation is deliberately blunt, and the fingerprint errs toward calling
two failures *different*. Saying "you are stuck" about work that is progressing
would stop it; failing to notice a repeat only means a person hears later.
"""

import hashlib
import re

from relab_core.coding.patch import VerificationResult
from relab_core.repair import FailureFingerprint

# How much of the output the signature is taken over. The end is where the error
# is; the start is usually the command echoing itself.
SIGNATURE_CHARACTERS = 2000

_SUBSTITUTIONS = (
    # Windows and POSIX absolute paths, including the per-attempt checkouts.
    (re.compile(r"[A-Za-z]:\\[^\s\"'<>|]+"), "<path>"),
    (re.compile(r"(?<![\w.])/(?:[\w.\-+@]+/)+[\w.\-+@]*"), "<path>"),
    # Run and session ids, which appear in objectives and in checkout names.
    (re.compile(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}"
                r"-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b"), "<id>"),
    # Memory addresses and object reprs.
    (re.compile(r"\b0[xX][0-9a-fA-F]+\b"), "<addr>"),
    # Timestamps, then bare times, then durations.
    (re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?"),
     "<time>"),
    (re.compile(r"\b\d+(?:\.\d+)?\s?(?:ms|s|sec|secs|seconds|us|ns)\b"), "<duration>"),
    # Line and column references, which move when the file does.
    (re.compile(r"(?i)\bline\s+\d+"), "line <n>"),
    (re.compile(r":\d+:\d+\b"), ":<n>:<n>"),
    # Anything left that is only a number is not what makes a failure distinct.
    (re.compile(r"\b\d{3,}\b"), "<n>"),
)


def normalise(text: str) -> str:
    """Strip everything that differs between two runs of the same failure."""
    for pattern, replacement in _SUBSTITUTIONS:
        text = pattern.sub(replacement, text)
    # Collapse whitespace last, so nothing above has to care about layout.
    return " ".join(text.split())


def fingerprint(verification: VerificationResult) -> FailureFingerprint:
    """What this failure is, in a form two of them can be compared by.

    Standard error is preferred because that is where a failure says what it was;
    standard output is used only when there is no standard error at all.
    """
    source = verification.stderr.strip() or verification.stdout.strip()
    signature = normalise(source)[-SIGNATURE_CHARACTERS:]
    # The exit code and the timeout are part of what happened, so two failures
    # with identical text but different exits are not called the same.
    material = f"{verification.exit_code}|{verification.timed_out}|{signature}"
    return FailureFingerprint(
        digest=hashlib.sha256(material.encode("utf-8")).hexdigest()[:16],
        exit_code=verification.exit_code, timed_out=verification.timed_out,
        signature=signature,
    )
