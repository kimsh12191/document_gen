"""Observed range checks; not proof of statistical or experimental reproducibility."""

from decimal import Decimal, localcontext

from relab_core.evaluation import (
    CodingMetrics,
    MetricRegistry,
    RepeatabilityItem,
    RepeatabilityReport,
)


def assess_repeatability(
    samples: list[CodingMetrics], registry: MetricRegistry, *, minimum_runs: int = 3,
) -> RepeatabilityReport:
    if type(minimum_runs) is not int or minimum_runs < 2:
        raise ValueError("minimum_runs must be an integer of at least 2")
    ids = [sample.run_id for sample in samples]
    if len(ids) != len(set(ids)):
        raise ValueError("repeatability requires distinct run IDs")
    enough = len(samples) >= minimum_runs
    items: list[RepeatabilityItem] = []
    for rule in registry.rules:
        missing = [sample.run_id for sample in samples if rule.name not in sample.metrics]
        item = RepeatabilityItem(
            name=rule.name, passed=False, reason="insufficient distinct runs",
            missing_run_ids=missing,
        )
        if enough and missing:
            item.reason = "required metric missing from one or more runs"
        elif enough:
            values = [sample.metrics[rule.name] for sample in samples]
            item.minimum, item.maximum = min(values), max(values)
            with localcontext() as context:
                context.prec = 700
                spread = Decimal(str(item.maximum)) - Decimal(str(item.minimum))
                item.spread = str(spread)
                item.passed = spread <= Decimal(str(rule.repeatability_tolerance))
            item.reason = "within spread tolerance" if item.passed else "spread exceeds tolerance"
        items.append(item)
    passed = enough and all(item.passed for item in items)
    return RepeatabilityReport(
        registry=registry, minimum_runs=minimum_runs, samples=samples, passed=passed, items=items,
        reason="observed metric ranges passed" if passed else "repeatability requirements not met",
    )
