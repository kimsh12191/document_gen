"""Reading a ruler's claims against the design in force.

The fourth axis, and the one that would have caught the calculator study. Three
were already here and all three said the measurement was fine:

    P1  a measurement happened, under a contract it did not break
    M2  it was taken under the ruler currently in force
    P2  whether the evidence supports a conclusion

None of them can ask whether the instrument was pointed at the question. The
verifier imported a module, reported one executed check, and every arm scored
identically -- a valid, current measurement of nothing the study was about.

So the design declares what has to be checked, the verifier claims what it
checks, and this reads one against the other. What it produces is deliberately
narrow.

## What a claim is worth

The verifier is written by the same pipeline that writes the arms, so a claim
is the thing being measured saying what it will be measured on. That makes this
asymmetric, and the asymmetry is the whole value:

    INCOMPLETE_CLAIMS   strong. The ruler does not even *say* it checks what
                        the study asked. Nothing has to be trusted for that to
                        be a finding.
    FULLY_CLAIMED       weak. Nothing mechanically declared is missing, which
                        is not the same as the checking being any good.

A word like "adequate" would promote the second into a verdict it cannot carry,
so it is not used. What could earn one is a ruler shown to detect a difference
it ought to detect, and that is a later thing with controls of its own.

## Why nothing here is stored

An observation is a fact about a ruler at a moment. The requirements are the
current design, and a design can change without the ruler changing. So the
status is computed on every read: a requirement added last week must change what
the same claims mean, and a recorded status would answer with what they used to.
"""

from collections.abc import Callable
from datetime import datetime, timezone

from relab_core.lifecycle import MeasurementClaimBlocker
from relab_core.measurement import (
    ClaimDispatchBlocker,
    ClaimDispatchDecision,
    MeasurementClaimAssessment,
    MeasurementClaimObservation,
    MeasurementClaimStatus,
    MeasurementOwnership,
    MeasurementRequirement,
    ownership_of,
)
from relab_core.research import ResearchSession
from relab_core.runs import CodingRun


def assess_claims(
    requirements: list[MeasurementRequirement] | None,
    observation: MeasurementClaimObservation | None,
    ownership: MeasurementOwnership = MeasurementOwnership.ADOPTED,
) -> MeasurementClaimAssessment:
    """What this design makes of what its ruler claimed.

    Both absences are answers, and they are different ones. A design that never
    said what its measurement must check has no contract to read a claim
    against; one that said, and has heard nothing back, is waiting rather than
    failing. Collapsing either into "fine" is how a study written before any of
    this existed would quietly pass a check it was never held to.
    """
    declared = [item.requirement_id for item in requirements or []]
    if not declared:
        return MeasurementClaimAssessment(status=MeasurementClaimStatus.UNDECLARED,
                                          ownership=ownership)
    if observation is None:
        return MeasurementClaimAssessment(
            status=MeasurementClaimStatus.UNOBSERVED,
            ownership=ownership, declared_requirement_ids=declared)

    claimed = list(observation.claimed_requirement_ids)
    # Order is the design's, so a person reads their own requirements in the
    # order they wrote them rather than in whatever order a verifier listed.
    recognized = [name for name in declared if name in set(claimed)]
    unknown = _first_mention([name for name in claimed if name not in set(declared)])
    uncovered = [name for name in declared if name not in set(claimed)]
    return MeasurementClaimAssessment(
        status=(MeasurementClaimStatus.INCOMPLETE_CLAIMS if uncovered
                else MeasurementClaimStatus.FULLY_CLAIMED),
        ownership=ownership,
        declared_requirement_ids=declared,
        claimed_requirement_ids=claimed,
        recognized_claim_ids=recognized,
        unknown_claim_ids=unknown,
        uncovered_requirement_ids=uncovered,
        limitations=[*observation.limitations, *_about(claimed, unknown)])


def _first_mention(names: list[str]) -> list[str]:
    """Each once, in the order it was first claimed."""
    return list(dict.fromkeys(names))


def _about(claimed: list[str], unknown: list[str]) -> list[str]:
    """What is worth saying in words about these claims, for a person.

    Neither of these makes a claim unusable, which is why both are sentences
    rather than states. A repeated identifier still says the verifier claims
    that requirement; an identifier nobody declared still says the verifier
    checks something, and possibly something worth declaring.
    """
    said = []
    if len(set(claimed)) != len(claimed):
        said.append("the verifier claimed the same requirement more than once")
    if unknown:
        said.append(
            "the verifier claimed requirements this design does not declare: "
            + ", ".join(unknown))
    return said


def claim_dispatch_policy(
    assessment: MeasurementClaimAssessment, *, current_ruler_had_verification: bool,
) -> ClaimDispatchDecision:
    """Whether another arm may be dispatched against this ruler.

    Three facts, kept apart on purpose, because pressing them into one enum is
    how a reading stops being arguable:

        status      what was observed
        ownership   who may be required to answer
        history     whether the chance to answer has actually been had

    The last is the subtle one, and "the first attempt" is the wrong way to
    count it. An attempt whose provider timed out, whose generation was refused
    or whose patch never applied did not reach the verifier at all -- so it
    used no opportunity, and holding it against the ruler would blame the
    instrument for a provider having a bad afternoon. What is counted is a
    verification that actually ran under the ruler in force.

    Blocking is about dispatch and only about dispatch. Nothing here concludes
    anything about evidence already recorded; readings taken under a ruler stay
    exactly as valid as they were.
    """
    if assessment.status is MeasurementClaimStatus.INCOMPLETE_CLAIMS:
        uncovered = ", ".join(assessment.uncovered_requirement_ids)
        return ClaimDispatchDecision(
            allowed=False, blocker=ClaimDispatchBlocker.CLAIMS_INCOMPLETE,
            reason=(f"the verifier claims to check none of: {uncovered}. Running "
                    "another arm cannot repair the ruler that measures it."))
    if assessment.status is not MeasurementClaimStatus.UNOBSERVED:
        # UNDECLARED has no contract to read against; FULLY_CLAIMED has nothing
        # missing, which is not the same as the checking being any good.
        return ClaimDispatchDecision(
            allowed=True, reason="nothing about the ruler's claims stops this study")
    if assessment.ownership is not MeasurementOwnership.MANAGED:
        return ClaimDispatchDecision(
            allowed=True,
            reason=("this verifier was adopted as it stands, so it was never in a "
                    "position to be asked what it checks"))
    if not current_ruler_had_verification:
        return ClaimDispatchDecision(
            allowed=True,
            reason=("this verifier has not yet run under the ruler in force; one "
                    "verification may still declare what it checks"))
    return ClaimDispatchDecision(
        allowed=False, blocker=ClaimDispatchBlocker.CLAIMS_STILL_UNOBSERVED,
        reason=("ReLab wrote this verifier, asked it to declare what it checks, and "
                "it has now run without declaring anything. Running another arm "
                "cannot make it answer."))


def current_ruler_claims(
    session: ResearchSession, load: "Callable[[str], CodingRun]",
) -> tuple[MeasurementClaimObservation | None, list[str]]:
    """What is known about this ruler's claims, and which runs gave it a chance.

    **Reads, and records nothing.** That matters more than it looks: this is
    what the lifecycle projection calls, and a status read that appended a
    session event would break the one invariant every projection here keeps --
    lifecycle reads records and never writes them. The execution path is the
    only thing that may promote a claim it heard into the session's canonical
    observation, and it does that separately.

    So there are two sources and a strict order. The recorded observation is
    the canonical one, and when there is none, a verification run under this
    same ruler may have heard a claim -- that is read as a fallback, and read
    only. An observation derived here exists for the length of one projection.

    The chance to declare is counted as verifications actually recorded under
    the ruler in force, never as attempts. An attempt whose provider timed out
    or whose patch never applied did not reach the verifier, so it gave the
    instrument no opportunity to say anything.
    """
    frozen = session.measurement_snapshot
    if frozen is None or frozen.snapshot_id is None:
        return None, []
    recorded = next((item for item in session.measurement_claim_observations
                     if item.snapshot_id == frozen.snapshot_id), None)
    heard, opportunities = None, []
    for reference in session.runs:
        evidence = load(reference.run_id).patch_evidence
        verification = None if evidence is None else evidence.verification
        if (verification is None
                or verification.measurement_snapshot_id != frozen.snapshot_id):
            continue
        opportunities.append(reference.run_id)
        if heard is None and verification.claimed_requirements is not None:
            heard = MeasurementClaimObservation(
                snapshot_id=frozen.snapshot_id,
                claimed_requirement_ids=list(verification.claimed_requirements),
                observed_at=datetime.now(timezone.utc),
                limitations=["heard during a verification rather than from the probe"])
    return recorded or heard, opportunities


def claim_blocker(
    session: ResearchSession, load: "Callable[[str], CodingRun]",
) -> MeasurementClaimBlocker | None:
    """What stops this study, when its ruler's claims are what stop it.

    None is the ordinary answer and means only that the claims are not the
    problem. It says nothing about whether the measurement worked, which is
    `MeasurementBlocker`'s question and a different one.
    """
    plan = session.plan
    frozen = session.measurement_snapshot
    if plan is None or frozen is None or frozen.snapshot_id is None:
        return None
    observed, opportunities = current_ruler_claims(session, load)
    assessment = assess_claims(plan.measurement_requirements, observed,
                               ownership_of(plan.measurement))
    decision = claim_dispatch_policy(
        assessment, current_ruler_had_verification=bool(opportunities))
    if decision.allowed or decision.blocker is None:
        return None
    return MeasurementClaimBlocker(
        blocker=decision.blocker,
        snapshot_id=frozen.snapshot_id,
        declared_requirement_ids=assessment.declared_requirement_ids,
        claimed_requirement_ids=assessment.claimed_requirement_ids,
        uncovered_requirement_ids=assessment.uncovered_requirement_ids,
        unknown_claim_ids=assessment.unknown_claim_ids,
        opportunity_run_ids=opportunities[:64])
