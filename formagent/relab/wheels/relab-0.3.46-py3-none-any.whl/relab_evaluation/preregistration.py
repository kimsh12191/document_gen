"""Whether an amendment moved what counts as success, and when.

Amending a pre-registered plan is a legitimate, recorded act. Amending the part
that decides whether a result passes, once results are already in hand, is the
one move pre-registration exists to prevent -- so it is named separately here
rather than left among every other change a plan can undergo.
"""

from relab_core.contracts import RunState
from relab_core.research import ResearchPlan
from relab_core.runs import CodingRun

# What decides whether evidence passes: the rules, and what is compared to what.
DECIDING_FIELDS = ("registry", "holdout_registry", "candidate_arm", "baseline_arm")


def _rulers(plan: ResearchPlan) -> dict[str, tuple[tuple[str, ...], tuple[str, ...]]]:
    """The commands that measure each arm, by arm."""
    return {task.arm: (tuple(task.verify_argv), tuple(task.holdout_argv))
            for task in plan.arm_tasks}


def _moved_rulers(before: ResearchPlan, after: ResearchPlan) -> list[str]:
    """Arms whose measuring command changed, which is a deciding change.

    An arm task is otherwise "how the work is done": its objective and its
    targets say what to attempt, and changing those leaves intact what would
    count as having succeeded. `verify_argv` and `holdout_argv` are not that.
    They are the ruler that arm is held to, and swapping a failing verifier for
    a passing one is the cheapest escape a stuck arm has -- it produces a green
    session without anything having been fixed.

    Only arms that already had a ruler are reported. Declaring one for an arm
    that had none makes a previously unexecutable arm executable; it re-judges
    nothing, because there was nothing to judge.
    """
    was, now = _rulers(before), _rulers(after)
    moved = []
    for arm, (verify, holdout) in was.items():
        current = now.get(arm, ((), ()))
        if verify and current[0] != verify:
            moved.append(f"arm_tasks.{arm}.verify_argv")
        if holdout and current[1] != holdout:
            moved.append(f"arm_tasks.{arm}.holdout_argv")
    return moved


def moved_goalposts(before: ResearchPlan, after: ResearchPlan) -> list[str]:
    """Deciding fields this amendment changed.

    Three fields move the bar only in one direction, so only that direction counts.
    Asking for *more* repeats demands more evidence; asking for fewer lowers the bar
    the existing evidence has to clear. Demanding comparable conditions raises the
    bar; withdrawing the demand lets evidence that could not pass under the declared
    policy pass. And while comparability is required, isolation is part of what
    comparable means for an arm's repeats, so dropping it accepts repeats measured
    at revisions the declared policy would have rejected.

    Everything else a plan declares -- arms, data, sandbox, and what an arm task
    attempts -- changes how the work is done, not what would count as it having
    worked. An arm task's *measuring command* is the exception, and it is the
    one an arm that cannot pass would reach for first; see `_moved_rulers`.
    """
    moved = [name for name in DECIDING_FIELDS
             if getattr(before, name) != getattr(after, name)]
    moved.extend(_moved_rulers(before, after))
    if after.repeats_per_arm < before.repeats_per_arm:
        moved.append("repeats_per_arm")
    if before.require_comparable_conditions and not after.require_comparable_conditions:
        moved.append("require_comparable_conditions")
    if (after.require_comparable_conditions
            and before.isolate_attempts and not after.isolate_attempts):
        moved.append("isolate_attempts")
    return sorted(moved)


def produced_results(run: CodingRun) -> bool:
    """Whether this run had an outcome to see, whatever that outcome was.

    A failed attempt is a result: knowing an approach failed is exactly the kind
    of knowledge that can tempt a change to the rules.
    """
    return (run.result is not None or run.patch_evidence is not None
            or run.state in {RunState.COMPLETED, RunState.FAILED, RunState.CANCELLED})
