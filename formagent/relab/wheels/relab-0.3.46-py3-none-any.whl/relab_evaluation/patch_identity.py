"""When two attempts proposed the same change.

`fingerprints.py` answers "did it fail the same way". This answers "was it the
same edit", and the two together separate a model exploring a space where
everything fails alike from a model repeating itself. The first is a hard
problem; the second is a convergence failure and much cheaper to name.

The rules here are AutoCode's, re-derived rather than carried over. Its
`normalized_patch_fingerprint` normalises away hunk line numbers, blob hashes,
trailing whitespace and file-section order -- everything a model can vary while
proposing the *same* change -- and nothing that could alter what the patch does.
Two diffs sharing this digest really are the same edit.

Line endings are collapsed first, and that is not cosmetic. A diff is emitted in
its target file's newline style, and Git for Windows with `core.autocrlf=true`
hands a file back as CRLF, so an identical edit can come back byte-different.
A digest that missed this would report "not a repeat" on Windows exactly where
one is staring at the reader -- an artefact of the host read as a property of the
model, and this repository is developed on Windows.
"""

import hashlib
import re

_HUNK_HEADER = re.compile(r"^@@ -\d+(?:,\d+)? \+\d+(?:,\d+)? @@.*$", re.MULTILINE)
_BLOB_INDEX = re.compile(r"^index [0-9a-f]+\.\.[0-9a-f]+(?: \d+)?$", re.MULTILINE)
_FILE_HEADER = "diff --git "


def patch_digest(diff: str) -> str:
    """Identity of an edit, up to how it happens to be written down."""
    text = _BLOB_INDEX.sub("index", diff.replace("\r\n", "\n"))
    text = _HUNK_HEADER.sub("@@", text)
    sections: list[list[str]] = []
    for line in (item.rstrip() for item in text.splitlines()):
        if line.startswith(_FILE_HEADER) or not sections:
            sections.append([])
        sections[-1].append(line)
    # Sorted, so the same edits described in a different order are one edit.
    parts = sorted(part for part in ("\n".join(item).strip() for item in sections) if part)
    # NUL-joined: the parts are arbitrary text, and a printable separator would
    # let one section's content forge a boundary into another's.
    return hashlib.sha256("\x00".join(parts).encode("utf-8")).hexdigest()[:16]
