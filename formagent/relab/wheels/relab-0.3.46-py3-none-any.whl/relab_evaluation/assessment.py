"""Apply a pre-registered policy to a pre-registered design over stored evidence."""

from relab_core.evaluation import (
    CodingMetrics,
    DecisionSupport,
    MetricComparison,
    MetricRegistry,
)
from relab_core.research import (
    CodingRunReference,
    ResearchArmAssessment,
    ResearchPlan,
    ResearchSessionAssessment,
)
from relab_core.runs import RunEvent
from relab_evaluation.comparison import compare_metrics
from relab_evaluation.conditions import compare_conditions
from relab_evaluation.metrics import extract_coding_metrics
from relab_evaluation.readiness import assess_readiness
from relab_evaluation.repeatability import assess_repeatability


def assess_session(
    session_id: str, event_sequence: int, plan: ResearchPlan,
    pinned: list[tuple[CodingRunReference, RunEvent]],
) -> ResearchSessionAssessment:
    """Judge only a fully covered design; partial evidence yields no metric claim."""
    readiness = assess_readiness(session_id, event_sequence, plan, pinned)
    report = ResearchSessionAssessment(
        session_id=session_id, event_sequence=event_sequence, readiness=readiness,
        passed=False, reason="the declared experiment design is not covered by pinned evidence",
    )
    if not readiness.ready:
        return report
    events = {event.run_id: event for _, event in pinned}
    covered = [run.run_id for arm in readiness.arms for run in arm.runs if run.usable]
    report.conditions = compare_conditions(
        "design", [(run_id, events[run_id].snapshot.conditions) for run_id in covered],
        require_revision=plan.isolate_attempts)
    samples: dict[str, list[CodingMetrics]] = {}
    for arm in readiness.arms:
        # Readiness already proved every run here is verified and reports each metric.
        usable = [extract_coding_metrics(events[run.run_id]) for run in arm.runs if run.usable]
        samples[arm.arm] = usable
        report.arms.append(ResearchArmAssessment(
            arm=arm.arm, run_ids=[sample.run_id for sample in usable],
            repeatability=None if plan.repeats_per_arm < 2 else assess_repeatability(
                usable, plan.registry, minimum_runs=plan.repeats_per_arm),
            conditions=compare_conditions(
                arm.arm, [(sample.run_id, events[sample.run_id].snapshot.conditions)
                          for sample in usable], require_targets=True,
                require_revision=plan.isolate_attempts),
        ))
    report.comparisons, report.unpaired_run_ids = paired_comparisons(
        plan, samples, plan.registry)
    if plan.require_comparable_conditions:
        incomparable = [item.conditions for item in report.arms
                        if item.conditions is not None and not item.conditions.comparable]
        if not report.conditions.comparable:
            # Incomparable evidence makes the remaining rules meaningless, not merely weaker.
            report.reason = ("the plan requires comparable conditions: "
                             + "; ".join(report.conditions.reasons))
            return report
        if incomparable:
            # Not only independence now: an arm's repeats must also have been
            # measured by the same command, so the wording says what it means.
            report.reason = ("the plan requires comparable conditions, and these arms' "
                             "repeats did not share them: "
                             + ", ".join(item.scope for item in incomparable))
            return report
    failed = [arm.arm for arm in report.arms
              if arm.repeatability is not None and not arm.repeatability.passed]
    if failed:
        report.reason = f"observed spread exceeded the planned tolerance: {', '.join(failed)}"
        return report
    if not all(comparison.passed for comparison in report.comparisons):
        report.reason = "a planned comparison did not pass its metric rules"
        # The one case where evidence carries a conclusion the rules did not
        # reach: a comparison that ran and did not pass is a result about the
        # candidate, not an absence of one.
        report.decision_support = DecisionSupport.SUPPORTS_REJECTION
        report.support_reason = (
            "a planned comparison ran and did not pass, which is an answer about the "
            "candidate rather than the lack of one")
        return report
    report.passed = True
    report.identical_everywhere = identical_everywhere(samples, plan.registry)
    report.reason = (
        "the planned comparison and range rules passed; this is not a research conclusion"
        if report.comparisons else
        "the planned range rules passed; the plan designates no comparison"
    )
    if report.identical_everywhere:
        report.reason += (
            "; and " + ", ".join(report.identical_everywhere)
            + " took one value in every run, so the rules held without telling the arms apart"
        )
    report.decision_support, report.support_reason = _support(report, plan)
    return report


def _support(
    report: ResearchSessionAssessment, plan: ResearchPlan,
) -> tuple[DecisionSupport, str]:
    """Whether evidence that satisfied the rules can also carry a conclusion.

    Asked only of a report that passed, because a comparison that did not pass
    has already answered. What is left is the case a live session produced: ten
    admissible readings, every rule held, and `pass_rate` identical in all ten,
    because the verifier's single check was that the module imported and both
    arms import. Nothing there supports accepting the candidate, and nothing
    refutes it either.

    **A tie is not read as success, and not because ties never are.** A study
    asking "is the candidate better" and a study asking "is the candidate no
    worse" are answered oppositely by the same numbers, and a `MetricRule`
    records a direction and a tolerance without saying which question was
    asked. So an unvaried deciding metric is inconclusive *here*, and the reason
    says it is the plan that cannot tell them apart -- not the evidence. A plan
    able to declare non-inferiority as its criterion would change this answer,
    and would be a change to the plan rather than to this rule.
    """
    if not report.comparisons:
        return (DecisionSupport.INCONCLUSIVE, (
            "the plan designates no comparison, so its evidence answers no question "
            "about a candidate"))
    deciding = sorted({rule.name for rule in plan.registry.rules}
                      & set(report.identical_everywhere))
    if deciding:
        return (DecisionSupport.INCONCLUSIVE, (
            f"{', '.join(deciding)} took one value in every run of every arm, so the "
            f"comparison could not have come out differently; whether a tie is the "
            f"result this study wanted is not something the recorded rules say"))
    return (DecisionSupport.SUPPORTS_ACCEPTANCE, (
        "the planned comparison passed on a metric that varied, so it could have "
        "failed and did not"))


def identical_everywhere(
    samples: dict[str, list[CodingMetrics]], registry: MetricRegistry,
) -> list[str]:
    """Rules whose value was the same in every usable run of every arm.

    A rule can be satisfied by evidence that contains no finding. `maximize
    pass_rate` is held by 0.0 against 0.0, because neither is worse than the
    other, and an assessment that says only "every pre-registered rule held" is
    then true and useless -- which is what a live session reported after both arms
    were measured by a verifier counting tests nobody had been asked to write.

    Two arms genuinely tying is a legitimate result, so this refuses nothing. It
    is an observation about the evidence, offered where a person can see it
    before recording a decision, because the alternative is that they cannot tell
    that result from a real one.

    A single run is not evidence of sameness and is left out: there is nothing for
    one number to be identical to.
    """
    if sum(len(group) for group in samples.values()) < 2:
        return []
    names = []
    for rule in registry.rules:
        seen = {sample.metrics[rule.name] for group in samples.values()
                for sample in group if rule.name in sample.metrics}
        if len(seen) == 1:
            names.append(rule.name)
    return names


def paired_comparisons(
    plan: ResearchPlan, samples: dict[str, list[CodingMetrics]], registry: MetricRegistry,
) -> tuple[list[MetricComparison], list[str]]:
    """Pair runs by attachment order; this is sequence alignment, not statistical matching.

    The registry is a parameter so a holdout judges the same pairs the selection did,
    under different rules, rather than aligning them its own way.
    """
    if plan.candidate_arm is None or plan.baseline_arm is None:
        return [], []
    candidates, baselines = samples[plan.candidate_arm], samples[plan.baseline_arm]
    pairs = min(len(candidates), len(baselines))
    return (
        [compare_metrics(candidates[index], baselines[index], registry)
         for index in range(pairs)],
        [sample.run_id for group in (candidates, baselines) for sample in group[pairs:]],
    )
