"""Reading an arm's failed attempts out of the evidence they left.

Pure, and given snapshots rather than a store, so the same derivation serves the
read-only surface and the execution path without either importing the other --
and so there is exactly one answer to "what has this arm already failed with".
"""

from collections.abc import Mapping, Sequence

from relab_core.provider import produced_an_attempt
from relab_core.repair import MAXIMUM_ATTEMPTS, RepairAttempt, RepairHistory
from relab_core.research import ResearchRunReadiness
from relab_core.runs import CodingRun
from relab_evaluation.fingerprints import fingerprint
from relab_evaluation.patch_identity import patch_digest


def repair_history(
    session_id: str, arm: str, runs: Sequence[ResearchRunReadiness],
    snapshots: Mapping[str, CodingRun],
) -> RepairHistory:
    """Every attempt on this arm that produced no usable evidence.

    An attempt, and not every run. A call the provider lost, or that the model
    answered without proposing anything, produced no patch and ran no verifier --
    so counting it here would put "arm has 1 failed attempt" in front of a person
    about an arm that was never tried. Fixing the budget accounting and leaving
    this projection alone would bring the same confusion back by another route.
    """
    attempts = [
        _attempt(item.run_id, item.event_sequence, arm, item.reason,
                 snapshots.get(item.run_id))
        for item in runs
        if not item.usable and _was_attempted(snapshots.get(item.run_id))
    ]
    return RepairHistory(session_id=session_id, arm=arm,
                         attempts=attempts[-MAXIMUM_ATTEMPTS:])


def _attempt(
    run_id: str, event_sequence: int, arm: str, reason: str,
    run: CodingRun | None,
) -> RepairAttempt:
    evidence = None if run is None else run.patch_evidence
    verification = None if evidence is None else evidence.verification
    proposal = None if run is None else run.proposal
    return RepairAttempt(
        run_id=run_id, event_sequence=event_sequence, arm=arm,
        reason=reason or "no usable evidence",
        # An attempt that never reached a verifier has nothing to fingerprint. It
        # is still recorded: failing before running is part of what happened.
        fingerprint=None if verification is None else fingerprint(verification),
        patch_digest=None if proposal is None else patch_digest(proposal.diff),
    )


def _was_attempted(run: CodingRun | None) -> bool:
    """Whether this run got far enough to be one of the arm's attempts.

    Unknown runs count: a missing snapshot is a gap in what can be read, not
    evidence that nothing happened, and silently dropping those would understate
    the failures rather than clarify them.
    """
    return run is None or produced_an_attempt(run.provider_incident)
