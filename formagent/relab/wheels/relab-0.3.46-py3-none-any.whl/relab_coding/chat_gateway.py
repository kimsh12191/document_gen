"""Explicit OpenRouter or loopback vLLM chat-completions gateway."""

import ast
import contextlib
import copy
import errno
import http.client
import json
import math
import re
import socket
import ssl
import threading
import time
from collections.abc import Callable
from typing import Any
from urllib.parse import urlsplit

from relab_coding.ollama import MAXIMUM_REQUEST_BYTES, ModelTransportError, undeclared
from relab_coding.usage import parse_usage
from relab_core.generation import CallTiming, ModelIdentity, ModelReply, ToolCall, ToolReply
from relab_core.provider import ProviderIncident, RequestRefusal

# What every request carries unless a caller says otherwise: a bound on the reply,
# and nothing else.
#
# `temperature` is deliberately absent. With OpenRouter's `require_parameters`,
# a parameter the chosen model does not accept leaves no eligible provider and the
# answer is HTTP 404 -- which is what a live call against openai/gpt-5-mini
# returned. A generation parameter whose support is uncertain is safer not sent
# than sent hopefully, and a caller that needs one can say so.
#
# There is no special case keyed on a model name. A gateway that inspected "is
# this a GPT-5?" would be carrying a table of provider trivia that goes stale
# silently, and the first model outside the table would fail the same way with
# nobody the wiser.
DEFAULT_OPTIONS: dict[str, object] = {"max_tokens": 4096}
# How long asking a server for its window may take, in all.
LIMITS_SECONDS = 3.0
# How long a larger model's server is given to answer before a loop moves up to it (0.2.98).
REACHABLE_SECONDS = 10.0

# How long a streamed call may take in all; a call not streamed keeps 600.
MAXIMUM_STREAMED_SECONDS = 1800
# How much a streamed reply may say -- its text, thinking and tool calls, as UTF-8 -- and
# how much it may carry with its framing, a bound only for a reply that never ends (0.3.35).
# Framing alone was 4 MiB: vLLM sends each token in about 200 bytes of JSON, so a reply was
# cut near 20,000 tokens while 32,768 were asked for, and a model thinking long never answered.
MAXIMUM_REPLY_BYTES = 4 * 1024 * 1024
MAXIMUM_STREAMED_BYTES = 64 * 1024 * 1024
# One line of the stream, one piece of it.
MAXIMUM_LINE_BYTES = 4 * 1024 * 1024
# OpenRouter's reasoning efforts.
REASONING_EFFORTS = {"minimal", "low", "medium", "high"}
# OpenRouter's orderings of the providers that serve a model.
PROVIDER_SORTS = {"price", "throughput", "latency"}
# The sampling a person may set for a model (0.3.38), and the range each takes. None is sent
# unless set: see DEFAULT_OPTIONS for why -- a model that refuses one on OpenRouter has no
# provider left. Set, it is the person's to choose, as for Cline: compare the two the same.
SAMPLING_RANGES: dict[str, tuple[float, float]] = {"temperature": (0.0, 2.0), "top_p": (0.0, 1.0)}


def parse_sampling(text: str) -> dict[str, float]:
    """`temperature=0.6, top_p=0.95` -- either, both, by commas or spaces; ValueError if not."""
    found: dict[str, float] = {}
    for part in re.sub(r"\s*=\s*", "=", text).replace(",", " ").split():
        name, equals, value = part.partition("=")
        name = name.strip().lower().replace("-", "_")
        if not equals or name not in SAMPLING_RANGES:
            raise ValueError(f"sampling reads temperature=N and/or top_p=N; {part!r} does not")
        try:
            number = float(value)
        except ValueError:
            raise ValueError(f"{name} is a number; {value!r} is not") from None
        low, high = SAMPLING_RANGES[name]
        if not math.isfinite(number) or not low <= number <= high or (name == "top_p" and number == 0):
            raise ValueError(f"{name} is between {low:g} and {high:g}"
                             f"{' (above 0)' if name == 'top_p' else ''}; {value!r} is not")
        if name in found:
            raise ValueError(f"{name} is given twice")
        found[name] = number
    return found


# How often a streamed reply is said to be shaping up, to whoever shows it.
DRAFTING_SECONDS = 1.0
# What a listener is told the reply is, while the model is still thinking.
THINKING = "(thinking)"
# Where a parsed body carries this side's measurement of the call, and where a
# stream says when its first piece came: keys no provider sends (RL-02).
TIMING = "_relab_timing"
FIRST_TOKEN = "_relab_first_token"
# How much of a refused request's body is read to say what it was about.
REFUSAL_BYTES = 8192
# What servers write when they refuse, by kind, the context first: a long
# prompt with tools is refused for its length (RL-05).
REFUSALS = (
    (RequestRefusal.CONTEXT_LENGTH, re.compile(
        r"context length|context window|maximum context|max_model_len|max_tokens.*exceed"
        r"|too many tokens|prompt is too long|input is too long|reduce the length", re.IGNORECASE)),
    # Before the tools: a server's message about an image part names neither tools nor a schema.
    (RequestRefusal.IMAGES, re.compile(
        r"multi-?modal|image input|images? (?:are|is) not supported|does not support images?"
        r"|not support(?:ed)? (?:for )?images?|unknown part type: image|image_url", re.IGNORECASE)),
    (RequestRefusal.TOOLS, re.compile(
        r"tool[_ -]?choice|tool[_ -]call[_ -]parser|enable-auto-tool-choice|tools? (?:are|is) not "
        r"supported|does not support tools|function calling is not", re.IGNORECASE)),
    (RequestRefusal.SCHEMA, re.compile(
        r"response_format|json_schema|guided_json|structured output|guided decoding",
        re.IGNORECASE)),
)


def openrouter_routing(sort: str | None) -> dict[str, object]:
    """Which of OpenRouter's providers may serve a call.

    Only one taking every parameter sent (`require_parameters`): a reply schema
    is never silently dropped. Fallbacks are allowed among those (from 0.2.20):
    with them off, the first provider's rate limit was the call's -- live, every
    plain-text call (an analysis report, a summary) went to the fastest provider,
    which answered HTTP 429 every time, while the others answered at once.
    """
    return {"require_parameters": True, "allow_fallbacks": True,
            **({"sort": sort} if sort else {})}


def refusal_of(body: bytes) -> RequestRefusal | None:
    """What a refused request's body says it was about, from `REFUSALS`; its words are not kept."""
    text = body.decode("utf-8", errors="replace")
    return next((kind for kind, words in REFUSALS if words.search(text)), None)


# How servers say the prompt they refused for its length, and their window (vLLM's
# forms over its versions, OpenAI's): numbers only are taken from them (0.3.18).
PROMPT_TOKENS = (
    re.compile(r"\((\d[\d,]*) in the messages"),
    re.compile(r"requested (\d[\d,]*) tokens in the messages"),
    re.compile(r"request has (\d[\d,]*) input tokens"),
    re.compile(r"prompt contains (?:at least )?(\d[\d,]*) input tokens"),
    re.compile(r"messages resulted in (\d[\d,]*) tokens"),
)
CONTEXT_WINDOW = re.compile(r"maximum context length is (\d[\d,]*) tokens")


def told_lengths(body: bytes) -> tuple[int | None, int | None]:
    """A length refusal's own count of the prompt, and the model's window, when it says them.

    The prompt was estimated from its characters, and for a JSON of Korean
    labels that ran at a third of its tokens: the server's count is the measure.
    """
    text = body.decode("utf-8", errors="replace")
    prompt = next((match for words in PROMPT_TOKENS for match in [words.search(text)] if match), None)
    window = CONTEXT_WINDOW.search(text)
    return (int(prompt.group(1).replace(",", "")) if prompt else None,
            int(window.group(1).replace(",", "")) if window else None)

# The most room a caller may ask a reply to take. Not a policy about cost -- the
# provider's own limit is far lower for most models -- but a bound on a number
# that reaches the wire, so a mistyped one is refused here rather than billed.
MAXIMUM_REPLY_TOKENS = 200_000

# What a provider may say about why it stopped, and what each means for whoever
# has to act on it. Anything outside this is reported as unrecognised rather than
# echoed: `finish_reason` is a string the provider controls, and
# `ModelTransportError` is documented as safe to display.
STOP_REASONS = {
    "length": (ProviderIncident.OUTPUT_LIMIT,
               ("The reply was cut off by the token limit; "
                "raise max_tokens or ask for a smaller design")),
    "content_filter": (ProviderIncident.CONTENT_FILTER,
                       "The provider's content filter stopped the reply"),
    "tool_calls": (ProviderIncident.TOOL_CALL,
                   "The model tried to call a tool, which this gateway does not offer"),
    "error": (ProviderIncident.TRANSPORT,
              "The provider reported an error partway through the reply"),
}


def _spent(usage: object, asked: object) -> str:
    """What the reply cost against what it was allowed, when the provider says.

    "raise max_tokens" is advice; this is the measurement that sizes it. A budget
    was raised once on reasoning about how long a design is, the next live call
    was cut off again, and nothing in the failure said by how much -- so the
    second guess had no more to go on than the first.

    Reported as counts, which are the provider's own integers. Nothing it wrote
    reaches this string, because `ModelTransportError` is documented as safe to
    display.
    """
    if not isinstance(usage, dict):
        return ""
    completion = usage.get("completion_tokens")
    if not isinstance(completion, int):
        return ""
    limit = f" of {asked} allowed" if isinstance(asked, int) else ""
    return f" (the reply spent {completion} completion tokens{limit})"


def why_unusable(choice: object) -> tuple[ProviderIncident, str] | None:
    """Why this reply cannot be read, or None when it can.

    Five conditions used to share the sentence "Incomplete or unsupported model
    response", which named none of them. A reply cut off by `max_tokens`, a model
    declining the request, and a provider returning no text at all need three
    different responses from whoever reads the message, and telling them apart by
    re-running with a packet capture is not a reasonable thing to ask.

    Nothing the provider wrote is quoted. `finish_reason` is matched against the
    reasons above and otherwise reported as unrecognised, and a refusal is
    reported as having happened rather than repeated: this error is documented as
    safe to display, and text from a model is not.
    """
    if not isinstance(choice, dict):
        return ProviderIncident.TRANSPORT, "The provider returned a choice that is not an object"
    stopped = choice.get("finish_reason")
    if stopped != "stop":
        if isinstance(stopped, str) and stopped in STOP_REASONS:
            return STOP_REASONS[stopped]
        # Including None, which is what a provider sends for a reply still in
        # flight -- and what arrives when a stream is read as though it were not.
        return ProviderIncident.INCOMPLETE, "The model stopped for an unrecognised reason"
    message = choice.get("message")
    if not isinstance(message, dict):
        return ProviderIncident.TRANSPORT, "The provider returned no message"
    if message.get("refusal"):
        # The model's own answer, not an accident of the wire.
        return ProviderIncident.REFUSED, "The model declined to answer this request"
    if message.get("tool_calls"):
        return (ProviderIncident.TOOL_CALL,
                "The model tried to call a tool, which this gateway does not offer")
    if not isinstance(message.get("content"), str):
        return ProviderIncident.INCOMPLETE, "The model returned no text content"
    return None


def _image_bytes(content: object) -> int:
    """How much the images of one message's content carry, as sent."""
    if not isinstance(content, list):
        return 0
    found = 0
    for part in content:
        if isinstance(part, dict) and part.get("type") == "image_url":
            image = part.get("image_url")
            if isinstance(image, dict):
                found += len(str(image.get("url", "")))
    return found


def network_reason(error: BaseException) -> str:
    """Why a request failed on the way, as one of a closed set of phrases."""
    if isinstance(error, json.JSONDecodeError | UnicodeError):
        return "the reply was not JSON"
    if isinstance(error, ssl.SSLCertVerificationError):
        return "certificate not trusted"
    if isinstance(error, ssl.SSLError):
        return "TLS handshake failed"
    if isinstance(error, socket.gaierror):
        return "host name not found"
    if isinstance(error, ConnectionRefusedError):
        return "connection refused"
    if isinstance(error, http.client.RemoteDisconnected):
        return "the server closed the connection"
    if isinstance(error, ConnectionResetError):
        return "connection reset"
    if isinstance(error, http.client.HTTPException):
        return "the reply was not HTTP"
    if isinstance(error, OSError) and error.errno in (errno.ENETUNREACH, errno.EHOSTUNREACH):
        return "network unreachable"
    return f"network error ({type(error).__name__})"



def cut_off(sent: object, usage: object, asked: object) -> bool:
    """Whether arguments that could not be read were cut short, not written wrong (0.3.41).

    Found in use: at 97k of a 128k window a model wrote a whole file in one `write_file`; the
    reply ran past the room it was given and vLLM still said `tool_calls`, so the arguments
    ended inside the file's text and read as "Unterminated string". Cut short: the provider
    counted the reply at the bound it was asked for, or the arguments never reach the `}`
    that closes them. Arguments written wrong but whole -- raw line breaks, single quotes --
    still close, and stay the model's to resend.
    """
    if isinstance(usage, dict):
        completion = usage.get("completion_tokens")
        if isinstance(completion, int) and isinstance(asked, int) and asked > 0 and completion >= asked:
            return True
    if not isinstance(sent, str):
        return False
    text = sent.strip()
    if text.startswith("```"):
        text = text.strip("`").removeprefix("json").strip()
    return text.startswith("{") and not text.endswith("}")


def tool_arguments(sent: object) -> tuple[dict[str, object] | None, str | None]:
    """A tool call's arguments as an object; else None and what was wrong, said shortly.

    Found in use (0.2.33): a local model's `run` carried a Python one-liner with
    its line breaks written raw inside the JSON string, which strict JSON
    refuses; the call was "not a JSON object" three times and the loop ended.
    Read, in turn: as JSON allowing raw control characters; a JSON string that
    holds the object (sent twice encoded); the same inside a Markdown fence; a
    Python dict literal. Nothing at all is an empty object, which the step's
    own checks then say what it lacks.
    """
    if isinstance(sent, dict):
        return sent, None
    if sent is None or (isinstance(sent, str) and not sent.strip()):
        return {}, None
    if not isinstance(sent, str):
        return None, f"a {type(sent).__name__}, not an object"
    text = sent.strip()
    if text.startswith("```"):
        text = text.strip("`").removeprefix("json").strip()
    problem = "not JSON"
    for attempt in range(2):
        try:
            value: object = json.loads(text, strict=False)
        except json.JSONDecodeError as error:
            problem = f"{error.msg} at line {error.lineno}, column {error.colno}"
            break
        if isinstance(value, dict):
            return value, None
        if isinstance(value, str) and attempt == 0:
            text = value.strip()
            continue
        problem = f"a JSON {type(value).__name__}, not an object"
        break
    if text.startswith("{"):
        try:
            literal = ast.literal_eval(text)
        except (ValueError, SyntaxError, MemoryError, RecursionError):
            literal = None
        if isinstance(literal, dict) and all(isinstance(key, str) for key in literal):
            return literal, None
    shown = text[:200].replace("\n", "\\n")
    return None, f"{problem}; it began: {shown}"[:400]

class ChatGateway:
    def __init__(self, provider: str, model: str, *, endpoint: str | None = None,
                 api_key: str | None = None,
                 response_contract: dict[str, object] | None = None,
                 generation_options: dict[str, object] | None = None,
                 stream_idle_seconds: float | None = None,
                 provider_sort: str | None = None,
                 reasoning_effort: str | None = None,
                 sampling: dict[str, float] | None = None,
                 declared: bool = False) -> None:
        # `declared`: the person named this endpoint for this use -- in the
        # editor's settings or with --allow-endpoint -- so a vLLM or Ollama
        # server on another machine, by http or https, is reached. Undeclared,
        # only this machine is, as before.
        # How hard a reasoning model thinks, as OpenRouter's `reasoning.effort`;
        # None leaves the model's own default. A live call thought for 521
        # seconds before choosing to run one command.
        if reasoning_effort is not None and reasoning_effort not in REASONING_EFFORTS:
            raise ValueError(f"reasoning_effort is one of {sorted(REASONING_EFFORTS)}")
        self.reasoning_effort = reasoning_effort
        # Told, while a streamed reply arrives, the tool call it is writing
        # ("" for a reply in text) and its text so far; at most every
        # DRAFTING_SECONDS. Set by whoever shows it, None by default. It must
        # not raise; anything it does raise is dropped.
        self.drafting: Callable[[str, str], None] | None = None
        # Streamed, a reply is waited on while it keeps arriving and given up
        # on only when nothing has come for this long. Not streamed, a call
        # that took 293 seconds and one that hung for 300 look alike, and a
        # live loop failed on the second with the first still in its history.
        if stream_idle_seconds is not None and (
                not math.isfinite(stream_idle_seconds) or not 0 < stream_idle_seconds <= 600):
            raise ValueError("the idle timeout must be between 0 and 600 seconds")
        self.stream_idle_seconds = stream_idle_seconds
        # Which of OpenRouter's providers for the model to try first, by its
        # own ordering; None leaves its default.
        if provider_sort is not None and provider_sort not in PROVIDER_SORTS:
            raise ValueError(f"provider_sort is one of {sorted(PROVIDER_SORTS)}")
        self.provider_sort = provider_sort
        # Temperature and top_p as the person set them for this model (0.3.38); none, nothing sent.
        if sampling and (set(sampling) - set(SAMPLING_RANGES) or not all(
                isinstance(value, (int, float)) and SAMPLING_RANGES[name][0] <= value <= SAMPLING_RANGES[name][1]
                for name, value in sampling.items())):
            raise ValueError("sampling is temperature (0-2) and top_p (0-1)")
        self.sampling = dict(sampling or {})
        # What a reply must look like, when the caller knows. A gateway that chose
        # this for itself would be a code-edit adapter wearing a general name --
        # which is what this one was, and what the first live call found.
        self.response_contract = response_contract
        # Generation parameters, likewise declared rather than assumed. See
        # DEFAULT_OPTIONS for why the default is as small as it is.
        self.generation_options = generation_options
        if provider not in {"openrouter", "vllm", "openai", "ollama"}:
            raise ValueError("unsupported chat provider")
        if not model.strip() or len(model) > 256 or any(ord(c) < 32 for c in model):
            raise ValueError("invalid model name")
        if api_key is not None and (not api_key or any(
                ord(c) <= 32 or ord(c) >= 127 for c in api_key)):
            raise ValueError("invalid API key")
        if provider == "openrouter":
            if endpoint not in {None, "https://openrouter.ai/api/v1"}:
                raise ValueError("OpenRouter requires its fixed HTTPS endpoint")
            if api_key is None:
                raise ValueError("OPENROUTER_API_KEY is required")
            self.host, self.port, self.path = "openrouter.ai", 443, "/api/v1/chat/completions"
        elif provider == "openai":
            if endpoint not in {None, "https://api.openai.com/v1"}:
                raise ValueError("OpenAI requires its fixed HTTPS endpoint")
            if api_key is None:
                raise ValueError("OPENAI_API_KEY is required")
            self.host, self.port, self.path = "api.openai.com", 443, "/v1/chat/completions"
        else:
            # vLLM, or Ollama by its OpenAI-compatible endpoint: on this machine.
            named = "vLLM" if provider == "vllm" else "Ollama"
            endpoint = endpoint or ("http://127.0.0.1:8000/v1" if provider == "vllm"
                                    else "http://127.0.0.1:11434/v1")
            given = endpoint
            if urlsplit(endpoint).path.rstrip("/") == "":
                # The server's own address, as Ollama's other gateway and other
                # coding agents take it: its OpenAI-compatible API is under /v1.
                endpoint = endpoint.rstrip("/") + "/v1"
            if any(c.isspace() or ord(c) < 32 for c in endpoint):
                raise ValueError(f"invalid {named} endpoint")
            origin = urlsplit(endpoint)
            loopback = origin.hostname in {"127.0.0.1", "localhost", "::1"}
            well_formed = (origin.scheme in ("http", "https") and bool(origin.hostname)
                           and origin.username is None and origin.password is None
                           and origin.path.rstrip("/").endswith("/v1")
                           and not origin.query and not origin.fragment)
            if well_formed and not loopback and not declared:
                raise ValueError(undeclared(named, given))
            schemes = ("http", "https") if declared else ("http",)
            if (origin.scheme not in schemes or not origin.hostname
                    or not (loopback or declared)
                    or origin.username is not None or origin.password is not None
                    or not origin.path.rstrip("/").endswith("/v1")
                    or origin.query or origin.fragment):
                raise ValueError(f"{named} requires an HTTP loopback endpoint ending in /v1, "
                                 f"or one the person declared (--allow-endpoint)")
            self.secure = origin.scheme == "https"
            self.host = "127.0.0.1" if origin.hostname == "localhost" else origin.hostname
            self.port = origin.port if origin.port is not None else (443 if self.secure else 80)
            if not 1 <= self.port <= 65535:
                raise ValueError(f"invalid {named} port")
            # Behind a gateway the API can sit under a prefix (`/qwen/v1`); the
            # requests go where the person's address says.
            self.path = origin.path.rstrip("/") + "/chat/completions"
        self.provider, self.model, self._api_key = provider, model, api_key
        # The context window the server said, asked once (`server_limits`).
        self._limits: int | None = None
        self._limits_asked = False
        self.secure = getattr(self, "secure", False)

    def variant(self, *, reasoning_effort: str | None) -> "ChatGateway":
        """This gateway, asking for another reasoning effort; the same provider and model."""
        if reasoning_effort is not None and reasoning_effort not in REASONING_EFFORTS:
            raise ValueError(f"reasoning_effort is one of {sorted(REASONING_EFFORTS)}")
        other = copy.copy(self)
        other.reasoning_effort = reasoning_effort
        return other

    @property
    def identity(self) -> ModelIdentity:
        return ModelIdentity.model_validate({"provider": self.provider, "model": self.model})

    def complete(self, prompt: str, *, timeout_seconds: float,
                 response_contract: dict[str, object] | None = None,
                 generation_options: dict[str, object] | None = None,
                 reply_tokens: int | None = None) -> str:
        return self.complete_chat([{"role": "user", "content": prompt}],
                                  timeout_seconds=timeout_seconds,
                                  response_contract=response_contract,
                                  generation_options=generation_options,
                                  reply_tokens=reply_tokens)

    def complete_chat(self, messages: list[dict[str, object]], *, timeout_seconds: float,
                      response_contract: dict[str, object] | None = None,
                      generation_options: dict[str, object] | None = None,
                      reply_tokens: int | None = None) -> str:
        """A conversation, answered in text: JSON under `response_contract` when one is given."""
        if not messages or not all(isinstance(item, dict) and item.get("role") in
                                   ("system", "user", "assistant") for item in messages):
            raise ValueError("messages are system, user or assistant messages")
        self._check_timeout(timeout_seconds)
        if reply_tokens is not None and (type(reply_tokens) is not int
                                         or not 1 <= reply_tokens <= MAXIMUM_REPLY_TOKENS):
            raise ValueError(
                f"reply_tokens must be an integer between 1 and {MAXIMUM_REPLY_TOKENS}")
        # Use the common schema subset; the bridge enforces size/newline constraints.
        payload: dict[str, object] = {
            "model": self.model, "messages": messages, "stream": False,
        }
        declared = self.generation_options
        if declared is None:
            declared = generation_options
        payload.update(DEFAULT_OPTIONS if declared is None else declared)
        if reply_tokens is not None and (declared is None or "max_tokens" not in declared):
            # `max_tokens` is this dialect's spelling for the room a reply needs.
            # It beats the default, which is a bound nobody chose for this call,
            # and loses to an explicit `generation_options` -- that is a caller
            # naming the wire parameter itself, and it keeps the last word.
            payload["max_tokens"] = reply_tokens
        contract = self.response_contract if response_contract is None else response_contract
        if contract is not None:
            # Only when a caller declared one. Sending a schema nobody asked for is
            # how a planner came to be told its design must look like a file edit.
            payload["response_format"] = {"type": "json_schema", "json_schema": {
                "name": "reply", "strict": True, "schema": contract}}
        if self.provider == "openrouter":
            payload["provider"] = openrouter_routing(self.provider_sort)
        self._streamed(payload)
        data = self._exchange(payload, timeout_seconds)
        choice = data["choices"][0]
        unusable = why_unusable(choice)
        if unusable is not None:
            incident, said = unusable
            raise ModelTransportError(
                said + _spent(data.get("usage"), payload.get("max_tokens")), incident)
        assert isinstance(choice, dict)
        message = choice["message"]
        content = message["content"]
        assert isinstance(content, str)
        return ModelReply(content, parse_usage(data.get("usage")), reported_model=data.get("model"),
                          timing=data.get(TIMING))

    def complete_tools(self, prompt: str, *, tools: list[dict[str, object]],
                       timeout_seconds: float, reply_tokens: int | None = None) -> ToolReply:
        """One prompt, with tools: a conversation of one message."""
        return self.complete_messages([{"role": "user", "content": prompt}], tools=tools,
                                      timeout_seconds=timeout_seconds, reply_tokens=reply_tokens)

    def complete_messages(self, messages: list[dict[str, object]], *,
                          tools: list[dict[str, object]], timeout_seconds: float,
                          reply_tokens: int | None = None) -> ToolReply:
        """Ask with tools the model may call, and return the calls it made, in order.

        `tool_choice` is "auto", the one every provider that takes tools takes:
        a model that answers in text instead is returned as text, for the
        caller to read as it would a reply without tools. A provider that does
        not take tools at all answers with a 4xx, carried as the error's
        `status`, so the caller can ask again without them.
        """
        self._check_timeout(timeout_seconds)
        if reply_tokens is not None and (type(reply_tokens) is not int
                                         or not 1 <= reply_tokens <= MAXIMUM_REPLY_TOKENS):
            raise ValueError(
                f"reply_tokens must be an integer between 1 and {MAXIMUM_REPLY_TOKENS}")
        if not tools or len(tools) > 64:
            raise ValueError("between 1 and 64 tools")
        if not messages or not all(isinstance(item, dict) and item.get("role") in
                                   ("system", "user", "assistant", "tool") for item in messages):
            raise ValueError("messages are system, user, assistant or tool messages")
        payload: dict[str, object] = {
            "model": self.model, "messages": messages,
            "stream": False, "tools": tools, "tool_choice": "auto",
        }
        declared = self.generation_options
        payload.update(DEFAULT_OPTIONS if declared is None else declared)
        if reply_tokens is not None and (declared is None or "max_tokens" not in declared):
            payload["max_tokens"] = reply_tokens
        if self.provider == "openrouter":
            payload["provider"] = openrouter_routing(self.provider_sort)
        self._streamed(payload)
        # Images ride along in the messages; the bound grows by what they carry.
        pictured = sum(_image_bytes(item.get("content")) for item in messages)
        data = self._exchange(payload, timeout_seconds, allowance=pictured)
        choice = data["choices"][0]
        if not isinstance(choice, dict) or not isinstance(choice.get("message"), dict):
            raise ModelTransportError("The provider returned no message", ProviderIncident.TRANSPORT)
        message = choice["message"]
        stopped = choice.get("finish_reason")
        called = message.get("tool_calls")
        if stopped not in ("stop", "tool_calls") or (stopped == "tool_calls" and not called):
            # Every other way of stopping means what it means without tools.
            unusable = why_unusable({**choice, "finish_reason": stopped
                                     if stopped != "tool_calls" else "stop"})
            incident, said = unusable or (ProviderIncident.INCOMPLETE,
                                          "The model stopped for an unrecognised reason")
            raise ModelTransportError(
                said + _spent(data.get("usage"), payload.get("max_tokens")), incident)
        if message.get("refusal"):
            raise ModelTransportError("The model declined to answer this request",
                                      ProviderIncident.REFUSED)
        calls = []
        for item in called if isinstance(called, list) else []:
            function = item.get("function") if isinstance(item, dict) else None
            name = function.get("name") if isinstance(function, dict) else None
            if not isinstance(name, str) or not 1 <= len(name) <= 64:
                raise ModelTransportError("A tool call named no tool", ProviderIncident.TRANSPORT)
            arguments = function.get("arguments") if isinstance(function, dict) else None
            parsed, problem = tool_arguments(arguments)
            if parsed is None and cut_off(arguments, data.get("usage"),
                                          payload.get("max_tokens", payload.get("max_completion_tokens"))):
                # Cut at the output limit, though said as a finished tool call (0.3.41): told to
                # escape its strings, a model sent the same large file three times and the loop ended.
                raise ModelTransportError(
                    "The model's reply was cut off at the output limit: a tool call's arguments end "
                    "unfinished" + _spent(data.get("usage"), payload.get("max_tokens")),
                    ProviderIncident.OUTPUT_LIMIT)
            calls.append(ToolCall(name=name, arguments=parsed, unreadable=problem))
        content = message.get("content")
        reply = ModelReply("", None, reported_model=data.get("model"))
        return ToolReply(content=content if isinstance(content, str) else "", calls=calls,
                         usage=parse_usage(data.get("usage")),
                         reported_model=reply.reported_model, timing=data.get(TIMING))

    def _check_timeout(self, timeout_seconds: float) -> None:
        bound = MAXIMUM_STREAMED_SECONDS if self.stream_idle_seconds is not None else 600
        if not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= bound:
            raise ValueError(f"model timeout must be finite and between 0 and {bound} seconds")

    def server_limits(self) -> int | None:
        """The model's context window as its server says it, asked once; None when it does not say.

        Asked for in use (0.2.35): a person had to declare each model's window by
        hand, and without it a long loop's prompt and its reply room could pass
        what the server takes. vLLM says `max_model_len` under `/v1/models`;
        OpenRouter and others `context_length`. Any failure is None: the loop
        goes on as before.
        """
        if self._limits_asked:
            return self._limits
        self._limits_asked = True
        if self.provider == "openai":
            return None
        path = ("/api/v1/models" if self.provider == "openrouter"
                else self.path.removesuffix("/chat/completions") + "/models")
        headers = {} if self._api_key is None else {"Authorization": "Bearer " + self._api_key}
        connection_type = (http.client.HTTPSConnection
                           if self.provider == "openrouter" or self.secure
                           else http.client.HTTPConnection)
        # Short, and bounded in all: it is asked before a loop's first call, and
        # a busy server must not hold the start (0.2.37).
        deadline = time.monotonic() + LIMITS_SECONDS
        try:
            connection = connection_type(self.host, self.port, timeout=LIMITS_SECONDS)
            try:
                connection.request("GET", path, headers=headers)
                response = connection.getresponse()
                body = b""
                while len(body) < 8_000_000 and time.monotonic() < deadline:
                    piece = response.read(65536)
                    if not piece:
                        break
                    body += piece
                else:
                    return None
            finally:
                connection.close()
            if response.status != 200:
                return None
            listed = json.loads(body).get("data")
        except (OSError, http.client.HTTPException, ValueError, AttributeError):
            return None
        for item in listed if isinstance(listed, list) else []:
            if isinstance(item, dict) and item.get("id") == self.model:
                for key in ("max_model_len", "context_length", "context_window"):
                    value = item.get(key)
                    if isinstance(value, int) and 1024 <= value <= 10_000_000:
                        self._limits = value
                        return value
        return None

    def reachable(self) -> bool | None:
        """Whether this model's server answers its model list within REACHABLE_SECONDS.

        Asked before a loop moves up to a larger model (0.2.98): in use the top
        model's server was down, the loop moved up anyway, and waited out the
        whole call timeout and its retries before going back. None where it
        cannot be asked (OpenAI's list is not this kind of check); a refusal,
        a timeout or an error status is False.
        """
        if self.provider == "openai":
            return None
        path = ("/api/v1/models" if self.provider == "openrouter"
                else self.path.removesuffix("/chat/completions") + "/models")
        headers = {} if self._api_key is None else {"Authorization": "Bearer " + self._api_key}
        connection_type = (http.client.HTTPSConnection
                           if self.provider == "openrouter" or self.secure
                           else http.client.HTTPConnection)
        try:
            connection = connection_type(self.host, self.port, timeout=REACHABLE_SECONDS)
            try:
                connection.request("GET", path, headers=headers)
                status = connection.getresponse().status
            finally:
                connection.close()
        except (OSError, http.client.HTTPException):
            return False
        return status == 200

    def _streamed(self, payload: dict[str, object]) -> None:
        """Ask for the reply as a stream, when this gateway streams; how hard to think; how to sample."""
        payload.update(self.sampling)
        if self.reasoning_effort is not None and self.provider == "openrouter":
            payload["reasoning"] = {"effort": self.reasoning_effort}
        if self.reasoning_effort in ("minimal", "low") and self.provider == "vllm":
            # A thinking model on vLLM (Qwen3 and the like) asked to think less:
            # its chat template's switch, which templates without it ignore
            # (0.2.35: reasoning took the room a file's content needed).
            payload["chat_template_kwargs"] = {"enable_thinking": False}
        if self.provider == "openai":
            # OpenAI's reasoning models take the reply's room as
            # `max_completion_tokens`, and refuse `max_tokens`.
            if "max_tokens" in payload:
                payload["max_completion_tokens"] = payload.pop("max_tokens")
            if self.reasoning_effort is not None:
                payload["reasoning_effort"] = self.reasoning_effort
        if self.stream_idle_seconds is None:
            return
        payload["stream"] = True
        if self.provider in ("vllm", "openai", "ollama"):
            # OpenRouter reports usage in its last chunk unasked; vLLM is
            # asked. Not sent to OpenRouter, whose `require_parameters` would
            # count it as one more parameter a provider must take.
            payload["stream_options"] = {"include_usage": True}

    def _read_stream(self, response: "http.client.HTTPResponse", expired: threading.Event,
                     deadline: float, begun: socket.socket | None = None) -> dict[str, Any]:
        """A streamed reply, assembled into the shape a reply that was not streamed has.

        Server-sent events, a `data:` line per chunk until `[DONE]`; a comment
        line (`: PROCESSING`) is the provider saying it is still there. Text,
        the tool calls in their pieces by index, the reason it stopped and the
        usage are put together so the caller reads one reply either way. A
        read that waits longer than the idle timeout is a stall, said as one;
        running out of the whole timeout while chunks still came is a timeout.

        Only a chunk counts as the reply coming. OpenRouter sends `: OPENROUTER
        PROCESSING` every few seconds while no provider has begun, and a
        benchmark lost thirteen runs to calls kept open that way for 600 seconds
        each: comments alone for the idle timeout are a stall too.
        """
        content: list[str] = []
        thinking: list[str] = []
        calls: dict[int, dict[str, Any]] = {}
        finish: object = None
        refusal: object = None
        usage: object = None
        model: object = None
        received = 0
        said = 0
        first: float | None = None
        progress = time.monotonic()
        said_at = progress
        while True:
            try:
                line = response.readline(MAXIMUM_LINE_BYTES + 1)
            except TimeoutError as error:
                if expired.is_set() or time.monotonic() >= deadline:
                    raise
                raise ModelTransportError(
                    f"The reply stopped arriving for {self.stream_idle_seconds:g} seconds",
                    ProviderIncident.TIMEOUT, stalled=True) from error
            if expired.is_set() or time.monotonic() >= deadline:
                raise ModelTransportError("Model request timed out", ProviderIncident.TIMEOUT)
            if not line:
                break
            received += len(line)
            if len(line) > MAXIMUM_LINE_BYTES:
                raise ModelTransportError("A line of the streamed reply exceeds 4 MiB", ProviderIncident.TRANSPORT)
            if received > MAXIMUM_STREAMED_BYTES:
                # Too long, not a fault of the wire (0.3.35): asked again as it was, the model
                # went as long again -- three calls, 700 seconds, the loop ended.
                raise ModelTransportError("Model response exceeds 64 MiB with its framing",
                                          ProviderIncident.OUTPUT_LIMIT)
            text = line.strip()
            if not text or text.startswith(b":") or not text.startswith(b"data:"):
                if (self.stream_idle_seconds is not None
                        and time.monotonic() - progress >= self.stream_idle_seconds):
                    raise ModelTransportError(
                        f"Only keep-alive comments arrived for {self.stream_idle_seconds:g} "
                        "seconds", ProviderIncident.TIMEOUT, stalled=True)
                continue
            progress = time.monotonic()
            if begun is not None and self.stream_idle_seconds is not None:
                # The reply has begun: from here it may go quiet only so long.
                begun.settimeout(self.stream_idle_seconds)
                begun = None
            data = text[5:].strip()
            if data == b"[DONE]":
                break
            chunk = json.loads(data)
            if not isinstance(chunk, dict):
                raise ModelTransportError("Malformed model response", ProviderIncident.TRANSPORT)
            if chunk.get("error") is not None:
                raise ModelTransportError("The provider reported an error partway through the reply",
                                          ProviderIncident.TRANSPORT)
            model = chunk.get("model") or model
            usage = chunk.get("usage") or usage
            for choice in chunk.get("choices") or []:
                if not isinstance(choice, dict):
                    continue
                finish = choice.get("finish_reason") or finish
                found = choice.get("delta")
                delta: dict[str, Any] = found if isinstance(found, dict) else {}
                if isinstance(delta.get("content"), str):
                    content.append(delta["content"])
                    said += len(delta["content"].encode("utf-8"))
                # A reasoning model's thinking, before its answer: OpenRouter's
                # `reasoning`, vLLM's `reasoning_content`. Never part of the
                # reply; said to a listener only, so the wait is not silent.
                for key in ("reasoning", "reasoning_content"):
                    if isinstance(delta.get(key), str):
                        thinking.append(delta[key])
                        said += len(delta[key].encode("utf-8"))
                refusal = delta.get("refusal") or refusal
                for piece in delta.get("tool_calls") or []:
                    if not isinstance(piece, dict):
                        continue
                    index = piece.get("index", 0)
                    call = calls.setdefault(index if isinstance(index, int) else 0, {
                        "id": None, "type": "function", "function": {"name": "", "arguments": ""}})
                    call["id"] = piece.get("id") or call["id"]
                    given = piece.get("function")
                    function: dict[str, Any] = given if isinstance(given, dict) else {}
                    if isinstance(function.get("name"), str):
                        call["function"]["name"] += function["name"]
                        said += len(function["name"].encode("utf-8"))
                    if isinstance(function.get("arguments"), str):
                        call["function"]["arguments"] += function["arguments"]
                        said += len(function["arguments"].encode("utf-8"))
            if said > MAXIMUM_REPLY_BYTES:
                raise ModelTransportError("Model reply exceeds 4 MiB of text", ProviderIncident.OUTPUT_LIMIT)
            if first is None and (any(content) or any(thinking) or calls):
                first = progress
            if self.drafting is not None and progress - said_at >= DRAFTING_SECONDS \
                    and (calls or content or thinking):
                said_at = progress
                # The newest tool call, a reply in text (steps asked for as
                # JSON), or -- before either has begun -- the thinking.
                newest = calls[max(calls)]["function"] if calls else None
                if newest is not None:
                    self._say_drafting(newest["name"], newest["arguments"])
                elif content:
                    self._say_drafting("", "".join(content))
                else:
                    self._say_drafting(THINKING, "".join(thinking))
        message: dict[str, Any] = {
            "content": "".join(content) if content else ("" if calls else None),
            "tool_calls": [calls[index] for index in sorted(calls)] or None,
            "refusal": refusal,
        }
        return {"model": model, "usage": usage, FIRST_TOKEN: first,
                "choices": [{"finish_reason": finish, "message": message}]}

    def _say_drafting(self, name: str, text: str) -> None:
        """Tell `drafting` what the reply is so far; never raise from it."""
        if self.drafting is None:
            return
        # A display must never end a reply.
        with contextlib.suppress(Exception):
            self.drafting(name[:64], text)

    def _exchange(self, payload: dict[str, object], timeout_seconds: float, *,
                  allowance: int = 0) -> dict[str, Any]:
        """One request and its parsed body, with exactly one choice; every failure classified.

        A request is at most 1 MiB, besides what its images carry (`allowance`).
        """
        # As UTF-8, not escaped (0.3.34): Korean escaped took six bytes a character, twice
        # its UTF-8, and a loop reached the bound with its window a third full.
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        if len(body) > MAXIMUM_REQUEST_BYTES + allowance:
            raise ValueError(f"model request exceeds 1 MiB ({len(body) - allowance:,} bytes besides images)")
        headers = {"Content-Type": "application/json"}
        if self._api_key is not None:
            headers["Authorization"] = "Bearer " + self._api_key
        connection_type = (http.client.HTTPSConnection
                           if self.provider in ("openrouter", "openai") or self.secure
                           else http.client.HTTPConnection)
        streamed = payload.get("stream") is True
        # Streamed, each read waits only as long as the reply may go quiet --
        # once it has begun, from a server on this side (vLLM, Ollama). Before
        # its first piece such a server is reading the prompt, and a long one on
        # a large model took longer than the idle timeout: every call of a loop
        # holding whole files failed as "the reply stopped arriving" before it
        # had started. A hosted provider is held to the idle timeout throughout:
        # one with no provider started yet is a stall, not a slow prompt.
        local = self.provider in ("vllm", "ollama")
        connection = connection_type(
            self.host, self.port,
            timeout=min(timeout_seconds, self.stream_idle_seconds or timeout_seconds)
            if streamed and not local else timeout_seconds)
        expired = threading.Event()
        deadline = time.monotonic() + timeout_seconds
        active_socket: socket.socket | None = None

        def expire() -> None:
            expired.set()
            if active_socket is not None:
                try:
                    active_socket.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

        timer: threading.Timer | None = None
        began = time.monotonic()
        try:
            connection.connect()
            active_socket = connection.sock
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise ModelTransportError("Model request timed out", ProviderIncident.TIMEOUT)
            timer = threading.Timer(remaining, expire)
            timer.daemon = True
            timer.start()
            connection.request("POST", self.path, body=body, headers=headers)
            with connection.getresponse() as response:
                if response.status != 200:
                    said = response.read(REFUSAL_BYTES) if 400 <= response.status < 500 else b""
                    refusal = refusal_of(said) if said else None
                    prompt, window = (told_lengths(said) if refusal is RequestRefusal.CONTEXT_LENGTH
                                      else (None, None))
                    raise ModelTransportError(
                        f"Model provider returned HTTP {response.status}"
                        + (f" ({refusal.value.replace('_', ' ')})" if refusal else ""),
                        ProviderIncident.TRANSPORT, status=response.status, refusal=refusal,
                        prompt_tokens=prompt, context_window=window)
                if streamed and "event-stream" in (response.getheader("Content-Type") or ""):
                    read = self._read_stream(response, expired, deadline,
                                             active_socket if local else None)
                    first = read.pop(FIRST_TOKEN)
                    read[TIMING] = CallTiming(
                        seconds=time.monotonic() - began,
                        first_token_seconds=None if first is None else first - began)
                    return read
                raw = response.read(262145)
            if expired.is_set() or time.monotonic() >= deadline:
                raise ModelTransportError("Model request timed out", ProviderIncident.TIMEOUT)
            if len(raw) > 262144:
                raise ModelTransportError("Model response exceeds 256 KiB", ProviderIncident.OUTPUT_LIMIT)
            data = json.loads(raw)
            choices = data.get("choices") if isinstance(data, dict) else None
            if (not isinstance(data, dict) or data.get("error") is not None
                    or not isinstance(choices, list) or len(choices) != 1):
                raise ModelTransportError("Malformed model response", ProviderIncident.TRANSPORT)
            data[TIMING] = CallTiming(seconds=time.monotonic() - began)
            return data
        except (OSError, http.client.HTTPException, UnicodeError, json.JSONDecodeError) as error:
            # `TimeoutError` first, and not as one more way of asking the clock.
            # The socket's own timer and `time.monotonic()` are different clocks,
            # and on Windows the socket's fires a few milliseconds early -- so a
            # read that timed out at 0.094 against a 0.1 bound left both checks
            # below false and reported a timeout as a possibly malformed reply.
            # This connection has no deadline but the one set here, so a socket
            # timeout on it is that deadline, whichever clock noticed first.
            if isinstance(error, TimeoutError) or expired.is_set() or time.monotonic() >= deadline:
                # How a timeout actually arrives. The deadline fires, the socket
                # is shut down under the read in progress, and the read raises --
                # so the check after it is never reached and every timeout was
                # reported as "transport failed or response was invalid". Those
                # need opposite responses: one is a budget to raise, the other is
                # a network or a provider to look at. A live planner call spent
                # exactly its 180 seconds and was told it might be malformed.
                raise ModelTransportError(
                    f"Model request timed out after {timeout_seconds:g} seconds",
                    ProviderIncident.TIMEOUT) from error
            network = f"{network_reason(error)} at {self.host}:{self.port}"
            raise ModelTransportError(
                f"Model transport failed: {network}",
                ProviderIncident.TRANSPORT, network=network) from error
        finally:
            if timer is not None:
                timer.cancel()
            connection.close()
