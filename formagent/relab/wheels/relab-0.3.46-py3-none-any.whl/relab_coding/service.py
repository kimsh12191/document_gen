from pathlib import Path

from relab_coding.repo_map import RepositoryMapper
from relab_core.coding.identity import carry_identity
from relab_core.coding.inspection import CodeInspectionRequest, CodeInspectionResult


class CodingService:
    """In-process repository intelligence backed by the migrated implementation."""

    def inspect(self, request: CodeInspectionRequest) -> CodeInspectionResult:
        result = RepositoryMapper(
            max_files=request.max_files, max_symbol_bytes=request.max_symbol_bytes
        ).build(Path(request.path))
        return carry_identity(result, request)
