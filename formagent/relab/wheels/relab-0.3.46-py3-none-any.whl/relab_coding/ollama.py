"""Bounded native Ollama HTTP adapter; explicit loopback origins only."""

import http.client
import json
import math
import socket
import threading
import time
from urllib.parse import urlsplit

from relab_coding.usage import parse_usage
from relab_core.generation import ModelIdentity, ModelReply
from relab_core.provider import ProviderIncident, RequestRefusal

# What a reply gets unless the caller says how much room it needs. Enough for a
# file edit, which is what this adapter was written for; a caller asking for
# something larger says so rather than discovering the ceiling as a truncation.
DEFAULT_REPLY_TOKENS = 4096
# See `chat_gateway.MAXIMUM_REPLY_TOKENS`: a bound on a number reaching the wire.
MAXIMUM_REPLY_TOKENS = 200_000


# The most a model request may be, as sent (its images aside, for a chat gateway).
MAXIMUM_REQUEST_BYTES = 1048576


def undeclared(named: str, endpoint: str) -> str:
    """Why a server on another machine is not reached, with the flag that would reach it.

    Found in use (0.3.33): "requires an HTTP loopback endpoint ..., or one the person
    declared (--allow-endpoint)" left a person running `prompt-compare` on a server
    to guess that the same address goes once more after --allow-endpoint.
    """
    return (f"{named} at {endpoint} is on another machine, reached only when the person declared it: "
            f"add --allow-endpoint {endpoint} (the editor declares the addresses in its settings)")


class ModelTransportError(ValueError):
    """Sanitized provider failure safe for CLI display.

    `incident` says which of the closed set happened, because whether an
    experimental attempt was spent turns on it and that is not a judgement to
    make from the message. A timeout and a model declining the work both arrive
    here and belong on opposite sides of that line.

    `None` for the failures raised before a reply was classified -- a bad request,
    an unusable timeout -- which never reached a provider at all.
    """

    def __init__(self, message: str, incident: "ProviderIncident | None" = None, *,
                 status: int | None = None, stalled: bool = False,
                 network: str | None = None, refusal: "RequestRefusal | None" = None,
                 prompt_tokens: int | None = None, context_window: int | None = None) -> None:
        super().__init__(message)
        # For a refused request (4xx): what it was about, when the body said
        # (RL-05) -- the kind only, never the body.
        self.refusal = refusal
        # Refused for its length: the server's own count of the prompt and its
        # window, when the body said them (0.3.18) -- the numbers only.
        self.prompt_tokens = prompt_tokens
        self.context_window = context_window
        # Why the connection failed, from a closed set ("connection refused",
        # "host name not found", "certificate not trusted"...), with the address
        # tried: the socket's account, never the provider's words. One sentence
        # for all of them sent a person with a working server to guess.
        self.network = network
        self.incident = incident
        # A streamed reply that stopped arriving part-way: the connection or
        # the provider stalled, which -- unlike a reply that was still coming
        # when time ran out -- trying again may not repeat.
        self.stalled = stalled
        # The HTTP status, when the provider answered with one that was not
        # 200: a 4xx is the request refused (a feature the model lacks, a bad
        # key), which trying again does not change; a 5xx, 408 or 429 may.
        self.status = status


class OllamaGateway:
    def __init__(self, model: str, endpoint: str = "http://127.0.0.1:11434", *,
                 response_contract: dict[str, object] | None = None,
                 declared: bool = False) -> None:
        # `declared`: named by the person for this use (see ChatGateway), so a
        # server on another machine, by http or https, is reached.
        # Declared by the caller, never chosen here; see ChatGateway.
        self.response_contract = response_contract
        if not model.strip() or len(model) > 256 or any(ord(char) < 32 for char in model):
            raise ValueError("model must be a nonblank name of at most 256 characters")
        if any(char.isspace() or ord(char) < 32 for char in endpoint):
            raise ValueError("Ollama endpoint must not contain whitespace or controls")
        origin = urlsplit(endpoint)
        loopback = origin.hostname in {"localhost", "127.0.0.1", "::1"}
        if (not loopback and not declared and origin.scheme in ("http", "https") and origin.hostname
                and origin.username is None and origin.password is None
                and origin.path in {"", "/"} and not origin.query and not origin.fragment):
            raise ValueError(undeclared("Ollama", endpoint))
        if (origin.scheme not in (("http", "https") if declared else ("http",))
                or not origin.hostname or not (loopback or declared)
                or origin.username is not None or origin.password is not None
                or origin.path not in {"", "/"} or origin.query or origin.fragment):
            raise ValueError("Ollama endpoint must be an HTTP loopback origin without credentials, "
                             "or one the person declared (--allow-endpoint)")
        self.secure = origin.scheme == "https"
        self.host = "127.0.0.1" if origin.hostname == "localhost" else origin.hostname
        self.port = origin.port if origin.port is not None else 11434
        if not 1 <= self.port <= 65535:
            raise ValueError("invalid Ollama port")
        self.model = model

    @property
    def identity(self) -> ModelIdentity:
        return ModelIdentity(provider="ollama", model=self.model)

    def complete(self, prompt: str, *, timeout_seconds: float,
                 response_contract: dict[str, object] | None = None,
                 reply_tokens: int | None = None) -> str:
        if not math.isfinite(timeout_seconds) or not 0 < timeout_seconds <= 600:
            raise ValueError("model timeout must be finite and between 0 and 600 seconds")
        if reply_tokens is not None and (type(reply_tokens) is not int
                                         or not 1 <= reply_tokens <= MAXIMUM_REPLY_TOKENS):
            raise ValueError(
                f"reply_tokens must be an integer between 1 and {MAXIMUM_REPLY_TOKENS}")
        contract = self.response_contract if response_contract is None else response_contract
        payload = json.dumps({
            "model": self.model, "prompt": prompt, "stream": False,
            **({} if contract is None else {"format": contract}),
            # `num_predict` is this provider's spelling for the same thing the
            # chat dialect calls `max_tokens`.
            "options": {"temperature": 0,
                        "num_predict": DEFAULT_REPLY_TOKENS if reply_tokens is None
                        else reply_tokens},
        }, ensure_ascii=False).encode("utf-8")
        if len(payload) > MAXIMUM_REQUEST_BYTES:
            raise ValueError(f"model request exceeds 1 MiB ({len(payload):,} bytes)")
        deadline = time.monotonic() + timeout_seconds
        connection = (http.client.HTTPSConnection if self.secure else http.client.HTTPConnection)(
            self.host, self.port, timeout=timeout_seconds)
        timer: threading.Timer | None = None
        try:
            connection.connect()
            assert connection.sock is not None
            active_socket = connection.sock

            def expire() -> None:
                try:
                    active_socket.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise ModelTransportError("Ollama request timed out", ProviderIncident.TIMEOUT)
            timer = threading.Timer(remaining, expire)
            timer.daemon = True
            timer.start()
            connection.request("POST", "/api/generate", body=payload,
                               headers={"Content-Type": "application/json"})
            with connection.getresponse() as response:
                if response.status != 200:
                    raise ModelTransportError(
                        f"Ollama returned HTTP {response.status}", ProviderIncident.TRANSPORT)
                raw = response.read(262145)
            if time.monotonic() >= deadline:
                raise ModelTransportError("Ollama request timed out", ProviderIncident.TIMEOUT)
            if len(raw) > 262144:
                raise ModelTransportError("Ollama response exceeds 256 KiB", ProviderIncident.TRANSPORT)
            data = json.loads(raw)
            if (not isinstance(data, dict) or data.get("done") is not True
                    or not isinstance(data.get("response"), str)
                    or data.get("error") is not None
                    or data.get("done_reason") == "length"):
                # `done_reason == "length"` is this provider's truncation, so the
                # incident says so rather than calling every shape problem the same.
                raise ModelTransportError(
                    "Ollama returned an incomplete or malformed response",
                    ProviderIncident.OUTPUT_LIMIT
                    if isinstance(data, dict) and data.get("done_reason") == "length"
                    else ProviderIncident.INCOMPLETE)
            content = data["response"]
            assert isinstance(content, str)
            return ModelReply(content, parse_usage(data, ollama=True), reported_model=data.get("model"))
        except (OSError, http.client.HTTPException, UnicodeError, json.JSONDecodeError) as error:
            raise ModelTransportError(
                "Ollama transport failed or response was invalid",
                ProviderIncident.TIMEOUT if time.monotonic() >= deadline
                else ProviderIncident.TRANSPORT) from error
        finally:
            if timer is not None:
                timer.cancel()
            connection.close()
