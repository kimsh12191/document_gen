"""Allowlist provider-reported token counts; unknown is not zero."""

import math

from relab_core.generation import TokenUsage


def parse_usage(value: object, *, ollama: bool = False) -> TokenUsage | None:
    if not isinstance(value, dict):
        return None
    names = {"prompt_tokens": "prompt_eval_count" if ollama else "prompt_tokens",
             "completion_tokens": "eval_count" if ollama else "completion_tokens"}
    if not ollama:
        names["total_tokens"] = "total_tokens"
    counts = {}
    for name, source in names.items():
        count = value.get(source)
        counts[name] = count if type(count) is int and 0 <= count <= 2**63 - 1 else None
    details = value.get("prompt_tokens_details")
    cached = details.get("cached_tokens") if isinstance(details, dict) else None
    counts["cached_tokens"] = cached if type(cached) is int and 0 <= cached <= 2**63 - 1 else None
    cost = value.get("cost")
    spent = None
    if isinstance(cost, (int, float)) and not isinstance(cost, bool)             and math.isfinite(cost) and cost >= 0:
        spent = float(cost)
    # A cost with no count beside it is not taken: usage is the counts, and
    # what they cost rides along with them.
    if all(count is None for count in counts.values()):
        return None
    return TokenUsage(**counts, cost=spent)
