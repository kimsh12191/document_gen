"""Bounded, deterministic repository inspection.

Mirrors (independently — no shared code) the AutoResearch `RepositoryMapper`
pattern: a flat, hashable file inventory plus a bounded Python symbol/import
index, never an embedding/semantic index. `truncated` is the only signal
that the map is incomplete; callers must check it rather than assume
completeness.

Beyond the file+symbol inventory, this module also builds the import graph
(`DependencyEdge`), a best-effort call-site index (`SymbolReference`), a
per-file role classification (`FileSummary`), and a test<->source pairing
(`TestReference`) — this is what makes "where do I look to change X"
answerable without an LLM (doc/ROADMAP.md v0.1's completion condition).
"""

import ast
import hashlib
import os
import re
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath

from relab_core.coding.inspection import (
    CodeInspectionResult,
    DependencyEdge,
    FileSummary,
    PythonSymbol,
    RepoFile,
    SymbolReference,
    TestReference,
)
from relab_core.targets import UNSEARCHED_DIRECTORIES

# The one list, in core, because the workspace search needs the same one and
# a second copy is a copy that drifts.
EXCLUDED_DIRECTORIES = UNSEARCHED_DIRECTORIES
_DEF_KINDS: dict[type[ast.ClassDef | ast.FunctionDef | ast.AsyncFunctionDef], str] = {
    ast.ClassDef: "class",
    ast.FunctionDef: "function",
    ast.AsyncFunctionDef: "async_function",
}

_TEST_FILENAME = re.compile(r"^(test_.*|.*_test)\.py$")
_TEST_PREFIX = "test_"
_TEST_SUFFIX = "_test"
_CONFIG_FILENAMES = {
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "tox.ini",
    "makefile",
    "dockerfile",
    ".pre-commit-config.yaml",
}
_CONFIG_SUFFIXES = {".toml", ".ini", ".cfg", ".yaml", ".yml"}
_DOC_SUFFIXES = {".md", ".rst", ".txt"}
_VENV_MARKER = "pyvenv.cfg"


def walk_candidates(root: Path) -> list[Path]:
    """Directory-pruning traversal: never descend into an excluded directory
    or one containing a `pyvenv.cfg` marker (catches any virtualenv, not
    just ones matching a name already in `EXCLUDED_DIRECTORIES` — e.g. a
    real repo's own `.venv-test` release-verification environment)."""

    candidates: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        if _VENV_MARKER in filenames:
            dirnames[:] = []
            continue
        dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIRECTORIES]
        current = Path(dirpath)
        for filename in filenames:
            path = current / filename
            if not path.is_symlink():
                candidates.append(path)
    return candidates


@dataclass
class _PythonAnalysis:
    symbols: list[PythonSymbol] = field(default_factory=list)
    dependency_edges: list[DependencyEdge] = field(default_factory=list)
    call_sites: list[tuple[str, int]] = field(default_factory=list)  # (bare_name, line)
    is_entrypoint: bool = False


class RepositoryMapper:
    def __init__(self, max_files: int = 2000, max_symbol_bytes: int = 1_000_000) -> None:
        if max_files < 1:
            raise ValueError("max_files must be >= 1")
        if max_symbol_bytes < 1:
            raise ValueError("max_symbol_bytes must be >= 1")
        self.max_files = max_files
        self.max_symbol_bytes = max_symbol_bytes

    def build(self, root: Path) -> CodeInspectionResult:
        root = root.resolve()
        if not root.is_dir():
            raise ValueError(f"not a directory: {root}")
        candidates = sorted(walk_candidates(root))
        truncated = len(candidates) > self.max_files
        selected = candidates[: self.max_files]
        python_paths = {
            item.relative_to(root).as_posix() for item in selected if item.suffix == ".py"
        }

        files: list[RepoFile] = []
        symbols: list[PythonSymbol] = []
        dependency_edges: list[DependencyEdge] = []
        file_summaries: list[FileSummary] = []
        call_sites_by_file: dict[str, list[tuple[str, int]]] = {}

        for path in selected:
            content = path.read_bytes()
            relative = path.relative_to(root).as_posix()
            digest = hashlib.sha256(content).hexdigest()
            files.append(RepoFile(path=relative, size=len(content), sha256=digest))

            analysis = _PythonAnalysis()
            if path.suffix == ".py" and len(content) <= self.max_symbol_bytes:
                analysis = _analyze_python_file(relative, content, python_paths)
                symbols.extend(analysis.symbols)
                dependency_edges.extend(analysis.dependency_edges)
                if analysis.call_sites:
                    call_sites_by_file[relative] = analysis.call_sites

            role = _classify_role(relative, analysis.is_entrypoint)
            file_summaries.append(
                FileSummary(
                    path=relative,
                    role=role,
                    symbol_count=len(analysis.symbols),
                    import_count=len(analysis.dependency_edges),
                )
            )

        symbol_references = _resolve_call_sites(call_sites_by_file, symbols)
        test_references = _match_tests(file_summaries, dependency_edges)

        return CodeInspectionResult(
            root=str(root),
            files=files,
            symbols=symbols,
            symbol_references=symbol_references,
            dependency_edges=dependency_edges,
            file_summaries=file_summaries,
            test_references=test_references,
            truncated=truncated,
        )


def _analyze_python_file(relative: str, content: bytes, python_paths: set[str]) -> _PythonAnalysis:
    try:
        tree = ast.parse(content.decode("utf-8"))
    except (SyntaxError, UnicodeDecodeError, ValueError):
        return _PythonAnalysis()

    analysis = _PythonAnalysis()
    base_dir = PurePosixPath(relative).parent
    analysis.is_entrypoint = _has_main_guard(tree)

    def visit(node: ast.AST, prefix: str) -> None:
        for child in ast.iter_child_nodes(node):
            if isinstance(child, ast.ClassDef | ast.FunctionDef | ast.AsyncFunctionDef):
                kind = _DEF_KINDS[type(child)]
                qualified = f"{prefix}{child.name}"
                analysis.symbols.append(
                    PythonSymbol(
                        path=relative, qualified_name=qualified, kind=kind, line=child.lineno
                    )
                )
                visit(child, f"{qualified}.")
            elif isinstance(child, ast.Import):
                for alias in child.names:
                    to_path = _resolve_absolute_module(alias.name, python_paths)
                    analysis.dependency_edges.append(
                        DependencyEdge(
                            from_path=relative,
                            to_module=alias.name,
                            to_path=to_path,
                            line=child.lineno,
                        )
                    )
                visit(child, prefix)
            elif isinstance(child, ast.ImportFrom):
                for alias in child.names:
                    to_module, to_path = _resolve_import_from_alias(
                        base_dir, child.level, child.module, alias.name, python_paths
                    )
                    analysis.dependency_edges.append(
                        DependencyEdge(
                            from_path=relative,
                            to_module=to_module,
                            to_path=to_path,
                            line=child.lineno,
                        )
                    )
                visit(child, prefix)
            elif isinstance(child, ast.Call) and isinstance(child.func, ast.Name):
                analysis.call_sites.append((child.func.id, child.lineno))
                visit(child, prefix)
            else:
                visit(child, prefix)

    visit(tree, "")
    return analysis


def _has_main_guard(tree: ast.Module) -> bool:
    for node in tree.body:
        if isinstance(node, ast.If) and _is_name_equals_main(node.test):
            return True
    return False


def _is_name_equals_main(test: ast.expr) -> bool:
    if not isinstance(test, ast.Compare):
        return False
    if len(test.ops) != 1 or not isinstance(test.ops[0], ast.Eq):
        return False
    sides = (test.left, test.comparators[0])
    saw_name = any(isinstance(side, ast.Name) and side.id == "__name__" for side in sides)
    saw_main = any(
        isinstance(side, ast.Constant) and side.value == "__main__" for side in sides
    )
    return saw_name and saw_main


def _resolve_path_candidates(as_path: str, python_paths: set[str]) -> str | None:
    if not as_path:
        return None
    for candidate in (f"{as_path}.py", f"{as_path}/__init__.py"):
        if candidate in python_paths:
            return candidate
    return None


def _resolve_absolute_module(dotted: str, python_paths: set[str]) -> str | None:
    if not dotted:
        return None
    return _resolve_path_candidates(dotted.replace(".", "/"), python_paths)


def _anchor_dir(base_dir: PurePosixPath, level: int) -> str:
    """The package directory `level` dots up from `base_dir` (as a posix path, "" for root)."""

    anchor = base_dir
    for _ in range(level - 1):
        anchor = anchor.parent
    return "" if str(anchor) == "." else str(anchor)


def _resolve_import_from_alias(
    base_dir: PurePosixPath, level: int, module: str | None, name: str, python_paths: set[str]
) -> tuple[str, str | None]:
    """Resolve one `from <module> import <name>` alias to (to_module, to_path)."""

    dots = "." * level
    dotted = f"{dots}{module}.{name}" if module else f"{dots}{name}"
    if level == 0:
        return dotted, _resolve_absolute_module(module or "", python_paths)

    anchor_text = _anchor_dir(base_dir, level)
    if module:
        # from ..sub import name -> the module itself is the resolution target,
        # `name` is presumed to be a symbol defined inside it.
        module_slug = module.replace(".", "/")
        module_path = f"{anchor_text}/{module_slug}" if anchor_text else module_slug
        return dotted, _resolve_path_candidates(module_path, python_paths)

    # from . import name -> try `name` as a submodule of the anchor package first
    submodule_path = f"{anchor_text}/{name}" if anchor_text else name
    to_path = _resolve_path_candidates(submodule_path, python_paths)
    if to_path is not None:
        return dotted, to_path

    # fall back: `name` is an attribute defined in the anchor package's __init__.py
    init_path = f"{anchor_text}/__init__.py" if anchor_text else "__init__.py"
    return dotted, init_path if init_path in python_paths else None


def _classify_role(relative: str, is_entrypoint: bool) -> str:
    if is_entrypoint:
        return "entrypoint"
    path = PurePosixPath(relative)
    name = path.name
    parts_lower = {part.lower() for part in path.parts[:-1]}
    if path.suffix == ".py":
        if _TEST_FILENAME.match(name) or "tests" in parts_lower or "test" in parts_lower:
            return "test"
        return "source"
    if name.lower() in _CONFIG_FILENAMES or path.suffix.lower() in _CONFIG_SUFFIXES:
        return "config"
    if path.suffix.lower() in _DOC_SUFFIXES:
        return "doc"
    return "other"


def _resolve_call_sites(
    call_sites_by_file: dict[str, list[tuple[str, int]]], symbols: list[PythonSymbol]
) -> list[SymbolReference]:
    by_bare_name: dict[str, list[str]] = {}
    for symbol in symbols:
        bare = symbol.qualified_name.rsplit(".", 1)[-1]
        by_bare_name.setdefault(bare, []).append(symbol.qualified_name)

    references: list[SymbolReference] = []
    for path, call_sites in call_sites_by_file.items():
        for name, line in call_sites:
            for qualified_name in by_bare_name.get(name, []):
                references.append(
                    SymbolReference(path=path, qualified_name=qualified_name, line=line)
                )
    return references


def _match_tests(
    file_summaries: list[FileSummary], dependency_edges: list[DependencyEdge]
) -> list[TestReference]:
    sources_by_stem: dict[str, list[str]] = {}
    for summary in file_summaries:
        if summary.role == "source":
            stem = PurePosixPath(summary.path).stem
            sources_by_stem.setdefault(stem, []).append(summary.path)
    role_by_path = {summary.path: summary.role for summary in file_summaries}

    edges_from: dict[str, list[str]] = {}
    for edge in dependency_edges:
        if edge.to_path:
            edges_from.setdefault(edge.from_path, []).append(edge.to_path)

    results: list[TestReference] = []
    seen: set[tuple[str, str]] = set()
    for summary in file_summaries:
        if summary.role != "test":
            continue
        stem = PurePosixPath(summary.path).stem
        candidate_stems = set()
        if stem.startswith(_TEST_PREFIX):
            candidate_stems.add(stem[len(_TEST_PREFIX) :])
        if stem.endswith(_TEST_SUFFIX):
            candidate_stems.add(stem[: -len(_TEST_SUFFIX)])
        for candidate_stem in candidate_stems:
            for source_path in sources_by_stem.get(candidate_stem, []):
                key = (summary.path, source_path)
                if key not in seen:
                    seen.add(key)
                    results.append(
                        TestReference(
                            test_path=summary.path, source_path=source_path, confidence=1.0
                        )
                    )
        for source_path in edges_from.get(summary.path, []):
            key = (summary.path, source_path)
            if key not in seen and role_by_path.get(source_path) == "source":
                seen.add(key)
                results.append(
                    TestReference(test_path=summary.path, source_path=source_path, confidence=0.6)
                )

    return sorted(results, key=lambda item: (item.test_path, item.source_path))
