"""Rank existing files against an objective using only inspected structure.

The ranking is lexical and deterministic: it matches objective tokens against
path segments and Python symbol names, weighting each token by how few files
carry it. It reads no file contents, calls no model and decides nothing — the
caller still chooses what an arm actually edits.
"""

import re
from collections import defaultdict
from decimal import Decimal, localcontext

from relab_core.coding.inspection import CodeInspectionResult
from relab_core.targets import (
    RankedPaths,
    TargetEvidence,
    TargetPlan,
    TargetProposal,
)

MINIMUM_TOKEN_CHARACTERS = 3
PATH_WEIGHT = 2
SYMBOL_WEIGHT = 1
EVIDENCE_SYMBOLS = 3
_TOKEN = re.compile(r"[a-z0-9]+")


def _tokens(text: str) -> set[str]:
    return {token for token in _TOKEN.findall(text.lower())
            if len(token) >= MINIMUM_TOKEN_CHARACTERS}


def propose_targets(
    inspection: CodeInspectionResult, objective: str, *, limit: int = 5,
) -> TargetPlan:
    """Suggest at most `limit` files; an unmatched objective proposes nothing."""
    if type(limit) is not int or not 1 <= limit <= 8:
        raise ValueError("target limit must be an integer between 1 and 8")
    if not objective.strip():
        raise ValueError("a target objective must not be blank")
    plan = TargetPlan(objective=objective, considered_files=len(inspection.files),
                      truncated=inspection.truncated)
    wanted = _tokens(objective)
    if not wanted or not inspection.files:
        return plan
    roles = {item.path: item.role for item in inspection.file_summaries}
    named: dict[str, list[str]] = defaultdict(list)
    for symbol in inspection.symbols:
        named[symbol.path].append(symbol.qualified_name)
    paths = {item.path: _tokens(item.path) for item in inspection.files}
    symbols = {path: _tokens(" ".join(names)) for path, names in named.items()}
    carried: dict[str, int] = defaultdict(int)
    for path, tokens in paths.items():
        for token in tokens | symbols.get(path, set()):
            carried[token] += 1
    ranked = []
    with localcontext() as context:
        context.prec = 40
        for path in sorted(paths):
            score, evidence = _rank(path, paths[path], symbols.get(path, set()),
                                    named.get(path, []), wanted, carried)
            if evidence:
                ranked.append((-score, path, TargetProposal(
                    path=path, role=roles.get(path, "other"), score=str(score),
                    evidence=evidence)))
    plan.proposals = [item for _, _, item in sorted(ranked, key=lambda item: item[:2])][:limit]
    return plan


def _rank(
    path: str, path_tokens: set[str], symbol_tokens: set[str], names: list[str],
    wanted: set[str], carried: dict[str, int],
) -> tuple[Decimal, list[TargetEvidence]]:
    """Weight each shared token by its rarity so a common word cannot dominate."""
    score = Decimal(0)
    evidence = []
    for token in sorted(wanted & path_tokens):
        score += Decimal(PATH_WEIGHT) / Decimal(carried[token])
        evidence.append(TargetEvidence(signal="path", detail=f"{path} contains '{token}'"))
    # A token already credited to the path is not counted again through a symbol.
    matched = (wanted & symbol_tokens) - path_tokens
    for token in sorted(matched):
        score += Decimal(SYMBOL_WEIGHT) / Decimal(carried[token])
    defining = sorted(name for name in names if _tokens(name) & matched)
    for name in defining[:EVIDENCE_SYMBOLS]:
        evidence.append(TargetEvidence(signal="symbol", detail=f"defines '{name}'"))
    return score, evidence


def rank_paths(
    inspection: CodeInspectionResult, goal: str | None, *, limit: int,
) -> RankedPaths:
    """Paths a goal makes relevant, first; then whatever else is here.

    The same lexical, deterministic scoring `propose_targets` uses, over a longer
    list, because showing a planner the *first* files a repository happens to
    yield is showing it nothing in particular.

    Unmatched paths still follow. A vague goal should not starve a planner of
    context, and `related_count` says how much of the list was chosen for it.
    """
    if type(limit) is not int or limit < 1:
        raise ValueError("path limit must be a positive integer")
    every = [item.path for item in inspection.files]
    wanted = _tokens(goal or "")
    if not wanted or not every:
        # No goal, or nothing to rank: the list is what is here, and says so.
        return RankedPaths(paths=every[:limit], related_count=0, ranked=False)
    named: dict[str, list[str]] = defaultdict(list)
    for symbol in inspection.symbols:
        named[symbol.path].append(symbol.qualified_name)
    paths = {item.path: _tokens(item.path) for item in inspection.files}
    symbols = {path: _tokens(" ".join(names)) for path, names in named.items()}
    carried: dict[str, int] = defaultdict(int)
    for path, tokens in paths.items():
        for token in tokens | symbols.get(path, set()):
            carried[token] += 1
    scored = []
    with localcontext() as context:
        context.prec = 40
        for path in sorted(paths):
            score, evidence = _rank(path, paths[path], symbols.get(path, set()),
                                    named.get(path, []), wanted, carried)
            if evidence:
                scored.append((-score, path))
    related = [path for _, path in sorted(scored, key=lambda item: item[:2])]
    rest = [path for path in every if path not in set(related)]
    chosen = [*related, *rest][:limit]
    return RankedPaths(paths=chosen, related_count=min(len(related), limit),
                       ranked=bool(related))
