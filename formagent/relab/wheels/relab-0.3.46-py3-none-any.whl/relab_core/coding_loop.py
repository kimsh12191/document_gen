"""The coding loop: a closed set of steps a model may take, and the record of them.

ReLab spent a research protocol on requests like "make an add function": a
design, a measurement, its calibration, two arms run three times each, and a
conclusion, walked by the person one step at a time. A coding agent does the
other thing -- read, search, edit, run, read what happened, edit again -- as
one continuous task. This is that, with ReLab's rules kept: every step is one
of a closed set of typed actions, validated before anything happens, and what each one
did is recorded.

The model proposes; nothing it writes is executed unless it parses as one of
these actions, and each action is then checked by the layer that performs it
(paths inside the workspace, commands from an allowed shape). See
`docs/architecture/CODING_FIRST_LOOP.md`.
"""

import json
from datetime import datetime
from enum import Enum
from typing import Literal

from pydantic import Field, field_validator, model_validator

from relab_core.completion import CompletionAssessment, VerificationEvidence
from relab_core.contracts import Contract
from relab_core.evidence import EngineeringDecision, EvidencePackage

# Bounds on what one reply may carry, so a reply cannot be a denial of service
# on the prompt it is fed back into or the record it is kept in.
MAXIMUM_WRITTEN_BYTES = 400_000
MAXIMUM_ARGUMENTS = 32
MAXIMUM_OBSERVATION = 12_000
# A read_file's result may be larger: a file shown whole, up to a quarter of
# a large model's window (relab_app.coding_loop.MAXIMUM_READ_CHARACTERS).
MAXIMUM_STEP_OBSERVATION = 120_000
# How long an answer to "analyze this" may be.
MAXIMUM_DIGEST = 6000
MAXIMUM_REPORT = 20_000
# How many background processes a loop may have running at once, and how long
# a step may wait on one's output.
MAXIMUM_PROCESSES = 3
# A wait for output may be long for a job, which a read returns from as soon as it
# ends (0.2.66: a 30-minute batch was handed to the person to run).
MAXIMUM_WAIT_SECONDS = 1800


class LoopActionKind(str, Enum):
    """What one step does. Closed: anything else is not a step."""

    READ_FILE = "read_file"
    READ_FILES = "read_files"
    SEARCH_CODEBASE = "search_codebase"
    SEARCH = "search"
    # The files under a folder, by a name pattern: what a project holds when
    # the listing in the prompt is cut short, or only one kind is wanted.
    LIST_FILES = "list_files"
    # What the code under a folder or in a file defines -- classes, functions,
    # methods, with signatures and lines -- without reading it whole.
    OUTLINE = "outline"
    # Where a Python name is defined and every place that uses it, from the
    # syntax trees, imports and aliases followed: "query" is the name, "path"
    # the file of the definition meant when several share it (M5.5).
    REFERENCES = "references"
    # A page of documentation from the web, as text: asked about first, like
    # a command, and kept as a rule for its site if the person says so.
    FETCH_URL = "fetch_url"
    # A whole file, created or replaced. Whole rather than a diff: a model's
    # diff that does not apply is a step wasted on a format, and a file written
    # whole is exactly what is recorded and can be undone.
    WRITE_FILE = "write_file"
    # Replace one exact passage of a file with another. Whole-file writes made
    # a model reproduce a large file to change a line of it, and every
    # reproduction is a chance to change something else by accident.
    EDIT_FILE = "edit_file"
    EDIT_BATCH = "edit_batch"
    RUN = "run"
    # A program that keeps running -- a dev server, a watcher -- started in the
    # background, its output read as it comes and stopped when done with. A
    # `run` waits for its command to end, which a server never does.
    START_PROCESS = "start_process"
    READ_PROCESS = "read_process"
    STOP_PROCESS = "stop_process"
    # The code plan for work larger than a fix -- which files and folders,
    # what each holds, in what order -- shown to the person before any of it
    # is written. The loop waits for approval or for changes.
    PLAN = "plan"
    # A question only the person can answer -- a model name, an endpoint, which
    # of two readings of the request they meant. The loop waits for the answer
    # rather than guessing: a live loop, asked to use "qwen-3.5" through vllm,
    # invented both the model name and the way vllm is called.
    ASK = "ask"
    # The checklist of the work, kept as it goes: the whole list each time.
    # A long task lost track of what was left; written down, it is in front
    # of the model on every step, and on the card in front of the person.
    TODO = "todo"
    # Propose a measured comparison: the question is one only an experiment can
    # answer. Proposed, never started -- the loop ends, and the person decides.
    RESEARCH = "research"
    # A read-only question handed to a helper loop, which reports back.
    EXPLORE = "explore"
    # A tool of an MCP server the person configured.
    MCP = "mcp"
    # A short fact about the project, kept for the loops after this one.
    REMEMBER = "remember"
    FINISH = "finish"


class ResearchEscalationReason(str, Enum):
    """Why a coding request should become a measured study. A closed set.

    Narrow on purpose: everything else -- a bug, a feature, a refactor, a test,
    a build error -- is coding, and a loop that reached for research whenever
    something was uncertain would put the protocol back in front of the work.
    The model names one of these; the application accepts only these.
    """

    # Two or more implementations, configurations, prompts or models, and the
    # request is to choose between them on how well they do.
    COMPARISON_REQUIRED = "comparison_required"
    # How well something does has to be measured -- accuracy, latency, recall
    # -- and the project has nothing that measures it.
    MEASUREMENT_REQUIRED = "measurement_required"
    # The person asked for an experiment, an evaluation or a benchmark.
    USER_REQUESTED = "user_requested"


class PlannedFile(Contract):
    """One file of a code plan: where it goes, and what it holds."""

    path: str = Field(min_length=1, max_length=260)
    purpose: str = Field(min_length=1, max_length=300)
    # The public functions and classes it defines, each with its signature
    # ("class OcrBackend: extract(image: Path, language: str) -> str"). Files are
    # written one step at a time; a live loop wrote an agent that guessed six
    # names for the backend module it had written two steps before. Fixed here,
    # every file is written against the same names, and finish checks them.
    interface: list[str] = Field(default_factory=list, max_length=15)

    @model_validator(mode="after")
    def short(self) -> "PlannedFile":
        if any(not item.strip() or len(item) > 200 for item in self.interface):
            raise ValueError("each interface entry is one short, non-blank signature")
        return self


class PlannedRequirement(Contract):
    """One thing the request asks for, and where and how the plan does it (0.2.88).

    Seen with 0.2.86 next to Cline: asked to summarize DART reports with a VLM,
    ReLab's plan had the model read the pages and keyword lists fill the report;
    the request's method was lost between the request and the files. Cline had
    first set out the request's goals. Said in the plan, before any code.
    """

    asked: str = Field(min_length=1, max_length=300)
    how: str = Field(min_length=1, max_length=300)


class LoopPlan(Contract):
    """What a loop means to build, before it builds it.

    The same shape a research design's implementation plan has -- a layout and
    the steps -- so a plan a study produced can be handed to a loop as is.
    """

    files: list[PlannedFile] = Field(min_length=1, max_length=40)
    steps: list[str] = Field(default_factory=list, max_length=20)
    requirements: list[PlannedRequirement] = Field(default_factory=list, max_length=20)

    @model_validator(mode="after")
    def readable(self) -> "LoopPlan":
        paths = [item.path.casefold() for item in self.files]
        if len(paths) != len(set(paths)):
            raise ValueError("a plan names each file once")
        if any(not item.strip() or len(item) > 300 for item in self.steps):
            raise ValueError("each plan step is a short, non-blank line")
        return self


class LoopQuestion(Contract):
    """One thing the person is asked, short, with the choices they can pick.

    A live loop asked six things in one paragraph -- interface, model, streaming,
    device, credentials, scope -- which the person had to read as prose and
    answer as prose. Each is now a sentence and a few options, which an editor
    can offer as choices; an empty list of options asks for free text.
    """

    prompt: str = Field(min_length=1, max_length=300)
    options: list[str] = Field(default_factory=list, max_length=5)

    @model_validator(mode="after")
    def short(self) -> "LoopQuestion":
        if any(not item.strip() or len(item) > 120 for item in self.options):
            raise ValueError("each option is a short, non-blank choice")
        return self


# How many replacements one edit may make.
MAXIMUM_EDITS = 20


class Replacement(Contract):
    """One exact passage of a file, and what replaces it."""

    old_text: str = Field(min_length=1, max_length=MAXIMUM_WRITTEN_BYTES)
    new_text: str = Field(max_length=MAXIMUM_WRITTEN_BYTES)


class TodoItem(Contract):
    """One thing to do, and whether it is done."""

    text: str = Field(min_length=1, max_length=200)
    done: bool = False


MAXIMUM_TODOS = 20


class FileEditRequest(Contract):
    path: str = Field(min_length=1, max_length=260)
    edits: list[Replacement] = Field(min_length=1, max_length=MAXIMUM_EDITS)


class FileReadRequest(Contract):
    path: str = Field(min_length=1, max_length=260)
    start_line: int | None = Field(default=None, strict=True, ge=1)
    line_count: int | None = Field(default=None, strict=True, ge=1, le=2000)


class SearchRequest(Contract):
    query: str = Field(min_length=1, max_length=200)
    path: str | None = Field(default=None, min_length=1, max_length=260)
    regex: bool = False
    glob: str | None = Field(default=None, min_length=1, max_length=100)


class LoopAction(Contract):
    """One step as a model proposes it.

    Flat, with every field present and the irrelevant ones null, because that
    is the shape a provider's structured-output mode can enforce; which fields
    an action needs is checked here.
    """

    # One or two sentences on why this step, shown to the person as the trace.
    thought: str = Field(min_length=1, max_length=2000)
    action: LoopActionKind
    edit_files: list[FileEditRequest] | None = Field(default=None, min_length=1, max_length=20)
    files: list[FileReadRequest] | None = Field(default=None, min_length=1, max_length=20)
    queries: list[SearchRequest] | None = Field(default=None, min_length=1, max_length=20)
    path: str | None = Field(default=None, min_length=1, max_length=260)
    query: str | None = Field(default=None, min_length=1, max_length=200)
    # For `search`: the query is a regular expression (of the shapes the
    # search takes); and, with `list_files`, which files, by a name pattern.
    regex: bool | None = None
    glob: str | None = Field(default=None, min_length=1, max_length=100)
    # For `read_file`: the lines to show, from 1, when not the whole file.
    start_line: int | None = Field(default=None, ge=1)
    line_count: int | None = Field(default=None, ge=1, le=2000)
    content: str | None = Field(default=None, max_length=MAXIMUM_WRITTEN_BYTES)
    # For `edit_file`: the exact text to find, once, and what replaces it.
    old_text: str | None = Field(default=None, min_length=1, max_length=MAXIMUM_WRITTEN_BYTES)
    new_text: str | None = Field(default=None, max_length=MAXIMUM_WRITTEN_BYTES)
    # Or several replacements at once, applied in order, all or none.
    edits: list[Replacement] | None = Field(default=None, min_length=1, max_length=MAXIMUM_EDITS)
    argv: list[str] | None = Field(default=None, max_length=MAXIMUM_ARGUMENTS)
    # For `fetch_url`: the page to read.
    url: str | None = Field(default=None, min_length=1, max_length=2000,
                            pattern=r"^https?://")
    # For `mcp`: which configured server, which of its tools, and the tool's
    # input as a JSON object, written out.
    server: str | None = Field(default=None, min_length=1, max_length=100)
    tool: str | None = Field(default=None, min_length=1, max_length=200)
    tool_input: str | None = Field(default=None, max_length=20_000)

    @field_validator("argv", mode="before")
    @classmethod
    def one_line(cls, value: object) -> object:
        """A command sent as one string, read as the one-element command line it is.

        Found in use (0.2.42): the instruction says a command line as one string
        works -- meaning ["a && b"] -- and a model sent the string alone; every
        `run` was refused as "not a valid list" three times and a new project
        stopped before its tests ran.
        """
        return [value] if isinstance(value, str) and value.strip() else value

    @field_validator("tool_input", mode="before")
    @classmethod
    def written_out(cls, value: object) -> object:
        """The tool's input sent as the object itself, written out as JSON.

        Found in use (0.2.24): asked for "a JSON object", models sent one, not
        a string; every `mcp` step was refused as not a step, three times in a
        row, and the loop stopped -- reading code outside the workspace went
        through MCP, so it could not be done at all.
        """
        return json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else value
    # For `remember`: the fact, in one or two sentences.
    note: str | None = Field(default=None, min_length=1, max_length=300)
    # For `read_process` and `stop_process`: which background process, by the
    # name `start_process` gave it.
    process: str | None = Field(default=None, pattern=r"^p[0-9]{1,2}$")
    # For `start_process` and `read_process`: how long to wait for output.
    seconds: int | None = Field(default=None, ge=1, le=MAXIMUM_WAIT_SECONDS)
    # For `start_process`: a job that goes on after this run (training, a long
    # evaluation), read later by `read_process`, in this run or another.
    keep: bool | None = None
    # For `finish`: what changed, what was checked, and what is left.
    summary: str | None = Field(default=None, min_length=1, max_length=4000)
    # For `finish`, when the request was to analyze, explain, review or
    # answer a question: the answer itself, in Markdown. Six short summary
    # lines were all a live "analyze this folder" had room for.
    report: str | None = Field(default=None, min_length=1, max_length=MAXIMUM_REPORT)
    # For `plan`: the layout and the steps.
    plan: LoopPlan | None = None
    # For `research`: why, from the closed set, and the comparison to design,
    # in one or two sentences a planner can design from.
    reason: ResearchEscalationReason | None = None
    goal: str | None = Field(default=None, min_length=1, max_length=2000)
    # For `todo`: the whole checklist, as it stands now.
    todos: list[TodoItem] | None = Field(default=None, min_length=1, max_length=MAXIMUM_TODOS)
    # For `ask`: what the person is asked, one short question at a time.
    questions: list[LoopQuestion] | None = Field(default=None, min_length=1, max_length=6)
    # Records written before `questions` existed asked in one paragraph.
    question: str | None = Field(default=None, min_length=1, max_length=2000)

    @model_validator(mode="after")
    def complete(self) -> "LoopAction":
        needs = {
            LoopActionKind.READ_FILES: ("files",),
            LoopActionKind.SEARCH_CODEBASE: ("queries",),
            LoopActionKind.READ_FILE: ("path",),
            LoopActionKind.SEARCH: ("query",),
            LoopActionKind.LIST_FILES: (),
            LoopActionKind.OUTLINE: (),
            LoopActionKind.REFERENCES: ("query",),
            LoopActionKind.FETCH_URL: ("url",),
            LoopActionKind.WRITE_FILE: ("path", "content"),
            LoopActionKind.EDIT_FILE: ("path",),
            LoopActionKind.EDIT_BATCH: ("edit_files",),
            LoopActionKind.RUN: ("argv",),
            LoopActionKind.START_PROCESS: ("argv",),
            LoopActionKind.READ_PROCESS: ("process",),
            LoopActionKind.STOP_PROCESS: ("process",),
            LoopActionKind.PLAN: ("plan",),
            LoopActionKind.ASK: (),
            LoopActionKind.TODO: ("todos",),
            LoopActionKind.RESEARCH: ("reason", "goal"),
            LoopActionKind.EXPLORE: ("goal",),
            LoopActionKind.MCP: ("server", "tool"),
            LoopActionKind.REMEMBER: ("note",),
            LoopActionKind.FINISH: ("summary",),
        }[self.action]
        missing = [name for name in needs if getattr(self, name) is None]
        if missing:
            raise ValueError(f"{self.action.value} needs {', '.join(missing)}")
        if self.action in (LoopActionKind.RUN, LoopActionKind.START_PROCESS) and not self.argv:
            raise ValueError("run needs a command")
        if self.action is LoopActionKind.ASK and not self.questions and not self.question:
            raise ValueError("ask needs questions")
        if self.action is LoopActionKind.EDIT_FILE:
            if self.old_text is None and not self.edits and self.start_line is not None:
                # By line numbers (0.2.53): the lines read, replaced without quoting them.
                if self.line_count is None or self.new_text is None:
                    raise ValueError("edit_file by lines needs start_line, line_count and new_text")
                return self
            single = self.old_text is not None and self.new_text is not None
            if single == bool(self.edits) or (not single and (
                    self.old_text is not None or self.new_text is not None)):
                raise ValueError("edit_file needs old_text and new_text, or edits -- not both"
                                 " (or start_line, line_count and new_text)")
        return self


# How many steps one reply may carry. Enough to read a few files and search
# twice in one call; few enough that a turn that went wrong early wastes little.
MAXIMUM_TURN_ACTIONS = 12


class LoopTurn(Contract):
    """One reply: the steps to take now, in order.

    A model that may only take one step a call spends a call on every file it
    reads; one that sends several independent steps at once does in one call
    what took five. They are still steps -- each validated, performed and
    recorded on its own -- and the turn stops at the first that fails, waits
    or ends, so nothing runs on a result the model has not seen.
    """

    actions: list[LoopAction] = Field(min_length=1, max_length=MAXIMUM_TURN_ACTIONS)


class FileRead(Contract):
    """What a read showed of one file (R04, 0.3.0): which version, and which of its lines.

    Recorded when the read runs, from what it read -- never worked out again
    from the words of its result. A read cut short by its room shows fewer
    lines than the file has, whether a range was asked for or not.
    """

    path: str = Field(min_length=1, max_length=260)
    # Of the whole file as it was read; None when it could not be told (not UTF-8).
    digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    first_line: int = Field(ge=1)
    # The last line the result holds whole; first_line - 1 when it holds none.
    last_line: int = Field(ge=0)
    total_lines: int = Field(ge=0)

    @property
    def whole(self) -> bool:
        return self.first_line == 1 and self.last_line >= self.total_lines


class RuleUse(Contract):
    """One rules file as the loop was given it (R06, 0.3.0): from where, which version, how much.

    The room for rules goes to the nearest first -- the project's, then the
    workspace's, then the person's own, then ReLab's defaults -- so a long
    file further out never crowds out the project's. What did not fit is said
    here, cut or left out, with why.
    """

    file: str = Field(min_length=1, max_length=300)
    level: Literal["default", "personal", "workspace", "project"]
    digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    length: int = Field(ge=0)
    kept: int = Field(ge=0)
    state: Literal["whole", "cut", "left_out"]
    reason: str | None = Field(default=None, max_length=200)


class PromptBudget(Contract):
    """What one call's prompt was made of, and the room left for the reply (R09, 0.3.0).

    In characters by part, as sent; the tokens are estimated from them --
    there is no tokenizer here -- and an image, whose cost is not known, is
    counted at a fixed share, never at nothing.
    """

    system: int = Field(default=0, ge=0)
    tools: int = Field(default=0, ge=0)
    conversation: int = Field(default=0, ge=0)
    images: int = Field(default=0, ge=0)
    # What the images take on the wire (a data URL's characters): not counted as text (F4).
    image_characters: int = Field(default=0, ge=0)
    estimated_tokens: int = Field(ge=0)
    # The prompt the provider reported for the call before, when it did.
    reported_tokens: int | None = Field(default=None, ge=0)
    window: int | None = Field(default=None, ge=1)
    reply_tokens: int
    estimated: bool = True


class CallMeasure(Contract):
    """One model call, measured (R09 11.2, 0.3.6): what it sent, by part and digest, and what came back.

    The manifest says how the latest call was made; these keep every call's,
    so a run's calls can be read one by one -- the budget estimated here, the
    tokens as the provider reported them (None when it did not: not zero), the
    time on the wire as measured here.
    """

    call: int = Field(ge=0)
    purpose: Literal["act", "report", "digest"]
    way: str = Field(min_length=1, max_length=40)
    at: datetime
    instruction_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    tools_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    rules_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    budget: "PromptBudget"
    prompt_tokens: int | None = Field(default=None, ge=0)
    completion_tokens: int | None = Field(default=None, ge=0)
    cached_tokens: int | None = Field(default=None, ge=0)
    seconds: float | None = Field(default=None, ge=0)
    # Until its first streamed piece (0.3.38), None when not streamed: a prompt read slowly
    # shows here, a long reply in `seconds`.
    first_token_seconds: float | None = Field(default=None, ge=0)


class RunManifest(Contract):
    """How a loop's latest call was made (R09): the policy, the prompt's parts by digest, the model.

    Typed, beside `performance` (numbers only). Never a key, a header or an
    address: the model and provider by name.
    """

    relab_version: str | None = Field(default=None, max_length=40)
    code_sha: str | None = Field(default=None, max_length=64)
    policy_revision: str = Field(min_length=1, max_length=40)
    profile: str = Field(min_length=1, max_length=40)
    profile_source: str = Field(min_length=1, max_length=80)
    task_mode: Literal["change", "answer", "review", "plan"]
    call_way: Literal["tools_conversation", "tools_prompt", "json_conversation", "json_prompt"]
    # Each way taken in turn, a fallback included.
    ways: list[str] = Field(default_factory=list, max_length=8)
    instruction: str = Field(min_length=1, max_length=40)
    instruction_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    tools_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    rules_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    check_style: str = Field(min_length=1, max_length=20)
    checks_off: list[str] = Field(default_factory=list, max_length=40)
    plan_first: bool
    default_rules: bool
    personal_rules: bool
    docs_kept: bool
    lessons: int = Field(default=0, ge=0)
    auto: bool
    time_limit_seconds: float | None = Field(default=None, ge=0)
    model: str | None = Field(default=None, max_length=200)
    provider: str | None = Field(default=None, max_length=80)
    reasoning_effort: str | None = Field(default=None, max_length=20)
    budget: PromptBudget | None = None


class LoopStep(Contract):
    """One step taken, and what it showed."""

    index: int = Field(ge=1)
    action: LoopAction
    # What the step returned to the model -- file text, matches, a command's
    # output, or why it was refused -- bounded as it was shown.
    observation: str = Field(max_length=MAXIMUM_STEP_OBSERVATION)
    # False when the step was refused or failed; the loop goes on either way,
    # because a refusal is information the model can act on.
    succeeded: bool
    started_at: datetime
    finished_at: datetime
    # Which model call it came from: the steps of one call are one assistant
    # message when the loop is replayed as a conversation. None in records
    # from before turns were numbered, each then a call of its own.
    turn: int | None = Field(default=None, ge=1)
    # What its result shows of each file it read (R04): none in older records,
    # whose reads then count as showing nothing now.
    files_read: list[FileRead] = Field(default_factory=list, max_length=40)


class WrittenFile(Contract):
    """A file the loop wrote: what it held first, and what it holds now."""

    path: str = Field(min_length=1, max_length=260)
    # Absent when the loop created the file.
    before_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    after_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    # Lines added and removed from what it held first to what it holds now,
    # for a change to be read at a glance; absent for a file that is not text.
    added: int | None = Field(default=None, ge=0)
    removed: int | None = Field(default=None, ge=0)


class FileChange(Contract):
    """One write to one file, as it happened (UX-03): what the file held just
    before it and what it held after, both kept in the snapshot store.

    The loop's `written` says what each file went from and to over the whole
    loop; this says each step on the way, so one change, or everything after a
    checkpoint, can be put back without taking the rest with it.
    """

    change_id: int = Field(ge=1)
    # The step that made it, counted from 1.
    step: int = Field(ge=1)
    path: str = Field(min_length=1, max_length=260)
    # Absent when this change created the file.
    before_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    after_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    added: int | None = Field(default=None, ge=0)
    removed: int | None = Field(default=None, ge=0)
    # Put back on the person's request; the record stays.
    reverted: bool = False
    # The change, short, as the chat shows it (0.2.35); absent in older records.
    diff: str | None = Field(default=None, max_length=12_000)


class FollowUp(Contract):
    """A request the person made after the loop had answered, gone on with in the same loop.

    As in Cline, a conversation is one context: the next question is put to
    the model that has every step, result and answer before it, not to a new
    loop told about them in a summary.
    """

    request: str = Field(min_length=1, max_length=8000)
    # How many steps the loop had taken when it was asked.
    after_step: int = Field(ge=0)
    at: datetime


class Checkpoint(Contract):
    """A point worth coming back to: the changes made up to it (UX-03)."""

    checkpoint_id: int = Field(ge=1)
    label: str = Field(min_length=1, max_length=200)
    # How many changes had been made when it was taken.
    changes: int = Field(ge=0)
    created_at: datetime


class Revert(Contract):
    """A request to put files back, and what it did -- kept for the record."""

    # "loop", "file:<path>", "change:<id>" or "checkpoint:<id>".
    target: str = Field(min_length=1, max_length=300)
    restored: list[str] = Field(default_factory=list)
    # Left as they were, because they no longer hold what the loop wrote.
    kept: list[str] = Field(default_factory=list)
    at: datetime


class EditReview(Contract):
    """A change to one file, shown to the person before it is written."""

    path: str = Field(min_length=1, max_length=260)
    # What the file holds now; absent when the change creates it.
    before_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    # What it would hold once accepted.
    after_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    added: int | None = Field(default=None, ge=0)
    removed: int | None = Field(default=None, ge=0)


class DecidedReview(EditReview):
    """A change shown to the person, and whether they accepted it (RL-08).

    Kept after the decision, so the record says what was turned down, and the
    contents shown stay named by it: dropped, a rejected change's contents were
    left in the snapshot store with nothing naming them.
    """

    accepted: bool
    at: datetime


class ProcessState(str, Enum):
    RUNNING = "running"
    # It ended on its own; `exit_code` says how.
    EXITED = "exited"
    # Stopped: by the model, or because the loop stopped or paused. A process
    # lives no longer than the leg of the loop that started it.
    STOPPED = "stopped"


class BackgroundProcess(Contract):
    """A program a loop started in the background, and what became of it."""

    name: str = Field(pattern=r"^p[0-9]{1,2}$")
    argv: list[str] = Field(min_length=1, max_length=MAXIMUM_ARGUMENTS)
    pid: int = Field(ge=1)
    # Its output, stdout and stderr together, under `.relab/processes/`.
    log: str = Field(min_length=1, max_length=1000)
    started_at: datetime
    state: ProcessState = ProcessState.RUNNING
    exit_code: int | None = None
    # A job (P5): started apart, it goes on after the run that started it, and a
    # later run reads its log from `read_to` and its exit code from `exit_file`.
    kept: bool = False
    exit_file: str | None = Field(default=None, max_length=1000)
    read_to: int = Field(default=0, ge=0)
    # When what it runs is a check (EVI-09, 0.3.3): which, from where, run in which
    # folder, on which revision of the work it started -- and whether what it found,
    # once it ended, has been kept as evidence. None in records from before.
    check: str | None = Field(default=None, max_length=120)
    check_origin: Literal["project", "person", "acceptance", "model"] | None = None
    check_cwd: str | None = Field(default=None, max_length=300)
    input_revision: str | None = Field(default=None, max_length=80)
    evidence_kept: bool = False


class LoopOutcome(str, Enum):
    """How a loop ended."""

    RUNNING = "running"
    # Waiting for the person to answer the question the loop asked.
    WAITING = "waiting"
    # The model said it was done, with a summary.
    FINISHED = "finished"
    # The step budget ran out first.
    BUDGET_SPENT = "budget_spent"
    # The model could not be reached or replied with nothing usable, often
    # enough that going on would only spend more.
    FAILED = "failed"
    # Every file it wrote was restored.
    UNDONE = "undone"
    # It proposed a measured comparison; nothing was started.
    ESCALATED = "escalated"
    # The person stopped it part-way. What it wrote is kept, and can be undone.
    STOPPED = "stopped"


class ResearchEscalation(Contract):
    """A measured comparison a coding loop proposed, for the person to start or not."""

    reason: ResearchEscalationReason
    goal: str = Field(min_length=1, max_length=2000)
    session_id: str | None = None


class ModelChangeReason(str, Enum):
    """Why the model working a loop changed. Closed, and read from the record.

    A larger model is called on when the record says the one working is stuck
    -- never because a model asked for one, and never for a provider's
    failure (a timeout or a rate limit is not the model's).
    """

    # The same check failed again and again, with changes between.
    REPEATED_CHECK_FAILURE = "repeated_check_failure"
    # Its replies were not steps, or ran past the output limit, time after time.
    UNREADABLE_REPLIES = "unreadable_replies"
    # Only read, or sent the same steps, without moving.
    STALLED = "stalled"
    # Spent its budget without finishing.
    BUDGET_SPENT = "budget_spent"
    # The person chose the model to go on with.
    CHOSEN_BY_PERSON = "chosen_by_person"
    # The loop before it in the conversation had moved up to it: a follow-up
    # does not start back down on the smaller model.
    KEPT_FROM_BEFORE = "kept_from_before"
    # The larger model could not be reached -- its server down or past its
    # time -- so the model below it went on (0.2.96): asked in use, a ladder
    # whose top was down had stopped the work instead of leaving it where it was.
    LARGER_UNREACHABLE = "larger_unreachable"


class SteeringStatus(str, Enum):
    # Given while the loop ran, and read into it at a turn's end.
    APPLIED = "applied"
    # Arrived as the loop was ending: never read by it, so it is the next request.
    QUEUED = "queued"


class SteeringInstruction(Contract):
    """What the person said while a loop worked, to the work in hand (UX-02).

    Found in use: a message typed while a loop ran waited for it to end and
    then started a task of its own. Said to the running loop instead, it is
    read at the next turn's end and comes before the request where they differ.
    """

    steering_id: str = Field(pattern=r"^steer-[0-9a-f]{32}$")
    instruction: str = Field(min_length=1, max_length=4000)
    created_at: datetime
    status: SteeringStatus = SteeringStatus.QUEUED
    applied_at: datetime | None = None
    # The steps the loop had taken when it read this.
    applied_after_step: int | None = Field(default=None, ge=0)


class PendingWrite(Contract):
    """A write about to happen, saved before the file is touched (RL-06).

    A process ended between writing a file and saving the record left a file
    changed that the record did not know of -- not in `written`, so not undone.
    Saved first, it is settled when the loop is next taken up: done (the file
    holds `after_digest`) and recorded; not done (it holds `just_before`) and
    dropped; or neither, and said to be changed outside.
    """

    path: str = Field(min_length=1, max_length=260)
    step: int = Field(ge=1)
    before_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    just_before: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    after_digest: str = Field(pattern=r"^[0-9a-f]{64}$")


class ModelChange(Contract):
    """One change of the model working a loop: when, from what, to what, and why."""

    at_call: int = Field(ge=0)
    at_step: int = Field(ge=0)
    from_model: str = Field(min_length=1, max_length=256)
    to_model: str = Field(min_length=1, max_length=256)
    reason: ModelChangeReason
    said: str = Field(min_length=1, max_length=400)
    # What the loop had spent when it changed, as the provider reported it, so
    # each model's share of a ladder's cost and tokens can be told (RL-05).
    # None in records from before, or where nothing was reported.
    cost_before: float | None = Field(default=None, ge=0)
    prompt_tokens_before: int | None = Field(default=None, ge=0)
    completion_tokens_before: int | None = Field(default=None, ge=0)


# Models a ladder may hold, smallest first.
MAXIMUM_LADDER = 6


class CodingLoop(Contract):
    """One request worked through, step by step, as it happened."""

    loop_version: str = "coding-loop-v1"
    performance: dict[str, float] = Field(default_factory=dict)
    plan_only: bool = False
    evidence: list[EvidencePackage] = Field(default_factory=list, max_length=4)
    decisions: list[EngineeringDecision] = Field(default_factory=list, max_length=100)
    unlinked_decisions: list[str] = Field(default_factory=list, max_length=100)
    loop_id: str = Field(pattern=r"^loop-[0-9a-f]{32}$")
    request: str = Field(min_length=1, max_length=8000)
    started_at: datetime
    steps: list[LoopStep] = Field(default_factory=list)
    written: list[WrittenFile] = Field(default_factory=list)
    outcome: LoopOutcome = LoopOutcome.RUNNING
    # The model's summary when it finished; ReLab's own sentence otherwise.
    summary: str | None = Field(default=None, max_length=4000)
    # The checks the loop ran and how they ended, newest last: the project's own
    # tests, never measured research evidence, and labelled as such wherever
    # they are shown.
    checks: list[str] = Field(default_factory=list)
    # Whether the task is done and whether it was verified (0.3.0), apart from
    # `outcome`: FINISHED is the model's word, this the verdict. None in a record
    # from before it existed, read as unknown -- never as passed or failed.
    assessment: CompletionAssessment | None = None
    # The runs that verified something, made by ReLab from what it ran (0.3.0).
    verifications: list[VerificationEvidence] = Field(default_factory=list, max_length=200)
    # Finishes held back for this request revision and repaired since (0.3.0):
    # kept with the record, so a restart does not give the repairs back.
    finish_repairs: int = Field(default=0, ge=0)
    # Finishes short of the request's goal sent back to go on, with room left
    # (0.3.15): the step of the score each was sent back on, for this request.
    goal_holds: list[int] = Field(default_factory=list, max_length=10)
    # Which revision of the request (with what was said while it ran) was judged:
    # a new requirement given while it works is a new revision.
    requirements_revision: int = Field(default=0, ge=0)
    # The answer, when the request was one to analyze, explain or answer.
    report: str | None = Field(default=None, max_length=MAXIMUM_REPORT)
    # Its checklist, as the model last wrote it.
    todos: list[TodoItem] = Field(default_factory=list)
    # Programs it started in the background, running or not.
    processes: list[BackgroundProcess] = Field(default_factory=list)
    # Model calls tried again after a transport failure, in all; each leg may
    # spend at most a fixed few (`relab_app.coding_loop.TRANSPORT_RETRIES`).
    retries: int = Field(default=0, ge=0)
    # Why it ended before, when the person asked it to go on from there.
    resumed_after: str | None = Field(default=None, max_length=4000)
    # Whether its replies came as native tool calls (True) or as JSON (False),
    # in its latest leg; None before it asked anything.
    tool_calls: bool | None = None
    # Model calls made, in all its legs: what a budget is counted in, since a
    # call may carry several steps.
    calls: int = Field(default=0, ge=0)
    # The last step whose result is shown cut short when the loop is replayed
    # as a conversation: set once the conversation grows past its bound, and
    # only moved forward, so what came before it reads the same every call.
    compacted_through: int = Field(default=0, ge=0)
    # The model's own summary of the steps cut short, and the last step it
    # covers: what was found, changed, failed and decided, kept when the
    # results themselves no longer are.
    digest: str | None = Field(default=None, max_length=MAXIMUM_DIGEST)
    digest_through: int = Field(default=0, ge=0)
    # How long its legs took, in all, and the tokens its calls spent as the
    # provider reported them -- None while no reply has reported any.
    seconds: float = Field(default=0.0, ge=0)
    prompt_tokens: int | None = Field(default=None, ge=0)
    completion_tokens: int | None = Field(default=None, ge=0)
    # Of the prompt tokens, those served from the provider's cache; and what
    # its calls cost in US dollars -- each only as the provider reported it.
    cached_tokens: int | None = Field(default=None, ge=0)
    cost: float | None = Field(default=None, ge=0)
    # The context in use: the latest call's prompt tokens, as reported; the
    # window of the model working it, when known; and how often the steps cut
    # short were summarized to make room.
    context_tokens: int | None = Field(default=None, ge=0)
    context_window: int | None = Field(default=None, ge=1)
    digests: int = Field(default=0, ge=0)
    # Of those, the ones whose model call gave no summary -- a timeout, a
    # reply that was not JSON, an empty one -- and were written from the
    # record instead; and why the latest of them failed (RL-01).
    digest_failures: int = Field(default=0, ge=0)
    # Call modes a leg started without because the server was found, by an
    # earlier loop, not to take them (RL-05): "native_tools: HTTP 400, tools".
    remembered_modes: list[str] = Field(default_factory=list, max_length=4)
    # A write saved as about to happen and not yet recorded as done (RL-06).
    pending_write: PendingWrite | None = None
    # Files this loop wrote that were found, when it was taken up again, to hold
    # something else -- changed by the person or a command while it was stopped
    # or waiting: "path: changed since it was written" / "path: removed". The
    # latest leg's.
    drift: list[str] = Field(default_factory=list, max_length=50)
    digest_failure: str | None = Field(default=None, max_length=200)
    # Ended because it only read, step after step, and wrote nothing: not a
    # budget to extend without a look.
    stalled: bool = False
    # Reads only inside its project folder: another folder of the workspace
    # is not read, searched or listed -- as when the folder beside it is the
    # other half of a comparison.
    project_only: bool = False
    # The loop this one follows in the same conversation, when there is one: it
    # inherits that loop's project folder and is shown what came before. A live
    # "now add subtraction" knew nothing of the "write addition" before it, and
    # a later "make verify test all of them" rewrote another folder's verify.py.
    after: str | None = Field(default=None, pattern=r"^loop-[0-9a-f]{32}$")
    # What earlier loops here learned by failing, given to this one at its
    # start because they match its request, files or project (M6.1) -- and,
    # after a command of its own failed, those matching that error (M7b).
    lessons: list[str] = Field(default_factory=list, max_length=12)
    # The rule files the loop was given (RELAB.md, AGENTS.md, CLAUDE.md...),
    # so a person can see which of them it read.
    rules: list[str] = Field(default_factory=list, max_length=64)
    # Each of them as given (R06): its version, how much of it, and what did not
    # fit; and how many times they changed while the loop ran, a turn later.
    rules_used: list[RuleUse] = Field(default_factory=list, max_length=64)
    rules_revision: int = Field(default=0, ge=0)
    # How its latest call was made (R09); None in records from before.
    manifest: RunManifest | None = None
    # Each call, measured, newest last (0.3.6): empty in records from before.
    calls_measured: list[CallMeasure] = Field(default_factory=list, max_length=400)
    # Each write, in order; the points worth coming back to; and each request
    # to put files back (UX-03). Empty for a loop recorded before them, which
    # can still be undone file by file or whole.
    changes: list[FileChange] = Field(default_factory=list)
    # The requests made after the first, in order, each gone on with here.
    followups: list[FollowUp] = Field(default_factory=list, max_length=100)
    checkpoints: list[Checkpoint] = Field(default_factory=list, max_length=200)
    reverts: list[Revert] = Field(default_factory=list)
    # What the person said while it worked, in the order said (UX-02).
    steering: list[SteeringInstruction] = Field(default_factory=list, max_length=100)
    # The loop this one is a read-only helper of, when it is one: it explored
    # for that loop and reported back, and is not a conversation of its own.
    helper_of: str | None = Field(default=None, pattern=r"^loop-[0-9a-f]{32}$")
    # The project folder the loop works in, when it has one: named by the
    # request, set by an approved plan whose files all sit under it, or given.
    # Nothing is written outside it, and its code imports nothing from another
    # folder of this workspace -- a project has to ship on its own.
    scope: str | None = Field(default=None, min_length=1, max_length=260)
    # The whole workspace is the project, said outright (a task's scope "."):
    # no folder is inferred later from a plan or from what was written.
    whole_workspace: bool = False
    # The code plan it proposed, and whether the person approved it.
    plan: LoopPlan | None = None
    plan_approved: bool = False
    # The comparison it proposed, when it ended by proposing one.
    escalation: ResearchEscalation | None = None
    # The model working it now, when one was named; the models it may move up
    # through, smallest first, when a ladder was declared; and each move.
    model: str | None = Field(default=None, min_length=1, max_length=256)
    ladder: list[str] = Field(default_factory=list, max_length=MAXIMUM_LADDER)
    model_changes: list[ModelChange] = Field(default_factory=list)
    # The larger model offered to go on with, when it stopped stuck and moving
    # up was the person's to decide (Ask mode).
    next_model: str | None = Field(default=None, min_length=1, max_length=256)
    # A command the loop is waiting for the person to allow, and why it asks.
    permission: list[str] | None = Field(default=None, max_length=MAXIMUM_ARGUMENTS)
    permission_reason: str | None = Field(default=None, max_length=400)
    # The shape a rule allowing commands like it would take (`npm install`),
    # offered beside the command as "always allow".
    permission_rule: list[str] | None = Field(default=None, max_length=8)
    # Whether each change to a file is shown to the person before it is
    # written (the editor's Ask mode), and whether they accepted every change
    # for the rest of this loop.
    review_edits: bool = False
    edits_accepted: bool = False
    # A change the loop is waiting for the person to accept, while it waits.
    review: EditReview | None = None
    # Every change shown before writing, once the person decided (RL-08).
    reviewed: list[DecidedReview] = Field(default_factory=list, max_length=500)
    # What the loop is waiting on, while it waits.
    questions: list[LoopQuestion] = Field(default_factory=list)
    question: str | None = Field(default=None, max_length=2000)
