"""Where a research session stands and what it needs next, derived from its records."""

from enum import Enum

from pydantic import Field

from relab_core.contracts import Contract
from relab_core.measurement import (
    MAXIMUM_CLAIMS,
    MAXIMUM_REQUIREMENTS,
    ClaimDispatchBlocker,
    MeasurementInvalidity,
)
from relab_core.reconciliation import SessionReconciliation
from relab_core.research import ResearchSessionAssessment, ResearchSessionReadiness
from relab_core.runs import PendingHumanGate
from relab_core.sensitivity import MeasurementSensitivity


class LifecyclePhase(str, Enum):
    """Derived for display and never persisted, like the client's session state."""

    PLANNING = "planning"
    DISPATCHING = "dispatching"
    BUDGET_EXHAUSTED = "budget_exhausted"
    # The instrument, not the arms. A study whose frozen measurement broke its
    # contract cannot advance by running anything again, so it is not waiting,
    # not exhausted, and not stuck on a failure -- it needs a different ruler.
    NEEDS_MEASUREMENT_REPAIR = "needs_measurement_repair"
    EXECUTING = "executing"
    AWAITING_HUMAN = "awaiting_human"
    NEEDS_RECOVERY = "needs_recovery"
    ASSESSING = "assessing"
    HOLDOUT = "holdout"
    CONCLUDING = "concluding"
    CONCLUDED = "concluded"


class LifecycleAction(str, Enum):
    """The one operation that moves this session forward; the CLI names the command."""

    NONE = "none"
    RECORD_PLAN = "record_plan"
    REVISE_PLAN = "revise_plan"
    DECLARE_ARM_TASKS = "declare_arm_tasks"
    RECOVER = "recover"
    INSPECT_HISTORY = "inspect_history"
    WAIT = "wait"
    RESOLVE_GATE = "resolve_gate"
    # Build the plan-owned measurement and freeze it. Mechanical: the plan that
    # declared it was already approved, so there is no second judgement to make.
    MATERIALISE_MEASUREMENT = "materialise_measurement"
    # Run the frozen ruler against the design's declared controls. Mechanical
    # for the same reason, and before any arm: a ruler that cannot be run on a
    # control's subjects cannot be run on an arm's either.
    CALIBRATE_MEASUREMENT = "calibrate_measurement"
    EXECUTE = "execute"
    REVIEW_BUDGET = "review_budget"
    # The same failure keeps happening; attempts remain but repeating is not a plan.
    REVIEW_FAILURES = "review_failures"
    # The frozen measurement did not measure. Retrying the arms cannot repair
    # it, because every arm is measured by that same frozen file.
    REVISE_MEASUREMENT = "revise_measurement"
    EVALUATE_HOLDOUT = "evaluate_holdout"
    CONCLUDE = "conclude"


class MeasurementBlocker(Contract):
    """What was wrong with the instrument, as data rather than as a sentence.

    `blockers` is prose and will be reworded. A surface that had to recognise
    "the verifier did not report..." to tell a measurement failure from a spent
    budget would break the first time somebody improved the wording, and the
    two need different things from a person.
    """

    # Every distinct way this study's measurement broke its contract, in the
    # order the taxonomy declares them. Several at once is ordinary: each arm
    # is measured by the same file and can fail it differently.
    invalidities: list[MeasurementInvalidity] = Field(min_length=1, max_length=4)
    # The runs that found it. Their code and their patches are untouched by
    # this; what they lack is a measurement.
    affected_runs: list[str] = Field(min_length=1, max_length=64)
    # The arms those runs belong to, named for the same reason `blocked_arms`
    # is: so nothing has to read a name back out of a sentence.
    affected_arms: list[str] = Field(default_factory=list, max_length=8)


class MeasurementClaimBlocker(Contract):
    """What the ruler does not say it covers, as data rather than as a sentence.

    A sibling of `MeasurementBlocker` and deliberately not an extension of it,
    because the two answer different questions about the same file.

        MeasurementBlocker        the measurement ran and broke its contract
        MeasurementClaimBlocker   the ruler does not claim to check the study

    They can be true at once, they are repaired differently, and folding the
    second into the first's `invalidities` would make "this reading is not
    evidence" and "this instrument was never pointed at the question" the same
    finding -- which is exactly the conflation the whole measurement axis was
    split up to stop.

    Both end at `REVISE_MEASUREMENT`, because neither is repaired by running
    another arm. That is what they have in common and all of it.
    """

    # Which of the two ways the claims fall short.
    blocker: ClaimDispatchBlocker
    # The ruler this is about. A study that replaces it starts this over.
    snapshot_id: str = Field(min_length=1, max_length=64)
    declared_requirement_ids: list[str] = Field(default_factory=list,
                                                max_length=MAXIMUM_REQUIREMENTS)
    claimed_requirement_ids: list[str] = Field(default_factory=list,
                                               max_length=MAXIMUM_CLAIMS)
    # The finding, named so a surface never reads an identifier out of prose.
    uncovered_requirement_ids: list[str] = Field(default_factory=list,
                                                 max_length=MAXIMUM_REQUIREMENTS)
    unknown_claim_ids: list[str] = Field(default_factory=list, max_length=MAXIMUM_CLAIMS)
    # The verifications that gave this ruler a real chance to declare, for
    # `CLAIMS_STILL_UNOBSERVED`. Named rather than counted, so a surface does
    # not reconstruct "it has had its chance" from how many arms are attached --
    # which is the wrong count, because an attempt that never reached the
    # verifier gave it no chance at all.
    opportunity_run_ids: list[str] = Field(default_factory=list, max_length=64)


class SessionLifecycle(Contract):
    report_version: str = "session-lifecycle-v1"
    session_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    phase: LifecyclePhase
    action: LifecycleAction
    detail: str = Field(min_length=1)
    attempts_per_slot: int = Field(default=1, strict=True, ge=1, le=3)
    exhausted_arms: list[str] = Field(default_factory=list)
    # Arms hitting one failure over and over. Distinct from exhausted: attempts
    # are left, and spending them on the same approach would waste them.
    stuck_arms: list[str] = Field(default_factory=list)
    # Everything that must change before this action can succeed, written for a
    # person to read.
    blockers: list[str] = Field(default_factory=list)
    # The arms those blockers are about, named as data. `blockers` is prose and
    # will be reworded; anything that needs to *act* on which arm is blocked reads
    # this instead. A surface parsing an arm name back out of a sentence would
    # break silently the first time the sentence changed.
    blocked_arms: list[str] = Field(default_factory=list)
    reconciliation: SessionReconciliation
    gates: list[PendingHumanGate] = Field(default_factory=list)
    # Absent until a plan declares arms, because coverage is undefined without them.
    readiness: ResearchSessionReadiness | None = None
    assessment: ResearchSessionAssessment | None = None
    # Present when this study's own measurement is what stopped it. Absent is
    # the ordinary case and says nothing about how the arms are doing.
    measurement_blocker: MeasurementBlocker | None = None
    # And what it does not say it covers, which is a different repair.
    measurement_claim_blocker: MeasurementClaimBlocker | None = None
    # What the declared controls have shown about the ruler, when any were
    # declared. Carried and not acted on: this reports, and nothing here stops a
    # study because of it.
    #
    # Deliberately no blocker yet. MQ1's finding was strong -- a ruler that will
    # not even say it checks the study needs no interpretation -- and this one
    # is not: a control that showed nothing may mean a blind instrument, a badly
    # written control, a separation asked for that was too large, or an
    # expectation nobody but a model established. The distribution is worth
    # seeing before anything is stopped on it.
    measurement_sensitivity: MeasurementSensitivity | None = None
