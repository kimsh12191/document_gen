"""A skill: a typed name for work that already exists, and what it may change.

`docs/architecture/SKILL_MODEL.md` is the design. A skill declares its effect:

- READ touches nothing;
- RECORD appends to a store and changes no tree;
- MUTATE changes a working tree or an environment, or runs a command.

A caller says which effects it permits, and a skill whose effect is not among
them is refused before it starts -- the declaration is what is checked, so a
skill that misdeclared its effect would route around the rules the
application layer keeps for each. Every invocation, refused ones included, is
recorded, so what was asked for and what happened is read from the record.
"""

from datetime import datetime
from enum import Enum

from pydantic import Field

from relab_core.contracts import Contract

SKILL_NAME = r"^[a-z][a-z0-9_]{2,40}$"


class SkillEffect(str, Enum):
    READ = "read"
    RECORD = "record"
    MUTATE = "mutate"


class SkillDefinition(Contract):
    """What a skill is called, what it does, and what it may change."""

    name: str = Field(pattern=SKILL_NAME)
    summary: str = Field(min_length=1, max_length=400)
    effect: SkillEffect
    # The existing code it delegates to, so the skill is a name and not a copy.
    delegates_to: str = Field(min_length=1, max_length=200)


class SkillOutcome(str, Enum):
    DONE = "done"
    # Its effect was not permitted, or its input was not valid: nothing ran.
    REFUSED = "refused"
    # It ran and could not do its work; the reason is recorded.
    FAILED = "failed"


class SkillInvocation(Contract):
    """One request to run one skill, and what came of it."""

    invocation_id: str = Field(pattern=r"^skill-[0-9a-f]{32}$")
    skill: str = Field(pattern=SKILL_NAME)
    effect: SkillEffect
    # Who asked: "cli", "evaluation", or a coding loop's id.
    caller: str = Field(min_length=1, max_length=80)
    input: dict[str, object]
    outcome: SkillOutcome
    # One line: what it found or did, or why it was refused or failed.
    said: str = Field(max_length=400)
    started_at: datetime
    ended_at: datetime
