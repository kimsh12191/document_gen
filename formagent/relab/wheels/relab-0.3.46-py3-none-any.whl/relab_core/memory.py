"""What was learned, as distinct from what happened.

Evidence says what happened. A finding says what, of that, is worth carrying into
the next experiment. The two are kept apart because they are worth different
things: evidence is a record, a finding is a second-order claim derived from one.

The rule that keeps this honest is that a finding **cites the evidence it came
from, and that citation must resolve**. A memory store that accepted unsupported
findings would be the one place where "a claim is worth what its evidence is
worth" stopped being true, and the most damaging place, because findings are what
the next plan is built from.
"""

from datetime import datetime

from pydantic import Field, model_validator

from relab_core.contracts import Contract

MAXIMUM_CITATIONS = 64
MAXIMUM_CONDITIONS = 16
MAXIMUM_TAGS = 16
DEFAULT_RETRIEVAL_LIMIT = 10
MAXIMUM_RETRIEVAL_LIMIT = 100


class EvidenceCitation(Contract):
    """One run event a finding rests on, named precisely enough to be checked."""

    run_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)


class MemoryDraft(Contract):
    """A finding as someone writes it, before it is one this workspace holds.

    It carries no identity and no time, because neither is the author's to state:
    a draft is a claim, and what makes it a record is the act of recording it.
    """

    # What was observed, in one sentence.
    finding: str = Field(min_length=1, max_length=2000)
    # Where it is believed to hold. "batch=16 fails" is not a finding; "batch=16
    # fails for this model in this environment" is. A finding without a scope is a
    # generalisation nobody checked.
    scope: str = Field(min_length=1, max_length=500)
    conditions: list[str] = Field(default_factory=list, max_length=MAXIMUM_CONDITIONS)
    # At least one: a finding that cites nothing is an opinion.
    citations: list[EvidenceCitation] = Field(min_length=1, max_length=MAXIMUM_CITATIONS)
    tags: list[str] = Field(default_factory=list, max_length=MAXIMUM_TAGS)

    @model_validator(mode="after")
    def supported_claim(self) -> "MemoryDraft":
        if any(not item.strip() for item in self.conditions):
            raise ValueError("a stated condition must not be blank")
        if any(not tag.strip() for tag in self.tags):
            raise ValueError("a tag must not be blank")
        cited = {(item.run_id, item.event_sequence) for item in self.citations}
        if len(cited) != len(self.citations):
            raise ValueError("a finding must not cite the same run event twice")
        return self

    @property
    def sample_size(self) -> int:
        """How many distinct runs this rests on.

        Derived rather than stored, so it cannot disagree with the evidence. One
        OOM is one OOM; three runs is three, and the number is what makes a
        finding readable as weak or strong rather than a bare claim.
        """
        return len({item.run_id for item in self.citations})


class MemoryItem(MemoryDraft):
    """A recorded finding: a draft, plus the identity and time of its recording."""

    memory_version: str = "research-memory-v1"
    memory_id: str = Field(min_length=1)
    created_at: datetime
    # Set when a later finding replaces this one. Never deleted: the record of
    # what was believed, and when, is part of the record of how a conclusion was
    # reached.
    superseded_by: str | None = Field(default=None, min_length=1)

    @model_validator(mode="after")
    def not_its_own_replacement(self) -> "MemoryItem":
        if self.superseded_by == self.memory_id:
            raise ValueError("a finding cannot supersede itself")
        return self


class MemoryQuery(Contract):
    """What was asked for, recorded alongside what came back."""

    scope: str | None = Field(default=None, min_length=1, max_length=500)
    tags: list[str] = Field(default_factory=list, max_length=MAXIMUM_TAGS)
    include_superseded: bool = False
    limit: int = Field(default=DEFAULT_RETRIEVAL_LIMIT, strict=True, ge=1,
                       le=MAXIMUM_RETRIEVAL_LIMIT)


class MemoryMatch(Contract):
    """One retrieved finding, with why it matched.

    Retrieval that cannot say why it returned something is retrieval nobody can
    argue with, and what it returns is what the next plan is built from.
    """

    item: MemoryItem
    matched_scope: bool = False
    matched_tags: list[str] = Field(default_factory=list, max_length=MAXIMUM_TAGS)


class MemoryRetrieval(Contract):
    """Exactly what was retrieved, for exactly what question."""

    query: MemoryQuery
    matches: list[MemoryMatch] = Field(default_factory=list)
    # How many items matched, which is not how many came back. A caller that asked
    # for five of twenty is told there were twenty; a truncated retrieval silently
    # presented as the whole answer is how "we never tried that" gets said about
    # something that was tried.
    considered: int = Field(default=0, ge=0)
    truncated: bool = False
