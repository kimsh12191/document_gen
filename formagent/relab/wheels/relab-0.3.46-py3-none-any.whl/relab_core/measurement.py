"""Who holds the ruler, as distinct from who is being measured.

An arm owns what it changes. Nothing had ever owned the thing that decides
whether the change worked, and a greenfield task made that absence visible: a
design proposed a verifier, no arm could create it because a verifier belongs to
no arm, and the run was reverted for a missing file.

The two candidate answers were both worse than this one. An arm creating its own
verifier means two arms measured by two rulers, and a comparison between them
says nothing. An arm creating *another* arm's verifier is the thing being
measured writing its own answer sheet. So the measurement belongs to the plan:

    Plan
      |-- measurement          plan-owned, created once, frozen before any arm runs
      |     |-- artifacts      the verifier, its fixtures, its reference data
      |     `-- verify_argv    the one command every arm is measured by
      |
      |-- arm A targets        arm-owned
      `-- arm B targets        arm-owned

Two rules follow, and both are mechanical rather than matters of judgement.

**Disjoint ownership.** No arm target may name a measurement artifact. An arm
that could rewrite the verifier could pass by rewriting it.

**A local verifier must be declared.** If `verify_argv` runs a file inside the
workspace, that file has to be a measurement artifact. This is what finally makes
`targets=["candidate.py"]` with `verify_argv=["python", "candidate.py"]` a
refusal rather than a design nobody noticed -- the gap recorded in the gap
analysis as mechanically detectable and not yet closed.

Freezing is the third rule. Artifacts may be created and revised until the
measurement is frozen, and the freeze happens **before the first arm is
dispatched** -- not after the first result. Waiting for a result leaves a window
where arm A is already running, nothing is recorded yet, the verifier is edited,
and arm A's number arrives afterwards: the ruler moved under an experiment
already in flight. Writing the exam after seeing any of the answers is the same
act as moving the deciding rules, and is refused on the same grounds.
"""

import re
from datetime import datetime
from enum import Enum

from pydantic import Field, model_validator

from relab_core.coding.patch import MeasuredSubject
from relab_core.contracts import Contract
from relab_core.targets import EDITABLE_TARGET_PATTERN, unusable_target

MAXIMUM_ARTIFACTS = 8
# What a study may ask of one measurement. A design with more requirements
# than this has more to say than one ruler is the place to say it in.
MAXIMUM_REQUIREMENTS = 32


class MeasurementKind(str, Enum):
    """What an artifact is for. Named because they fail differently.

    A missing verifier means nothing can be measured at all; a missing fixture
    means it measures the wrong thing. Recording which is which is what lets a
    refusal say something useful later.
    """

    VERIFIER = "verifier"
    FIXTURE = "fixture"
    REFERENCE_DATA = "reference_data"


class ArtifactSource(str, Enum):
    """Where the artifact comes from, which is three answers rather than two.

    `USE_EXISTING` is not "edit": a measurement artifact already in the workspace
    is adopted as it stands and never rewritten. There is deliberately no way to
    say "change the verifier", because that is what a new plan revision is for.

    The third value exists because "already in the workspace" turned out to cover
    two different things, and only one of them is a project's own ruler:

        USE_EXISTING     the project's, written by whoever owns the project
        REUSE_RECORDED   made by an earlier session of this workspace

    A live session adopted `tools/verify.py` under `USE_EXISTING`. That file had
    been created by an earlier session, for a different design, and it counted a
    test suite nobody in the new design was asked to write -- so every arm scored
    the floor value and the pre-registered rules held over evidence that
    separated nothing.

    The planner had done nothing wrong: a file was there, and it said so. What
    was missing is that reusing a previous experiment's instrument is a claim
    about the two designs being comparable, and a claim nobody made is a claim
    nobody can be wrong about. So it is said, or it is refused.
    """

    CREATE = "create"
    USE_EXISTING = "use_existing"
    REUSE_RECORDED = "reuse_recorded"


class MeasurementArtifact(Contract):
    """One file the measurement owns."""

    path: str = Field(pattern=EDITABLE_TARGET_PATTERN)
    kind: MeasurementKind
    operation: ArtifactSource

    @model_validator(mode="after")
    def usable_path(self) -> "MeasurementArtifact":
        wrong = unusable_target(self.path)
        if wrong is not None:
            raise ValueError(wrong)
        return self


class MeasurementSetup(Contract):
    """The ruler: what it is made of, and the command that reads it."""

    artifacts: list[MeasurementArtifact] = Field(min_length=1,
                                                 max_length=MAXIMUM_ARTIFACTS)
    verify_argv: list[str] = Field(min_length=1)

    @model_validator(mode="after")
    def coherent_measurement(self) -> "MeasurementSetup":
        named = [artifact.path for artifact in self.artifacts]
        if len({path.casefold() for path in named}) != len(named):
            raise ValueError("a measurement names each artifact once")
        if sum(1 for item in self.artifacts
               if item.kind is MeasurementKind.VERIFIER) != 1:
            # Exactly one. No verifier means nothing measures; two means nobody
            # can say which reading decided the experiment.
            raise ValueError("a measurement has exactly one verifier")
        if any(not item.strip() for item in self.verify_argv):
            raise ValueError("a verification argument must not be blank")
        return self

    @property
    def paths(self) -> set[str]:
        """Every path this measurement owns, for comparing against arm targets."""
        return {artifact.path for artifact in self.artifacts}


class MeasurementRequirement(Contract):
    """One thing the research asks its measurement to check.

    Not part of `MeasurementSetup`, on purpose, and the reason is worth keeping
    where somebody will be tempted to move it. `MeasurementSetup` is instrument
    *identity*: the artifacts and the command, frozen into a snapshot that every
    reading is pinned to. A requirement is not part of the instrument -- it is
    what the study asks of one.

    Put inside the setup, the type's own shape would suggest that adding a
    requirement changes the ruler, and changing the ruler retires every reading
    taken under it. That is not the meaning. Adding a requirement does not
    change what the verifier does; it changes what we require of it, so the
    readings stand and only their *qualification* moves.

        the reading's identity        unchanged
        the reading's standing as
        evidence for this question    may change

    which is the same shape M2 already established for a revised ruler, read
    from the other direction.

    A statement is for a person to read and for a prompt to carry. Nothing
    parses it. What is mechanical is the identifier, and all it supports is
    asking whether anything claims to check this.
    """

    # No version of its own, like the artifact and the setup beside it: this is
    # a value inside a plan and the plan carries the version.
    #
    # Stable, and stable is the whole job: a verifier's claim is matched to a
    # requirement by this and by nothing else.
    requirement_id: str = Field(pattern=r"^[A-Z][A-Z0-9]*(-[A-Z0-9]+)*$",
                                min_length=2, max_length=48)
    statement: str = Field(min_length=1, max_length=400)


def declared_requirements(
    requirements: "list[MeasurementRequirement] | None",
) -> "list[MeasurementRequirement] | None":
    """What a plan declares, with absence kept distinct from emptiness.

    `None` is a plan recorded before requirements existed, and it is not the
    empty set. "Nothing was asked of this measurement" and "nobody ever said
    what to ask of it" are different findings: the first is a design somebody
    could argue with, and the second is the absence of one. A plan that could
    silently read as the first would let every study written before this pass
    a check it was never held to.

    So the empty list is refused where a plan is built, and this returns `None`
    unchanged -- the caller decides what an undeclared measurement means, and
    the one thing it may not mean is that every requirement is satisfied.
    """
    return requirements or None


def requirements_named_once(
    requirements: "list[MeasurementRequirement] | None",
) -> "list[MeasurementRequirement] | None":
    """The declared requirements, refusing the two shapes that mean nothing.

    An empty list is refused rather than read as "nothing is required": a design
    that asks nothing of its measurement is one somebody should have to write
    down as such, and `None` already means the plan never said. A repeated
    identifier is refused because a claim is matched to a requirement by that
    identifier alone, and two requirements under one name make a claim about
    both or neither with no way to tell which.
    """
    if requirements is None:
        return None
    if not requirements:
        raise ValueError(
            "declare at least one measurement requirement, or none at all")
    named = [item.requirement_id for item in requirements]
    if len(set(named)) != len(named):
        raise ValueError("a measurement requirement is declared once")
    return requirements


# A verifier reports these, so the bound is on what arrives rather than on what
# a design may ask for: a report naming a thousand claims is not a design with a
# thousand requirements, it is a file nobody should read all of.
MAXIMUM_CLAIMS = 64


class MeasurementClaimObservation(Contract):
    """What one frozen ruler said it was built to check, when it was asked.

    A fact about a ruler at a moment, and nothing about whether that was enough.
    The ids arrive exactly as reported -- repeats kept, ids no plan declared
    kept -- because this is the record of what was claimed and not a reading of
    it. Dropping an unrecognised id here would throw away the material a later
    reading needs: a requirement added next week may be one this verifier
    already said it checks, and that can only be seen if the claim survived.

        observation    what the verifier claimed
        assessment     what the design in force makes of that claim

    which is why nothing derived lives here. `unknown` is not a property of an
    observation: an id is unknown only relative to a set of requirements, and
    those change while the observation does not. Storing it would freeze a
    judgement into a record of a fact, and the two would drift the first time a
    requirement was added.

    One per snapshot, and immutable once taken. A second reading of the same
    frozen ruler that claimed something different is a disagreement worth
    diagnosing, not a correction to apply: letting the later one win would make
    "what did this ruler claim" answerable only by whichever run finished last.
    """

    snapshot_id: str = Field(min_length=1, max_length=64)
    # Exactly as reported. Normalising happens where the claim is read.
    claimed_requirement_ids: list[str] = Field(default_factory=list,
                                               max_length=MAXIMUM_CLAIMS)
    observed_at: datetime
    # What was wrong with the observing, in a sentence each. Only the limits of
    # this reading -- a report with no claim section, a list that was cut short
    # -- and never a judgement about the claims, which belongs to whatever reads
    # them against a design.
    limitations: list[str] = Field(default_factory=list, max_length=8)


class MeasurementClaimStatus(str, Enum):
    """How a design reads its ruler's claims. Recomputed, never recorded.

    `FULLY_CLAIMED` is the one to be careful with, and it is named for exactly
    what it is. It says every declared requirement has something claiming to
    check it. It does not say the checking is any good: the claim is written by
    the same pipeline that writes the arms, so a verifier that imports a module
    and claims both requirements reaches this state, and a test says so on
    purpose. What would earn a word like "adequate" is a ruler shown to detect a
    difference it should detect, which is a later thing entirely.
    """

    # The plan never said what its measurement has to check, so there is no
    # contract to read the claims against. Not "nothing is required".
    UNDECLARED = "undeclared"
    # It said, and nothing has been observed claiming anything yet.
    UNOBSERVED = "unobserved"
    # Something declared has nothing claiming to check it.
    INCOMPLETE_CLAIMS = "incomplete_claims"
    # Every declared requirement is claimed, and a claim is all that is.
    FULLY_CLAIMED = "fully_claimed"


def local_files(verify_argv: list[str]) -> set[str]:
    """Workspace-local files the command would run, as far as can be told.

    Deliberately shallow: an argument that looks like a relative path to a file
    in the workspace counts, and nothing else does. An interpreter name, a flag
    and an absolute path do not.

    Being shallow is why this is a check and not an oracle. It catches the shape
    that actually occurred -- `python verify.py`, `pytest tests/test_x.py` -- and
    says nothing about a command that reaches its script some other way. A rule
    that quietly failed to fire would be worse than one whose limits are written
    down, so they are: anything invoked through a shell string, an environment
    variable or a generated path is not seen here.
    """
    return {
        item.replace("\\", "/") for item in verify_argv
        if unusable_target(item.replace("\\", "/")) is None
    }


class RuntimeReadiness(str, Enum):
    """Whether this host could run the measurement's interpreter just now.

    An observation about a host at a moment, never a property of a design: the
    same plan read on another machine may find a different answer. So it is
    not stored on the plan and not an admission rule -- it is asked before a
    measurement is built, and answered by running something.
    """

    READY = "ready"
    # The process did not start, or the sandbox would not start it.
    START_FAILED = "start_failed"
    # It started and exited non-zero: the campaign's `python3`, an installer
    # stub on that host, exited 9009.
    NONZERO_EXIT = "nonzero_exit"
    TIMED_OUT = "timed_out"


# An interpreter's name, as a command names it. Shallow in the way
# `local_files` is, and for the same reason written down: `python`, `python3`,
# `python3.11`, `py`, each with or without `.exe`, as the last path component.
_PYTHON = re.compile(r"^(?:python(?:\d+(?:\.\d+)*)?|py)(?:\.exe)?$", re.IGNORECASE)
# Interpreter options that take the next token as their value.
_WITH_VALUE = frozenset({"-X", "-W"})


def python_readiness_argv(verify_argv: list[str], owned: set[str]) -> list[str] | None:
    """The command that asks whether this measurement's interpreter can run.

    Only for a command that runs a measurement-owned `.py` file directly with
    a Python interpreter, keeping the options in front of it:

        python3 tests/verify.py         ->  python3 -c "import sys"
        python -X utf8 tests/verify.py  ->  python -X utf8 -c "import sys"

    `None` for everything else, `python -m pytest ...` included. Whether pytest
    is importable is a different question from whether the interpreter starts,
    and answering both with one probe would report one as the other.
    """
    if not verify_argv:
        return None
    name = verify_argv[0].replace("\\", "/").rsplit("/", 1)[-1]
    if not _PYTHON.match(name):
        return None
    expecting_value = False
    for index, item in enumerate(verify_argv[1:], start=1):
        if expecting_value:
            expecting_value = False
            continue
        path = item.replace("\\", "/")
        if path in owned and path.endswith(".py"):
            return [*verify_argv[:index], "-c", "import sys"]
        if item in ("-m", "-c") or not item.startswith("-"):
            return None
        expecting_value = item in _WITH_VALUE
    return None


class MeasurementSnapshot(Contract):
    """The ruler as it stood when the experiment was allowed to start.

    Not a flag saying the measurement was frozen. A flag can only be asserted;
    this can be checked. Every artifact is recorded by digest, so "arm A and arm B
    were measured by the same verify.py" stops being a claim about process and
    becomes a comparison anyone can repeat.

    Fixtures and reference data are digested alongside the verifier, because a
    ruler whose markings changed is a different ruler however the code reads.

    The freeze happens before the first arm is dispatched rather than after the
    first result. Waiting for a result leaves a window -- arm A running, nothing
    recorded yet, the verifier edited, arm A's number arriving afterwards -- where
    the measurement moved under an experiment already in flight.
    """

    snapshot_version: str = "measurement-snapshot-v1"
    # This freeze, as an identity. Not derived from the contents: freezing the
    # same verifier twice produces two rulers, because what a study is measured
    # by is the instrument it was given, and being given it again is a
    # different event. `artifact_digests` answers "was it the same file"; this
    # answers "was it the same ruler", and those are different questions.
    #
    # Absent on snapshots frozen before identities were issued. Read as a
    # legacy identity, compatible only with other legacy ones -- never as a
    # wildcard, which would let a run measured under no identity at all count
    # as evidence under a ruler that has one.
    #
    # Never defaulted to a fresh value. A snapshot that minted an identity
    # while being read would have a different one every time it was loaded.
    snapshot_id: str | None = Field(default=None, min_length=8, max_length=64)
    # How many times this session has replaced its ruler. Deliberately not the
    # plan revision: changing an arm's objective and changing the instrument
    # every arm is measured by have different blast radii, and one number could
    # not say which had happened.
    revision: int = Field(default=0, ge=0, le=100)
    # Every owned path, by sha256 of its bytes at the moment of freezing.
    artifact_digests: dict[str, str] = Field(min_length=1)
    verify_argv: list[str] = Field(min_length=1)
    # Which revision of the policy this ruler belongs to. An amendment that
    # changes the measurement produces a new snapshot rather than editing one.
    plan_revision: int = Field(ge=0)
    frozen_at: datetime

    @model_validator(mode="after")
    def digests_are_readable(self) -> "MeasurementSnapshot":
        if any(not digest.strip() for digest in self.artifact_digests.values()):
            raise ValueError("a measurement artifact digest must not be blank")
        if any(not item.strip() for item in self.verify_argv):
            raise ValueError("a verification argument must not be blank")
        return self

    def disagreement(self, current: dict[str, str]) -> list[str]:
        """Which artifacts no longer match what was frozen.

        Read before an arm runs and before a reading is taken. The same
        reasoning as `holdout_data_changed`: the thing being measured must not
        write its own answer sheet, and neither may anything else -- a person
        editing the verifier between two arms invalidates the comparison just as
        thoroughly as an arm doing it.
        """
        return sorted(
            path for path, digest in self.artifact_digests.items()
            if current.get(path) != digest
        )


class MeasurementOwnership(str, Enum):
    """Who controls what this measurement is obliged to report, right now.

    Present tense on purpose. `REUSE_RECORDED` names a verifier an earlier
    session of this workspace built, and it is *not* managed: treating it as
    such assumes a file written under whatever contract held months ago still
    satisfies the one in force today. Ownership is about who can be held to the
    contract now, and for an adopted artifact the answer is nobody here.
    """

    # ReLab asked a model to write it, under this session's stated contract.
    MANAGED = "managed"
    # The project's own, or an earlier session's. Adopted as it stands.
    ADOPTED = "adopted"


class MeasurementObservability(str, Enum):
    """How much of what the verifier did can be seen from the record.

    Independent of ownership, and deliberately so. An adopted verifier that
    reports its checks is good evidence, and collapsing the two axes into one
    scale would make that combination unsayable.
    """

    REPORTED = "reported"
    UNREPORTED = "unreported"


class MeasurementInvalidity(str, Enum):
    """Why a managed measurement produced no usable reading.

    One outcome, four reasons, because a person's next move differs for each:
    fix the contract the verifier was asked for, write some checks, make the
    verifier say what it measured, or find out why it measured something else.
    """

    # No structured report at all. The verifier did not honour the contract.
    REPORT_MISSING = "report_missing"
    # It reported, and it ran nothing. A verifier that executed no check has
    # not measured the arm; it has confirmed that it started.
    NO_CHECKS_EXECUTED = "no_checks_executed"
    # It ran checks and did not say what they were of.
    SUBJECT_UNREPORTED = "subject_unreported"
    # It named an artifact, and the workspace held something else -- or nothing.
    SUBJECT_MISMATCH = "subject_mismatch"


def ownership_of(measurement: "MeasurementSetup | None") -> MeasurementOwnership:
    """Which contract this design's verifier is held to.

    Read from the verifier alone. A measurement may mix sources -- a created
    verifier with an adopted fixture is a perfectly ordinary design -- and the
    obligation to report belongs to the thing that reports.

    No measurement at all means the workspace's own verifier, adopted as it
    stands, which is the case a plan declaring none is defined to mean.
    """
    if measurement is None:
        return MeasurementOwnership.ADOPTED
    verifier = next(item for item in measurement.artifacts
                    if item.kind is MeasurementKind.VERIFIER)
    return (MeasurementOwnership.MANAGED if built_by_relab(verifier)
            else MeasurementOwnership.ADOPTED)


def built_by_relab(artifact: MeasurementArtifact) -> bool:
    """Whether ReLab wrote this artifact under its contract, now or earlier.

    `REUSE_RECORDED` is a file an earlier session of this workspace created --
    so ReLab wrote it, and told it to report and to declare. It was read as
    adopted, the project's own, and so excused from both: a live study reused a
    verifier that reported zero checks three times and spent three attempts,
    because only a created verifier was held to the contract.
    """
    return artifact.operation in (ArtifactSource.CREATE, ArtifactSource.REUSE_RECORDED)

class MeasurementClaimAssessment(Contract):
    """The design in force, read against what the ruler claimed.

    Derived on every read rather than stored, because half of it is the current
    plan: a requirement added after the observation changes what the same claims
    mean, and a recorded status would answer with what they used to mean.

    Every set is typed rather than folded into the sentences, so a surface reads
    `uncovered_requirement_ids` instead of parsing prose -- the same reason the
    conversation contract carries gates as data and not as a list of strings.
    """

    assessment_version: str = "measurement-claim-assessment-v1"
    status: MeasurementClaimStatus
    # Who can be held to the claim contract, kept apart from what was observed.
    #
    # There is deliberately no fifth status meaning "cannot be observed". An
    # adopted verifier may report claims -- by an older convention, or because
    # somebody wrote it that way -- so "unobservable" would assert more than is
    # known. What is known is who may be *required* to answer, and that is this.
    #
    #     UNOBSERVED + MANAGED   asked under this session's contract, not heard
    #     UNOBSERVED + ADOPTED   never in a position to be asked
    #
    # The same two axes P1 already keeps apart for the same reason.
    ownership: MeasurementOwnership = MeasurementOwnership.ADOPTED
    declared_requirement_ids: list[str] = Field(default_factory=list,
                                                max_length=MAXIMUM_REQUIREMENTS)
    claimed_requirement_ids: list[str] = Field(default_factory=list,
                                               max_length=MAXIMUM_CLAIMS)
    # Claims that name something this design declared.
    recognized_claim_ids: list[str] = Field(default_factory=list,
                                            max_length=MAXIMUM_CLAIMS)
    # Claims that name something it did not. Not an error and not evidence: the
    # verifier may be checking something real that nobody asked for, and it may
    # have invented an identifier. Either way it covers no requirement.
    unknown_claim_ids: list[str] = Field(default_factory=list, max_length=MAXIMUM_CLAIMS)
    # Declared requirements nothing claims to check. The finding this exists for.
    uncovered_requirement_ids: list[str] = Field(default_factory=list,
                                                 max_length=MAXIMUM_REQUIREMENTS)
    # The observation's own limits, plus anything about the claims worth saying
    # in words. For a person; nothing here is matched on.
    limitations: list[str] = Field(default_factory=list, max_length=16)


class ClaimDispatchBlocker(str, Enum):
    """Why a study may not dispatch another arm against this ruler.

    Two, because they are repaired differently. A requirement nothing claims to
    check needs a verifier that checks it; a managed verifier that has now had
    its chance and still declares nothing needs one that declares. Neither is
    repaired by running another arm, which is the point they have in common and
    the reason both end at the same lifecycle action.
    """

    # Something declared has nothing claiming to check it.
    CLAIMS_INCOMPLETE = "claims_incomplete"
    # ReLab wrote this verifier, asked it to declare, gave it a real run, and
    # heard nothing.
    CLAIMS_STILL_UNOBSERVED = "claims_still_unobserved"


class ClaimDispatchDecision(Contract):
    """Whether another arm may be dispatched, and what to do when it may not."""

    allowed: bool
    # Absent when allowed. Typed because the two blockers ask a person for
    # different work, and a surface that had to read that out of the sentence
    # would break the first time somebody improved the sentence.
    blocker: ClaimDispatchBlocker | None = None
    reason: str = Field(min_length=1, max_length=400)



class MeasurementReading(Contract):
    """What could be seen of one measurement, and whether it can be used.

    A projection over a run's verification, not a new fact about it: every
    input is already recorded. It answers P1's question and only P1's --
    *can this measurement be used, and how observable was it* -- and says
    nothing about whether the evidence supports any conclusion.

    The distinction it exists to keep is one a live session collapsed. A
    verifier ran, exited zero and printed `METRIC pass_rate=0.000000` without
    executing a single check, and the number was admitted as a score. A
    measurement that did not happen is not a measurement of zero:

        invalid   no score, and no claim about the arm either
        0.0       a score, which the arm earned
    """

    reading_version: str = "measurement-reading-v1"
    ownership: MeasurementOwnership
    observability: MeasurementObservability
    # As reported. None means the verifier never said, which is what makes a
    # managed measurement invalid and an adopted one merely opaque.
    executed_checks: int | None = Field(default=None, ge=0)
    # What the verifier claimed to measure, kept as a claim. See `MeasuredSubject`.
    subjects: list[MeasuredSubject] = Field(default_factory=list, max_length=16)
    # Absent when the measurement can be used.
    invalidity: MeasurementInvalidity | None = None
    reason: str = Field(min_length=1)
    # What this reading cannot tell anyone, in their own words. Facts about the
    # evidence, never a verdict on it: whether they matter to a conclusion is a
    # separate question, asked of the whole body of evidence and not of one run.
    limitations: list[str] = Field(default_factory=list, max_length=8)

    @property
    def usable(self) -> bool:
        return self.invalidity is None
