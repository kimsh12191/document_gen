"""What an arm that cannot pass is allowed to become.

Repair replaces an attempt. Replanning replaces the *task*: three attempts have
failed the same way, so trying the declared thing a fourth time is not a plan,
and what changes is what the arm is asked to do.

The one thing a stuck arm must not be allowed to change is what measures it.
That is not enforced here by a rule -- it is unrepresentable. `ProposedRetask`
has no `verify_argv` and no `holdout_argv`, so a model answering this question
cannot express "measure me with something else" however it is prompted, and
there is no sentence in a prompt for it to ignore.

`moved_goalposts` still treats an arm's measuring command as a deciding rule, so
an amendment that changes one by some other route is recorded and bars
acceptance. The two are not redundant: one makes the move impossible to say, the
other makes it impossible to profit from.
"""

from pydantic import Field, model_validator

from relab_core.contracts import Contract
from relab_core.routing import ModelInvocationProvenance
from relab_core.targets import EditTarget

# Enough failed approaches to see a pattern without carrying a transcript.
MAXIMUM_TRIED = 8
# The tail of each stream a verifier wrote, matching what a repair note carries.
OUTPUT_TAIL_CHARACTERS = 800


class TriedApproach(Contract):
    """One attempt already made at this arm, in what it is useful to know about."""

    run_id: str = Field(min_length=1)
    # Identity of the edit, not the edit. Two attempts failing the same way from
    # the same digest is a model repeating itself; from different digests it is a
    # model exploring a space where everything fails alike. Different problems,
    # and the difference decides whether a new task would help.
    patch_digest: str | None = Field(default=None, min_length=8, max_length=64)
    reason: str = Field(min_length=1, max_length=2000)


class StuckArm(Contract):
    """Why one arm is not worth attempting again as declared.

    Everything here is read from records. Nothing is a judgement, and nothing
    says what to do about it -- that is what the advisor is for.
    """

    stuck_arm_version: str = "stuck-arm-v1"
    session_id: str = Field(min_length=1)
    arm: str = Field(min_length=1)
    # What the plan currently asks of this arm, so a proposal can be a change
    # rather than a guess at what it is changing from.
    objective: str = Field(min_length=1, max_length=8000)
    targets: list[EditTarget] = Field(default_factory=list, max_length=8)
    # How many times the same failure. The count is the reason this is being
    # asked at all.
    repeated: int = Field(strict=True, ge=2)
    # What makes those failures the same one: the *normalised* text the digest
    # was taken over, with paths and line numbers replaced so that two runs of
    # one fault compare equal.
    failure_signature: str = Field(min_length=1, max_length=4000)
    # What the verifier actually said, as recorded. Not the same thing, and the
    # difference decided a live run: shown only the signature, a model read
    # `File "<path>", line <n>, in score`, correctly diagnosed that `score()`
    # raises NotImplementedError, and then proposed implementing it in the file
    # the arm already had -- because nothing it could see named any other file.
    #
    # Normalising is right for deciding sameness and wrong for deciding what to
    # do instead. Repair has always passed the real text; this is the same rule.
    failure_detail: str = Field(default="", max_length=OUTPUT_TAIL_CHARACTERS * 2)
    tried: list[TriedApproach] = Field(default_factory=list, max_length=MAXIMUM_TRIED)


class ProposedRetask(Contract):
    """A different attempt at the same question, for one arm, before anyone agrees.

    What it may change is what the arm attempts. What it may not change is not
    listed and refused -- it is absent from the contract.
    """

    retask_version: str = "proposed-retask-v1"
    arm: str = Field(min_length=1)
    objective: str = Field(min_length=1, max_length=8000)
    # Absent means the declared targets stand. An empty list is a different
    # statement -- "this arm writes nothing" -- and would make the arm
    # unexecutable, so it is refused rather than read as "unchanged".
    targets: list[EditTarget] | None = Field(default=None, min_length=1, max_length=8)
    rationale: str = Field(min_length=1, max_length=4000)
    # Which model wrote this, attached by the application from what the gateway
    # said. It travels onto the amendment this becomes, so "why does this arm do
    # that" is answerable by more than the sentence itself.
    proposed_by: ModelInvocationProvenance | None = None

    @model_validator(mode="after")
    def distinct_targets(self) -> "ProposedRetask":
        if self.targets is not None:
            paths = [item.path for item in self.targets]
            if len(set(paths)) != len(paths):
                raise ValueError("a retask names each target once")
        return self
