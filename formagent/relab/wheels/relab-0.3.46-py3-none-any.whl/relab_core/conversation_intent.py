"""Which capability a conversation turn is asking for.

A researcher types one thing into one box. What that means depends entirely on
where the session already is, and *that* is a fact the backend holds -- so the
choice is made here, deterministically, from recorded state.

The output is a **capability**, never a model. "Propose a research design" is a
capability; "call the planner with this prompt" is an implementation of one. A
router that chose the second would have put a model in the control plane by the
back door, which is the one thing the typed authority boundary exists to stop.

    ConversationInput          what a client sends: a session id and some text
            |
            v
    the application reads the session
            |
            v
    ConversationRouteContext   turn state, gates, refusal, and the sequence read
            |
            v
    deterministic router       one capability
            |
            v
    a model, or a service, only inside a branch

The two inputs are separate types on purpose. A client can send text and name a
session; it cannot send a turn state, because there is no field for one. A client
that believed a finished session was still running -- or said so deliberately --
changes nothing, because what the router reads was never the client's to supply.
"""

from enum import Enum

from pydantic import Field, model_validator

from relab_core.contracts import Contract
from relab_core.turns import TurnState


class ConversationCapability(str, Enum):
    """What the application is being asked to do. One of these, always."""

    # Nothing is under way: what a person says is a goal to design from.
    PROPOSE_RESEARCH = "propose_research"
    # A session is waiting on a person, and a gate is what it is waiting on.
    ANSWER_GATE = "answer_gate"
    # It is waiting on a person, and what is wanted is a judgement, not a gate.
    DISCUSS_BLOCKER = "discuss_blocker"
    # Something can be performed without asking anyone.
    CONTINUE_SESSION = "continue_session"
    # It is running, or otherwise not ours to move; a question can still be asked.
    ASK_ABOUT_SESSION = "ask_about_session"
    # It is finished, and what is left is to understand it.
    EXPLAIN_RESULT = "explain_result"
    # It is finished and cannot be amended into something acceptable.
    START_NEW_RESEARCH = "start_new_research"


class ConversationIntent(str, Enum):
    """A person's requested kind of help, deliberately distinct from an action.

    An intent says what the person is trying to do with a turn. It never names a
    gate, changes a plan or authorizes execution. Those remain record-derived
    capabilities and separately pinned actions. Keeping this vocabulary in core
    gives a future model interpreter, CLI and VS Code surface one contract to
    agree on without letting any of them grow their own control language.
    """

    NEW_GOAL = "new_goal"
    QUESTION = "question"
    EXPLORE_WORKSPACE = "explore_workspace"
    PLAN_CHANGE = "plan_change"
    EXECUTE = "execute"
    STATUS = "status"


class ConversationWorkflow(str, Enum):
    """The bounded next step an interpreted intent corresponds to.

    A signpost, and emphatically not an authority. `available_actions` remains
    the only list a surface may act from; this says which of the entry points
    that already exist is the one this person was reaching for, so a classified
    intent stops being a label with nowhere to go.

    Every one of these is a door somebody already has the key to. Starting one
    goes through the same pinned, approved path it always did -- an offer of
    `TAKE_TURN` is not permission to take a turn, it is the observation that
    taking one is what "run it" meant here.
    """

    # Read-only, and available whenever a session is: looking changes nothing.
    EXPLORE_WORKSPACE = "explore_workspace"
    # From an immutable exploration context into a pending amendment a person
    # then approves. Drafting is not amending.
    DRAFT_PLAN_CHANGE = "draft_plan_change"
    # Continue through the lifecycle, offered only where the records already
    # offered the action.
    TAKE_TURN = "take_turn"
    # Read the record. The answer in hand already is this, which is why it is
    # the honest workflow for a question rather than nothing at all.
    REVIEW_SESSION = "review_session"
    START_NEW_SESSION = "start_new_session"


class WorkflowUnavailable(str, Enum):
    """Why an interpreted intent leads nowhere right now.

    Typed rather than left to the message because a surface behaves differently:
    a session that moved is worth looking at again, and an intent this lifecycle
    simply does not afford is not.
    """

    # The records changed while the interpreter was being asked. What was
    # offered when the question was put is not what is offered now.
    SESSION_MOVED = "session_moved"
    # The intent stands, and the step it would lead to is not open here.
    NOT_AVAILABLE_NOW = "not_available_now"


class ConversationInput(Contract):
    """Everything a client may send. Deliberately almost nothing.

    Text, and which session it is about. There is no field for a turn state, a
    gate or a refusal, so no client can assert one -- not by mistake, and not on
    purpose. What a person *says* is carried into a branch; it never selects one.
    """

    said: str = Field(min_length=1, max_length=4000)
    # Absent when nothing is under way. Then there is nothing to route *about*.
    session_id: str | None = Field(default=None, min_length=1)


class ConversationRouteContext(Contract):
    """Where the session actually stands, read by the application from records.

    Built by the layer that may read the stores, never accepted from a caller.
    """

    turn_state: TurnState
    # Whether the action awaiting a person is a gate, rather than a judgement.
    awaiting_gate: bool = False
    # Whether the records can no longer support anything being carried forward.
    refused: bool = False
    # The session event this was read at, and the plan revision then in force.
    # Carried so an action taken afterwards can be pinned to them: if a worker or
    # another client recorded something in between, a stale conversational action
    # is refused rather than applied to a session that has moved on. Every other
    # execution boundary here already works this way.
    event_sequence: int = Field(ge=1)
    plan_revision: int | None = Field(default=None, ge=0)

    @model_validator(mode="after")
    def refusal_is_about_a_finished_session(self) -> "ConversationRouteContext":
        if self.awaiting_gate and self.turn_state is not TurnState.AWAITING_HUMAN:
            raise ValueError("a gate is something a session awaiting a person has")
        return self


def route(
    said: ConversationInput, context: ConversationRouteContext | None,
) -> ConversationCapability:
    """The one capability this request is asking for.

    Pure, total over the six turn states, and testable without a provider. The
    text is never read: it is carried into the branch the records chose, and the
    only thing taken from the input here is whether a session was named at all.
    """
    return capability_for(None if said.session_id is None else context)


def capability_for(
    context: ConversationRouteContext | None,
) -> ConversationCapability:
    """Which capability a session in this state is asking for.

    Separate from `route` so that "what a person typed never selects a branch" is
    structural rather than a promise: this function cannot read the text, because
    it is not given it. It is also what the application calls after performing an
    action, where there is no text and inventing one would imply somebody spoke.
    """
    if context is None:
        return ConversationCapability.PROPOSE_RESEARCH
    if context.turn_state is TurnState.AWAITING_HUMAN:
        # A gate is a specific thing to answer; everything else waiting on a
        # person is a judgement, and those are not the same conversation.
        return (ConversationCapability.ANSWER_GATE if context.awaiting_gate
                else ConversationCapability.DISCUSS_BLOCKER)
    if context.turn_state is TurnState.ACTION_QUEUED:
        return ConversationCapability.CONTINUE_SESSION
    if context.turn_state is TurnState.COMPLETE:
        # A session that can carry nothing forward cannot be explained into one
        # that can; the honest next move is a new pre-registration.
        return (ConversationCapability.START_NEW_RESEARCH if context.refused
                else ConversationCapability.EXPLAIN_RESULT)
    # Running, waiting on something outside, or failed: none of those is ours to
    # move from here, and a question about it is still a reasonable thing to ask.
    return ConversationCapability.ASK_ABOUT_SESSION


def available_intents(context: ConversationRouteContext | None) -> list[ConversationIntent]:
    """Read-only intents a conversation may offer at this point in its lifecycle.

    This list is an affordance list, not an authority list. In particular,
    `EXECUTE` means a person may ask to continue; the existing lifecycle and any
    approval gates still decide whether an execution action can be offered or
    carried out.
    """
    if context is None:
        return [ConversationIntent.NEW_GOAL]
    intents = [ConversationIntent.QUESTION, ConversationIntent.EXPLORE_WORKSPACE,
               ConversationIntent.STATUS]
    if context.turn_state is TurnState.ACTION_QUEUED:
        intents.append(ConversationIntent.EXECUTE)
    if context.turn_state is TurnState.AWAITING_HUMAN and not context.awaiting_gate:
        intents.append(ConversationIntent.PLAN_CHANGE)
    return intents


def workflow_for(
    intent: ConversationIntent,
    context: ConversationRouteContext | None,
    *,
    may_take_turn: bool = False,
    may_start_new: bool = False,
) -> ConversationWorkflow | None:
    """The bounded step this intent corresponds to here, or none.

    Deterministic, and derived from the same record-read context the router
    uses. The interpreter's prose reaches this function as one enum value and
    nothing else, so a model cannot widen what is offered -- at most it picks
    among steps the records had already opened.

    The two flags come from the answer's own `available_actions`, so a signpost
    never points at a door the records have not opened. They are passed in
    rather than read here because the action vocabulary belongs to the response
    contract, and this module is upstream of it.
    """
    if context is None:
        # Nothing is under way, so the only thing to reach for is a first study.
        return ConversationWorkflow.START_NEW_SESSION
    if intent not in available_intents(context):
        return None
    if intent is ConversationIntent.EXPLORE_WORKSPACE:
        return ConversationWorkflow.EXPLORE_WORKSPACE
    if intent is ConversationIntent.PLAN_CHANGE:
        return ConversationWorkflow.DRAFT_PLAN_CHANGE
    if intent is ConversationIntent.EXECUTE:
        return ConversationWorkflow.TAKE_TURN if may_take_turn else None
    if intent is ConversationIntent.NEW_GOAL:
        return ConversationWorkflow.START_NEW_SESSION if may_start_new else None
    # A question and a status request both end at the same place: the answer
    # already in hand. Saying so is more use than offering nothing.
    return ConversationWorkflow.REVIEW_SESSION
