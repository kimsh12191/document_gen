"""What happened when a ruler was pointed at a control.

A calibration is not an experiment and this record says so by being a different
one. `CodingRun` carries an arm, a repeat, a repair history, a provider budget,
an experimental slot and evidence; a control run has none of those and would be
lying about most of them. Nothing here is an attempt, nothing here spends a
repeat, and nothing here is evidence about the thing under study.

What it *is* about is the instrument. So it is pinned to the frozen ruler and
not to a plan revision: replacing the measurement means whatever sensitivity
was shown was shown by a different instrument, and has to be shown again.

    (snapshot_id, control_id)   one calibration, recorded once

Immutable for the same reason a claim observation is. A second run of the same
control against the same ruler that measured differently is a disagreement
worth diagnosing -- a flaky verifier, most likely, which is itself a finding --
and letting the later one overwrite would make "what did this ruler do with
this control" answerable only by whichever run finished last.

Not free, though. A calibration spends the same machine time an attempt does,
and belongs in operational accounting later. What it must never enter is
research accounting.
"""

from datetime import datetime

from pydantic import Field

from relab_core.coding.patch import VerificationResult
from relab_core.contracts import Contract

# Two readings per control, and each is one verifier run.
MAXIMUM_CONTROL_METRICS = 32
# Every control a design may declare, against every ruler it may retire.
MAXIMUM_CONTROL_RUNS = 128


class ControlReading(Contract):
    """One subject measured by the frozen ruler, and nothing concluded from it."""

    # What was actually measured, so a reading can be tied to the file that
    # produced it rather than to the intention that named it.
    subject_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    # The metrics the verifier printed. Empty is an answer: a ruler that printed
    # nothing for this subject told us something about the ruler.
    metrics: dict[str, float] = Field(default_factory=dict,
                                      max_length=MAXIMUM_CONTROL_METRICS)
    # The run itself, reused unchanged. A calibration is measured by exactly the
    # machinery an arm is, which is the only reason its numbers are comparable
    # to an arm's at all.
    verification: VerificationResult
    # Why this reading says less than it looks like it does, when it does.
    limitations: list[str] = Field(default_factory=list, max_length=8)
    # Whether the ruler reached its own declaration for this subject: the
    # claim a verifier ReLab built is asked to write before it touches any
    # subject path. It is what tells "ran and printed nothing" from "never got
    # as far as its own first step" -- a silent exit 2 and a command that was
    # not found look alike otherwise. `None` on readings taken before this was
    # read, which cannot say either way.
    declared: bool | None = None
    # Whether the report's own count of what ran was observed, read the way an
    # arm's verification is read. A live verifier printed `correctness_rate=0.0`
    # while reporting zero checks, and a number read without the count beside
    # it looked like a reading.
    #
    #     True    the report was read and carried `executed_checks`
    #     False   the report was read and carried no count, or was not there
    #     None    a reading taken before the count was read at all
    #
    # None is not False. A historical reading is not scored against a contract
    # nobody had yet asked the calibration to check.
    executed_checks_observed: bool | None = None


class MeasurementControlRun(Contract):
    """One control, run against one frozen ruler, with nothing decided."""

    run_version: str = "measurement-control-run-v1"
    control_id: str = Field(min_length=2, max_length=48)
    # The ruler this calibrates. A study that replaces its measurement starts
    # every calibration over, because the thing being calibrated changed.
    snapshot_id: str = Field(min_length=1, max_length=64)
    good: ControlReading
    bad: ControlReading
    executed_at: datetime

    @property
    def readings(self) -> tuple[ControlReading, ControlReading]:
        return self.good, self.bad
