"""What an unattended driver did, and why it stopped."""

from pydantic import Field

from relab_core.contracts import Contract
from relab_core.lifecycle import LifecycleAction, LifecyclePhase, SessionLifecycle


class DriveStep(Contract):
    phase: LifecyclePhase
    action: LifecycleAction
    # False when the driver read this state and stopped rather than acting on it.
    performed: bool
    detail: str = Field(min_length=1)


class SessionDrive(Contract):
    report_version: str = "session-drive-v1"
    session_id: str = Field(min_length=1)
    max_steps: int = Field(ge=1, le=10)
    steps: list[DriveStep] = Field(default_factory=list)
    # True when the driver stopped because nothing mechanical was left to do.
    settled: bool
    stopped_because: str = Field(min_length=1)
    final: SessionLifecycle
