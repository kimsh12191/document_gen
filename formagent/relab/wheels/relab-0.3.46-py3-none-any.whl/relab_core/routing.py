"""Which model each role calls, declared before anything calls one.

ReLab recorded model identity and checked it, and never chose it. Whatever
gateway a caller happened to construct is what ran, and afterwards
`generation_model` said which one that turned out to be. That is enough to
refuse evidence from the wrong model and not enough to say, beforehand, that the
planner uses one model and the arms use another.

**This is not `expected_model`, and the two must not be merged.** They answer
different questions with different authority:

    ModelRoute        who to call
    EscalationPolicy  when a different route may be used instead
    expected_model    whose results count as this study's evidence

Merging the first and the last is the tempting mistake. A coding arm that moved
from model A to model B does not thereby make B's results admissible -- that is
a separate judgement, and taking it automatically would let an execution detail
rewrite what a pre-registered study accepts. Worse, a study whose candidate arm
already succeeded under A would have that evidence invalidated by a change made
for a stuck baseline. Routing is amended as routing; admissibility is amended as
admissibility, and moves a goalpost when it moves one.

**Nothing here is written by a model.** A routing policy is caller-owned, the
same way a plan's registry is: a model that could choose which model to call
next would be choosing its own successor, and the budget that pays for it.
"""

from enum import Enum

from pydantic import Field

from relab_core.contracts import Contract
from relab_core.generation import ModelIdentity


class ModelRole(str, Enum):
    """What a call is for, which is what a route is declared against.

    Closed, because a role nobody declared a route for cannot be resolved, and
    discovering that at the moment of a call is discovering it too late.
    """

    # Designing a study from a stated goal, before any session exists.
    PLANNER = "planner"
    # Writing the code an arm's attempt proposes.
    CODING = "coding"
    # Saying what a stuck arm should attempt instead.
    REPLAN = "replan"
    # Saying what a declared policy should become, given what was observed.
    AMENDMENT = "amendment"


class ModelRoute(Contract):
    """Who to call for one role.

    The same two fields as `ModelIdentity` and deliberately not the same type.
    One is a declaration made before a call; the other is what a gateway said it
    was when the call happened. They agree in the ordinary case, and the whole
    point of recording both is the case where they do not.
    """

    provider: str = Field(min_length=1, max_length=64)
    model: str = Field(min_length=1, max_length=256)

    def matches(self, identity: ModelIdentity) -> bool:
        """Whether a call that happened was the call this route declared."""
        return identity.provider == self.provider and identity.model == self.model


class ModelRoutingPolicy(Contract):
    """Which model each role calls, for one study.

    Held by the session rather than by the plan, because the planner runs before
    a plan exists. A policy is chosen by whoever starts the work, travels with
    the proposal, and is pinned to the session when the design is accepted --
    so the model that designed a study is declared by the same document that
    declares the models which carry it out.
    """

    policy_version: str = "model-routing-policy-v1"
    routes: dict[ModelRole, ModelRoute] = Field(default_factory=dict)

    def route_for(self, role: ModelRole) -> ModelRoute | None:
        """The declared route for this role, or None when none was declared.

        None is an ordinary answer, and it means the caller supplies a gateway
        the way it always did. A policy that declared nothing is not a policy
        that forbids everything.
        """
        return self.routes.get(role)


class ModelInvocationProvenance(Contract):
    """Which model actually answered, for a role, against what was declared.

    Attached by the application to the artifact a call produced, never present
    in what a model is asked to return. A reply that could name its own model
    would be a reply that could name a different one.

    Three fields rather than one, because they can disagree and the disagreement
    is the interesting part: what was declared, what the gateway said it was,
    and what the provider reported having actually served.
    """

    provenance_version: str = "model-invocation-v1"
    role: ModelRole
    # Absent when nothing was declared for this role and the caller supplied a
    # gateway itself, which is how every call worked before routing existed.
    declared_route: ModelRoute | None = None
    identity: ModelIdentity
    # What the provider said it served. Providers substitute models, and a
    # record that only kept what we asked for could not show it.
    reported_model: str | None = Field(default=None, min_length=1, max_length=256)

    # No flag saying whether the call matched what was declared. Under routed
    # execution it always did -- a resolver returning a different identity is
    # refused before the provider is called -- so a flag could only ever be
    # `True`, or be `False` about a call that should not have happened. The same
    # reason `RepairProvenance` has no `is_repair` beside it: a fact and a flag
    # about the fact are two answers to one question, and they eventually
    # disagree.
    #
    # The three fields are three different layers, and only one pair is an error:
    #
    #     declared_route vs identity    refused before the call
    #     identity vs reported_model    a discrepancy to read afterwards
    #
    # A provider substituting a model underneath is the second, and is not a
    # violation of anything ReLab declared.
