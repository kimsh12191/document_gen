"""What a concluded study hands to coding: its evidence, as data (M8).

A study's result used to reach the coding loop as a paragraph the editor
wrote. A paragraph cannot say which runs a number came from, where it holds,
or that the study was inconclusive in a way a reader cannot miss. A package
says all three, and every part of it comes from the records: the outcome from
the conclusion gate, the claims and their citations from the interpretation,
the metrics from the assessment frozen at the conclusion, the conditions and
limitations from both. The only words in it a person wrote are the study's
objective and the rationale given when it was concluded, and they are labelled
as that. See docs/architecture/EVIDENCE_HANDOFF.md.
"""

from enum import Enum

from pydantic import Field, model_validator

from relab_core.contracts import Contract
from relab_core.memory import EvidenceCitation

MAXIMUM_PACKAGE_CLAIMS = 32
MAXIMUM_PACKAGE_METRICS = 64
MAXIMUM_PACKAGE_LINES = 32
MAXIMUM_PACKAGE_CITATIONS = 128


class EvidenceOutcome(str, Enum):
    """What the study concluded, said from the evidence's side.

    Accepted supports the candidate, rejected refutes it, inconclusive is a
    result of its own. An abandoned study concluded nothing and has no package.
    """

    SUPPORTS = "supports"
    REFUTES = "refutes"
    INCONCLUSIVE = "inconclusive"


class EvidenceClaim(Contract):
    """One thing the records support, worded by a template, with the events it rests on."""

    statement: str = Field(min_length=1, max_length=2000)
    citations: list[EvidenceCitation] = Field(min_length=1, max_length=MAXIMUM_PACKAGE_CITATIONS)


class EvidenceMetric(Contract):
    """One deciding metric as the conclusion's assessment compared it."""

    name: str = Field(min_length=1, max_length=128)
    # maximize or minimize, from the pre-registered rule; None when the rule is gone.
    direction: str | None = None
    candidate: float | None = None
    baseline: float | None = None
    # As the evaluator wrote it: a decimal string, so no difference overflows.
    delta: str | None = None
    passed: bool
    # Usable runs behind each side, as the readiness counted them.
    candidate_runs: int = Field(default=0, ge=0)
    baseline_runs: int = Field(default=0, ge=0)


class EvidencePackage(Contract):
    package_version: str = "evidence-package-v1"
    # "{session_id}/evidence-{event_sequence}": the same conclusion, the same package.
    package_id: str = Field(min_length=1, max_length=200)
    session_id: str = Field(min_length=1)
    # The session event the conclusion was recorded at.
    concluded_at_sequence: int = Field(ge=1)
    # The person's words, labelled as theirs: what the study was for, and why it
    # was concluded as it was.
    objective: str = Field(min_length=1)
    rationale: str = Field(min_length=1)
    decision: str = Field(min_length=1)
    outcome: EvidenceOutcome
    # The assessment's own verdict on the evidence, which can differ from the
    # decision a person took: kept beside it, never folded into it.
    evidence_support: str = Field(min_length=1)
    claims: list[EvidenceClaim] = Field(default_factory=list, max_length=MAXIMUM_PACKAGE_CLAIMS)
    metrics: list[EvidenceMetric] = Field(default_factory=list, max_length=MAXIMUM_PACKAGE_METRICS)
    # Where it held: model, code revision, what took one value in every run.
    conditions: list[str] = Field(default_factory=list, max_length=MAXIMUM_PACKAGE_LINES)
    # What these records do not let anyone say.
    limitations: list[str] = Field(default_factory=list, max_length=MAXIMUM_PACKAGE_LINES)
    citations: list[EvidenceCitation] = Field(default_factory=list,
                                              max_length=MAXIMUM_PACKAGE_CITATIONS)

    @model_validator(mode="after")
    def cites_only_what_it_lists(self) -> "EvidencePackage":
        listed = {(item.run_id, item.event_sequence) for item in self.citations}
        if len(listed) != len(self.citations):
            raise ValueError("a package lists each cited run event once")
        for claim in self.claims:
            for item in claim.citations:
                if (item.run_id, item.event_sequence) not in listed:
                    raise ValueError(f"a claim cites {item.run_id}@{item.event_sequence}, "
                                     "which the package does not list")
        if self.package_id != f"{self.session_id}/evidence-{self.concluded_at_sequence}":
            raise ValueError("a package is named for its session and its conclusion")
        return self


class StudyOrigin(Contract):
    """The coding request that explicitly handed work to this study."""

    loop_id: str = Field(pattern=r"^loop-[0-9a-f]{32}$")
    request: str = Field(min_length=1, max_length=8000)


class EngineeringDecision(Contract):
    statement: str = Field(min_length=1, max_length=2000)
    evidence_package_ids: list[str] = Field(min_length=1, max_length=4)
    files: list[str] = Field(default_factory=list, max_length=2000)
