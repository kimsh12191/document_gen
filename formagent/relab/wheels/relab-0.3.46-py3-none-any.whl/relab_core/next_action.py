"""What to do next, and who is allowed to do it.

There are only three kinds of answer worth giving after an experiment finishes:
an operation the driver may perform unattended, a change to the declared policy
that a person must approve, or a fresh pre-registration because this session's
policy can no longer honestly be changed. Anything else is a comment.

A proposed amendment says whether it would move what decides a pass. That is not
taken from whoever proposed it -- it is computed against the plan on record by the
layer holding that plan, the way a model's identity is read from the gateway
rather than believed from the reply.
"""

from enum import Enum

from pydantic import Field, model_validator

from relab_core.alternatives import MAXIMUM_ALTERNATIVES, Alternative
from relab_core.contracts import Contract
from relab_core.lifecycle import (
    LifecycleAction,
    MeasurementBlocker,
    MeasurementClaimBlocker,
)
from relab_core.memory import MAXIMUM_CITATIONS, EvidenceCitation
from relab_core.research import (
    ProposedAmendment,
    ResearchDecision,
)
from relab_core.sensitivity import MeasurementSensitivity
from relab_core.turns import TurnState

# Named so importing it from here stays a supported spelling: `ProposedAmendment`
# was defined in this module before a session had to hold one, and every caller
# that learned it here should keep working.
__all__ = [
    "MAXIMUM_BLOCKERS",
    "STOPPABLE",
    "NextAction",
    "NextActionKind",
    "ProposedAmendment",
    "ProposedConclusion",
]

# Bounded like every other list a client renders.
MAXIMUM_BLOCKERS = 32


class NextActionKind(str, Enum):
    # An operation the session's lifecycle already names; the driver may take it.
    LIFECYCLE = "lifecycle"
    # A change to the declared policy. A person approves it or does not.
    AMENDMENT = "amendment"
    # This session's policy cannot honestly be changed any further; pre-register
    # a new one instead of amending this one into something it was not.
    NEW_SESSION = "new_session"
    # A decision to stop, which a person confirms. Never a decision to accept:
    # see `ProposedConclusion`.
    CONCLUSION = "conclusion"
    # Nothing to do. Said plainly rather than by returning an empty amendment.
    NONE = "none"


# What a proposal to stop may propose. Acceptance is missing on purpose.
STOPPABLE = (ResearchDecision.REJECTED, ResearchDecision.ABANDONED)


class ProposedConclusion(Contract):
    """A decision to stop, before anyone has taken it.

    A session that cannot reach a verdict currently goes quiet. Its lifecycle
    says the budget is spent or an arm keeps hitting one failure, and "stop" sits
    in that sentence as a word rather than as something anybody did -- so the
    records end up saying this session was never concluded, which is a different
    thing from *we decided to stop*.

    **It cannot propose success.** Acceptance is a claim about the measured
    world; it is earned by a passing assessment over unmoved rules, and the
    lifecycle already names it the moment it is earned. A proposal that could say
    "this worked" would be the one thing pre-registration exists to prevent,
    arriving by the door marked "next action", and it would arrive precisely when
    a session had failed to work -- which is when the temptation is.

    `alternatives` is there so stopping is a choice rather than a default. They
    are read from the records -- an arm that could be asked something different,
    attempts still unspent, a model nothing has been tried against -- and none of
    them is a recommendation. A person who can see what is left is deciding;
    one who cannot is agreeing.

    They are typed rather than sentences, so one can be *chosen* instead of only
    read. Choosing is not performing: an executable alternative resolves to a
    change a person then approves through the path that already exists.
    """

    conclusion_version: str = "proposed-conclusion-v1"
    decision: ResearchDecision
    rationale: str = Field(min_length=1, max_length=4000)
    # What has not been tried, as facts rather than as advice, and as things
    # that can be pointed at rather than only read.
    alternatives: list[Alternative] = Field(default_factory=list,
                                            max_length=MAXIMUM_ALTERNATIVES)
    # The evidence the rationale rests on, when it rests on evidence rather than
    # on the mechanical state of the session.
    grounds: list[EvidenceCitation] = Field(default_factory=list, max_length=MAXIMUM_CITATIONS)

    @model_validator(mode="after")
    def never_proposes_success(self) -> "ProposedConclusion":
        if self.decision not in STOPPABLE:
            raise ValueError(
                "a proposed conclusion may stop a session, not declare it a success; "
                "acceptance is earned by a passing assessment and named by the lifecycle")
        return self


class NextAction(Contract):
    """One thing to do next, who may do it, and what state that leaves the turn in."""

    next_action_version: str = "next-action-v1"
    session_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    kind: NextActionKind
    detail: str = Field(min_length=1, max_length=2000)
    turn_state: TurnState
    # Set when the answer is an operation the session's lifecycle already names.
    lifecycle: LifecycleAction | None = None
    amendment: ProposedAmendment | None = None
    # The decision to stop this session, when stopping is what is being proposed.
    conclusion: ProposedConclusion | None = None
    # The evidence this rests on, when it rests on evidence rather than on the
    # mechanical state of the session.
    grounds: list[EvidenceCitation] = Field(default_factory=list, max_length=MAXIMUM_CITATIONS)
    # Everything that must change before this action can succeed, carried from the
    # lifecycle rather than recomputed. A client asking what to do next and what is
    # stopping it should not have to make two calls and hope they agree -- and a
    # person told only "a person is needed" has not been told what for.
    blockers: list[str] = Field(default_factory=list, max_length=MAXIMUM_BLOCKERS)
    # Present when this study's own measurement is what stopped it, rather than
    # any arm. Carried as data beside the prose for the same reason
    # `blocked_arms` is: a surface that had to recognise a sentence to tell a
    # broken instrument from a spent budget would break the first time somebody
    # improved the wording, and the two ask a person to do different things.
    measurement_blocker: MeasurementBlocker | None = None
    # And what the ruler does not say it covers. A sibling rather than more
    # `invalidities`, because "this reading is not evidence" and "this
    # instrument was never pointed at the question" are different findings.
    measurement_claim_blocker: MeasurementClaimBlocker | None = None
    # And what its controls showed, when the design declared any.
    # And what its controls showed, when the design declared any.
    measurement_sensitivity: MeasurementSensitivity | None = None
    # Which arms those blockers are about, as data. A surface needing to act on a
    # blocked arm reads this; `blockers` is prose, and a reader parsing an arm
    # name back out of a sentence breaks the first time the sentence is reworded.
    blocked_arms: list[str] = Field(default_factory=list, max_length=MAXIMUM_BLOCKERS)
    # Which revision of the plan this answer was read against. An amendment is
    # approved against the policy a person was shown, so recording their approval
    # needs the revision they saw -- not whatever it has since become.
    plan_revision: int | None = Field(default=None, ge=0)

    @model_validator(mode="after")
    def the_kind_and_the_answer_agree(self) -> "NextAction":
        if (self.kind is NextActionKind.LIFECYCLE) != (self.lifecycle is not None):
            raise ValueError("a lifecycle action is exactly what a lifecycle answer carries")
        if (self.kind is NextActionKind.AMENDMENT) != (self.amendment is not None):
            raise ValueError("an amendment answer carries exactly one proposed amendment")
        if (self.kind is NextActionKind.CONCLUSION) != (self.conclusion is not None):
            raise ValueError("a conclusion answer carries exactly one proposed conclusion")
        if self.kind is NextActionKind.NONE and self.turn_state is not TurnState.COMPLETE:
            raise ValueError("nothing left to do is a completed turn")
        return self
