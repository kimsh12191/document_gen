"""One turn of work, and the state it left things in.

A turn is what a conversation does when a person says "go on": it performs
whatever was the driver's to perform, stops at the first thing that is not, and
says where that leaves the session.

The rule this exists to make structural is that **no turn may end having only
spoken**. There is no state meaning that, so a turn that performed nothing and
awaits nobody is `COMPLETE` and says so; a turn stopped by a judgement is
`AWAITING_HUMAN` and carries what the judgement is and what is blocking it. The
legacy client needed a repetition counter because a director could end twenty
turns in a row without any of this being expressible.
"""

from pydantic import Field, model_validator

from relab_core.contracts import Contract
from relab_core.next_action import NextAction
from relab_core.orchestration import DriveStep
from relab_core.turns import TurnState

MAXIMUM_PERFORMED = 10


class ConversationTurn(Contract):
    """What this turn did, what it left to do, and the state it ended in."""

    turn_version: str = "conversation-turn-v1"
    session_id: str = Field(min_length=1)
    state: TurnState
    # What was actually performed. Empty is a legal and ordinary answer: it is
    # what "nothing here was mine to do" looks like, and it is not a failure.
    performed: list[DriveStep] = Field(default_factory=list, max_length=MAXIMUM_PERFORMED)
    # Where the session stands now, including what is stopping the next step.
    next: NextAction
    # Why the turn stopped where it did, in one line a person can read.
    detail: str = Field(min_length=1, max_length=2000)
    # Set when the turn stopped because an operation was refused. The refusal is
    # the turn's outcome, not an exception the caller has to catch to find out
    # that the turn ended at all.
    refusal: str | None = Field(default=None, min_length=1, max_length=2000)

    @model_validator(mode="after")
    def ends_somewhere_actionable(self) -> "ConversationTurn":
        if (self.state is TurnState.FAILED) != (self.refusal is not None):
            raise ValueError("a failed turn carries its refusal, and only a failed turn has one")
        if self.state is not TurnState.FAILED and self.state is not self.next.turn_state:
            # Otherwise a turn could report a state its own next action contradicts,
            # and a reader would have two answers to choose between.
            raise ValueError("a turn ends in the state its next action names")
        return self

    @property
    def changed_anything(self) -> bool:
        """Whether this turn moved the session, as distinct from reading it."""
        return any(step.performed for step in self.performed)
