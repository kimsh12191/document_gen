"""Read models a client renders; these summarize stored state and decide nothing."""

from datetime import datetime
from enum import Enum

from pydantic import Field

from relab_core.contracts import Contract, RunState
from relab_core.operations import OperationEvent
from relab_core.research import (
    HoldoutRecord,
    ResearchDecision,
    ResearchPlan,
    ResearchSessionAssessment,
)
from relab_core.runs import PendingHumanGate


class SessionState(str, Enum):
    """Derived from the stored snapshot; never persisted as session state."""

    CREATED = "created"
    PLANNED = "planned"
    COLLECTING = "collecting"
    AWAITING_HUMAN = "awaiting_human"
    COVERED = "covered"
    CONCLUDED = "concluded"


class SessionSummary(Contract):
    session_id: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    state: SessionState
    event_sequence: int = Field(ge=1)
    plan_revision: int | None = None
    arms: list[str] = Field(default_factory=list)
    attached_runs: int = Field(default=0, ge=0)
    decision: ResearchDecision | None = None
    # When the session last changed, so a list of conversations can put the
    # newest first. Absent from summaries written before it existed.
    updated_at: datetime | None = None


class RunSummary(Contract):
    run_id: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    request_id: str = Field(min_length=1)
    state: RunState
    event_sequence: int = Field(ge=1)


class WorkspaceOverview(Contract):
    report_version: str = "workspace-overview-v1"
    workspace: str = Field(min_length=1)
    sessions: list[SessionSummary] = Field(default_factory=list)
    runs: list[RunSummary] = Field(default_factory=list)
    gates: list[PendingHumanGate] = Field(default_factory=list)


class TimelineEntry(Contract):
    # `operation` is the journal of what was going on, and decides nothing. It
    # travels here because a person watching wants one ordered account, not
    # because it is the same kind of thing as the other two.
    source: str = Field(pattern=r"^(run|research|operation)$")
    subject_id: str = Field(min_length=1)
    sequence: int = Field(ge=1)
    kind: str = Field(min_length=1)
    timestamp: datetime
    # Current recorded research sessions that reference this subject. Empty for
    # unattached runs and for older serialized entries written before this projection.
    session_ids: list[str] = Field(default_factory=list)
    # Opaque to the client: hand it back as `after` to read only what followed.
    cursor: str = Field(min_length=1)
    # What was going on, for an `operation` entry. Absent on the other two: a
    # domain record's meaning is its kind and its snapshot, and inventing a
    # detail for it here would be this file deciding what a record means.
    operation: OperationEvent | None = None


class WorkspaceTimeline(Contract):
    report_version: str = "workspace-timeline-v1"
    workspace: str = Field(min_length=1)
    # Without `after`: older entries exist. With it: newer ones still do.
    truncated: bool = False
    # The last returned entry's cursor, or None when nothing was returned.
    next_cursor: str | None = None
    entries: list[TimelineEntry] = Field(default_factory=list)


class GateRequest(Contract):
    """What an open gate asks a person to allow, read from the stored request.

    A dependency installation is the only thing that stops for a person today,
    so this describes that and nothing speculative beyond it.
    """

    dependency: str = Field(min_length=1)
    version_constraint: str | None = None
    # The exact module name the failure named, kept apart from the distribution.
    source_module: str = Field(min_length=1)
    installer: str = Field(min_length=1)
    environment_path: str = Field(min_length=1)
    network_required: bool = False
    attempt: int = Field(ge=1)


class BlockedSession(Contract):
    """A session this gate holds up, named so a person sees what is waiting."""

    session_id: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    # The arm the blocked run was most recently attached as, when it has one.
    role: str | None = None


class GateDetail(Contract):
    """One open gate with the context a view needs; it resolves nothing."""

    gate: PendingHumanGate
    # Absent when the record no longer carries the request: the gate is still shown.
    request: GateRequest | None = None
    blocks: list[BlockedSession] = Field(default_factory=list)


class GateBoard(Contract):
    report_version: str = "gate-board-v1"
    workspace: str = Field(min_length=1)
    gates: list[GateDetail] = Field(default_factory=list)


class EvidencePointer(Contract):
    """Where a claim rests: the exact run event this session pinned.

    Whether that evidence is usable is the assessment's to say, and it says it
    once; repeating the judgement here would be a second answer able to differ.
    """

    run_id: str = Field(min_length=1)
    role: str | None = None
    event_sequence: int = Field(ge=1)
    state: RunState
    patch_id: str | None = None
    reported_model: str | None = None
    restored: bool = False
    conditions_recorded: bool = False


class PolicyChange(Contract):
    """A recorded change to the pre-registered policy, and what was known then."""

    kind: str = Field(pattern=r"^(amendment|reopening)$")
    event_sequence: int = Field(ge=1)
    # Reopenings set a decision aside rather than revising the plan.
    revision: int | None = None
    rationale: str = Field(min_length=1)
    attached_runs: int = Field(default=0, ge=0)
    # Of those attachments, how many had already produced a result.
    runs_with_results: int = Field(default=0, ge=0)
    after_results: bool = False
    # Which deciding fields this change moved: the rules, the compared arms, or a
    # lowered repeat count. Non-empty together with `after_results` is the one
    # combination that bars acceptance.
    deciding_fields: list[str] = Field(default_factory=list)


class SessionReport(Contract):
    """One archival record of a session: its policy, its evidence and its decision."""

    report_version: str = "session-report-v1"
    workspace: str = Field(min_length=1)
    session_id: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    state: SessionState
    plan: ResearchPlan | None = None
    evidence: list[EvidencePointer] = Field(default_factory=list)
    # A concluded session reports the assessment its decision was taken on, not a
    # fresh one that could since have changed.
    assessment: ResearchSessionAssessment | None = None
    assessment_source: str | None = Field(default=None, pattern=r"^(conclusion|current)$")
    # Why none could be produced, when there is none.
    assessment_unavailable: str | None = None
    holdout: HoldoutRecord | None = None
    decision: ResearchDecision | None = None
    rationale: str | None = None
    # What the decision's evidence could not show (P5, 0.2.83), as the conclusion recorded it.
    limitations: list[str] = Field(default_factory=list)
    policy_changes: list[PolicyChange] = Field(default_factory=list)
    # The declared policy was never changed once this session had results in hand.
    # It says nothing about whether those results were good.
    pre_registered: bool = True
    # Narrower and sharper: nothing that decides whether a result passes was changed
    # once results existed. False is what stops this session being accepted.
    rules_held: bool = True
