"""Integrated dependency preflight result, separate from legacy wire contracts."""

from pydantic import Field

from relab_core.coding.dependency import DependencyInstallOutcome
from relab_core.coding.sandbox import SandboxResult
from relab_core.contracts import Contract


class DependencyPreflight(Contract):
    request_id: str
    environment_path: str
    python_path: str
    declared_python_version: str
    network_allowed: bool
    # Set only for an offline install; the resolved local wheel directory.
    wheelhouse_path: str | None = None


class DependencyInstallation(Contract):
    outcome: DependencyInstallOutcome
    commands: list[list[str]] = Field(default_factory=list)
    results: list[SandboxResult] = Field(default_factory=list)
