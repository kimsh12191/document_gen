"""Ranked edit-target suggestions from repository structure; not a decision.

Also the one rule about what a file a model may edit has to look like, kept here
because two layers need it and neither may import the other. It was stated only
in the workspace layer, which meant a design naming an impossible target passed
validation, was accepted, recorded a session -- and was refused at the first turn.
The refusal was right and its timing was wrong: by then a person had a session
they did not ask for.
"""

import re
from enum import Enum

from pydantic import Field, model_validator

from relab_core.contracts import Contract

# A relative POSIX path to a Python file. Deliberately narrow: this names a file
# a model is about to rewrite, and everything not on this list -- a drive letter,
# a backslash, a glob, a space -- is either not a path this can edit or not a
# path at all.
# Written as a string because it goes two places: this module compiles it, and
# `ProposedArm` hands it to the schema a planner is asked to satisfy. A provider
# that enforces it is a provider that cannot return a target we would refuse --
# which is the difference between a constraint and a request.
EDITABLE_TARGET_PATTERN = r"^[A-Za-z0-9_./-]+\.py$"
EDITABLE_TARGET = re.compile(EDITABLE_TARGET_PATTERN)

# The same shape without the `.py`, for the paths that are only ever read.
# Inspection is a different capability from editing: a verifier worth looking at
# may be `pyproject.toml` or a `.md` that explains it, and refusing to *read*
# those would leave a planner unable to find out what it was choosing between.
# Nothing here says such a path may be written -- `EDITABLE_TARGET` still says
# that, and says it more narrowly.
READABLE_PATH_PATTERN = r"^[A-Za-z0-9_./-]+$"
READABLE_PATH = re.compile(READABLE_PATH_PATTERN)

# Directories whose contents are nobody's to rewrite from a prompt.
PROTECTED_SEGMENTS = frozenset({".git", ".relab", ".autocode", ".env", "secrets", "private"})

# Directories not worth walking into, which is a different question from whether
# a path is allowed. `PROTECTED_SEGMENTS` is about permission -- nobody's prompt
# may reach `.git` -- and these are about signal: a match inside `node_modules`
# or `__pycache__` answers a question nobody asked, and searching them makes the
# answer longer and worse.
#
# Here rather than beside either reader, because two copies of a list like this
# drift and the copy that matters is the one nobody looked at.
UNSEARCHED_DIRECTORIES = frozenset({
    ".relab", ".git", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    ".venv", "venv", "__pycache__", "build", "dist", "node_modules",
    ".auto-research", ".autocode", "target",
})


class TargetOperation(str, Enum):
    """What an arm intends to do to a file.

    Two words, and no third meaning "whichever applies". Absence is not intent:
    a file that happens not to exist could be a design that means to create it or
    a design that misspelled a path, and those deserve opposite answers. Inferring
    from the filesystem would turn the second into the first silently.
    """

    EDIT = "edit"
    CREATE = "create"


class EditTarget(Contract):
    """One file an arm will change, and what it will do to it.

    This replaces a bare path. A string said where to write and left what kind of
    write it was to be discovered at execution -- which is where a design that
    named files it meant to create was refused, long after a session had been
    recorded for it.
    """

    path: str = Field(pattern=EDITABLE_TARGET_PATTERN)
    operation: TargetOperation

    @model_validator(mode="after")
    def usable_path(self) -> "EditTarget":
        # The pattern has refused anything not shaped like a relative Python
        # path. What is left is what a pattern cannot say: `../x.py` and
        # `.git/x.py` both match it.
        wrong = unusable_target(self.path)
        if wrong is not None:
            raise ValueError(wrong)
        return self


def unusable_path(relative: str) -> str | None:
    """Why this cannot name anything in this workspace, or None when its shape is fine.

    The rules every workspace path obeys whatever it is for: relative, POSIX,
    canonical, and outside the directories nobody's prompt may reach. Reading a
    file and rewriting one are different capabilities with different rules, and
    these are the ones they share -- so a path safe to read is not thereby safe
    to write, and the part that keeps `.git` out of both lives in one place.

    Deliberately silent about what kind of file it is. That is the caller's
    question: generation wants Python, inspection wants whatever is there.
    """
    if not READABLE_PATH.fullmatch(relative):
        return f"{relative!r} is not an explicit relative workspace path"
    parts = relative.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        return f"{relative!r} does not use canonical relative path segments"
    if any(part.lower() in PROTECTED_SEGMENTS for part in parts):
        return f"{relative!r} is protected"
    return None


def unusable_target(relative: str) -> str | None:
    """Why this cannot be a generation target, or None when its shape is fine.

    Shape only. Whether the file exists, is small enough, and is UTF-8 text are
    facts about a workspace, and this is asked in places that have none -- when a
    design is proposed, most importantly, which is before anything is recorded.

    So a design naming a target that is merely absent is still accepted here and
    refused later, with the record showing a plan that was legal when it was
    made. A design naming a drive letter or `src/thing.md` never gets that far.

    One rule of its own on top of the shared ones: a file a model is about to
    write is Python.
    """
    if not EDITABLE_TARGET.fullmatch(relative):
        return f"{relative!r} is not an explicit relative Python file"
    return unusable_path(relative)


class TargetEvidence(Contract):
    signal: str = Field(pattern=r"^(path|symbol)$")
    detail: str = Field(min_length=1)


class TargetProposal(Contract):
    path: str = Field(min_length=1)
    role: str = Field(min_length=1)
    # A decimal string keeps the ranking reproducible across platforms.
    score: str = Field(min_length=1)
    evidence: list[TargetEvidence] = Field(min_length=1)


class TargetPlan(Contract):
    plan_version: str = "target-plan-v1"
    objective: str = Field(min_length=1)
    considered_files: int = Field(ge=0)
    # A truncated inspection cannot have ranked the files it never read.
    truncated: bool = False
    proposals: list[TargetProposal] = Field(default_factory=list)


class RankedPaths(Contract):
    """Candidate paths, most related to a stated goal first.

    `related_count` is how many were chosen *because* they relate to the goal;
    the rest are simply what else is here. Without that number a reader cannot
    tell a considered shortlist from an arbitrary one, and the list is recorded
    as what a planner was shown.
    """

    paths: list[str] = Field(default_factory=list)
    related_count: int = Field(default=0, ge=0)
    # False when nothing was ranked at all -- no goal, or nothing matched it.
    ranked: bool = False
