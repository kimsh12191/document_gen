"""Common request/result identity, carried by every AutoCode Protocol contract.

Lets a caller follow one objective across steps — e.g. AutoResearch's
`EXP-103` -> LabFlow -> AutoCode's `PLAN-238` -> `PATCH-412` -> `VERIFY-817`
— once LabFlow exists (doc/ROADMAP.md v0.11). Every contract carries these
fields from v0.2 on so nothing has to be retrofitted piecemeal later.

  request_id  unique to this one request/response exchange
  task_id     groups requests belonging to the same higher-level task
  trace_id    end-to-end correlation id across every component involved
  parent_id   the request_id of the step that caused this one
"""

from typing import TypeVar
from uuid import uuid4

from pydantic import Field

from relab_core.coding.base import ContractModel

IDENTITY_FIELDS = ("request_id", "task_id", "trace_id", "parent_id")


class RequestIdentity(ContractModel):
    request_id: str = Field(default_factory=lambda: f"req-{uuid4()}", min_length=1)
    task_id: str | None = None
    trace_id: str | None = None
    parent_id: str | None = None


_Result = TypeVar("_Result", bound=ContractModel)


def carry_identity(result: _Result, request: RequestIdentity) -> _Result:
    """Echo a request's identity fields onto its (already-built) result.

    Every `CodingAgentProtocol` implementation uses this rather than
    threading identity through each subsystem's own construction logic —
    content-producing code (e.g. `RepositoryMapper`) stays decoupled from
    tracing concerns.
    """

    identity = {field: getattr(request, field) for field in IDENTITY_FIELDS}
    return result.model_copy(update=identity)
