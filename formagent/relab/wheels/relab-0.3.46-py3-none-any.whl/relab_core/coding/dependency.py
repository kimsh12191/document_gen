"""Typed contracts for AutoCode's own human-approval gate: a missing
Python dependency detected during verification, escalated to an
explicit human decision, installed only into a caller-declared
project-local environment, and verification resumed on the *same*
attempt -- never a new coding session.

First slice only: a missing importable Python module, a pip-compatible
installer, a project-local venv the caller must declare explicitly and
that must already exist. Never a system/global interpreter, never a
shell command AutoCode was not given every argument of, never a package
manager other than pip. See `core/dependency_policy.py` (environment
validation), `core/loop.py` (detection + pause/resume), and
`core/dependency_installer.py` (the approval + install boundary).
"""

from enum import Enum

from pydantic import Field

from relab_core.coding.agent import CodingState
from relab_core.coding.base import ContractModel
from relab_core.coding.identity import RequestIdentity
from relab_core.coding.sandbox import SandboxPolicy


class DependencyEnvironmentKind(str, Enum):
    PROJECT_LOCAL_VENV = "project_local_venv"
    # First slice supports exactly one kind. A second (e.g. an existing
    # externally-managed venv the caller already trusts for other reasons)
    # can be added once a real caller needs it -- not speculatively now.


class DependencyEnvironment(ContractModel):
    """A caller-declared, already-existing install target. AutoCode never
    creates or discovers one on its own -- see
    `core.dependency_policy.resolve_dependency_environment`, which
    verifies `path` is a real venv inside the workspace boundary before
    any request is ever built."""

    kind: DependencyEnvironmentKind
    # Workspace-relative, the same convention `SandboxRequest.cwd` uses --
    # never absolute, never containing "..". Validated (existence as a
    # real venv, containment) by `core.dependency_policy`, not here.
    path: str = Field(min_length=1)


class DependencyInstallPolicy(ContractModel):
    """Caller opt-in. Its mere absence is what keeps every existing caller's
    behavior unchanged: no policy, no install request ever, full stop --
    a missing module still just fails verification the ordinary way."""

    environment: DependencyEnvironment
    network_allowed: bool = False
    # A workspace-relative directory of wheels; the offline alternative to an index.
    wheelhouse: str | None = Field(default=None, min_length=1)
    # A hard ceiling on how many distinct install requests one coding
    # session may raise. Without this, a project with several missing
    # modules could ask once per module forever, one per attempt budget.
    max_requests: int = Field(default=3, ge=1)


class DependencyInstallRequest(RequestIdentity):
    session_id: str = Field(min_length=1)
    attempt: int = Field(ge=1)
    dependency: str = Field(min_length=1)
    version_constraint: str | None = None
    reason: str = Field(min_length=1)
    # The exact "No module named 'X'" name the failure parser extracted --
    # never inferred from an unstructured string.
    source_module: str = Field(min_length=1)
    environment: DependencyEnvironment
    installer: str = "pip"
    network_required: bool = False
    # What resuming this exact attempt needs: re-apply the SAME diff,
    # never regenerate one -- the model that produced it may not
    # reproduce it identically on a second call. Carried here rather
    # than reconstructed from anything recomputed at resume time.
    resume_diff: str = Field(min_length=1)
    resume_base_hashes: dict[str, str] = Field(min_length=1)


class DependencyDecision(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"


class DependencyInstallDecision(ContractModel):
    """The caller's typed answer to one, specific `DependencyInstallRequest`.

    Bound to `request_id`: `core.dependency_installer.resolve_dependency_decision`
    refuses a decision whose `request_id` does not match the request it is
    given -- a stale, duplicate, or misdirected approval must never
    silently bind to the wrong install.
    """

    request_id: str = Field(min_length=1)
    decision: DependencyDecision
    decided_by: str | None = None


class DependencyInstallOutcome(ContractModel):
    request_id: str = Field(min_length=1)
    dependency: str = Field(min_length=1)
    # The requested constraint and the version pip actually resolved are
    # recorded separately -- never fabricating one from the other.
    resolved_version: str | None = None
    environment: DependencyEnvironment
    installer: str
    decided_by: str | None = None
    succeeded: bool
    message: str = Field(min_length=1)


class PausedCodingSession(ContractModel):
    """What `core.memory.paused_session_store.PausedCodingSessionStore`
    persists server-side while a coding session is paused for a
    dependency decision -- keyed by `request.request_id`.

    Neither the paused `CodingState` nor the `DependencyInstallRequest`
    ever crosses the wire in either direction: `autocode serve`'s
    `"run"` response never echoed the full `CodingState` back to a
    cross-process caller (only the trimmed, frozen `CodingResult`), so a
    caller resuming later has no way to supply it again. Persisting it
    here instead -- the same pattern `PatchEvidenceStore`/
    `DependencyInstallStore` already use -- means a resume only ever
    needs to name which paused session it means, by id.
    """

    request: DependencyInstallRequest
    state: CodingState


class DependencyResume(ContractModel):
    """Resumes a coding session paused for a dependency install --
    reconstructs the SAME attempt (the same diff, re-validated base
    hashes) rather than starting a fresh coding session. `request_id`
    names the `PausedCodingSession` this answers; `run_coding_loop` loads
    it from its own store rather than trusting anything the caller
    echoes back."""

    request_id: str = Field(min_length=1)
    outcome: DependencyInstallOutcome


class DependencyResolveRequest(RequestIdentity):
    """`autocode serve`'s `"resolve_dependency"` method -- the wire form of
    `core.dependency_installer.resolve_dependency_decision`. Only names
    which paused request this answers (`request_id`); AutoCode looks the
    request itself up from its own `PausedCodingSessionStore` rather than
    having the caller re-supply it. `serve` is otherwise stateless per
    call, so `policy` is still supplied explicitly here, the same way
    `CodingSessionRequest.workspace_policy` is supplied on every `"run"`
    call rather than remembered across processes."""

    workspace: str = "."
    request_id: str = Field(min_length=1)
    decision: DependencyInstallDecision
    policy: DependencyInstallPolicy
    sandbox_policy: SandboxPolicy | None = None
