"""Strict base contract shared by every typed schema in this package."""

from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class ContractModel(BaseModel):
    """Strict base for typed request/result contracts: unknown fields are rejected."""

    model_config = ConfigDict(extra="forbid")
