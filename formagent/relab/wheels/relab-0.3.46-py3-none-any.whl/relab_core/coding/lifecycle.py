"""Map the producer's coding outcome into the application lifecycle."""

from relab_core.coding.session import CodingResult
from relab_core.contracts import HumanGate, RunState


def project_result(result: CodingResult, run_id: str) -> tuple[RunState, HumanGate | None]:
    if result.protocol_version.split(".")[0] != "2":
        raise ValueError("unsupported coding protocol major")
    if result.status == "awaiting_dependency":
        failure = result.failure
        request = failure.dependency_install_request if failure else None
        if request is None:
            raise ValueError("dependency pause requires its typed install request")
        return RunState.AWAITING_HUMAN, HumanGate(
            gate_id=request.request_id, run_id=run_id, reason=request.reason
        )
    if result.status == "success":
        return RunState.COMPLETED, None
    if result.status == "cancelled":
        return RunState.CANCELLED, None
    return RunState.FAILED, None
