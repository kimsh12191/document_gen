"""A caller's declarative restriction on what a coding session may modify
(doc/ROADMAP.md v0.21, realignment P5; AutoResearch's matching gate is its
v0.24).

The problem this exists for is recorded on both sides. A Research caller
has its own workspace boundaries, but a session applies its own patches
under AutoCode's `PathPolicy` -- so a caller policy was either silently
not enforced, or the combination had to be refused outright. AutoResearch
chose refusal at its v0.20, which is the correct temporary answer and a
bad permanent one: it means the safer request is the one AutoCode cannot
serve.

Both realignment documents independently warn against the obvious fix --
passing a caller's policy *object* through. This is the alternative they
name instead: the caller declares intent as data, and AutoCode validates
it and enforces it with its own machinery.

Two rules make that safe, and they run in opposite directions:

- **`mutable_roots` may only narrow.** A requested root must lie inside
  one AutoCode already permits. A root outside is *rejected*, never
  quietly clipped -- silent narrowing is the same silence this contract
  exists to remove, just with a different sign.
- **`protected_roots` only ever add.** A caller's list is unioned with
  AutoCode's own, so no request can expose `.git`, `.autocode`, `.env`,
  `secrets` or `private`. There is deliberately no way to spell "protect
  less".

Deliberately NOT `PathPolicy`. That type's `protected_roots` default *is*
AutoCode's own protected list, so a caller sending `protected_roots=[]`
would be asking to replace it. Here the same field defaults to empty and
means "add nothing", so the weakening request is not expressible rather
than merely rejected.
"""

from pathlib import PurePosixPath

from pydantic import Field, field_validator

from relab_core.coding.base import ContractModel


def _validate_root(raw: str) -> str:
    """Workspace-relative, one spelling per root.

    The same normalization `core/patch_policy.py` applies to diff paths,
    for the same reason: these strings are compared against those, and two
    spellings of one directory would make containment answer differently
    depending on which side was written by whom.
    """

    if not raw:
        raise ValueError("a policy root must not be empty")
    candidate = raw.replace("\\", "/")
    path = PurePosixPath(candidate)
    if path.is_absolute() or candidate.startswith("/"):
        raise ValueError(f"a policy root must be workspace-relative: {raw}")
    segments = candidate.split("/")
    if ".." in segments:
        raise ValueError(f"a policy root must not escape the workspace: {raw}")
    if candidate != "." and ("." in segments or "" in segments):
        raise ValueError(f"a policy root must be normalized: {raw}")
    return candidate


class WorkspacePolicy(ContractModel):
    """What a session may and may not modify, as declared by its caller."""

    #: Roots the session may modify, each of which must lie within one
    #: AutoCode already permits. `["."]` is the whole workspace.
    mutable_roots: list[str] = Field(default_factory=lambda: ["."])
    #: Roots the session must not modify, ADDED to AutoCode's own. Empty
    #: means "add nothing", never "protect nothing".
    protected_roots: list[str] = Field(default_factory=list)

    @field_validator("mutable_roots", "protected_roots")
    @classmethod
    def _roots_are_relative_and_normalized(cls, value: list[str]) -> list[str]:
        return [_validate_root(raw) for raw in value]

    @field_validator("mutable_roots")
    @classmethod
    def _at_least_one_mutable_root(cls, value: list[str]) -> list[str]:
        if not value:
            raise ValueError(
                "a session with no mutable root can never apply a patch; "
                "omit the policy instead of declaring an unusable one"
            )
        return value
