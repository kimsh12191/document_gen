"""Typed terminal outcomes emitted by the deterministic coding loop."""

from enum import Enum

from pydantic import Field, model_validator

from relab_core.coding.base import ContractModel


class FailureCategory(str, Enum):
    CONFIGURATION = "configuration"
    VERIFICATION = "verification"
    CAPABILITY = "capability"
    RESOURCE = "resource"
    CANCELLED = "cancelled"
    INTERNAL = "internal"
    PROVIDER = "provider"
    PLANNING = "planning"
    CONTEXT = "context"
    GENERATION = "generation"
    PATCH_POLICY = "patch_policy"
    EXECUTION = "execution"
    # Dependency Installation Contract: a missing Python module escalated
    # to a typed human decision, distinct from an ordinary VERIFICATION
    # failure -- no amount of patch repair fixes a missing package.
    DEPENDENCY = "dependency"


class FailurePhase(str, Enum):
    PLAN = "plan"
    VERIFY = "verify"
    REPAIR = "repair"
    ROUTING = "routing"
    TRANSPORT = "transport"
    CONTEXT = "context"
    GENERATION = "generation"
    PATCH_POLICY = "patch_policy"
    DEPENDENCY = "dependency"


class EvidenceKind(str, Enum):
    PATCH_EVIDENCE = "patch_evidence"


class EvidenceReference(ContractModel):
    kind: EvidenceKind
    ref: str = Field(min_length=1)
    description: str = ""


class TerminationCode(str, Enum):
    OBJECTIVE_APPLIED = "objective_applied"
    CONFIGURATION_ERROR = "configuration_error"
    WALL_TIME_BUDGET_EXHAUSTED = "wall_time_budget_exhausted"
    MODEL_CALL_BUDGET_EXHAUSTED = "model_call_budget_exhausted"
    REPAIR_CONVERGENCE_CEILING = "repair_convergence_ceiling"
    PATCH_ATTEMPTS_EXHAUSTED = "patch_attempts_exhausted"
    SESSION_CANCELLED = "session_cancelled"
    UNCLASSIFIED_ABORT = "unclassified_abort"
    PROVIDER_ERROR = "provider_error"
    PLANNING_ERROR = "planning_error"
    CONTEXT_ERROR = "context_error"
    GENERATION_ERROR = "generation_error"
    PATCH_POLICY_REJECTED = "patch_policy_rejected"
    SANDBOX_EXECUTION_ERROR = "sandbox_execution_error"
    # v0.21: the caller's declared `WorkspacePolicy` cannot be honoured.
    # Session-level, not loop-level -- it is decided before the first
    # model call, which is what makes `model_calls: 0` meaningful.
    WORKSPACE_POLICY_REJECTED = "workspace_policy_rejected"
    # Dependency Installation Contract: a missing module was detected and
    # a caller-declared `DependencyInstallPolicy` lets the loop ask a
    # human instead of failing outright. `retriable=True` -- a human CAN
    # unblock this by approving; the loop pauses, it does not give up.
    DEPENDENCY_INSTALL_REQUIRED = "dependency_install_required"
    # The approved install itself failed (pip's own exit code, a timeout,
    # or the sandbox rejecting the request). One attempt, no automatic
    # retry -- a second try needs a fresh, separate approval.
    DEPENDENCY_INSTALL_FAILED = "dependency_install_failed"
    # The declared environment could not be safely identified (not a real
    # venv, or outside the workspace boundary), or network is required but
    # the policy does not allow it. No install request is ever built in
    # this case -- BLOCKED, not "ask anyway and let the human sort it out."
    DEPENDENCY_ENVIRONMENT_UNRESOLVED = "dependency_environment_unresolved"
    # `DependencyInstallPolicy.max_requests` reached -- a distinct budget
    # from environment/network unresolved, so the message says which one
    # actually stopped the session.
    DEPENDENCY_REQUEST_BUDGET_EXHAUSTED = "dependency_request_budget_exhausted"


class CodingTermination(ContractModel):
    """Machine-actionable source of truth for why the coding loop stopped."""

    status: str = Field(
        pattern=r"^(success|exhausted|capability_ceiling|cancelled|policy_violation|awaiting_dependency)$"
    )
    category: FailureCategory | None = None
    code: TerminationCode
    phase: FailurePhase
    retriable: bool
    attempt: int = Field(ge=0)
    model_tier: int = Field(default=0, ge=0)
    evidence_refs: list[EvidenceReference] = Field(default_factory=list)
    message: str = Field(min_length=1)
    details: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_category(self) -> "CodingTermination":
        if self.status == "success" and self.category is not None:
            raise ValueError("a successful termination cannot have a failure category")
        if self.status != "success" and self.category is None:
            raise ValueError("a non-success termination requires a failure category")
        return self
