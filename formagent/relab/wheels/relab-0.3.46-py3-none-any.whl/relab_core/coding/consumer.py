"""Forward-compatible v2 consumer; strict producer schemas remain unchanged."""

from pydantic import BaseModel, ConfigDict, Field, model_validator

from relab_core.coding.dependency import DependencyInstallRequest
from relab_core.coding.termination import FailureCategory
from relab_core.contracts import HumanGate, RunState


class ReceivedModel(BaseModel):
    # Preserve extension fields for audit/relay without interpreting them.
    model_config = ConfigDict(extra="allow")


class ReceivedEvidence(ReceivedModel):
    kind: str = Field(min_length=1)
    ref: str = Field(min_length=1)
    description: str = ""


class ReceivedFailure(ReceivedModel):
    category: str = Field(min_length=1)
    code: str = Field(min_length=1)
    message: str = Field(min_length=1)
    phase: str = Field(min_length=1)
    retriable: bool = Field(strict=True)
    attempt: int = Field(ge=0)
    model_tier: int = Field(default=0, ge=0)
    evidence_refs: list[ReceivedEvidence] = Field(default_factory=list)
    dependency_install_request: DependencyInstallRequest | None = None

    def permits_retry(self) -> bool:
        try:
            category = FailureCategory(self.category)
        except ValueError:
            return False
        blocked = {
            FailureCategory.CONFIGURATION, FailureCategory.RESOURCE,
            FailureCategory.CAPABILITY, FailureCategory.CANCELLED,
            FailureCategory.PATCH_POLICY, FailureCategory.DEPENDENCY,
        }
        return self.retriable and category not in blocked


class ReceivedCodingResult(ReceivedModel):
    protocol_version: str = Field(min_length=1)
    status: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    workspace: str
    attempts: int = Field(ge=0)
    model_calls: int = Field(ge=0)
    request_id: str | None = None
    task_id: str | None = None
    trace_id: str | None = None
    parent_id: str | None = None
    escalation_tier: int = Field(default=0, ge=0)
    available_escalation_tiers: int = Field(default=0, ge=0)
    failure: ReceivedFailure | None = None
    evidence_refs: list[ReceivedEvidence] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_protocol(self) -> "ReceivedCodingResult":
        if self.protocol_version.split(".")[0] != "2":
            raise ValueError("unsupported coding protocol major")
        if self.status == "success" and self.failure is not None:
            raise ValueError("success cannot contain a failure")
        if self.status == "awaiting_dependency" and (
            self.failure is None or self.failure.dependency_install_request is None
        ):
            raise ValueError("dependency pause requires a typed install request")
        return self

    def permits_retry(self) -> bool:
        return (
            self.status == "exhausted"
            and self.failure is not None
            and self.failure.permits_retry()
        )

    def project(self, run_id: str) -> tuple[RunState, HumanGate | None]:
        if self.status == "success":
            return RunState.COMPLETED, None
        if self.status == "cancelled":
            return RunState.CANCELLED, None
        if self.status == "awaiting_dependency":
            if self.failure is None or self.failure.dependency_install_request is None:
                raise ValueError("dependency pause requires a typed install request")
            request = self.failure.dependency_install_request
            return RunState.AWAITING_HUMAN, HumanGate(
                gate_id=request.request_id, run_id=run_id, reason=request.reason
            )
        return RunState.FAILED, None
