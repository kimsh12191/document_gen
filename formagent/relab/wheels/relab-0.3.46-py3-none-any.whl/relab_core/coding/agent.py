"""Typed contracts for the Agentic Coding Loop (doc/ROADMAP.md v0.7).

Everything before this gate is a good coding *harness* — `plan`/
`propose`/`apply` as separate, human-driven steps. This is where AutoCode
becomes a coding *agent*: a bounded observe-decide-act loop. The loop
control itself is deterministic Python, never an LLM call (AGENTS.md
rule 2/6) — only the `PLAN`/`EDIT` steps it dispatches call a model.
"""

from enum import Enum

from pydantic import Field

from relab_core.coding.base import ContractModel
from relab_core.coding.identity import RequestIdentity
from relab_core.coding.patch import PatchEvidence
from relab_core.coding.progress import AttemptProgress
from relab_core.coding.termination import CodingTermination

STATUS_PATTERN = r"^(running|done|failed|aborted|awaiting_dependency)$"


class AgentDecision(str, Enum):
    """Only the decisions `run_coding_loop` actually emits.

    `plan`/`inspect`/`ask_human`/`done`/`abort` were also defined here and
    never emitted by anything -- an aspirational surface that made the
    loop look like it had states it does not have. Removed before 1.0
    rather than frozen; the same reasoning removed `awaiting_human` from
    `STATUS_PATTERN` above. Re-add one when a real code path produces it.

    The Dependency Installation Contract is that real code path -- but
    for the specific, narrow reason of a missing package, not a generic
    `awaiting_human`, so `STATUS_PATTERN` gained `awaiting_dependency`
    instead of resurrecting the generic name. Still no new `AgentDecision`:
    the loop pausing is a new terminal *status*, never a new *decision* it
    makes.
    """

    EDIT = "edit"
    VERIFY = "verify"
    REPAIR = "repair"


class CodingBudget(ContractModel):
    max_iterations: int = Field(default=5, ge=1)
    max_model_calls: int = Field(default=20, ge=1)
    max_wall_time_seconds: float = Field(default=600.0, gt=0)
    max_patch_attempts: int = Field(default=3, ge=1)


class CodingStep(ContractModel):
    attempt: int = Field(ge=0)
    decision: AgentDecision
    detail: str = Field(min_length=1)
    patch_evidence: PatchEvidence | None = None


class CodingState(RequestIdentity):
    objective: str = Field(min_length=1)
    workspace: str
    status: str = Field(default="running", pattern=STATUS_PATTERN)
    attempt: int = Field(default=0, ge=0)
    model_calls: int = Field(default=0, ge=0)
    steps: list[CodingStep] = Field(default_factory=list)
    stop_reason: str | None = None
    # v0.17: source-of-truth terminal outcome. ``stop_reason`` remains a
    # compatibility/presentation field populated from ``message``.
    termination: CodingTermination | None = Field(default=None, exclude=True)
    # Dynamic Model Routing (doc/ROADMAP.md v0.12, Experiment 5): whether
    # this run ever escalated repair to a larger model, and how many of
    # model_calls went to that larger tier -- the cost side of "similar
    # success rate to always-large, for how much less large-model spend".
    escalated: bool = False
    large_model_calls: int = Field(default=0, ge=0)
    # v0.9.7: escalation can now cascade through more than one tier
    # (e.g. 7B -> 14B -> 32B) -- 0 means never escalated, 1 means one
    # tier up, etc. `escalated` above stays True the moment this is >0,
    # for existing callers that only care whether escalation happened
    # at all, not how far.
    escalation_tier: int = Field(default=0, ge=0)
    # v0.22: one record per patch attempt, for a later routing study to
    # read back. Collected, never consulted -- nothing on the control path
    # may read these, and `tests/test_layering.py` enforces it.
    attempts: list[AttemptProgress] = Field(default_factory=list)
    # Dependency Installation Contract: how many distinct install requests
    # this session has already raised, bounded by
    # `DependencyInstallPolicy.max_requests` -- without this, a project
    # with several missing modules could ask once per module forever.
    dependency_requests: int = Field(default=0, ge=0)
