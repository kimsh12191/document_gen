"""Typed contracts for `CodingAgentProtocol.propose()` and the v0.5
transactional apply/verify/auto-revert lifecycle that enforces them.

Mirrors AutoResearch's proven `PatchProposal`/`PathPolicy` shapes
(independently — no shared code): `diff` is a git-compatible unified
diff; `base_hashes` maps each touched relative path to the sha256 of its
current content, or the `MISSING_FILE_HASH` sentinel for a new file, so a
stale proposal is rejected before anything is mutated. A `PatchProposal`
is a plan for a mutation, never the mutation itself — `autocode/core/
patch_policy.py` and `autocode/core/patcher.py` own all filesystem
authority (AGENTS.md rule 3).
"""

import re
from enum import Enum

from pydantic import Field, model_validator

from relab_core.coding.base import ContractModel
from relab_core.coding.identity import RequestIdentity
from relab_core.coding.termination import TerminationCode
from relab_core.snapshots import FileSnapshot

SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
MISSING_FILE_HASH = "missing"


class PatchProposal(RequestIdentity):
    diff: str = Field(min_length=1)
    base_hashes: dict[str, str] = Field(min_length=1)
    summary: str = Field(min_length=1)

    @model_validator(mode="after")
    def validate_hashes(self) -> "PatchProposal":
        for path, digest in self.base_hashes.items():
            if not path:
                raise ValueError("base_hashes path must not be empty")
            if digest != MISSING_FILE_HASH and not SHA256_PATTERN.match(digest):
                raise ValueError(f"invalid base hash for {path}: {digest!r}")
        return self


class PathPolicy(ContractModel):
    mutable_roots: list[str] = Field(default_factory=lambda: ["."])
    protected_roots: list[str] = Field(
        default_factory=lambda: [".git", ".autocode", ".env", "secrets", "private"]
    )


class PatchStatus(str, Enum):
    APPLIED = "applied"
    REVERTED = "reverted"
    REJECTED = "rejected"
    REVERT_FAILED = "revert_failed"


class MeasuredSubject(ContractModel):
    """One artifact a verify command reports having measured.

    A claim, and recorded as one. What a verifier says it looked at is written
    by the verifier -- which, for a measurement ReLab asked a model to build, is
    written by a model. It is kept beside what ReLab observed rather than merged
    with it, so the two can disagree and be seen to.

    What a matching digest establishes is narrow and worth stating: the artifact
    this verifier named is the artifact the workspace held when it ran. It is
    protocol consistency, not proof that the code was executed -- a verifier can
    hash a file it never imports. Proving execution needs coverage or import
    tracing, which is a different capability and not this one.
    """

    path: str = Field(min_length=1, max_length=1024)
    digest: str = Field(min_length=1, max_length=128)


class VerificationResult(ContractModel):
    argv: list[str] = Field(min_length=1)
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False
    passed: bool = False
    # v0.14 verification honesty: how many checks the verify command
    # itself reports having executed, via the AUTOCODE_VERIFY_REPORT
    # convention (autocode/core/patcher.py). None means the command never
    # reported one -- exit-code-only semantics apply, unchanged from
    # before v0.14. A reported 0 means `passed` is forced False even on
    # exit code 0: a verify command that ran nothing is not a pass (e.g.
    # `python -m unittest discover` on a test file with no discoverable
    # tests, exit 0 regardless).
    executed_checks: int | None = Field(default=None, ge=0)
    # v0.22: the passed/failed split, when the verify command reports it
    # through the same `AUTOCODE_VERIFY_REPORT` convention. Never derived
    # from `executed_checks` and an exit code -- a suite can exit non-zero
    # with most checks passing, so deriving it would put a number in
    # `AttemptProgress` that nothing measured.
    passed_checks: int | None = Field(default=None, ge=0)
    failed_checks: int | None = Field(default=None, ge=0)
    # What the verify command said it measured, through the same report. Empty
    # means it named nothing, which for a measurement ReLab owns is a broken
    # contract and for one it merely adopted is a fact about how much can be
    # seen. A verifier naming an artifact is a claim; the next field is not.
    reported_subjects: list[MeasuredSubject] = Field(default_factory=list, max_length=16)
    # Which requirements this run's verifier declared it exercises, exactly as
    # it reported them.
    #
    # Raw per-run report data, like `reported_subjects` and `executed_checks`
    # beside it: this says what *this run* heard, and nothing about what the
    # ruler is. The one fact about the ruler is the session's single
    # `MeasurementClaimObservation`, which is why that is not stored here --
    # one observation per instrument, however many runs it measures.
    #
    # Carried at all because a claim heard during a real verification is the
    # only way a study whose preflight probe went unanswered ever gets one, and
    # a record can be read back later while a callback cannot.
    #
    # `None` is "said nothing about requirements", which is not "checks none".
    claimed_requirements: list[str] | None = Field(default=None, max_length=64)
    # What the workspace actually held, for each path this run declared it was
    # writing, observed at the verification boundary -- after the patch was
    # applied and before the command ran. `None` for a declared path that was
    # not there, which is an observation and not a gap in one.
    #
    # Keyed by declared subject rather than by touched file on purpose. They
    # coincide most of the time and mean different things: one is a property of
    # the patch, the other of the measurement. A patch that changes nothing, or
    # a design measuring a file no arm writes, separates them.
    measured_digests: dict[str, str | None] = Field(default_factory=dict)
    # Which frozen ruler took this reading, when the study had one. Recorded
    # here rather than on the run's reference because this is the first moment
    # it can be known: a run is attached before it is measured, and a plan's
    # measurement may not have been frozen yet when it was.
    #
    # It is what makes evidence expire. A study that replaces its instrument
    # does not delete what the old one measured; those readings simply stop
    # being readings under the ruler in force, which is a comparison rather
    # than a rewrite.
    measurement_snapshot_id: str | None = Field(default=None, min_length=8, max_length=64)


class PatchEvidence(ContractModel):
    patch_id: str = Field(min_length=1)
    diff: str
    touched_files: list[str] = Field(default_factory=list)
    # What each touched file held either side of this patch, addressed by
    # digest. A diff says what changed and not what the file was, so this is
    # what a before/after comparison is built from -- and it is recorded at the
    # moment it was true, which is the only moment it is available for an
    # attempt that was afterwards undone. Empty for a patch that never reached
    # the tree, and for records written before this was kept.
    snapshots: list[FileSnapshot] = Field(default_factory=list)
    verification: VerificationResult | None = None
    status: PatchStatus
    error: str | None = None
    # Internal loop signal; excluded so v0.18 does not alter PatchEvidence's
    # established JSON surface while the session protocol publishes the
    # corresponding CodingFailure.
    termination_code: TerminationCode | None = Field(default=None, exclude=True)
    failure_details: dict[str, str] = Field(default_factory=dict, exclude=True)
