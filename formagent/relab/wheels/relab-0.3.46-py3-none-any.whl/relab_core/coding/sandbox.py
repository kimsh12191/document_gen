"""Typed contracts for the verification sandbox (doc/ROADMAP.md v0.6).

Independently mirrors AutoResearch's `SandboxPolicy`/`SandboxRequest`
shape. **Defense in depth against a real secret-leak bug found this
session** in AutoResearch's own `LocalProcessSandbox`: a policy could
declare `environment_allowlist: [OPENROUTER_API_KEY]` with no matching
key in the actual request, and the runtime silently sourced the real
value from the host `os.environ` without ever checking it against the
secret-name pattern. Here, the secret-name check runs at THIS
schema-construction layer (below) *and* independently again in
`autocode/runtime/sandbox.py`'s `_safe_environment()` at every allowlist
entry, not only ones present in a given request — so the check cannot be
skipped by the same code path that leaked it there.

**Stated limitation:** `SECRET_NAME_PATTERN` is a name heuristic and a
*backstop*, not the primary control. It cannot tell `DATABASE_URL` (holds
credentials) from `VLLM_BASE_URL` (does not), so it will always both miss
some secrets and refuse some innocent names. The primary control is that
`environment_allowlist` is explicitly authored — nothing reaches a child
process that a human did not name. Widen the pattern when a real miss is
found; never treat it as sufficient on its own.
"""

import re
from enum import Enum
from pathlib import PurePosixPath

from pydantic import Field, model_validator

from relab_core.coding.base import ContractModel

SECRET_NAME_PATTERN = re.compile(
    r"(SECRET|TOKEN|PASSWORD|PASSWD|API[_-]?KEY|CREDENTIAL"
    # widened after an assessment found the original list passed
    # DATABASE_URL, GH_PAT and AWS_SESSION_TOKEN-adjacent names:
    # AUTH(?!OR) so a legitimate GIT_AUTHOR_NAME isn't refused as a secret
    r"|PRIVATE[_-]?KEY|ACCESS[_-]?KEY|AUTH(?!OR)|SESSION|_PAT$|^PAT_|SIGNING|PASSPHRASE"
    r"|DATABASE[_-]?URL|CONN(ECTION)?[_-]?STRING|DSN)",
    re.IGNORECASE,
)
# `RECOVERY_ID_PATTERN` was here, validating ids for a sandbox recovery
# mechanism whose directory nothing ever wrote to or read. Removed with the
# rest of it before 1.0 (see `runtime/sandbox.py`).


class SandboxBackend(str, Enum):
    LOCAL_PROCESS = "local_process"
    DOCKER = "docker"


class NetworkPolicy(str, Enum):
    DENY = "deny"
    INHERIT = "inherit"


class SandboxStatus(str, Enum):
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    REJECTED = "rejected"
    TIMED_OUT = "timed_out"
    CANCELLED = "cancelled"


def is_secret_environment_name(name: str) -> bool:
    return bool(SECRET_NAME_PATTERN.search(name))


class SandboxPolicy(ContractModel):
    # `cleanup: bool` was here to control removal of a recovery directory
    # that nothing ever wrote to or read -- removed with the rest of that
    # mechanism (see `runtime/sandbox.py`). `network` deliberately stays
    # fail-closed at DENY: only the Docker backend can enforce it, and
    # `LocalProcessSandbox` refuses DENY outright rather than pretending,
    # so `build_sandbox_policy()` passes INHERIT explicitly for local runs.
    backend: SandboxBackend = SandboxBackend.LOCAL_PROCESS
    network: NetworkPolicy = NetworkPolicy.DENY
    environment_allowlist: list[str] = Field(default_factory=list)
    secret_names: list[str] = Field(default_factory=list)
    docker_image: str | None = None

    @model_validator(mode="after")
    def validate_policy(self) -> "SandboxPolicy":
        if len(self.environment_allowlist) != len(set(self.environment_allowlist)):
            raise ValueError("environment allowlist entries must be unique")
        if set(self.environment_allowlist) & set(self.secret_names):
            raise ValueError("secret names cannot be environment-allowlisted")
        for name in self.environment_allowlist:
            if is_secret_environment_name(name):
                raise ValueError(f"secret-shaped name cannot be environment-allowlisted: {name}")
        if self.backend is SandboxBackend.DOCKER and not self.docker_image:
            raise ValueError("docker_image is required for the Docker sandbox")
        if self.backend is SandboxBackend.LOCAL_PROCESS and self.docker_image:
            raise ValueError("docker_image is only valid for the Docker sandbox")
        return self


class SandboxRequest(ContractModel):
    id: str = Field(min_length=1)
    argv: list[str] = Field(min_length=1)
    cwd: str = "."
    timeout_seconds: float = Field(default=300.0, gt=0)
    environment: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_cwd(self) -> "SandboxRequest":
        path = PurePosixPath(self.cwd.replace("\\", "/"))
        if path.is_absolute() or ".." in path.parts:
            raise ValueError("sandbox cwd must be relative and bounded")
        return self


class SandboxResult(ContractModel):
    request_id: str
    backend: SandboxBackend
    status: SandboxStatus
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""
    error: str | None = None
