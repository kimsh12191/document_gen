"""Coding v2 contracts migrated from AutoCode 21deb65; see migration provenance."""
