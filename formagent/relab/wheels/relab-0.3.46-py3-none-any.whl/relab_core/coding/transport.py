"""Structured transport failures for the one-shot ``autocode serve`` boundary.

These failures mean the request did not reach a coding operation (invalid
JSON, an unknown method, malformed parameters, or local setup failure for a
lower-level direct call).  They deliberately are not ``CodingFailure``:
Protocol v2 remains the typed terminal outcome of a well-formed coding
session, while this contract replaces the old flat ``error`` string outside
that session.
"""

from pydantic import Field

from relab_core.coding.base import ContractModel

__all__ = ["TransportFailure"]


class TransportFailure(ContractModel):
    """Machine-readable failure returned in an ``ok: false`` envelope."""

    code: str = Field(min_length=1)
    message: str = Field(min_length=1)
