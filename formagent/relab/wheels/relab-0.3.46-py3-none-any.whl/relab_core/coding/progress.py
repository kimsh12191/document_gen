"""Per-attempt progress records (doc/ROADMAP.md v0.22).

What one patch attempt did, in a form a later study can read back. The
gate is **collection only**: nothing in the coding loop, the session, or
anything else on the control path reads these to make a decision, and
`tests/test_layering.py` fails if that changes. The reason is not caution
about the data but about the evidence — a signal wired into routing on
external-API results would be optimising against a provider's current
checkpoint, and it would also make every subsequent recording a
consequence of the policy rather than an observation of the loop.

v0.20 measured that byte-identical patch convergence — today's escalation
trigger — is reached on 14% of failing runs. Whether a looser trigger
would do better is a Local LLM question (Experiment L4). This is the data
that question needs, gathered while it cannot yet be asked.

Every optional field here is optional because the situation it describes
really occurs, never as a placeholder:

- an attempt that never produced a patch has no patch fingerprint;
- an attempt that succeeded has no failure;
- an attempt whose patch was rejected before execution has no
  verification result;
- the first attempt has nothing to be compared against.
"""

from pydantic import Field

from relab_core.coding.base import ContractModel
from relab_core.coding.termination import FailureCategory, TerminationCode


class AttemptProgress(ContractModel):
    """One patch attempt, as evidence rather than as a decision."""

    attempt: int = Field(ge=1)
    #: Which escalation tier produced this attempt (0 = the primary editor).
    model_tier: int = Field(default=0, ge=0)
    #: Cumulative model calls at the end of this attempt, matching
    #: `CodingState.model_calls` — a per-attempt delta is derivable from
    #: consecutive records, while the total is not derivable from deltas
    #: if any record is missing.
    model_calls: int = Field(default=0, ge=0)
    #: See `core/fingerprints.py::context_fingerprint` for exactly what
    #: this covers, and what it does not.
    context_fingerprint: str = Field(min_length=1)

    #: `None` when the attempt failed before producing a patch at all
    #: (a planning, context, generation or provider failure).
    patch_fingerprint: str | None = None
    #: The same patch under presentation-only normalization. The gap
    #: between this and `patch_fingerprint` across attempts is the whole
    #: reason this record exists.
    normalized_patch_fingerprint: str | None = None
    touched_files: list[str] = Field(default_factory=list)

    #: `None` when the attempt succeeded.
    failure_category: FailureCategory | None = None
    failure_code: TerminationCode | None = None
    failure_fingerprint: str | None = None

    #: `None` when verification never ran — the patch was rejected by
    #: policy, or no patch existed. Distinct from `False`, which means it
    #: ran and did not pass.
    verification_passed: bool | None = None
    #: How many checks the verify command reported running, via the
    #: `AUTOCODE_VERIFY_REPORT` convention. `None` when it reported none;
    #: a reported 0 is a real answer ("ran nothing"), not a missing one.
    executed_checks: int | None = Field(default=None, ge=0)
    passed_checks: int | None = Field(default=None, ge=0)
    failed_checks: int | None = Field(default=None, ge=0)

    #: Comparison against the immediately preceding attempt. `None` on
    #: the first attempt, where there is nothing to compare against —
    #: which is not the same as "nothing changed".
    repeats_previous_patch: bool | None = None
    repeats_previous_normalized_patch: bool | None = None
    repeats_previous_failure: bool | None = None

    def produced_a_patch(self) -> bool:
        return self.patch_fingerprint is not None

    def succeeded(self) -> bool:
        return self.failure_category is None and self.verification_passed is True
