"""Typed contracts for bounded repository inspection.

`CodeInspectionResult` is the AutoCode Protocol's `inspect()` return type
(see doc/ROADMAP.md v0.1/v0.2) — it carries the flat file inventory and
Python symbol index from the first increment, plus the richer structural
signals (file roles, import graph, test<->source mapping) added while
extending v0.1 in place, so downstream capabilities (planning, context
selection) have exactly one result type to depend on rather than two
overlapping ones.
"""

from pydantic import Field

from relab_core.coding.base import ContractModel
from relab_core.coding.identity import RequestIdentity

SHA256_PATTERN = r"^[0-9a-f]{64}$"
SYMBOL_KIND_PATTERN = r"^(class|function|async_function)$"
FILE_ROLE_PATTERN = r"^(source|test|config|entrypoint|doc|other)$"


class RepoFile(ContractModel):
    path: str = Field(min_length=1)
    size: int = Field(ge=0)
    sha256: str = Field(pattern=SHA256_PATTERN)


class PythonSymbol(ContractModel):
    """A definition site: a class/function/async-function statement."""

    path: str = Field(min_length=1)
    qualified_name: str = Field(min_length=1)
    kind: str = Field(pattern=SYMBOL_KIND_PATTERN)
    line: int = Field(ge=1)


class SymbolReference(ContractModel):
    """A use site: a call whose callee name matches a known symbol.

    Best-effort and name-based (no cross-module type resolution) — a
    single call site may legitimately match more than one candidate
    symbol when the name is not unique across the repository.
    """

    path: str = Field(min_length=1)
    qualified_name: str = Field(min_length=1)
    line: int = Field(ge=1)


class DependencyEdge(ContractModel):
    """One `import`/`from ... import ...` statement, resolved where possible."""

    from_path: str = Field(min_length=1)
    to_module: str = Field(min_length=1)
    to_path: str | None = None
    line: int = Field(ge=1)


class FileSummary(ContractModel):
    path: str = Field(min_length=1)
    role: str = Field(pattern=FILE_ROLE_PATTERN)
    symbol_count: int = Field(default=0, ge=0)
    import_count: int = Field(default=0, ge=0)


class TestReference(ContractModel):
    """A plausible test<->source pairing, with a confidence signal.

    1.0 = naming convention (test_foo.py <-> foo.py); lower = import-graph
    proximity only (the test file imports the source file, but the names
    do not otherwise match).
    """

    test_path: str = Field(min_length=1)
    source_path: str = Field(min_length=1)
    confidence: float = Field(ge=0, le=1)


class CodeInspectionRequest(RequestIdentity):
    path: str = "."
    max_files: int = Field(default=2000, ge=1)
    max_symbol_bytes: int = Field(default=1_000_000, ge=1)


class CodeInspectionResult(RequestIdentity):
    root: str = Field(min_length=1)
    files: list[RepoFile] = Field(default_factory=list)
    symbols: list[PythonSymbol] = Field(default_factory=list)
    symbol_references: list[SymbolReference] = Field(default_factory=list)
    dependency_edges: list[DependencyEdge] = Field(default_factory=list)
    file_summaries: list[FileSummary] = Field(default_factory=list)
    test_references: list[TestReference] = Field(default_factory=list)
    truncated: bool = False
