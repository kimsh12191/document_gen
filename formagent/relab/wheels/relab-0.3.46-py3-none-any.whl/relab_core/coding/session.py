"""Typed contracts for v0.14 Coding Session and Structured Protocol v2
(doc/ROADMAP.md v0.14, doc/plan/14_coding_session_protocol_v2.md).

    CodingSessionRequest -> run_coding_session() (autocode/core/session.py,
    the same run_coding_loop() `autocode implement` already runs)
    -> CodingResult

Distinguishes TRANSPORT success (the call completed and returned a
well-formed response) from CODING success (the objective was actually
verified and applied): a well-formed `CodingResult` can terminally report
`exhausted` or `capability_ceiling`, not only `success`. `CodingFailure`
carries the structured why (category/code/phase/retriable/evidence) instead
of a flat error string, so a caller (eventually AutoResearch -- see the
plan doc's "Cross-repo contract ownership") can make a retry/escalate/
give-up decision without parsing prose.

FROZEN at v0.16.1. Every status, failure category, and phase below is one
`autocode/core/session.py` actually emits -- asserted mechanically by
`tests/test_protocol_v2_freeze.py`, which fails if a value is added
without a code path that produces it or a code path stops producing one.

The freeze is what *removed* schema rather than what added it. v0.14
shipped a status (`policy_violation`) and six failure categories
(`provider`, `planning`, `context`, `generation`, `patch_policy`,
`repair`) that no code path could ever produce. They are cut here rather
than frozen into 1.0, following the same call this package already made
on `ModelCapabilities` (`autocode/schema/models.py`): a contract value
nothing emits is not a promise, it is a consumer writing a branch it can
never reach or test.

Five of those six were unreachable structurally, not by oversight. A
provider outage, an invalid plan, a policy-rejected patch and a bad
editor response are all caught *inside* `run_coding_loop()` (the
`except (ValueError, ModelProviderError)` branch), which appends a
constraint and retries -- so they never terminate a session on their own.
Whatever they cause surfaces as the terminal reason that eventually does
fire, normally `verification` / `patch_attempts_exhausted`. Making them
reachable would mean changing what the loop *does*, not what this file
says, and that is a deliberate behaviour change for a later gate rather
than something to smuggle in under a freeze. The known cost is recorded
in CURRENT_STATE.md's "Known limitations": a caller cannot today tell an
API outage apart from a model that simply kept failing.

`internal` is kept despite also being unreachable from a valid loop exit.
Since v0.17 it is the adapter's defensive backstop for a legacy or invalid
`CodingState` missing its typed termination; no prose is inspected.
"""

from pydantic import Field

from relab_core.coding.agent import CodingBudget
from relab_core.coding.base import ContractModel
from relab_core.coding.dependency import (
    DependencyInstallPolicy,
    DependencyInstallRequest,
    DependencyResume,
)
from relab_core.coding.identity import RequestIdentity
from relab_core.coding.termination import (
    EvidenceKind,
    EvidenceReference,
    FailureCategory,
    FailurePhase,
)
from relab_core.coding.workspace import WorkspacePolicy

__all__ = [
    "CodingFailure",
    "CodingResult",
    "CodingSessionRequest",
    "EvidenceKind",
    "EvidenceReference",
    "FailureCategory",
    "FailurePhase",
]

PROTOCOL_V2_VERSION = "2.0"
# Frozen at v0.16.1. Adding a value here is a protocol change: it needs a
# classifier branch that emits it, a fixture in tests/fixtures/protocol_v2/,
# and a matching change on the consuming side (see "Cross-repo contract
# ownership" in doc/ROADMAP.md).
#
# `awaiting_dependency` (Dependency Installation Contract): added by the
# same route the freeze prescribes -- a real emitting path
# (`core/loop.py`'s dependency branch) built first, then this pattern,
# then `tests/fixtures/protocol_v2/awaiting_dependency.json`, then
# `tests/test_protocol_v2_freeze.py` updated to keep both directions
# honest. Distinct from every other value here: it is retriable by a
# human decision, not exhausted/cancelled/policy-rejected.
CODING_RESULT_STATUS_PATTERN = (
    r"^(success|exhausted|capability_ceiling|cancelled|policy_violation|awaiting_dependency)$"
)


class CodingFailure(ContractModel):
    category: FailureCategory
    code: str = Field(min_length=1)
    message: str = Field(min_length=1)
    phase: FailurePhase
    retriable: bool
    attempt: int = Field(ge=0)
    # 0 = the primary/configured model, no escalation; matches
    # `CodingState.escalation_tier` (doc/ROADMAP.md v0.13).
    model_tier: int = Field(default=0, ge=0)
    evidence_refs: list[EvidenceReference] = Field(default_factory=list)
    # Dependency Installation Contract: set only when `code ==
    # "dependency_install_required"`. A typed field rather than the
    # internal `CodingTermination.details` string-blob this is parsed
    # from -- a caller building an approval decision needs the actual
    # request, not a JSON string to parse a second time.
    dependency_install_request: DependencyInstallRequest | None = None


class CodingSessionRequest(RequestIdentity):
    """Input to `run_coding_session()` / `autocode serve`'s `"run"` method --
    the Research-mode entry point that owns plan/edit/verify/repair/routing
    for one objective, instead of leaving the caller to build its own retry
    loop around one-shot `propose`."""

    objective: str = Field(min_length=1)
    workspace: str = "."
    target_paths: list[str] = Field(default_factory=list)
    verify_argv: list[str] = Field(default_factory=list)
    # v0.21: constraints the caller wants the planner to work under. The
    # gap this closes: a Research caller that measures a result and derives
    # guidance from it had a `constraints` field on the one-shot
    # `propose` path and none here, so once a session became its default
    # (AutoResearch v0.23) that guidance had nowhere to go. `implement`
    # and `plan` have taken constraints since v0.4; only the session
    # protocol could not.
    constraints: list[str] = Field(default_factory=list)
    budget: CodingBudget = Field(default_factory=CodingBudget)
    # v0.15: Dynamic Model Routing (doc/ROADMAP.md v0.13) exposed to
    # Research-mode callers, deferred from v0.14. Paths are resolved
    # relative to `workspace` -- the wire-protocol equivalent of
    # `autocode implement --escalation-models`, which takes arbitrary
    # filesystem paths instead since a CLI caller isn't crossing a
    # process/JSON boundary. Ascending order: index 0 is the first tier
    # to escalate to.
    escalation_registry_paths: list[str] = Field(default_factory=list)
    # v0.21: the caller's declarative restriction on what this session may
    # modify. `None` means "AutoCode's own policy", which is what every
    # caller got before this field existed.
    #
    # An AutoCode too old to know this field does not ignore it: every
    # contract model forbids extra keys, so the request fails validation
    # and comes back as a structured transport refusal. A caller that
    # needs its policy enforced therefore cannot be silently downgraded to
    # one that does not enforce it -- which is the whole reason
    # AutoResearch refused this combination rather than sending it.
    workspace_policy: WorkspacePolicy | None = None
    # Dependency Installation Contract. `None` (the default) is a stricter
    # default, not a looser one: with no policy, a missing module still
    # just fails verification the ordinary way -- unchanged behavior for
    # every caller that does not know this field exists yet.
    dependency_install_policy: DependencyInstallPolicy | None = None
    # Resumes a session paused for a dependency install (`status:
    # "awaiting_dependency"`) after the caller has approved/rejected it
    # and, if approved, run the install. Mutually exclusive with actually
    # starting a new objective in the same request -- a caller resuming
    # passes the SAME `objective`/`workspace` the paused session used.
    resume: DependencyResume | None = None


class CodingResult(RequestIdentity):
    protocol_version: str = PROTOCOL_V2_VERSION
    status: str = Field(pattern=CODING_RESULT_STATUS_PATTERN)
    objective: str = Field(min_length=1)
    workspace: str
    attempts: int = Field(ge=0)
    model_calls: int = Field(ge=0)
    escalation_tier: int = Field(default=0, ge=0)
    # v0.15: how many escalation tiers were CONFIGURED for this session,
    # regardless of how many were actually climbed (`escalation_tier`
    # above). Deliberately a plain count, not a declarative capability
    # descriptor naming parameter sizes or features -- `ModelCapabilities`
    # was cut before 1.0 (see autocode/schema/models.py) precisely because
    # no caller ever checked a flag like that. A caller CAN act on a count:
    # `escalation_tier == available_escalation_tiers` at a `capability_
    # ceiling` status means every configured tier converged, not that no
    # bigger model exists to try.
    available_escalation_tiers: int = Field(default=0, ge=0)
    failure: CodingFailure | None = None
    evidence_refs: list[EvidenceReference] = Field(default_factory=list)
