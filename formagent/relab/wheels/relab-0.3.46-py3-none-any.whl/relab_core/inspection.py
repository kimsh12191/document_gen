"""What ReLab looked at, as a record rather than as a model's account of it.

A planner is given a repository map and a ranked list of paths, and from that it
must decide things it cannot see: which of two verifiers measures the task in
hand, how an existing harness imports the thing it tests, whether a file named
`old_verify.py` is still the one that matters. Today it cannot ask. It designs
from the names.

So inspection becomes a capability, and the shape of it is decided before the
machinery, because the shape is where this goes wrong:

    model                proposes an inspection request, and nothing more
    application          validates it against what this workspace allows
    workspace service    reads or searches; the only layer that touches a file
    result               comes back as a bounded observation, and is recorded

A model never holds filesystem authority. It asks, and something else decides
whether the asking was allowed -- the same division the plan already has for
what an arm may edit.

## Why the result is a contract and not a string

"What did the planner see when it chose this verifier?" has to be answerable
later, from the record, by someone who was not there. An observation carries its
path and a digest of what was read, so the answer is checkable rather than
remembered: if the file has changed since, the digest says so.

Observations are *workspace* evidence. They are what the tree held, recorded by
the layer that read it. Nothing a model wrote goes in one -- a model's summary of
a file is a claim about the file, and storing that here would put the two beyond
telling apart.
"""

from typing import Literal, Protocol
from uuid import uuid4

from pydantic import Field

from relab_core.contracts import Contract
from relab_core.targets import READABLE_PATH_PATTERN

# Enough of a file to judge what it does, bounded because it reaches a prompt.
MAXIMUM_READ_BYTES = 65_536


class FileObservation(Contract):
    """One file as the workspace held it, read for inspection and not for editing.

    Not `bytes`: this is going into a prompt and into a record, and both want
    text. The read refuses anything that is not UTF-8 rather than lossily
    decoding it, because a planner shown mojibake would reason about mojibake.
    """

    observation_version: str = "file-observation-v1"
    path: str = Field(pattern=READABLE_PATH_PATTERN)
    content: str
    # Of the bytes actually read, so a truncated observation's digest is the
    # digest of what was seen rather than of a file nobody looked at whole.
    digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    bytes_read: int = Field(ge=0)
    # Said outright. A planner that read the first 64 KiB of a long file and a
    # planner that read all of a short one are in different positions, and a
    # record that cannot tell them apart cannot explain a decision either.
    truncated: bool = False


# What a search may answer with, bounded because it reaches a prompt and a record.
MAXIMUM_MATCHES = 50
# One matching line, cut so a minified file cannot become the whole answer.
MAXIMUM_MATCH_CHARACTERS = 300
# How much of any one file is searched. The same bound as a read, for the same
# reason: a file too large to show is too large to answer questions about.
MAXIMUM_SEARCHED_BYTES = MAXIMUM_READ_BYTES
# How many files one query may open. A search that walks an unbounded tree is a
# cost nobody declared.
MAXIMUM_SEARCHED_FILES = 2_000


class LineMatch(Contract):
    """One line a query was found on, and where.

    The line number is what makes this an answer rather than a list of files. A
    planner asking how an existing harness imports the thing it tests wants
    `tools/verify.py:18`, not `tools/verify.py`.
    """

    path: str = Field(pattern=READABLE_PATH_PATTERN)
    # One-based, because that is what an editor, a traceback and a person all use.
    line: int = Field(ge=1)
    text: str = Field(max_length=MAXIMUM_MATCH_CHARACTERS)
    # Of the bytes searched in that file, so a match can be checked later against
    # the file it was found in. Without it "the planner saw this line" is a claim
    # about a file that may since have changed.
    digest: str = Field(pattern=r"^[0-9a-f]{64}$")


class SearchObservation(Contract):
    """What one query found, as the workspace held it.

    Workspace evidence, like `FileObservation`: recorded by the layer that read
    the tree, and never a model's account of what it thinks is there. Keeping
    those apart is what lets "why did the planner choose this verifier" be
    answered from the record rather than from a summary.
    """

    observation_version: str = "search-observation-v1"
    # Kept because the matches mean nothing without it, and because a record of
    # what was searched for is half of what was learned.
    query: str = Field(min_length=1, max_length=200)
    # Empty is an answer: the query found nothing, which a planner can act on.
    matches: list[LineMatch] = Field(default_factory=list, max_length=MAXIMUM_MATCHES)
    files_searched: int | None = Field(ge=0)
    # Said outright, because a truncated search and an exhaustive one support
    # different conclusions and a record that cannot tell them apart supports
    # neither.
    truncated: bool = False
    # Why it stopped short, when it did: the matches it may return, the files it
    # may open, or its time. Each says something different about what was not
    # seen -- "no matches" in the first 2,000 files of 30,000 is not "none".
    stopped_by: Literal["matches", "files", "time"] | None = None


# What one request may ask for at a time. A planner that wants a sixth file can
# ask in the next round, having seen the first five -- which is a better question
# than the one it would have asked without them.
# How many times a planner may ask before it has to design something. A
# request for one more file is one a model can always make.
MAXIMUM_INSPECTION_ROUNDS = 2
MAXIMUM_READS = 5
MAXIMUM_SEARCHES = 5


class ReadRequest(Contract):
    """A file a planner asks to see. A request, and not an act."""

    path: str = Field(pattern=READABLE_PATH_PATTERN)
    # Why it wants this one. Not used to decide anything -- the application
    # validates the path, not the reason -- but recorded, so "what was the
    # planner trying to find out" is answerable from the record.
    because: str = Field(min_length=1, max_length=200)


class SearchRequest(Contract):
    """Words a planner asks to find, and where to look for them."""

    query: str = Field(min_length=1, max_length=200)
    scope: str | None = Field(default=None, pattern=READABLE_PATH_PATTERN)
    because: str = Field(min_length=1, max_length=200)


class InspectionRequest(Contract):
    """What a planner wants to look at before it designs anything.

    Asking is not doing. This is the whole of a model's authority over the
    filesystem: it names paths and words, and something else decides whether the
    naming was allowed and performs it. A model that could read directly could
    eventually write, and the boundary is easier to keep than to restore.

    An empty request is a real answer -- "nothing here needs looking at" -- and
    an empty workspace should produce one.
    """

    reads: list[ReadRequest] = Field(default_factory=list, max_length=MAXIMUM_READS)
    searches: list[SearchRequest] = Field(default_factory=list, max_length=MAXIMUM_SEARCHES)

    @property
    def is_empty(self) -> bool:
        return not self.reads and not self.searches


class InspectionResult(Contract):
    """What the workspace answered, and what was refused.

    Refusals are carried rather than raised. A planner asking for `.git/config`
    has made a mistake worth telling it about -- so the next round can ask
    something answerable -- and a design is not abandoned because one request in
    five was out of bounds. What is *not* negotiable is that the refused request
    produced no content.
    """

    files: list[FileObservation] = Field(default_factory=list, max_length=MAXIMUM_READS)
    searches: list[SearchObservation] = Field(default_factory=list, max_length=MAXIMUM_SEARCHES)
    # One sentence per request that could not be honoured, in the planner's terms.
    refused: list[str] = Field(default_factory=list, max_length=MAXIMUM_READS + MAXIMUM_SEARCHES)


class InspectionContext(Contract):
    """An immutable, workspace-read observation set for one later plan request."""

    context_version: str = "inspection-context-v1"
    context_id: str = Field(default_factory=lambda: f"inspection-{uuid4().hex}",
                            pattern=r"^inspection-[0-9a-f]{32}$")
    session_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    plan_revision: int = Field(ge=0)
    request: InspectionRequest
    result: InspectionResult


class WorkspaceInspector(Protocol):
    """Who actually looks. Implemented by the layer permitted to read a tree.

    A protocol for the same reason `ModelGateway` is one: the planner reasons and
    the application performs, and the planner must not be able to reach a
    filesystem even by accident. It holds one of these and can do nothing with it
    but ask.
    """

    def inspect(self, request: InspectionRequest) -> InspectionResult:
        """Perform what is allowed, refuse the rest, and read nothing else."""
        ...


class InspectedFile(Contract):
    """A file a planner read, recorded without its contents.

    The bytes are not kept. What has to survive is that this file was looked at,
    which one it was, and what it held at the time -- and a digest says the last
    of those in 64 characters rather than 64 kilobytes. A record that stored
    every file a planner ever opened would be a second copy of the repository.
    """

    path: str = Field(pattern=READABLE_PATH_PATTERN)
    digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    bytes_read: int = Field(ge=0)
    truncated: bool = False
    # The planner's own reason for asking, kept because it is the question the
    # rest of this round was an answer to.
    because: str = Field(min_length=1, max_length=200)


class InspectionRound(Contract):
    """One round of looking, as it happened, for the record.

    This exists so that "why was this verifier chosen" has an answer other than
    the choice itself. `measurement.path = tools/verify.py` says what was picked
    and nothing about why; the chain

        searched "METRIC"  ->  two files matched
        read both          ->  one measures this task
        chose              ->  use_existing on that one

    is what a person needs months later, and it cannot be recovered from the
    plan alone.
    """

    files: list[InspectedFile] = Field(default_factory=list, max_length=MAXIMUM_READS)
    searches: list[SearchObservation] = Field(default_factory=list, max_length=MAXIMUM_SEARCHES)
    refused: list[str] = Field(default_factory=list, max_length=MAXIMUM_READS + MAXIMUM_SEARCHES)


def recorded(request: InspectionRequest, result: InspectionResult) -> InspectionRound:
    """What to keep from one round: what was asked, and what came back.

    Pairs each observation with the reason it was asked for. The two arrive
    separately -- a request and a result -- and separating them again in the
    record would leave a reader with a list of files and no questions.
    """
    why = {item.path: item.because for item in request.reads}
    return InspectionRound(
        files=[InspectedFile(
            path=item.path, digest=item.digest, bytes_read=item.bytes_read,
            truncated=item.truncated,
            because=why.get(item.path, "unrecorded"),
        ) for item in result.files],
        searches=list(result.searches),
        refused=list(result.refused),
    )
