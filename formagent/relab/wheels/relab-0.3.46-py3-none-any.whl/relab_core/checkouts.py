"""Checkouts an isolated attempt left behind, and whether removing one is safe.

A checkout holds no evidence -- that lives in the workspace stores -- so removing
one loses no record. What it can lose is the only remaining copy of what an
interrupted attempt was doing, which is why these are reported before anything
is removed, and why one that may still be in use is never removed at all.
"""

from datetime import datetime
from enum import Enum

from pydantic import Field

from relab_core.contracts import Contract


class CheckoutState(str, Enum):
    """Terminal first: an active checkout is never anything else."""

    ACTIVE = "active"
    RECOVERABLE = "recoverable"
    MANUAL = "manual"


class CheckoutRecord(Contract):
    """One checkout directory, and what it said about itself while it lived."""

    name: str = Field(min_length=1)
    path: str = Field(min_length=1)
    # Absent when the checkout was left by a version that recorded no owner, or
    # when the marker itself did not survive.
    owner_run_id: str | None = None
    session_id: str | None = None
    created_at: datetime | None = None


class CheckoutFinding(Contract):
    checkout: CheckoutRecord
    state: CheckoutState
    reason: str = Field(min_length=1)


class CheckoutReport(Contract):
    report_version: str = "checkout-report-v1"
    workspace: str = Field(min_length=1)
    findings: list[CheckoutFinding] = Field(default_factory=list)
    active: int = Field(default=0, ge=0)
    recoverable: int = Field(default=0, ge=0)
    manual: int = Field(default=0, ge=0)


class CheckoutCleanup(Contract):
    """What an explicit cleanup removed, and what it deliberately did not."""

    report_version: str = "checkout-cleanup-v1"
    workspace: str = Field(min_length=1)
    removed: list[str] = Field(default_factory=list)
    kept: list[CheckoutFinding] = Field(default_factory=list)
