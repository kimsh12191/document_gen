"""What happened, said so a person can read it.

This is a **projection**, not a reading. It rearranges what the records already
say into the shape a researcher looking at a stuck arm needs, and it adds
nothing: no cause, no recommendation, no model.

That boundary is the whole design:

    Explain     what happened                 a deterministic projection
    Interpret   what it means, what to try    research intelligence
    Application whether we may do it          policy, budget, a person

"The same pytest failure has occurred three times" is an account of the record.
"Use a bigger model" is a judgement about what to do, and it needs evidence of a
different kind. Putting the second in an explanation would let a recommendation
inherit the authority of a fact, which is exactly what this repository spends its
provenance machinery preventing.

So there is no `suggested_decision` field here, and there is nowhere to put one.
"""

from pydantic import Field, model_validator

from relab_core.contracts import Contract
from relab_core.memory import MAXIMUM_CITATIONS, EvidenceCitation
from relab_core.repair import MAXIMUM_ATTEMPTS, FailureFingerprint, RepairAttempt


class FailureExplanation(Contract):
    """Why an arm has no usable evidence, from the attempts it actually made."""

    explanation_version: str = "failure-explanation-v1"
    session_id: str = Field(min_length=1)
    arm: str = Field(min_length=1)
    # One line: what happened, in the words a person would use.
    summary: str = Field(min_length=1, max_length=2000)
    # What the most recent attempt failed with, when it reached a verifier at all.
    current_failure: FailureFingerprint | None = None
    # How many times that same failure has now occurred, this one included.
    repeat_count: int = Field(default=0, ge=0)
    # Whether repeating the present approach has stopped being a plan. Derived
    # from the count, never asserted separately, so the two cannot disagree.
    stuck: bool = False
    # Of the attempts that failed this same way, how many proposed the same edit.
    # Separate from `repeat_count` on purpose: failing alike from different edits
    # and failing alike from the same edit are different problems, and only the
    # second one means the model is repeating itself.
    repeated_edits: int = Field(default=0, ge=0)
    attempts: list[RepairAttempt] = Field(default_factory=list, max_length=MAXIMUM_ATTEMPTS)
    # Where to look. Every attempt is citable, so nothing here rests on a
    # sentence a reader has to take on trust.
    evidence: list[EvidenceCitation] = Field(default_factory=list, max_length=MAXIMUM_CITATIONS)

    @model_validator(mode="after")
    def explains_only_what_is_there(self) -> "FailureExplanation":
        if self.repeat_count > len(self.attempts):
            raise ValueError("a failure cannot have repeated more often than it was attempted")
        if self.current_failure is None and self.repeat_count:
            raise ValueError("a repeat count needs a failure it is counting")
        if self.stuck and self.current_failure is None:
            raise ValueError("being stuck is a fact about one repeated failure")
        if self.repeated_edits > self.repeat_count:
            raise ValueError("an edit cannot repeat more often than the failure it produced")
        if any(item.arm != self.arm for item in self.attempts):
            raise ValueError("an explanation covers the attempts of one arm")
        return self

    @property
    def explains_anything(self) -> bool:
        """Whether there is a failure here at all. An arm that never failed is not a story."""
        return bool(self.attempts)
