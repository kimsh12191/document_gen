"""Taking one of the actions an answer offered.

An answer says where a session stands and what may be done about it. This is the
request that does one of those things, and it carries the answer's own reading of
the session with it.

That pinning is the point. Between an answer being rendered and a person clicking
something in it, a worker may have recorded a result, another client may have
answered a gate, or the plan may have been revised. The action was offered for a
session that no longer exists in that state, so it is refused rather than applied
to one this answer never described. Every other execution boundary here already
works this way; a conversational surface is not an exception to it.

There is no field for what a person typed. Text reaches the application through
`ConversationInput`, where it selects nothing; an action is chosen from a closed
set, and that set is the only vocabulary this request has.
"""

from pydantic import Field, model_validator

from relab_core.contracts import Contract
from relab_core.conversation_response import ConversationAction
from relab_core.research import ResearchDecision


class ConversationActionRequest(Contract):
    """One offered action, pinned to the answer that offered it."""

    action: ConversationAction
    # Absent for the one action whose subject is not a session yet.
    session_id: str | None = Field(default=None, min_length=1)
    # Where the session stood when this was offered. Required whenever there is a
    # session, because an unpinned action is one nothing can be checked against.
    event_sequence: int | None = Field(default=None, ge=1)
    plan_revision: int | None = Field(default=None, ge=0)
    # The proposed design, for the one action whose subject nothing has recorded.
    # Sent back as the typed document, because a person may have edited it -- that
    # is what reading a proposal before accepting it is for.
    proposal: dict[str, object] | None = None
    # A judgement, for the actions that are one. Each action carries the judgement
    # its own decision needs and nothing else: approving a policy change and
    # concluding a study are not the same act, and a single "confirmed: bool"
    # standing for both would make them look like one.
    approved: bool | None = None
    # Which offered gate. The client points at one of the runs the answer listed;
    # the gate id the decision binds to is read from the records, so a client can
    # choose among what it was shown and cannot name a gate it invented.
    run_id: str | None = Field(default=None, min_length=1)
    # Which of the alternatives the answer listed. The id and nothing else: the
    # change it resolves to is read from the records, so a client can choose
    # among what it was shown and cannot describe a change it wants made.
    alternative_id: str | None = Field(default=None, min_length=1, max_length=200)
    # Who decided, when a surface knows. Recorded as given and never inferred.
    decided_by: str | None = Field(default=None, min_length=1, max_length=200)
    decision: ResearchDecision | None = None
    # Why. Required where the record requires it, which is the conclusion: a
    # terminal decision nobody explained is one nobody can argue with later.
    rationale: str | None = Field(default=None, min_length=1, max_length=4000)

    @model_validator(mode="after")
    def pinned_to_what_offered_it(self) -> "ConversationActionRequest":
        if (self.session_id is None) != (self.event_sequence is None):
            raise ValueError(
                "an action on a session is pinned to the answer that offered it, and "
                "an action on no session has nothing to pin to")
        accepting = self.action is ConversationAction.ACCEPT_PROPOSAL
        if accepting != (self.proposal is not None):
            raise ValueError("a proposal is accepted with the document that was proposed")
        if accepting and self.session_id is not None:
            # Accepting is the act that creates the session. One already existing
            # would mean this answer described something else entirely.
            raise ValueError("accepting a proposal is what creates the session")
        gating = self.action is ConversationAction.ANSWER_GATE
        answering = self.action is ConversationAction.ANSWER_AMENDMENT
        concluding = self.action is ConversationAction.CONCLUDE
        # Confirming a stop is a yes or a no like the other two, and unlike
        # concluding: what would be recorded is already on the answer, so the
        # judgement is whether to record it and not what to record.
        stopping = self.action is ConversationAction.CONFIRM_STOP
        # Choosing an alternative comes in two presses and says which it is:
        # unset asks to see the change, and a yes applies what was seen. Without
        # the first press a person would be approving something unread; without
        # the second, nothing a preview showed could ever be taken.
        selecting = self.action is ConversationAction.SELECT_ALTERNATIVE
        if selecting:
            pass
        elif (answering or gating or stopping) != (self.approved is not None):
            raise ValueError(
                "answering an amendment or a gate, or confirming a stop, is saying "
                "yes or no to it")
        if stopping and self.decision is not None:
            # The decision confirmed here comes from the records. A client able
            # to send one would be a client deciding how a session ended, which
            # is the door `ProposedConclusion` closes at the other end.
            raise ValueError(
                "confirming a stop confirms the decision on the answer, not one sent with it")
        if gating != (self.run_id is not None):
            raise ValueError("answering a gate is answering the gate of one run")
        if concluding != (self.decision is not None):
            raise ValueError("concluding a session is recording which decision")
        if concluding and not self.rationale:
            # The service requires one anyway; refusing here means a person is
            # asked for it before a call is spent finding out.
            raise ValueError("a research conclusion requires a rationale")
        if self.rationale is not None and not (answering or concluding):
            raise ValueError("only a judgement carries a rationale")
        if self.decided_by is not None and not gating:
            raise ValueError("only a gate decision records who took it")
        choosing = self.action is ConversationAction.SELECT_ALTERNATIVE
        if choosing != (self.alternative_id is not None):
            raise ValueError("choosing an alternative is naming which one")
        return self
