"""What a file held before an attempt wrote to it, and what it held after.

A recorded unified diff says what changed. It does not say what the file *was*:
context lines are a few lines around each hunk, chosen to make the patch apply,
and a diff with no context at all is still a valid diff. So a surface wanting a
before/after comparison had two choices, and both were wrong.

Reading the workspace now and calling it the base is the worse one. A reverted
attempt left nothing behind, a later attempt overwrote it, and a person opening
a two-pane view a week afterwards would be shown today's file labelled as the
historical original. Reversing the diff against the current file is the same
mistake with extra steps: it needs the after-image, which only exists while the
patch stands, and it fails silently in exactly the cases somebody most wants to
look.

So the content is kept, at the moment it was true, and addressed by its own
digest.

## Why content-addressed

`PatchProposal.base_hashes` already records what each file hashed to before the
patch, and `validate_patch` already refuses a patch whose declared bases do not
match the tree. Storing the bytes under that same digest makes the record
self-verifying: a snapshot that does not hash to the name it is filed under is
not the snapshot, and nobody has to be trusted to have kept them in order. Two
arms reading the same unchanged file store it once.

## What is not kept

A snapshot is bounded, and a file over the bound is recorded as having been too
large rather than kept in part. Half a file shown in a diff pane is a worse
thing than a stated absence: the absence is read as an absence, and the half is
read as the file. The same goes for anything that is not text -- a diff editor
has nothing to show for it, and keeping bytes for a view that cannot render
them is storage spent on a worse answer.

In every one of those cases the *digests* still stand. What was given up is the
content, never the identity: the record still says which file, and which two
states of it, and that they differed.
"""

from enum import Enum

from pydantic import Field

from relab_core.contracts import Contract

# Per side, per file. A generated change is bounded well under this -- the
# whole selection an attempt may edit is 64 KiB combined -- so this is the
# bound for the patches nobody generated: a resumed dependency change, or a
# proposal a caller built itself.
MAXIMUM_SNAPSHOT_BYTES = 262144
# And for one patch, across every file and both sides of each. An attempt that
# rewrote a megabyte of text has more to say than a two-pane view is the place
# to say it in.
MAXIMUM_SNAPSHOT_TOTAL = 1048576


class SnapshotOmission(str, Enum):
    """Why a file's content was not kept, when it was not.

    Said rather than inferred from a missing blob. "There is nothing stored for
    this" and "this was too big to store" are different findings, and a surface
    that had to guess between them would tell somebody their record was
    incomplete when it was complete and bounded.
    """

    # Over the bound, on one side or across the patch. Better than a part of it.
    TOO_LARGE = "too_large"
    # Not text, so a comparison has nothing to show and the bytes buy nothing.
    NOT_TEXT = "not_text"
    # The tree would not give it up at the moment it was asked for.
    UNREADABLE = "unreadable"


class FileSnapshot(Contract):
    """One file's two states, as they were when the patch was applied to it.

    Both digests absent is not a case this records: a file the patch did not
    touch has no snapshot at all. `before_digest` absent means the attempt
    created the file, and the pair being equal means the patch wrote the bytes
    that were already there.
    """

    snapshot_version: str = "file-snapshot-v1"
    path: str = Field(min_length=1)
    # Absent when the file did not exist before this patch was applied.
    before_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    # Absent when the patch left nothing there.
    after_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    # Why the bytes behind those digests are not in the store. None means they
    # are -- for both sides that have a digest at all.
    omitted: SnapshotOmission | None = None

    @property
    def readable(self) -> bool:
        """Whether a before/after comparison can be shown from this record."""
        return self.omitted is None and (
            self.before_digest is not None or self.after_digest is not None)


class RecordedContent(Contract):
    """One side of one file, read back from the record rather than the tree."""

    content_version: str = "recorded-content-v1"
    run_id: str = Field(min_length=1)
    path: str = Field(min_length=1)
    side: str = Field(pattern=r"^(before|after)$")
    # Whether the file was there at all on this side. False with empty content
    # is a file that did not exist; True with empty content is an empty file,
    # and a comparison that blurred the two would invent a deletion.
    existed: bool
    content: str
