"""What a run executed under; recorded so repeats can be compared, not assumed."""

from pydantic import Field

from relab_core.contracts import Contract

SHA256_PATTERN = r"^[0-9a-f]{64}$"
REVISION_PATTERN = r"^[0-9a-f]{7,64}$"
MAXIMUM_DATA_PATHS = 16


class RunConditions(Contract):
    schema_version: str = "run-conditions-v1"
    # The interpreter and platform that orchestrated the run, which is not
    # necessarily the one the verifier command itself ran under.
    python_version: str = Field(min_length=1, max_length=64)
    platform: str = Field(min_length=1, max_length=128)
    # Absent when the workspace is not a Git repository or Git is unavailable.
    code_revision: str | None = Field(default=None, pattern=REVISION_PATTERN)
    code_dirty: bool | None = None
    # Digests of the files the caller declared as identifying its data.
    data_digests: dict[str, str] = Field(default_factory=dict)
    # Whether the declared data was digested again when the attempt ended. False on
    # records written before this existed, which is why it is kept apart from the
    # result: "not checked" and "checked and unchanged" must not read alike.
    data_rechecked: bool = False
    # Declared paths whose content no longer matched by then. A run listed here did
    # not necessarily read the wrong data -- it means the record cannot say it read
    # the right data, which for evidence is the same problem.
    data_changed: list[str] = Field(default_factory=list)
    # The held-out data, digested apart from the selection data because the question
    # about it is different: not "did both runs read the same", but "did this run get
    # to write its own answer sheet".
    holdout_data_digests: dict[str, str] = Field(default_factory=dict)
    holdout_data_changed: list[str] = Field(default_factory=list)
    # The state of the files this attempt is about to edit; None means absent.
    target_digests: dict[str, str | None] = Field(default_factory=dict)
    # The command that produced this run's evidence. Recorded as a condition because
    # numbers measured by different commands are not the same measurement, however
    # alike they look. Empty on records written before this existed.
    verification_argv: list[str] = Field(default_factory=list)
    # The sandbox the verifier ran under; "local_process" unless Docker was declared.
    sandbox_backend: str = Field(default="local_process", min_length=1, max_length=32)
    docker_image: str | None = Field(default=None, min_length=1, max_length=256)


class ConditionsComparison(Contract):
    """What the compared runs shared, and what they did not."""

    report_version: str = "conditions-comparison-v1"
    scope: str = Field(min_length=1)
    run_ids: list[str] = Field(default_factory=list)
    comparable: bool
    reasons: list[str] = Field(default_factory=list)
    missing_run_ids: list[str] = Field(default_factory=list)
    # Reported, never required to agree: arms differ in code by design.
    dirty_run_ids: list[str] = Field(default_factory=list)
    code_revisions: list[str] = Field(default_factory=list)
    # Runs whose declared data changed while they ran; their own conditions are
    # unknown, so this is never merely a disagreement between runs.
    changed_data_run_ids: list[str] = Field(default_factory=list)
