"""How a coding loop's work stands when it ends: the task, and what verified it (0.3.0).

`LoopOutcome.FINISHED` keeps its meaning -- the model said it was done -- and
is not a verdict. Whether the task is done and whether it was verified are
recorded here, apart from how the loop ended, so a card, a benchmark, a
lesson or a follow-up reads the verdict rather than the model's word.

Three records:

- `CheckFinding`: one check's result on the work as it stands -- PASS, FAIL,
  UNKNOWN or NOT_APPLICABLE -- and its effect: BLOCK for a condition the work
  must meet, ADVISE for a quality note that never holds finishing back alone.
- `VerificationEvidence`: one run that verified something -- which command,
  where, on which revision of the files, how it ended -- made by ReLab from
  what it ran, never by the model.
- `CompletionAssessment`: the task's status and the verification's, from the
  findings, with the revision they were judged on and why the loop stopped.

A record from before these existed has no assessment: read as unknown, never
promoted to passed or failed.
"""

from datetime import datetime
from enum import Enum
from typing import Literal

from pydantic import Field, model_validator

from relab_core.contracts import Contract

COMPLETION_SCHEMA = "completion-v1"
# How many more finishes a request revision gets after its first is held back:
# the work is repaired and finished again at most this many times (R02).
FINISH_REPAIRS = 2


class TaskStatus(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    BLOCKED = "blocked"
    UNKNOWN = "unknown"


class VerificationStatus(str, Enum):
    PASSED = "passed"
    FAILED = "failed"
    NOT_RUN = "not_run"
    INCONCLUSIVE = "inconclusive"
    NOT_APPLICABLE = "not_applicable"
    UNKNOWN = "unknown"


class FindingResult(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    UNKNOWN = "unknown"
    NOT_APPLICABLE = "not_applicable"


class FindingEffect(str, Enum):
    # A condition the work must meet: unmet or unknown, the task is not complete.
    BLOCK = "block"
    # A quality note: recorded and shown, never holding finishing back alone.
    ADVISE = "advise"


# Where a check's findings count: the task's conditions, or verifying the code.
VERIFICATION = "verification"


class CheckFinding(Contract):
    """One check's result on the work as it stands."""

    check_id: str = Field(min_length=1, max_length=120)
    requirement_id: str | None = Field(default=None, max_length=120)
    result: FindingResult
    effect: FindingEffect
    evidence_refs: list[str] = Field(default_factory=list, max_length=20)
    scope: str | None = Field(default=None, max_length=300)
    reason_code: str = Field(min_length=1, max_length=80)
    said: str = Field(default="", max_length=4000)

    @property
    def verifies(self) -> bool:
        """Whether this finding is about verifying the code rather than the task's conditions."""
        return self.check_id.startswith(f"{VERIFICATION}:")


class VerificationEvidence(Contract):
    """One run that verified something, recorded by ReLab from what it ran."""

    evidence_id: str = Field(pattern=r"^ev-[0-9a-f]{12}$")
    check_id: str = Field(min_length=1, max_length=120)
    source_step: int | None = Field(default=None, ge=1)
    source_job: str | None = Field(default=None, max_length=64)
    # Where the check came from: the project's own, the person's, the request's
    # acceptance, or a run the model chose to verify with.
    origin: Literal["project", "person", "acceptance", "model"]
    command: list[str] = Field(default_factory=list, max_length=64)
    cwd: str = Field(default=".", max_length=300)
    scope: str | None = Field(default=None, max_length=300)
    input_revision: str = Field(min_length=1, max_length=80)
    exit_code: int | None = None
    state: Literal["completed", "timed_out", "failed_to_start", "running"]
    verdict: FindingResult
    summary: str = Field(default="", max_length=600)
    # What the check was (EVI-07, 0.3.6): one that only reads the code's shape (static),
    # one that ran the code with stand-ins for what it calls (mock), or one that ran it
    # as it is (real) -- and whether what it ran calls a model or a service, with no
    # stand-in on the way. None where it was not told (records from before).
    kind: Literal["real", "mock", "static"] = "real"
    service: bool | None = None
    # For a script run as a check (F5, 0.3.14): the workspace's files it runs -- itself,
    # the project's modules it imports, the files it names. Its pass is of those, not of
    # the rest. None for other checks, and for records from before.
    runs: list[str] | None = Field(default=None, max_length=200)
    started_at: datetime
    finished_at: datetime | None = None


class CompletionAssessment(Contract):
    """The task's status and the verification's, judged on one revision of the work."""

    schema_version: Literal["completion-v1"] = "completion-v1"
    task_status: TaskStatus
    verification_status: VerificationStatus
    requirements_revision: int = Field(ge=0)
    evaluated_revision: str = Field(min_length=1, max_length=80)
    findings: list[CheckFinding] = Field(default_factory=list, max_length=60)
    evidence_ids: list[str] = Field(default_factory=list, max_length=60)
    # Why the loop stopped where it did: finished, repairs used up, blocked, stopped...
    stop_reason: str | None = Field(default=None, max_length=80)
    # Why verification does not apply, when it does not: a policy reason, never
    # "no check was found" or "the check could not run".
    not_applicable_reason: str | None = Field(default=None, max_length=200)
    assessed_at: datetime

    @model_validator(mode="after")
    def consistent(self) -> "CompletionAssessment":
        blocking = [item for item in self.findings
                    if item.effect is FindingEffect.BLOCK and not item.verifies]
        if self.task_status is TaskStatus.COMPLETE and any(
                item.result in (FindingResult.FAIL, FindingResult.UNKNOWN) for item in blocking):
            raise ValueError("a task with an unmet or unknown condition is not complete")
        if self.verification_status is VerificationStatus.PASSED and any(
                item.verifies and item.result in (FindingResult.FAIL, FindingResult.UNKNOWN)
                for item in self.findings):
            raise ValueError("verification with a failed or unknown check has not passed")
        if self.verification_status is VerificationStatus.NOT_APPLICABLE and not self.not_applicable_reason:
            raise ValueError("verification that does not apply says why")
        return self

    @property
    def advice(self) -> list[CheckFinding]:
        """The quality notes left: shown with the result, holding nothing back."""
        return [item for item in self.findings
                if item.effect is FindingEffect.ADVISE and item.result is not FindingResult.PASS]

    @property
    def succeeded(self) -> bool:
        """Whether this counts as a success where successes are counted."""
        return (self.task_status is TaskStatus.COMPLETE
                and self.verification_status in (VerificationStatus.PASSED, VerificationStatus.NOT_APPLICABLE))


def judged(findings: list[CheckFinding], *, code_changed: bool,
           not_applicable_reason: str | None = None) -> tuple[TaskStatus, VerificationStatus]:
    """The task's status and the verification's from what the checks found.

    A condition (BLOCK) that failed leaves the task partial, one unknown leaves
    it unknown; advice changes neither. Verification passes on passing checks
    with none failed or unknown; with none at all it has not run when code
    changed, and does not apply only for the reason given (no code changed).
    """
    blocking = [item for item in findings if item.effect is FindingEffect.BLOCK and not item.verifies]
    if any(item.result is FindingResult.FAIL for item in blocking):
        task = TaskStatus.PARTIAL
    elif any(item.result is FindingResult.UNKNOWN for item in blocking):
        task = TaskStatus.UNKNOWN
    else:
        task = TaskStatus.COMPLETE
    checks = [item for item in findings if item.verifies and item.result is not FindingResult.NOT_APPLICABLE]
    if any(item.result is FindingResult.FAIL for item in checks):
        verification = VerificationStatus.FAILED
    elif any(item.result is FindingResult.UNKNOWN for item in checks):
        verification = VerificationStatus.INCONCLUSIVE
    elif checks:
        verification = VerificationStatus.PASSED
    elif code_changed or not_applicable_reason is None:
        verification = VerificationStatus.NOT_RUN
    else:
        verification = VerificationStatus.NOT_APPLICABLE
    return task, verification
