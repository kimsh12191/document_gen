"""Research session records; grouping evidence does not execute research."""

import hashlib
from datetime import datetime
from enum import Enum

from pydantic import Field, field_validator, model_validator

from relab_core.calibration import MAXIMUM_CONTROL_RUNS, MeasurementControlRun
from relab_core.coding.patch import VerificationResult
from relab_core.contracts import Contract
from relab_core.controls import (
    MAXIMUM_CONTROLS,
    MeasurementControl,
    controls_named_once,
)
from relab_core.evaluation import (
    CodingEvaluation,
    DecisionSupport,
    MetricComparison,
    MetricRegistry,
    RepeatabilityReport,
)
from relab_core.evidence import StudyOrigin
from relab_core.generation import ModelIdentity
from relab_core.inspection import InspectionRound
from relab_core.measurement import (
    MAXIMUM_REQUIREMENTS,
    MeasurementClaimObservation,
    MeasurementKind,
    MeasurementReading,
    MeasurementRequirement,
    MeasurementSetup,
    MeasurementSnapshot,
    built_by_relab,
    local_files,
    requirements_named_once,
)
from relab_core.provenance import MAXIMUM_DATA_PATHS, ConditionsComparison
from relab_core.routing import ModelInvocationProvenance, ModelRoutingPolicy
from relab_core.targets import EditTarget, TargetOperation


class CodingRunReference(Contract):
    run_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    # References pinned before arms existed, and runs outside the design, stay readable.
    role: str | None = None
    # Identity of the arm task this run was an attempt at. Absent on references
    # pinned before this existed; those are read as attempts at whatever the plan
    # declares now, which is a reading rule for old records rather than a claim
    # about them. See `attempt_stands`.
    task_digest: str | None = Field(default=None, min_length=8, max_length=64)


class ArmTask(Contract):
    """The coding objective a declared arm's runs are requested and executed with."""

    arm: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    # Empty means the arm is requestable but not executable by the session.
    #
    # Typed rather than a bare path, so what an arm means to do to a file is part
    # of the recorded plan and not something execution works out from whether the
    # file happens to be there. A plan recorded before this existed names paths as
    # strings, and those are read as edits -- which is what they were, and which
    # is a reading rule for old records rather than an inference about intent.
    targets: list[EditTarget] = Field(default_factory=list, max_length=8)

    @field_validator("targets", mode="before")
    @classmethod
    def read_recorded_paths(cls, value: object) -> object:
        if not isinstance(value, list):
            return value
        return [
            {"path": item, "operation": TargetOperation.EDIT.value}
            if isinstance(item, str) else item
            for item in value
        ]
    verify_argv: list[str] = Field(default_factory=list)
    # A second command measuring held-out data; its output never feeds selection.
    holdout_argv: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def executable_intent(self) -> "ArmTask":
        # A target validates its own path, so what is left is the relationship
        # between them: the same file named twice in one arm is two writes with
        # no defined order, whatever each of them claims to be doing.
        named = [target.path for target in self.targets]
        if len({path.casefold() for path in named}) != len(named):
            raise ValueError("arm targets must be distinct (case-insensitive)")
        if any(not item for item in self.verify_argv):
            raise ValueError("an arm verification argument must not be blank")
        if bool(self.targets) != bool(self.verify_argv):
            raise ValueError("an executable arm task needs both targets and verify_argv")
        if any(not item for item in self.holdout_argv):
            raise ValueError("a holdout measurement argument must not be blank")
        if self.holdout_argv and not self.verify_argv:
            raise ValueError("a holdout measurement needs an executable arm task")
        return self



def task_digest(task: ArmTask) -> str:
    """Identity of what an arm was asked to do, up to how it was written down.

    Short, because it is only ever compared. Two tasks differing anywhere --
    objective, targets, or the command that measures them -- are different tasks,
    and nothing here decides which of those differences matters; that is the
    caller's question.
    """
    return hashlib.sha256(task.model_dump_json().encode()).hexdigest()[:16]


class DesignProvenance(Contract):
    """Where a recorded policy came from, when it was proposed rather than written.

    Kept in plain terms so this package need know nothing about planners: it
    records what was asked, what was reasoned over and who proposed it, which is
    what "why is the policy this" needs an answer from later. A plan written by
    hand has none of this, and says so by leaving it unset.
    """

    intent: str = Field(min_length=1, max_length=4000)
    rationale: str = Field(min_length=1, max_length=4000)
    assumptions: list[str] = Field(default_factory=list, max_length=16)
    # What the proposer was shown. Without it, "why this design" is answerable
    # only while the workspace still looks the way it did.
    known_session_ids: list[str] = Field(default_factory=list, max_length=64)
    candidate_paths: list[str] = Field(default_factory=list, max_length=64)
    # The implementation plan the design carried, as a person read it: each
    # planned file and its purpose, the steps in order, and the risks. It does
    # not execute. Absent from designs proposed before it existed.
    layout: list[str] = Field(default_factory=list, max_length=32)
    steps: list[str] = Field(default_factory=list, max_length=16)
    risks: list[str] = Field(default_factory=list, max_length=8)
    # The model that proposed it, when one did.
    proposed_by: ModelIdentity | None = None
    # What was looked at before this design existed, in the order it was looked
    # at. Without it "why this verifier" is answerable only by the choice itself,
    # which says what was picked and nothing about why.
    inspected: list[InspectionRound] = Field(default_factory=list, max_length=4)


class ResearchPlan(Contract):
    """Evaluation policy pre-registered before evidence is judged against it."""

    plan_version: str = "research-plan-v1"
    registry: MetricRegistry
    # 0 is the originally recorded policy; each explicit amendment increments it.
    revision: int = Field(default=0, strict=True, ge=0, le=100)
    # An empty arm list means no experiment design was declared, not one unnamed arm.
    arms: list[str] = Field(default_factory=list, max_length=8)
    repeats_per_arm: int = Field(default=1, strict=True, ge=1, le=100)
    candidate_arm: str | None = None
    baseline_arm: str | None = None
    # Requesting runs for an arm needs its objective declared up front.
    arm_tasks: list[ArmTask] = Field(default_factory=list, max_length=8)
    # The ruler, owned by the plan rather than by any arm. Absent on plans
    # recorded before measurement had an owner, which is why it is optional: an
    # experiment whose verifier already sat in the workspace still reads back.
    measurement: MeasurementSetup | None = None
    # What the study asks that measurement to check, beside the instrument and
    # deliberately not inside it. Absent on every plan recorded before this
    # existed, and absent is not empty: a plan that declared nothing has no
    # contract to be judged against, which is a different finding from a plan
    # whose verifier checks none of what it was asked to.
    measurement_requirements: list[MeasurementRequirement] | None = Field(
        default=None, max_length=MAXIMUM_REQUIREMENTS)
    # How the study proposes to find out whether that measurement can tell a
    # broken implementation from a working one. Beside the requirements and
    # beside the instrument, and part of neither: a control is a design for
    # testing a ruler, so changing one changes what sensitivity has been shown
    # and retires no reading.
    measurement_controls: list[MeasurementControl] | None = Field(
        default=None, max_length=MAXIMUM_CONTROLS)
    # Declaring these makes evidence from another model unusable, not merely noted.
    # Files that identify this study's data; digested into every run's conditions.
    data_paths: list[str] = Field(default_factory=list, max_length=MAXIMUM_DATA_PATHS)
    # Files the holdout measurement reads. Declared separately so the data, and not
    # only the rules and the command, is what is held out.
    holdout_data_paths: list[str] = Field(default_factory=list, max_length=MAXIMUM_DATA_PATHS)
    # Unset on a policy someone wrote; set on one that was proposed and accepted.
    provenance: DesignProvenance | None = None
    # When declared, evidence from runs that did not share conditions cannot pass.
    require_comparable_conditions: bool = False
    # Rules deliberately kept out of selection; see the holdout evaluation.
    holdout_registry: MetricRegistry | None = None
    # Undo each verified attempt so the next one starts where it did.
    restore_between_attempts: bool = False
    # Run each attempt in its own checkout of one revision, touching no shared tree.
    isolate_attempts: bool = False
    # How many provider calls an arm may lose before ReLab stops trying.
    #
    # A separate budget from `repeats_per_arm`, because the two count different
    # things. `repeats_per_arm` is a research quantity: run this arm to a
    # measurable state that many times and look at the spread. This is an
    # operational one: a provider having a bad afternoon does not get unbounded
    # retries just because its failures produced no evidence.
    #
    # Both are recorded, so afterwards "how many times was this arm measured" and
    # "how many provider calls did that take" have separate answers.
    max_transport_failures_per_arm: int = Field(default=2, strict=True, ge=0, le=10)
    # How many times the model may answer without proposing anything -- declining
    # the work, or reaching for a tool this gateway does not offer.
    #
    # Its own budget rather than the transport one, because the two mean
    # different things about the design. A provider dropping connections says
    # nothing about the experiment; a model that keeps declining the task is
    # telling you something about the task, and a person should see that rather
    # than watch it retry.
    max_generation_failures_per_arm: int = Field(default=2, strict=True, ge=0, le=10)
    # Where a verifier runs; only Docker can actually deny it a network.
    sandbox_backend: str | None = Field(default=None, pattern=r"^(local_process|docker)$")
    docker_image: str | None = Field(default=None, min_length=1, max_length=256)
    expected_model: ModelIdentity | None = None
    expected_reported_model: str | None = Field(default=None, min_length=1, max_length=256)

    def admission_findings(self) -> list[str]:
        """What this design breaks among the rules a new design must meet.

        Kept out of the validators on purpose. A validator runs every time a
        record is read, so a rule added there makes every study recorded before
        it unreadable -- which is what happened to the second live pilot the day
        its rule arrived. A design approved under older rules is still a design
        that was approved, and the record has to go on saying so; what changes
        is that it can now be diagnosed as one the current rules would refuse.
        So these are refused where a design is admitted (`ResearchSessionService`
        recording or revising a plan, a proposal being accepted) and only
        reported everywhere else.

        First, a control replaces the file the verifier measures, so
        its subject has to be a path some arm targets: a live planner put both
        subjects of each control at `controls/ctrl_add.py`, the verifier
        measured `calculator.py`, and calibration died on a missing file four
        times. Checked on the plan, since a control cannot see the arms. Narrow
        on purpose: the subject is a path this design measures, not a path the
        verifier measures well -- that is calibration's question.
        """
        measured = {target.path.casefold()
                    for task in self.arm_tasks for target in task.targets}
        findings = [
            f"measurement control {control.control_id} targets "
            f"{control.good_subject.path}, which is not an arm target measured by "
            f"this design"
            for control in self.measurement_controls or []
            if control.good_subject.path.casefold() not in measured
        ]
        # A second: a Python subject has to be Python. A live design's good and
        # broken subjects were both one line of escaped text; neither imported,
        # both measured 0.0, and calibration reported a ruler unable to tell
        # them apart when it had never seen either. Compiled, never run.
        for control in self.measurement_controls or []:
            for which, subject in (("good", control.good_subject),
                                   ("broken", control.bad_subject)):
                if not subject.path.endswith(".py"):
                    continue
                try:
                    compile(subject.content, subject.path, "exec")
                except SyntaxError as error:
                    findings.append(
                        f"measurement control {control.control_id}'s {which} subject "
                        f"is not valid Python ({error.msg}, line {error.lineno}), so "
                        f"calibrating with it would measure an import failure")
        return findings

    def asks_verifier_to_declare(self) -> bool:
        """Whether this design's verifier was built under the claim contract.

        True when ReLab creates the verifier and the study declares
        requirements -- the two conditions under which it is told to write its
        claim before touching anything under test. A verifier adopted as it
        stands was asked nothing, so its silence cannot mean it never started.
        """
        if self.measurement is None or not self.measurement_requirements:
            return False
        return any(item.kind is MeasurementKind.VERIFIER and built_by_relab(item)
                   for item in self.measurement.artifacts)

    def creates_files(self) -> bool:
        """Whether any arm writes a file that was not there when the plan was made."""
        return any(target.operation is TargetOperation.CREATE
                   for task in self.arm_tasks for target in task.targets)

    def must_isolate(self, dispatches: int) -> bool:
        """Whether attempts need checkouts of their own, given how many will run.

        A created file that passes verification stays in the workspace. The next
        thing to run was told to *create* that file, finds it already there, and
        is refused -- correctly, because overwriting it is not what was agreed.
        So a plan that creates files cannot be attempted twice in one tree: not a
        second repeat, and not a second arm.

        This is derived rather than declared, in the way materialising the
        measurement is performed rather than asked about. `isolate_attempts` is
        still what the plan *said*; this is a mechanical precondition of what it
        said, and deriving it keeps the natural greenfield design -- two arms
        creating one file, three repeats each -- from being illegal.

        Nothing is derived for a single dispatch, which has nothing to collide
        with, so a plan that creates one file once still runs in the workspace
        and leaves the file there.
        """
        return dispatches > 1 and self.creates_files()

    def _measurement_is_nobody_arm(self) -> None:
        """Nothing an arm can change may decide whether that arm passed.

        Two checks, both mechanical. An arm may not target a measurement
        artifact, and a verifier that lives in the workspace must be one -- which
        is what makes `targets=["candidate.py"]` measured by
        `["python", "candidate.py"]` a refusal rather than a design nobody looked
        at twice.
        """
        if self.measurement is None:
            return
        owned = self.measurement.paths
        # Asked first: a command running a file nobody owns is wrong however the
        # arms are shaped, and saying so beats a message about one arm.
        undeclared = local_files(self.measurement.verify_argv) - owned
        if undeclared:
            raise ValueError(
                "the verification command runs files the measurement does not own: "
                f"{', '.join(sorted(undeclared))}")
        for task in self.arm_tasks:
            clash = owned & {target.path for target in task.targets}
            if clash:
                raise ValueError(
                    f"arm {task.arm!r} would change what measures it: "
                    f"{', '.join(sorted(clash))}")
            if task.verify_argv and list(task.verify_argv) != list(
                    self.measurement.verify_argv):
                # One ruler. An arm measured by its own command is not being
                # compared with the others, whatever the numbers look like.
                raise ValueError(
                    f"arm {task.arm!r} declares its own verification command; "
                    f"the measurement owns it")

    @model_validator(mode="after")
    def consistent_design(self) -> "ResearchPlan":
        requirements_named_once(self.measurement_requirements)
        controls_named_once(self.measurement_controls)
        asked_for = {item.requirement_id for item in self.measurement_requirements or []}
        aimless = sorted({item.requirement_id for item in self.measurement_controls or []}
                         - asked_for)
        if aimless:
            # A control calibrates the ruler *for a requirement*. One aimed at
            # something the design never declared could be demonstrated and
            # still say nothing about whether this study can be measured.
            raise ValueError(
                "a measurement control names a requirement this design does not "
                f"declare: {', '.join(aimless)}")
        if any(not arm.strip() for arm in self.arms):
            raise ValueError("experiment arm names must not be blank")
        if len(self.arms) != len(set(self.arms)):
            raise ValueError("experiment arm names must be unique")
        designated = [self.candidate_arm, self.baseline_arm]
        if any(arm is not None and arm not in self.arms for arm in designated):
            raise ValueError("a designated comparison arm must also be declared")
        if (self.candidate_arm is None) != (self.baseline_arm is None):
            raise ValueError("a designated comparison requires both candidate and baseline arms")
        if self.candidate_arm is not None and self.candidate_arm == self.baseline_arm:
            raise ValueError("candidate and baseline arms must differ")
        if (self.docker_image is not None) != (self.sandbox_backend == "docker"):
            raise ValueError("a Docker sandbox needs an image, and an image needs Docker")
        if self.holdout_registry is not None:
            selected = {rule.name for rule in self.registry.rules}
            held = {rule.name for rule in self.holdout_registry.rules}
            if selected & held:
                raise ValueError(
                    "a holdout metric must not also drive selection: "
                    f"{', '.join(sorted(selected & held))}"
                )
        self._measurement_is_nobody_arm()
        if len(self.holdout_data_paths) != len({p.casefold() for p in self.holdout_data_paths}):
            raise ValueError("declared holdout data paths must be distinct (case-insensitive)")
        shared = ({p.casefold() for p in self.holdout_data_paths}
                  & {p.casefold() for p in self.data_paths})
        if shared:
            # Data read by both is not held out from anything, whatever the rules say.
            raise ValueError(
                "held-out data must not also be declared as selection data: "
                f"{', '.join(sorted(shared))}"
            )
        if self.holdout_data_paths and not any(task.holdout_argv for task in self.arm_tasks):
            raise ValueError(
                "declaring held-out data needs an arm task that measures it")
        if self.expected_reported_model is not None and self.expected_model is None:
            raise ValueError("a declared reported model needs a declared model identity")
        declared = [task.arm for task in self.arm_tasks]
        if any(arm not in self.arms for arm in declared):
            raise ValueError("an arm task must name a declared arm")
        if len(declared) != len(set(declared)):
            raise ValueError("each arm declares at most one task objective")
        return self



def admitted(plan: ResearchPlan) -> ResearchPlan:
    """The plan, if a new design may be recorded as it stands; refused otherwise."""
    findings = plan.admission_findings()
    if findings:
        raise ValueError("; ".join(findings))
    return plan


def task_stands(plan: ResearchPlan, reference: CodingRunReference) -> bool:
    """Whether this run was an attempt at the task the plan declares now.

    An arm gets a bounded number of attempts, and a stuck arm reaches that
    ceiling getting stuck. Revising its task and leaving the count alone would
    record a new instruction that nothing could ever carry out; counting the old
    runs toward coverage would be worse, because the arm would be satisfied by
    evidence about a task the plan no longer asks for.

    So the budget means attempts *at this task*, and a run attached under one
    since revised stands outside it. It is not deleted, detached or hidden -- it
    stays in the record, and what happened to it stays readable. It stops being
    an answer to a question that has changed.

    A reference with no digest predates this and stands: old records are read as
    attempts at whatever the plan declares, which is what they were.
    """
    if reference.task_digest is None or reference.role is None:
        return True
    declared = next((item for item in plan.arm_tasks if item.arm == reference.role), None)
    return declared is None or task_digest(declared) == reference.task_digest


def measurement_stands(
    snapshot: MeasurementSnapshot | None, verification: "VerificationResult | None",
) -> bool:
    """Whether this reading was taken under the ruler now in force.

    Asked of the verification rather than of the run's reference, because this
    is a fact about a measurement and not about an attempt. A run is attached
    before it is measured -- sometimes before the measurement exists at all --
    so a reference cannot say which instrument read it, and a run with no
    reading yet has no instrument to disagree with.

        no verification yet        stands; it has not been measured
        read under this ruler      stands
        read under an older one    does not stand
        read under no identity     stands only where the ruler has none either

    That last line is the one worth being careful about. A reading taken before
    identities existed is *legacy*, not universal: treating its absence as a
    wildcard would let a study replace its instrument and carry the old
    measurements forward under the new one, which is the entire thing identity
    is here to prevent.

    Nothing is deleted by a `False` here. The run, its patch and its verifier
    output stay exactly as recorded; what changes is that they are no longer
    readings under the ruler this study is being decided by.
    """
    if verification is None:
        return True
    measured_under = verification.measurement_snapshot_id
    if measured_under is None:
        return snapshot is None or snapshot.snapshot_id is None
    # A reading under an identity, and no ruler in force to match it against.
    # Unreachable while a frozen measurement is never removed, and refused
    # rather than assumed: evidence from an instrument the study no longer has
    # is not evidence for the study it has now.
    return snapshot is not None and measured_under == snapshot.snapshot_id


def attempt_stands(
    session: "ResearchSession", reference: CodingRunReference,
    verification: "VerificationResult | None",
) -> bool:
    """Whether this run still answers the question the study is asking now.

    Two identities, and both have to hold. The task says what the arm was told
    to do; the measurement says what read the result. A study can change either
    one, and a run that survives the first change can be retired by the second
    -- the same code, measured by an instrument the study has replaced.

    It takes the session rather than the plan because the ruler is the
    session's: the planner runs before a plan exists, and the measurement is
    frozen after one does.
    """
    plan = session.plan
    if plan is not None and not task_stands(plan, reference):
        return False
    return measurement_stands(session.measurement_snapshot, verification)


class ProposedAmendment(Contract):
    """A change to a pre-registered policy, before anyone has agreed to it."""

    amendment_version: str = "proposed-amendment-v1"
    rationale: str = Field(min_length=1, max_length=4000)
    # Only the fields being changed are set; everything unset stays as recorded.
    registry: MetricRegistry | None = None
    holdout_registry: MetricRegistry | None = None
    arms: list[str] | None = Field(default=None, min_length=1, max_length=8)
    repeats_per_arm: int | None = Field(default=None, strict=True, ge=1, le=100)
    candidate_arm: str | None = Field(default=None, min_length=1)
    baseline_arm: str | None = Field(default=None, min_length=1)
    arm_tasks: list[ArmTask] | None = Field(default=None, max_length=8)
    require_comparable_conditions: bool | None = None
    # Which model wrote this, when one did. Attached by the application from
    # what the gateway said, never present in what the model was asked to
    # return: a reply able to name its own model is a reply able to name a
    # different one. Absent on a change nobody asked a model for -- the
    # deterministic advisor writes one, and so does a person.
    proposed_by: ModelInvocationProvenance | None = None
    # Which deciding fields this would move, against the plan on record. Written by
    # the layer that holds the plan, never by whoever proposed the change.
    #
    # Bounded well above the count of plan-level deciding fields, because an arm's
    # measuring command is one too and a plan may declare eight arms. A bound that
    # only fits the plan-level fields would turn "this amendment moves too much"
    # into a validation error instead of the refusal it is supposed to be.
    moves_deciding_rules: list[str] = Field(default_factory=list, max_length=32)

    @model_validator(mode="after")
    def changes_something(self) -> "ProposedAmendment":
        changed = [name for name in (
            "registry", "holdout_registry", "arms", "repeats_per_arm", "candidate_arm",
            "baseline_arm", "arm_tasks", "require_comparable_conditions")
            if getattr(self, name) is not None]
        if not changed:
            raise ValueError("an amendment that changes nothing is not an amendment")
        return self

    @property
    def bars_acceptance(self) -> bool:
        """Whether recording this would stop the session ever being accepted.

        Derived from the fields it moves rather than stored, so it cannot be set
        to the convenient answer by whoever writes the document.
        """
        return bool(self.moves_deciding_rules)



class PendingAmendment(Contract):
    """A proposed change held between being shown and being decided.

    The step the amendment lifecycle was missing. A proposal used to exist only
    on the answer that carried it, which is enough when it can be derived again
    -- raise the repeat count by one, and the same rule over the same plan gives
    the same change twice. It is not enough when a model wrote it: two advisor
    calls need not agree, so approving a proposal that was only ever shown would
    record an objective nobody read.

    So the exact object is kept, and approving reads it back rather than asking
    again. The model is called once, when the proposal is made.

    This is not a store of alternatives. An alternative says what kind of next
    move is wanted; once a model has written a concrete objective, the thing
    being agreed to is a `ProposedAmendment`, and that is what is held here.
    """

    pending_version: str = "pending-amendment-v1"
    proposal: ProposedAmendment
    # Where the session stood when this was proposed, so an approval that arrives
    # after it moved on is refused against the state it was offered from.
    offered_at_event_sequence: int = Field(ge=1)
    plan_revision: int = Field(ge=0)
    # Which alternative asked for it, when one did. Present so the record answers
    # "what was offered, what was chosen, and what came of it" in one chain.
    source_alternative_id: str | None = Field(default=None, min_length=1, max_length=200)


class ResearchSession(Contract):
    session_id: str = Field(min_length=1)
    workspace: str
    objective: str = Field(min_length=1)
    origin: StudyOrigin | None = None
    runs: list[CodingRunReference] = Field(default_factory=list)
    # Sessions recorded before plans existed, and sessions without one, stay readable.
    plan: ResearchPlan | None = None
    # The ruler as it stood when experiments were allowed to start. Absent until
    # the measurement is frozen, and no arm may be dispatched before it is set.
    #
    # Absent *again* between a measurement being replaced and its successor
    # being built: that is the same state as before the first freeze, and it
    # stops arms for the same reason. A study without a ruler measures nothing.
    measurement_snapshot: MeasurementSnapshot | None = None
    # Rulers this study has retired, oldest first. They are not deleted and not
    # amended: a reading taken under one of these really was taken, and the
    # record has to keep saying so. What changed is which ruler the study is
    # being decided by, and `measurement_stands` reads that as a comparison
    # rather than as a rewrite.
    superseded_measurements: list[MeasurementSnapshot] = Field(
        default_factory=list, max_length=16)
    # What each frozen ruler said it was built to check, one entry per snapshot
    # and kept for the retired ones too. Beside the snapshots because that is
    # what an observation is about: a claim belongs to the ruler that made it,
    # not to the design that happens to be in force now, which is why the
    # reading over the two is computed and never stored here.
    measurement_claim_observations: list[MeasurementClaimObservation] = Field(
        default_factory=list, max_length=17)
    # What each declared control did when this study's rulers were pointed at
    # it, one entry per ruler and control. Kept for retired rulers too: a
    # calibration really happened under the instrument it happened under, and
    # replacing the instrument does not unhappen it -- it means the sensitivity
    # it showed has to be shown again by the new one.
    measurement_control_runs: list[MeasurementControlRun] = Field(
        default_factory=list, max_length=MAXIMUM_CONTROL_RUNS)
    requests: list["CodingTaskRequest"] = Field(default_factory=list)
    # Set the first time the holdout is evaluated; it is never cleared.
    holdout: "HoldoutRecord | None" = None
    # Amendments and reopenings keep a reversal visible in the current snapshot.
    #
    # `amendments` is history: what was applied, and at which revision. A
    # proposal nobody has decided yet is a different fact and is kept apart, so
    # that reading this list never raises "was this applied, or is it waiting?"
    amendments: list["PlanAmendment"] = Field(default_factory=list)
    # One change proposed and not yet decided. At most one: a second proposal
    # arriving while the first is unanswered would leave a person approving
    # whichever the surface happened to draw.
    pending_amendment: PendingAmendment | None = None
    reopenings: list["SessionReopening"] = Field(default_factory=list)
    # Which model each role calls for this study, declared before anything
    # called one. Held here rather than on the plan because the planner runs
    # before a plan exists: a session pins the policy its proposal was designed
    # under, so the model that designed the study is declared by the same
    # document as the models that carry it out.
    #
    # Absent on sessions recorded before routing was declared, and on any
    # session whose caller supplies gateways itself -- which is how every call
    # worked before this, and still works.
    routing_policy: ModelRoutingPolicy | None = None
    # Set only by the terminal conclusion event; forward declared below.
    conclusion: "ResearchConclusion | None" = None


class MeasurementImpact(Contract):
    """What replacing this study's instrument would do to what it already holds.

    Shown before anyone agrees to it, because this is a larger change than an
    amendment to an arm's objective and reads like a smaller one. Retasking an
    arm retires that arm's attempts; replacing the ruler retires every reading
    in the study, including the arms that were going perfectly well.

    Nothing here is deleted. The runs stay, their patches stay, their verifier
    output stays. They stop being readings under the ruler the study is decided
    by, which is why the wording says "not reused as evidence" and never
    "removed".
    """

    impact_version: str = "measurement-impact-v1"
    # Readings that would stop counting, by the run that produced them.
    retired_readings: list[str] = Field(default_factory=list, max_length=64)
    # And the arms those readings belong to, named as data.
    affected_arms: list[str] = Field(default_factory=list, max_length=8)
    # Attempts that have produced no reading yet. These are not retired: their
    # task still stands and the new ruler can take their first measurement, so
    # replacing the instrument does not throw away work nobody has measured.
    unmeasured_attempts: list[str] = Field(default_factory=list, max_length=64)

    @property
    def retires_anything(self) -> bool:
        return bool(self.retired_readings)


class ResearchRunReadiness(Contract):
    run_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    role: str | None = None
    usable: bool
    reason: str
    # Whether a measurement happened here, and how much of it could be seen.
    # Typed rather than folded into `reason`, because "the arm produced no
    # usable evidence" and "the instrument did not measure the arm" are
    # different findings that ask different people to do different things --
    # and a string nobody parses cannot keep them apart.
    #
    # Absent when the run never got as far as a measurement to read.
    measurement: MeasurementReading | None = None


class ResearchArmReadiness(Contract):
    arm: str = Field(min_length=1)
    required: int = Field(ge=1)
    usable: int = Field(ge=0)
    missing: int = Field(ge=0)
    satisfied: bool
    runs: list[ResearchRunReadiness] = Field(default_factory=list)


class ResearchSessionReadiness(Contract):
    """Whether pinned evidence covers the declared design; not a research verdict."""

    report_version: str = "research-readiness-v1"
    session_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    plan: ResearchPlan
    arms: list[ResearchArmReadiness]
    unassigned: list[ResearchRunReadiness] = Field(default_factory=list)
    ready: bool


class ResearchArmAssessment(Contract):
    arm: str = Field(min_length=1)
    run_ids: list[str] = Field(default_factory=list)
    # A design requiring one run per arm has no observable spread to assess.
    repeatability: RepeatabilityReport | None = None
    # Whether this arm's repeats started from the same conditions, targets included.
    conditions: ConditionsComparison | None = None


class ResearchSessionAssessment(Contract):
    """The pre-registered policy applied to the pre-registered design; not a verdict."""

    report_version: str = "research-assessment-v1"
    session_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    readiness: ResearchSessionReadiness
    arms: list[ResearchArmAssessment] = Field(default_factory=list)
    comparisons: list[MetricComparison] = Field(default_factory=list)
    unpaired_run_ids: list[str] = Field(default_factory=list)
    # Always reported once a design is covered, whether or not the plan requires it.
    conditions: ConditionsComparison | None = None
    # Pre-registered rules that took one value in every run of every arm. The
    # rules held; they did so without separating the arms, which is a different
    # thing from a result and has to be readable as one.
    identical_everywhere: list[str] = Field(default_factory=list)
    passed: bool
    reason: str
    # Whether this evidence can carry a conclusion, which is not whether the
    # rules held. Kept apart from `passed` because they answer different
    # questions and a live session proved they can disagree: every rule passed
    # over ten readings in which the deciding metric never varied.
    #
    # Defaults to `INCONCLUSIVE` so a report built before this existed, or one
    # that never got as far as a comparison, claims nothing.
    decision_support: DecisionSupport = DecisionSupport.INCONCLUSIVE
    support_reason: str = Field(default="", max_length=2000)


class PlanAmendment(Contract):
    """An explicit, recorded change to an already pre-registered policy."""

    revision: int = Field(ge=1)
    rationale: str = Field(min_length=1)
    # Attachments present when the policy changed, not usable evidence.
    attached_runs: int = Field(ge=0)


class RepairProvenance(Contract):
    """The failed attempt a replacement was created to repair.

    Recorded because the relationship was previously inferable only from
    sequence and from prose inside an objective. "Run B was created to repair run
    A" is a fact the application decided, and a fact somebody will want back
    without re-reading a prompt.

    Its presence is also what *makes* an attempt a repair. There is deliberately
    no boolean beside it: a flag and a link can disagree, and then the record has
    two answers to one question.
    """

    source_run_id: str = Field(min_length=1)
    source_event_sequence: int = Field(ge=1)
    # What went wrong, as the fingerprint that decides whether it keeps
    # happening. Absent when the attempt failed before reaching its verifier --
    # there is nothing to fingerprint, and saying so beats inventing one.
    failure_digest: str | None = Field(default=None, min_length=1, max_length=64)


class CodingTaskRequest(Contract):
    """A coding run this session asked for, recorded before the run is created."""

    request_id: str = Field(min_length=1)
    arm: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    # Set once the coding run exists and is attached under the arm's role.
    run_id: str | None = None
    # Set when this attempt replaces one that failed. `None` is an ordinary
    # repeat: the design asking for another independent measurement.
    repair: RepairProvenance | None = None


class HoldoutRecord(Contract):
    """When the holdout was first looked at, and on exactly which evidence."""

    event_sequence: int = Field(ge=1)
    pins: list[CodingRunReference] = Field(default_factory=list)


class ResearchSessionHoldout(Contract):
    """The declared holdout rules applied to the evidence selection already chose."""

    report_version: str = "session-holdout-v1"
    session_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    registry: MetricRegistry
    # Which output was judged: the verification selection also reads, or a
    # separate measurement of held-out data.
    source: str = Field(pattern=r"^(verification\.stdout|holdout\.stdout)$")
    comparisons: list[MetricComparison] = Field(default_factory=list)
    unpaired_run_ids: list[str] = Field(default_factory=list)
    first_event_sequence: int = Field(ge=1)
    # True when the pinned evidence is not the evidence the first look saw.
    evidence_changed_since_first_look: bool = False
    passed: bool
    reason: str = Field(min_length=1)


class ResearchDecision(str, Enum):
    """How a study ended, which is four answers rather than three.

    `INCONCLUSIVE` was added because the layer that detects the state could not
    record it. A live study ran properly: its measurement was valid, ten of ten
    readings were admitted, and every pre-registered rule held over evidence in
    which the deciding metric never varied. Nothing there supports accepting the
    candidate and nothing refutes it, and the only words available were

        ACCEPTED    a claim the evidence cannot carry
        REJECTED    a decision about the candidate nobody made
        ABANDONED   that somebody gave up, which is not what happened

    It is a *complete* outcome and not a failure. A study that measured what it
    set out to measure and found no difference has finished; calling that
    abandonment records the researcher as having quit, and calling it rejection
    records a verdict on a candidate that was never judged.
    """

    ACCEPTED = "accepted"
    REJECTED = "rejected"
    # The study ran and its evidence decides nothing. Terminal, and not a
    # failure: `ABANDONED` says the work stopped, this says the work finished.
    INCONCLUSIVE = "inconclusive"
    ABANDONED = "abandoned"


class ResearchConclusion(Contract):
    """A recorded decision bound to the evidence it was taken on; terminal."""

    decision: ResearchDecision
    rationale: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    # Abandonment needs no covered design, so it records no assessment.
    assessment: ResearchSessionAssessment | None = None
    # What the evidence could not say, recorded with the decision rather than left to
    # be remembered (P5, 0.2.83): arms that ran fewer times than telling the
    # difference from how much one version's runs differ needed.
    limitations: list[str] = Field(default_factory=list, max_length=8)


class SessionReopening(Contract):
    """A terminal decision that was explicitly set aside; the event keeps the original."""

    decision: ResearchDecision
    event_sequence: int = Field(ge=1)
    rationale: str = Field(min_length=1)


ResearchSession.model_rebuild()


class ResearchSessionEvent(Contract):
    session_id: str
    sequence: int = Field(ge=1)
    kind: str
    timestamp: datetime
    snapshot: ResearchSession


class ResearchSessionReview(Contract):
    session: ResearchSession
    event_sequence: int = Field(ge=1)
    evaluations: list[CodingEvaluation]


class ResearchSessionComparison(Contract):
    session_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    plan_applied: bool = False
    comparison: MetricComparison


class ResearchSessionRepeatability(Contract):
    session_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    plan_applied: bool = False
    repeatability: RepeatabilityReport
