"""Provider-independent single-edit model boundary."""

import re
from typing import Literal, Protocol, runtime_checkable

from pydantic import Field

from relab_core.contracts import Contract


class ModelGateway(Protocol):
    def complete(self, prompt: str, *, timeout_seconds: float,
                 response_contract: dict[str, object] | None = None,
                 reply_tokens: int | None = None) -> str:
        """Return JSON content; implementations must enforce the supplied timeout.

        `response_contract` is the shape the reply must take, when the caller
        knows it. A gateway that chose one for itself would be an adapter for one
        caller's purpose wearing a general name -- which is what this protocol's
        chat implementation turned out to be, and what a live call found.

        `reply_tokens` is how much room the reply needs, for the same reason and
        found the same way: every gateway here capped a reply at 4096 tokens --
        `max_tokens` in one, `num_predict` in the other -- which is a sensible
        bound for a single file edit and not enough for a whole design. A live
        planner call came back `finish_reason: length`, so the experiment was not
        run at all.

        It is a count and not a provider's spelling, because the caller knows how
        much it is asking for and does not know which key this provider calls it.
        Translating is the adapter's job; a caller that had to know would be
        choosing a provider by writing a dictionary key.
        """
        ...


class GeneratedFile(Contract):
    content: str = Field(min_length=1, max_length=65536)


class GeneratedPath(GeneratedFile):
    path: str = Field(min_length=1, max_length=1024)


class GeneratedFiles(Contract):
    files: list[GeneratedPath] = Field(min_length=2, max_length=8)


def single_file_schema() -> dict[str, object]:
    """The contract for an edit to one file.

    Here rather than inside a gateway, because it was written out twice -- once as
    a literal in the chat adapter and once from `GeneratedFile` in the Ollama one
    -- and two spellings of one contract eventually disagree about which is it.
    """
    return {"type": "object", "properties": {"content": {"type": "string"}},
            "required": ["content"], "additionalProperties": False}


def multi_file_schema() -> dict[str, object]:
    """Common structured-output subset; enforce limits locally after completion."""
    return {"type": "object", "properties": {"files": {"type": "array", "items": {
        "type": "object", "properties": {"path": {"type": "string"},
                                           "content": {"type": "string"}},
        "required": ["path", "content"], "additionalProperties": False}}},
        "required": ["files"], "additionalProperties": False}


class ModelIdentity(Contract):
    provider: Literal["openrouter", "vllm", "ollama", "openai"]
    model: str = Field(min_length=1, max_length=256)


class TokenUsage(Contract):
    prompt_tokens: int | None = Field(default=None, strict=True, ge=0)
    completion_tokens: int | None = Field(default=None, strict=True, ge=0)
    total_tokens: int | None = Field(default=None, strict=True, ge=0)
    # Of the prompt's tokens, those the provider served from its cache.
    cached_tokens: int | None = Field(default=None, strict=True, ge=0)
    # What the call cost, in US dollars, when the provider says (OpenRouter does).
    cost: float | None = Field(default=None, ge=0, allow_inf_nan=False)


class CallTiming(Contract):
    """How long one model call took, as this side measured it (RL-02).

    `seconds` is from connecting to the last byte. `first_token_seconds` is
    from connecting to the first streamed piece that carried anything --
    text, thinking or a tool call -- and None when the reply was not streamed,
    since then the first token cannot be told from the last.
    """

    seconds: float = Field(ge=0, allow_inf_nan=False)
    first_token_seconds: float | None = Field(default=None, ge=0, allow_inf_nan=False)


class ModelReply(str):
    """String-compatible result with per-call metadata, never gateway-global state."""

    usage: TokenUsage | None
    reported_model: str | None
    timing: CallTiming | None

    def __new__(  # noqa: PYI034 -- typing.Self requires Python 3.11.
        cls, content: str, usage: TokenUsage | None = None, *, reported_model: object = None,
        timing: CallTiming | None = None,
    ) -> "ModelReply":
        reply = super().__new__(cls, content)
        reply.usage = usage
        reply.timing = timing
        # Provider labels are optional untrusted metadata, not arbitrary log text.
        reply.reported_model = (
            reported_model if isinstance(reported_model, str)
            and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/@+\-]{0,255}", reported_model)
            else None
        )
        return reply


class ModelValidation(Contract):
    """One probe's result; conformance is not edit quality."""

    report_version: str = "model-validation-v1"
    identity: "ModelIdentity"
    conforms: bool
    reason: str = Field(min_length=1)
    reported_model: str | None = None
    usage: "TokenUsage | None" = None


class ToolCall(Contract):
    """One tool a model called, by name, with the arguments it gave.

    `arguments` is None when what the model sent was not a JSON object, which
    the caller treats as a reply it could not read -- never as no arguments.
    """

    name: str = Field(min_length=1, max_length=64)
    arguments: dict[str, object] | None = None
    # When `arguments` is None: the start of what was sent, and why it could not
    # be read, so the model is told what to send instead (0.2.34).
    unreadable: str | None = Field(default=None, max_length=400)


class ToolReply(Contract):
    """A reply that may call tools: the calls, in order, and any text beside them."""

    content: str = ""
    calls: list[ToolCall] = Field(default_factory=list)
    usage: "TokenUsage | None" = None
    reported_model: str | None = None
    timing: CallTiming | None = None


@runtime_checkable
class ToolGateway(Protocol):
    """A gateway whose provider takes tools natively, as function calls.

    Optional. A caller that has tools to offer asks `isinstance(gateway,
    ToolGateway)`; a gateway without it is asked in JSON, as ever. `tools` are
    OpenAI-style function declarations; the reply is the calls the model made,
    which the caller validates as it would any reply -- a provider's tool-call
    mode is a transport, not a contract.
    """

    def complete_tools(self, prompt: str, *, tools: list[dict[str, object]],
                       timeout_seconds: float, reply_tokens: int | None = None) -> ToolReply: ...


@runtime_checkable
class MessageGateway(Protocol):
    """A gateway that takes a whole conversation: what was asked, called and returned.

    Optional, beside `ToolGateway`. `messages` are OpenAI-style chat messages
    -- system, user, assistant with `tool_calls`, and a `tool` message per
    call's result -- which is the shape tool-calling models were trained on,
    and one a provider can cache the beginning of while it only grows.
    """

    def complete_messages(self, messages: list[dict[str, object]], *,
                          tools: list[dict[str, object]], timeout_seconds: float,
                          reply_tokens: int | None = None) -> ToolReply: ...


@runtime_checkable
class ChatGateway(Protocol):
    """A gateway that answers a whole conversation in text (JSON, when a contract is given).

    Optional, beside `MessageGateway`: for a model asked without tools. The
    conversation only grows, as a tool-calling one does, so a provider can
    cache its beginning and the model sees its own earlier replies and every
    result whole -- not one prompt rebuilt each call with the older results
    cut to a line.
    """

    def complete_chat(self, messages: list[dict[str, object]], *, timeout_seconds: float,
                      response_contract: dict[str, object] | None = None,
                      reply_tokens: int | None = None) -> str: ...


@runtime_checkable
class IdentifiedGateway(Protocol):
    @property
    def identity(self) -> ModelIdentity: ...
