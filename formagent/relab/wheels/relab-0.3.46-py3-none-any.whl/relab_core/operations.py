"""What ReLab is doing, while it is doing it. No authority, ever.

A person watching a study run could see that records were appended and not what
was happening. The timeline carried an event's *kind* and nothing else, so
`coding.patch_started` had to stand for "a model was asked for a change", "two
files were written" and "a verifier ran" all at once -- and the middle one had
no event at all, because verification happens inside `WorkspacePatchService`
between two records nobody splits.

    Calling coding model · openrouter/openai/gpt-5-mini
    Applying changes · 2 file(s)
    Running verifier · python tests/verify.py
    Verifier finished · exit 0

That is what this is for, and it is deliberately a *second* kind of record.

## Why it is not a `RunEvent`

`RunEvent.sequence` is not a display order. It is optimistic concurrency and a
state machine -- `expected_sequence=1`, then 2, then 3 -- and a session pins
evidence as `run_id` plus `event_sequence`. Adding "a provider call started" to
that stream would renumber what every pin refers to.

So observability gets its own journal. Reading is the only thing anything may
do with it:

    runs.db, sessions.db   what happened, and what may be concluded from it
    operations.db          what was going on, for somebody watching

Nothing in lifecycle, readiness, assessment or a decision reads this file. If
one ever did, a progress note would have become evidence, and the first time the
two disagreed the record would have two answers.

## What it may carry

Typed details, one shape per kind, and no free-form bag. The temptation here is
to make it a log: prompts, model prose, whole stdout, a diff. Those are either
already recorded as evidence -- where they are immutable and openable -- or they
are things ReLab has spent a lot of care *not* putting in front of people as if
they were facts. A detail names what was done and points at the record; it does
not reproduce it.
"""

from collections.abc import Iterator
from contextlib import contextmanager
from datetime import datetime, timezone
from enum import Enum
from typing import Literal, Protocol
from uuid import uuid4

from pydantic import Field

from relab_core.contracts import Contract
from relab_core.generation import (
    ChatGateway,
    IdentifiedGateway,
    MessageGateway,
    ModelGateway,
    ModelIdentity,
    ToolGateway,
    ToolReply,
)

# One attempt writes a handful of these. The bound is the practical one: a
# journal is read by a person watching, and a screen that needs paging has
# stopped being that.
MAXIMUM_SUBJECTS = 8


class OperationKind(str, Enum):
    """What sort of work was going on. Named for what a person would call it."""

    WORKSPACE_READ = "workspace_read"
    WORKSPACE_SEARCH = "workspace_search"
    MODEL_CALL = "model_call"
    PATCH_APPLICATION = "patch_application"
    VERIFICATION = "verification"
    MEASUREMENT = "measurement"
    # A coding loop's own words, each turn, on where the work stands and what
    # it does next: what a person watching would ask it.
    PROGRESS = "progress"


class OperationState(str, Enum):
    """Three, and `COMPLETED` says only that the work finished.

    Not that it succeeded. A verifier that ran and reported a failing check
    completed; whether that is a result is a question for the layers that judge
    evidence, and one this journal must never look like it has answered.
    """

    STARTED = "started"
    COMPLETED = "completed"
    FAILED = "failed"

    # Work with two ends is narrated as a pair. Something that is simply true
    # at a moment -- how far an arm has got -- is one COMPLETED record on its
    # own, because a STARTED for an instant is a line that says nothing.


class ModelCallDetail(Contract):
    """A provider call, by role and identity. Never the prompt or the reply."""

    detail: Literal["model_call"] = "model_call"
    role: str = Field(min_length=1, max_length=64)
    provider: str = Field(min_length=1, max_length=64)
    model: str = Field(min_length=1, max_length=256)
    # Counts, never text: the prompt's tokens as the provider reported them,
    # once it replied, and the context window the caller holds for the model --
    # what a person reads as "context 63k / 128k".
    prompt_tokens: int | None = Field(default=None, ge=0)
    context_window: int | None = Field(default=None, ge=1)


class WorkspaceReadDetail(Contract):
    """Files that were read, by path. The contents are the inspection's own record."""

    detail: Literal["workspace_read"] = "workspace_read"
    paths: list[str] = Field(default_factory=list, max_length=MAXIMUM_SUBJECTS)
    bytes_read: int = Field(default=0, ge=0)
    truncated: bool = False


class WorkspaceSearchDetail(Contract):
    """What was searched for, and how much came back -- not what came back."""

    detail: Literal["workspace_search"] = "workspace_search"
    query: str = Field(min_length=1, max_length=512)
    files_searched: int | None = Field(default=0, ge=0)
    matches: int = Field(default=0, ge=0)


class PatchDetail(Contract):
    """The files an attempt set out to write, and the patch it became."""

    detail: Literal["patch_application"] = "patch_application"
    targets: list[str] = Field(default_factory=list, max_length=MAXIMUM_SUBJECTS)
    # Present once the patch exists, so a surface can open the recorded evidence
    # rather than be handed a diff it would have to render itself.
    patch_id: str | None = Field(default=None, min_length=1, max_length=256)


class VerificationDetail(Contract):
    """The command, and how the process ended. Never its output.

    `exit_code` is a fact about a process. It is carried because a person
    watching wants to know the verifier finished rather than hung, and it is
    emphatically not a verdict: the measurement contract decides whether that
    run measured anything, and the assessment decides what it supports.
    """

    detail: Literal["verification"] = "verification"
    # Generous, because a command that does not fit is a command misreported.
    # Emitters clamp to this rather than let a progress line refuse a record.
    argv: list[str] = Field(default_factory=list, max_length=64)
    exit_code: int | None = None
    timed_out: bool = False
    # Where what it prints is appended as it runs, for a person to watch (0.2.66):
    # a file's path, never what is in it.
    log: str | None = Field(default=None, max_length=1000)
    # A job's name and the file its exit code is written to when it ends (0.2.68):
    # for a person watching to follow its log until then. Paths, never contents.
    job: str | None = Field(default=None, pattern=r"^p[0-9]{1,2}$")
    exit_file: str | None = Field(default=None, max_length=1000)


class MeasurementDetail(Contract):
    """How far an arm has got, as the records count it.

    Computed where the records are, so no surface ever counts runs itself. A
    progress figure worked out by a client is a second opinion about coverage,
    and coverage has an owner.
    """

    detail: Literal["measurement"] = "measurement"
    arm: str = Field(min_length=1, max_length=128)
    usable: int = Field(default=0, ge=0)
    required: int = Field(default=1, ge=1)


class ProgressDetail(Contract):
    """What the model working a coding loop said it is doing, in its words.

    The one detail that carries a model's prose, and only this: a sentence or
    two it wrote for the person, kept short. A surface shows it as the model's
    words -- never as a result, a check or a state of the work, which the other
    details report from what ReLab itself did.
    """

    detail: Literal["progress"] = "progress"
    said: str = Field(min_length=1, max_length=300)


class StartupDetail(Contract):
    """A runtime preparation phase, with duration and no prompt or model prose."""

    detail: Literal["startup"] = "startup"
    # `server`: asking the model's server for its window, once (0.2.37).
    phase: Literal["request", "project", "mcp", "server"]
    elapsed_ms: float | None = Field(default=None, ge=0)


class DraftingDetail(Contract):
    """What a streamed reply is shaping up to be, before it is a step.

    Counted from the pieces of a tool call as they arrive: which step, the
    file it names, and how many lines it has written so far. A minute-long
    write showed nothing but "working"; another coding agent shows the file
    as it is written. Nothing here is applied or believed: the step it becomes
    is checked as any other, and may yet be refused.
    """

    detail: Literal["drafting"] = "drafting"
    tool: str = Field(min_length=1, max_length=64)
    path: str | None = Field(default=None, min_length=1, max_length=300)
    lines: int = Field(default=0, ge=0)
    # The model's words to the person as they come: the step's thought, and a
    # report being written (its end, when long). Measured against another
    # agent, a three-minute analysis felt stopped until its answer appeared
    # whole; the other showed its words as they streamed. Shown as the model's
    # words, never as a result.
    thought: str | None = Field(default=None, min_length=1, max_length=300)
    report: str | None = Field(default=None, min_length=1, max_length=4000)
    # Before any of that: a reasoning model thinking, how much so far and the
    # end of it, so the wait before its first word is not silent.
    thinking: str | None = Field(default=None, min_length=1, max_length=300)
    thinking_characters: int = Field(default=0, ge=0)


class SteeringDetail(Contract):
    """What the person said to a running loop, as the loop read it (UX-02).

    Their own words, labelled as theirs: a surface shows that the direction
    they gave was taken up, at which point of the work.
    """

    detail: Literal["steering"] = "steering"
    steering_id: str = Field(pattern=r"^steer-[0-9a-f]{32}$")
    instruction: str = Field(min_length=1, max_length=4000)


class ChecklistItem(Contract):
    text: str = Field(min_length=1, max_length=200)
    done: bool = False


class ChecklistDetail(Contract):
    """A coding loop's checklist as it stands: how far the work has got, at a glance.

    Asked for in use: a loop plans its work and does it item by item, and a
    person watching had no way to see which item it was on or how many were
    left -- so no way to tell when it would end. The items are the loop's own
    `todo`, as it last sent it; one record per change, under one operation id,
    so a surface draws the newest in place.
    """

    detail: Literal["checklist"] = "checklist"
    items: list[ChecklistItem] = Field(min_length=1, max_length=40)


OperationDetail = (
    ModelCallDetail | WorkspaceReadDetail | WorkspaceSearchDetail
    | PatchDetail | VerificationDetail | MeasurementDetail | ProgressDetail | DraftingDetail
    | ChecklistDetail | SteeringDetail | StartupDetail
)


class OperationEvent(Contract):
    """One thing ReLab was doing, recorded as it started and as it ended."""

    operation_version: str = "operation-event-v1"
    # Shared by the started and finished records of one piece of work, so a
    # surface can pair them without matching on time or on kind.
    operation_id: str = Field(min_length=1, max_length=64)
    # Assigned by the store on append. A record in flight carries 1, meaning
    # only "not written yet": the order of these is the store's to say, because
    # two arms running at once both write here and an order they had to agree
    # on in advance would be a coordination problem invented for a display.
    sequence: int = Field(default=1, ge=1)
    timestamp: datetime
    kind: OperationKind
    state: OperationState
    # What this was part of. Both absent for work that belongs to a workspace
    # rather than to any one study -- an exploration before a session exists.
    session_id: str | None = Field(default=None, min_length=1)
    run_id: str | None = Field(default=None, min_length=1)
    detail: OperationDetail = Field(discriminator="detail")
    # Why it ended badly, when it did. Sanitised at the boundary that raised it,
    # like every other failure text this system carries across a process.
    reason: str | None = Field(default=None, min_length=1, max_length=2000)


class OperationObserver(Protocol):
    """Where a narration goes. It must not raise, and it must not be believed.

    Emitters call this from inside real work -- mid-patch, mid-verification --
    so an observer that threw would turn a display into a way to fail a study.
    The recorder shipped with ReLab swallows its own failures for that reason.
    """

    def __call__(self, event: OperationEvent, /) -> None: ...


class Narration:
    """One piece of work being talked about while it happens.

    The started record is written from what was known going in; `detail` is
    reassigned before the block ends when more is known by then, which is how a
    verifier's exit code reaches the finished record.
    """

    def __init__(self, detail: OperationDetail) -> None:
        self.detail = detail
        self.reason: str | None = None
        self._failed = False

    def failed(self, reason: str) -> None:
        """End badly without raising, for work that reports failure by returning."""
        self._failed = True
        self.reason = reason


@contextmanager
def narrate(
    observe: OperationObserver | None,
    kind: OperationKind,
    detail: OperationDetail,
    *,
    session_id: str | None = None,
    run_id: str | None = None,
) -> Iterator[Narration]:
    """Say that this began, and say how it ended, whichever way it ends.

    `observe` is None wherever nothing is listening, so a caller narrates the
    same way in both cases instead of asking first.
    """
    note = Narration(detail)
    if observe is None:
        yield note
        return

    operation_id = uuid4().hex

    def say(state: OperationState, reason: str | None) -> None:
        observe(OperationEvent(
            operation_id=operation_id, timestamp=datetime.now(timezone.utc),
            kind=kind, state=state, session_id=session_id, run_id=run_id,
            detail=note.detail, reason=reason))

    say(OperationState.STARTED, None)
    try:
        yield note
    except BaseException as error:
        # The exception's type, never its message. A message can carry provider
        # text, a captured stream or a path, and this record is made to be
        # shown rather than audited -- so it says which kind of thing went
        # wrong and leaves the account of it to the evidence.
        say(OperationState.FAILED, note.reason or type(error).__name__)
        raise
    say(OperationState.FAILED if note._failed else OperationState.COMPLETED, note.reason)


def observed(
    observe: OperationObserver | None,
    kind: OperationKind,
    detail: OperationDetail,
    *,
    session_id: str | None = None,
    run_id: str | None = None,
    operation_id: str | None = None,
    state: OperationState = OperationState.COMPLETED,
) -> None:
    """Record something that is true now rather than work that takes time.

    With `operation_id`, one more state of the same thing: a surface draws
    the newest in place of the ones before it.
    """
    if observe is None:
        return
    observe(OperationEvent(
        operation_id=operation_id or uuid4().hex, timestamp=datetime.now(timezone.utc),
        kind=kind, state=state,
        session_id=session_id, run_id=run_id, detail=detail))
# What a provider call is narrated as, by the part of the system making it.
# Deliberately not `ModelRole`: routing decides which model answers a coding or
# planning request, and this says which piece of work was asking. Forcing them
# into one type would mean every new narrated caller had to become a routable
# role, and a role nobody routes is a lie in the routing policy.
CONVERSATION_INTENT_ROLE = "conversation_intent"
PLANNER_ROLE = "planner"
AMENDMENT_ROLE = "amendment"
REPLAN_ROLE = "replan"


class NarratedGateway:
    """A gateway that says a provider is being called. It changes nothing else.

    A decorator rather than six lines at each call site, because the rule being
    kept is about *any* provider call a conversation can reach -- and a rule
    kept by remembering to add six lines is one that the next advisor somebody
    writes will not keep. Wrapping the gateway is the one place all of a
    component's provider calls go through, so a planner that asks twice narrates
    twice without knowing this exists.

    What travels is the role, the provider and the model. Not the prompt, not
    the reply, not the failure's message: a provider's own words are the one
    thing this system has spent the most care never putting in front of a person
    as if they were a fact.
    """

    def __new__(  # noqa: PYI034 -- typing.Self requires Python 3.11.
            cls, gateway: ModelGateway, *args: object, **kwargs: object) -> "NarratedGateway":
        # On Python 3.12, isinstance against a runtime-checkable protocol looks
        # attributes up statically: an `identity` reached through `__getattr__`
        # is not seen, and every narrated call lost its model. A wrapped gateway
        # with an identity is wrapped in the class that declares one; one without
        # still has none.
        identified = cls is NarratedGateway and _has_identity(gateway)
        return super().__new__(_IdentifiedNarratedGateway if identified else cls)

    def __init__(
        self,
        gateway: ModelGateway,
        observe: OperationObserver | None,
        *,
        role: str,
        session_id: str | None = None,
        run_id: str | None = None,
        context_window: int | None = None,
    ) -> None:
        self.gateway = gateway
        self.observe = observe
        self.role = role
        self.session_id = session_id
        self.run_id = run_id
        self.context_window = context_window

    def _detail(self) -> "ModelCallDetail":
        identity = (self.gateway.identity
                    if isinstance(self.gateway, IdentifiedGateway) else None)
        return ModelCallDetail(
            role=self.role,
            provider="unreported" if identity is None else identity.provider,
            model="unreported" if identity is None else identity.model,
            context_window=self.context_window)

    @staticmethod
    def _replied(note: "Narration", reply: object) -> None:
        """The finished record says how large the prompt was, when the reply reports it."""
        tokens = getattr(getattr(reply, "usage", None), "prompt_tokens", None)
        if isinstance(tokens, int) and tokens >= 0 and isinstance(note.detail, ModelCallDetail):
            note.detail = note.detail.model_copy(update={"prompt_tokens": tokens})

    def __getattr__(self, name: str) -> object:
        # `identity` and anything else the wrapped gateway offers, including its
        # absence: a gateway with no identity must not appear to have one just
        # because it was wrapped, which is what a declared property would do.
        return getattr(self.gateway, name)

    def complete(self, prompt: str, *, timeout_seconds: float,
                 response_contract: dict[str, object] | None = None,
                 reply_tokens: int | None = None) -> str:
        detail = self._detail()
        with narrate(self.observe, OperationKind.MODEL_CALL, detail,
                     session_id=self.session_id, run_id=self.run_id) as note:
            reply = self.gateway.complete(
                prompt, timeout_seconds=timeout_seconds,
                response_contract=response_contract, reply_tokens=reply_tokens)
            self._replied(note, reply)
            return reply

    def complete_chat(self, messages: list[dict[str, object]], *, timeout_seconds: float,
                      response_contract: dict[str, object] | None = None,
                      reply_tokens: int | None = None) -> str:
        """A whole conversation in text, narrated as one call; only for a gateway that has it."""
        if not isinstance(self.gateway, ChatGateway):
            raise AttributeError("complete_chat")  # noqa: TRY004 -- as a missing method does
        detail = self._detail()
        with narrate(self.observe, OperationKind.MODEL_CALL, detail,
                     session_id=self.session_id, run_id=self.run_id) as note:
            reply = self.gateway.complete_chat(
                messages, timeout_seconds=timeout_seconds,
                response_contract=response_contract, reply_tokens=reply_tokens)
            self._replied(note, reply)
            return reply

    def complete_messages(self, messages: list[dict[str, object]], *,
                          tools: list[dict[str, object]], timeout_seconds: float,
                          reply_tokens: int | None = None) -> ToolReply:
        """A whole conversation by tools, narrated as one call; only for a gateway that has it."""
        if not isinstance(self.gateway, MessageGateway):
            raise AttributeError("complete_messages")  # noqa: TRY004 -- as a missing method does
        detail = self._detail()
        with narrate(self.observe, OperationKind.MODEL_CALL, detail,
                     session_id=self.session_id, run_id=self.run_id) as note:
            replied = self.gateway.complete_messages(
                messages, tools=tools, timeout_seconds=timeout_seconds, reply_tokens=reply_tokens)
            self._replied(note, replied)
            return replied

    def complete_tools(self, prompt: str, *, tools: list[dict[str, object]],
                       timeout_seconds: float, reply_tokens: int | None = None) -> ToolReply:
        """The same call by tools, narrated the same way; only for a gateway that has it.

        Without this, `__getattr__` would hand the wrapped gateway's method out
        unwrapped and a tool call would reach the provider in silence.
        """
        if not isinstance(self.gateway, ToolGateway):
            raise AttributeError("complete_tools")  # noqa: TRY004 -- as a missing method does
        detail = self._detail()
        with narrate(self.observe, OperationKind.MODEL_CALL, detail,
                     session_id=self.session_id, run_id=self.run_id) as note:
            called = self.gateway.complete_tools(
                prompt, tools=tools, timeout_seconds=timeout_seconds, reply_tokens=reply_tokens)
            self._replied(note, called)
            return called


def _has_identity(gateway: object) -> bool:
    """Whether a gateway says which model it calls."""
    try:
        return getattr(gateway, "identity", None) is not None
    except Exception:  # noqa: BLE001 -- a gateway whose identity cannot be had has none
        return False


class _IdentifiedNarratedGateway(NarratedGateway):
    """A narrated gateway whose wrapped one has an identity, declared (Python 3.12+)."""

    @property
    def identity(self) -> "ModelIdentity":
        return self.gateway.identity  # type: ignore[attr-defined,no-any-return]


def narrated(
    gateway: ModelGateway,
    observe: OperationObserver | None,
    *,
    role: str,
    session_id: str | None = None,
    run_id: str | None = None,
) -> ModelGateway:
    """The same gateway, saying what it is doing. Unchanged when nobody listens."""
    if observe is None:
        return gateway
    return NarratedGateway(gateway, observe, role=role,
                           session_id=session_id, run_id=run_id)
