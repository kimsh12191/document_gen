"""Reading a change, as distinct from reading its outcome.

Everything else in this repository judges an attempt by what the verifier
measured. That is the right default and it has one hole, which no amount of
further evidence can close:

    Did this edit do the work, or did it satisfy the measurement?

An edit that hardcodes the expected metric, special-cases the verifier's input,
or stubs the function under test passes every check ReLab makes, and everything
downstream -- the comparison, the assessment, the interpretation, the finding --
is then worth nothing. The evidence cannot settle it because the evidence is what
is being subverted. `holdout_data_changed` already refuses a reading when an
attempt altered the data it was about to be measured on; this is the same concern
where it cannot be caught mechanically.

**A review is not evidence.** It is an unevidenced claim about an artefact, which
is the category the rest of this architecture exists to keep out of the record. So
it may not reach an assessment, a comparison, or an acceptance. It goes in front
of a person, like an amendment does, and nothing acts on it automatically.
"""

from enum import Enum

from pydantic import Field, model_validator

from relab_core.contracts import Contract
from relab_core.generation import ModelIdentity

MAXIMUM_FINDINGS = 16


class ReviewConcern(str, Enum):
    """What a finding is about. Deliberately few, and all about the measurement.

    Security and maintainability are absent. They are about code as a product,
    and the code here is a means to a measurement -- reviewing it on those terms
    would be answering a question nobody in this loop asked.
    """

    # The edit satisfies the verifier without doing the work it describes.
    SATISFIES_THE_MEASUREMENT = "satisfies_the_measurement"
    # The edit does the work, but the verifier would pass without it having done so.
    VERIFIER_TOO_WEAK = "verifier_too_weak"
    # The edit changes behaviour the objective did not ask about.
    UNASKED_CHANGE = "unasked_change"


class ReviewFinding(Contract):
    """One concern about a change, pointing at the line that raised it."""

    concern: ReviewConcern
    detail: str = Field(min_length=1, max_length=2000)
    # Which file the concern is in, and the exact added line that raised it.
    # Both are checked against the diff before a finding reaches anyone: a
    # citation that does not resolve is dropped, exactly as a memory item's is
    # refused. A reviewer naming a file it was not shown is not reviewing.
    path: str = Field(min_length=1)
    line: str = Field(min_length=1, max_length=500)

    @model_validator(mode="after")
    def points_at_something(self) -> "ReviewFinding":
        # Whitespace satisfies a length bound and points at nothing.
        if not self.line.strip() or not self.path.strip():
            raise ValueError("a finding points at a line of a file, or it is not a finding")
        return self


class PatchReview(Contract):
    """What a reader saw in one change. Advisory, and never part of the record."""

    review_version: str = "patch-review-v1"
    run_id: str = Field(min_length=1)
    # What the attempt was asked to do, so a reader can judge the concern against it.
    objective: str = Field(min_length=1, max_length=2000)
    summary: str = Field(min_length=1, max_length=2000)
    findings: list[ReviewFinding] = Field(default_factory=list, max_length=MAXIMUM_FINDINGS)
    # Read from the gateway, never from the reply. A model naming itself is a
    # claim; the gateway is the fact, as it is for a proposed design.
    reviewed_by: ModelIdentity | None = None
    # Citations the reviewer gave that the diff does not contain. Dropped from
    # the findings and counted here, because "it found nothing" and "it found
    # things it could not point at" are different answers about a reviewer.
    unresolved_citations: int = Field(default=0, ge=0)

    @property
    def concerned(self) -> bool:
        """Whether anything here is worth a person's attention before accepting."""
        return bool(self.findings)
