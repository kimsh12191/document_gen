"""What a study's controls have shown about the ruler in force.

The contracts only. Reading a set of control runs against a set of declared
controls is judgement, and judgement lives in `relab_evaluation.sensitivity` --
the same split the claim assessment next door already keeps, and for the same
reason: a surface needs the shape of the answer without depending on the thing
that works it out.
"""

from enum import Enum

from pydantic import Field, model_validator

from relab_core.contracts import Contract


class SensitivityStatus(str, Enum):
    """What the declared controls have shown about this ruler. Recomputed, never stored."""

    # No control was declared, so nothing was asked of the instrument here. Not
    # "it failed" and not "it passed": there is no contract to read against.
    UNDECLARED = "undeclared"
    # Controls exist and none has been run against the ruler in force.
    UNTESTED = "untested"
    # A control ran and the separation it asked for did not appear -- or it
    # appeared under an expectation only the model that wrote the ruler
    # established, which is not a thing this may believe.
    NOT_DEMONSTRATED = "not_demonstrated"
    # Every declared control showed what it asked for, under an expectation
    # somebody other than the verifier's author established. For those controls,
    # and no further.
    DEMONSTRATED = "demonstrated"


class ControlFinding(str, Enum):
    """Which of the ways a control can end, as a value something may branch on.

    `NOT_DEMONSTRATED` is true of all but one of these, and that is exactly why
    it cannot be what a policy reads. The n=5 campaign reached it five ways: a
    separation under a model's expectation, a verifier that exited without a
    number, a command the host could not run, a design refused before any of
    it. Answering all of them with "revise the measurement" would send a person
    to rewrite a ruler because `python3` is not installed.

    Ordered by how far the control got, and each says only that far.
    """

    # No run against the ruler in force.
    UNTESTED = "untested"
    # The control names a metric the registry declares no rule for, so no
    # direction exists to read a separation in. A design defect.
    UNKNOWN_METRIC = "unknown_metric"
    # No reading, and the ruler never reached its own declaration -- the first
    # thing a verifier ReLab built is asked to do. The command did not start,
    # or failed before its own first step: the n=5 campaign's `python3`, which
    # this host resolves to an installer stub. A fact about the run, not the
    # ruler's judgement.
    CALIBRATION_EXECUTION_FAILED = "calibration_execution_failed"
    # No reading, though the ruler declared: it ran, and printed nothing this
    # control reads. The campaign's verifier that could not import its own
    # reference data. A fact about the ruler.
    CALIBRATION_UNOBSERVABLE = "calibration_unobservable"
    # No reading, and nothing recorded says how far the ruler got: a reading
    # taken before that was read, or a ruler that was never asked to declare.
    NO_READING = "no_reading"
    # Both subjects were read and the separation is short of what was asked,
    # including a broken subject that measured better.
    INSUFFICIENT_SEPARATION = "insufficient_separation"
    # The separation asked for appeared, under an expectation only a model
    # established. Recorded, and not believed.
    SEPARATION_OBSERVED_BUT_UNTRUSTED = "separation_observed_but_untrusted"
    # The separation appeared, and somebody other than the ruler's author
    # established that it should.
    DEMONSTRATED = "demonstrated"


class ControlOutcome(Contract):
    """One control, and what the ruler did with it."""

    control_id: str = Field(min_length=2, max_length=48)
    requirement_id: str = Field(min_length=2, max_length=48)
    metric: str = Field(min_length=1, max_length=128)
    # What the ruler printed for each subject, when it printed anything.
    good_value: float | None = None
    bad_value: float | None = None
    # How much better the good subject measured, in the direction the registry
    # declares for this metric. Negative means the broken subject measured
    # better, which is a finding of its own.
    separation: float | None = None
    required_separation: float
    # Which way it ended. The value to branch on; `reason` is its sentence.
    finding: ControlFinding
    # Whether this control showed what it asked for *and* may be believed.
    demonstrated: bool = False
    # Why it showed nothing, when it showed nothing.
    reason: str | None = Field(default=None, min_length=1, max_length=400)

    @model_validator(mode="after")
    def one_answer(self) -> "ControlOutcome":
        # Two fields saying one thing must not be able to say two.
        if self.demonstrated != (self.finding is ControlFinding.DEMONSTRATED):
            raise ValueError("a control is demonstrated exactly when its finding says so")
        return self


class MeasurementSensitivity(Contract):
    """What the declared controls have shown about the ruler in force."""

    assessment_version: str = "measurement-sensitivity-v1"
    status: SensitivityStatus
    # Which requirements have a control that demonstrated something, and which
    # do not. Named rather than counted: "REQ-ADD is demonstrated and
    # REQ-SUBTRACT is not" is the sentence this axis exists to be able to say.
    demonstrated_requirement_ids: list[str] = Field(default_factory=list, max_length=32)
    undemonstrated_requirement_ids: list[str] = Field(default_factory=list, max_length=32)
    outcomes: list[ControlOutcome] = Field(default_factory=list, max_length=32)
