"""Turning a declared route into something that can be called.

The seam C6 needs, and the one it must not cross. Which model a role calls is a
fact about the study, so the application decides it; *constructing* a gateway
means holding endpoints and credentials, which the application has never done
and should not start doing.

    application        reads the declared route for a role
    GatewayResolver    hands back something that can answer
    composition root   owns providers, endpoints and keys

Before this, a caller built whatever gateway it liked and passed it in, so the
model that ran was whatever the command line said. That still works -- a session
with no declared route resolves to nothing and the caller's gateway is used --
but it is no longer the only way, and it is no longer the only thing the record
can say afterwards.
"""

from typing import Protocol

from relab_core.generation import ModelGateway
from relab_core.routing import ModelRoute


class GatewayResolver(Protocol):
    """Anything that can produce a gateway for a declared route.

    It is given a route and nothing else: no role, no session, no plan. What a
    call is *for* is the application's question and has already been answered by
    the time a route exists, so a resolver that could see the role would be a
    resolver that could decide differently by purpose -- which is routing, and
    is not its job.
    """

    def resolve(self, route: ModelRoute) -> ModelGateway:
        """The gateway for this route.

        Raising is the right answer for a route this resolver cannot serve --
        an unknown provider, a missing credential. Returning something that
        cannot answer would move the failure to the middle of a study.
        """
        ...
