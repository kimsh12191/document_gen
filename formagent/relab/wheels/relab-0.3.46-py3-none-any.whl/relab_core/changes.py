"""What an attempt wrote, and what became of it.

A conversation that says "patch applied and verified" has told a researcher that
something happened to their code and not what. The question a coding surface
exists to answer is *what changed*, and answering it by sending someone to a
terminal is the errand the surface was built to remove.

This is a projection of a run's recorded evidence, not a new fact about it. The
diff is already on the record; these are the parts of it a person reads at a
glance -- which files, how much, and whether what was written is still there.

**Whether it is still there is the part that is easy to get wrong.** A reverted
attempt wrote real code, ran a real verifier and produced real evidence, and
none of it is in the workspace now. A card that showed the same shape for both
would tell someone their file had been changed when it had not.

There are two ways for an attempt's code to be absent, and a live session found
the second the hard way: a patch the verifier rejected, and a patch that
succeeded and was then undone so the next arm could be measured against the same
starting tree. They are opposite outcomes and they leave the same empty file, so
this type keeps them in separate fields and derives "is it there" from both.
"""

from pydantic import Field, model_validator

from relab_core.coding.patch import PatchStatus
from relab_core.contracts import Contract
from relab_core.runs import RestoreReason

# An arm writes at most eight files; a change describes at most what one wrote.
MAXIMUM_CHANGED_FILES = 8


class FileChange(Contract):
    """One file an attempt wrote, and how much of it."""

    path: str = Field(min_length=1, max_length=1024)
    added: int = Field(strict=True, ge=0)
    removed: int = Field(strict=True, ge=0)
    # Whether both states of this file were kept, so a before/after comparison
    # can be shown from the record. Said here rather than worked out by a
    # surface: whether a snapshot exists is a fact about the evidence, and a
    # client guessing at it would offer a comparison that then came back empty.
    comparable: bool = False


class RunChange(Contract):
    """One attempt's change to the workspace, as the record holds it.

    Two separate facts, which a live session proved cannot share a field. Six
    attempts wrote a calculator, every patch applied and verified, and the
    conversation said "all of it is in your workspace" -- while the workspace
    held no such file, because each attempt had been undone after it was
    measured so the next arm would not measure the last one's code.

    Nothing was wrong with the study or with the record. The projection read
    `patch_evidence.status`, which says how the *patch* ended, and called it an
    answer to "what do my files hold now", which only the run's own restoration
    can answer.
    """

    change_version: str = "run-change-v2"
    run_id: str = Field(min_length=1)
    # Absent for a run attached outside the design, which has no arm.
    arm: str | None = Field(default=None, min_length=1)
    files: list[FileChange] = Field(default_factory=list, max_length=MAXIMUM_CHANGED_FILES)
    # How the patch ended: applied, reverted by the patcher, refused. This is
    # about the attempt, and it is not about the workspace now.
    patch_status: PatchStatus
    # Whether the applied edit was taken back out afterwards. A success, not a
    # failure -- and the reason a person's files do not hold it.
    restored_after_measurement: bool = False
    # Why. Absent for a run recorded before reasons were kept, and for one that
    # was never restored.
    restore_reason: RestoreReason | None = None
    # None when no verifier ran -- a rejected patch never reached one, and that
    # is a different thing from a verifier that ran and said no.
    verified: bool | None = None

    @model_validator(mode="after")
    def only_an_applied_patch_can_be_undone(self) -> "RunChange":
        if self.restored_after_measurement and self.patch_status is not PatchStatus.APPLIED:
            raise ValueError("a patch that did not apply cannot have been restored")
        if self.restore_reason is not None and not self.restored_after_measurement:
            raise ValueError("a restore reason belongs to a restoration that happened")
        return self

    @property
    def in_workspace(self) -> bool:
        """Whether what this attempt wrote is in the files now.

        An applied patch that was not taken back out, and nothing else. A
        reverted attempt and a restored one both produced evidence that is every
        bit as real and both left nothing behind; a surface that showed either
        as applied would tell a person their code had changed when it had not.
        """
        return self.patch_status is PatchStatus.APPLIED and not self.restored_after_measurement

    @property
    def added(self) -> int:
        return sum(item.added for item in self.files)

    @property
    def removed(self) -> int:
        return sum(item.removed for item in self.files)
