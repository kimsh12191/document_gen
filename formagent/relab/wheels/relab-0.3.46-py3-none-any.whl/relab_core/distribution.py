"""What an offline distribution bundle contains, and whether it is installable.

A directory of wheels is a hope, not a bundle. These contracts record what was
collected, what it hashes to, and which declared requirement each file answers --
so the question "can this install with no index?" has an answer before someone
carries it to a machine that has none.
"""

from pydantic import Field

from relab_core.contracts import Contract


class BundledFile(Contract):
    """One file in the bundle, named and digested so tampering is visible."""

    name: str = Field(min_length=1)
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    size: int = Field(ge=0)


class BundledRequirement(Contract):
    """One declared requirement and the wheels present to answer it."""

    requirement: str = Field(min_length=1)
    # The distribution name, normalized the way wheel filenames are.
    distribution: str = Field(min_length=1)
    wheels: list[str] = Field(default_factory=list)
    # Simply whether a wheel for it is here. Whether it is the right one for the
    # target machine is the installer's to decide, and it decides it there.
    satisfied: bool = False
    # The marker text, kept verbatim and never evaluated: whether it applies is a
    # fact about the machine that will install, not the one that built.
    environment_marker: str | None = None


class DistributionBundle(Contract):
    """An offline bundle's manifest; produced by building, checked by verifying."""

    report_version: str = "distribution-bundle-v1"
    name: str = Field(min_length=1)
    version: str = Field(min_length=1)
    requires_python: str | None = None
    files: list[BundledFile] = Field(default_factory=list)
    requirements: list[BundledRequirement] = Field(default_factory=list)
    # Requirements carrying a marker, listed rather than guessed at.
    unjudged: list[str] = Field(default_factory=list)
    # Every unconditional requirement has a wheel here. It is not a promise about
    # the conditional ones, which is why they are named above rather than assumed.
    self_sufficient: bool = False


class BundleVerification(Contract):
    """What a stored manifest still describes, re-read from the files themselves."""

    report_version: str = "bundle-verification-v1"
    bundle: DistributionBundle
    missing: list[str] = Field(default_factory=list)
    altered: list[str] = Field(default_factory=list)
    # Files present in the directory that the manifest never named.
    unexpected: list[str] = Field(default_factory=list)
    intact: bool = False
