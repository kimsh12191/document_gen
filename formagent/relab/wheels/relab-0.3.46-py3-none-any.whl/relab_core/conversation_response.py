"""What a conversation turn answers with.

Not one blob of text. A model saying "next you should run the experiment" as prose
for a surface to interpret would put the control plane back inside a sentence,
and the typed authority boundary would have been dissolved by the chat box rather
than by any decision anyone made.

So the answer carries the state, the blockers, the arms, and what may be done --
each as data. The message is the part a person reads, and it is the *only* part
that is prose.
"""

from enum import Enum

from pydantic import Field, model_validator

from relab_core.changes import RunChange
from relab_core.contracts import Contract
from relab_core.conversation import MAXIMUM_PERFORMED
from relab_core.conversation_intent import (
    ConversationCapability,
    ConversationIntent,
    ConversationWorkflow,
    WorkflowUnavailable,
)
from relab_core.explanation import FailureExplanation
from relab_core.inspection import InspectionContext, InspectionResult
from relab_core.lifecycle import (
    MeasurementBlocker,
    MeasurementClaimBlocker,
)
from relab_core.memory import MAXIMUM_CITATIONS, EvidenceCitation
from relab_core.next_action import (
    MAXIMUM_BLOCKERS,
    ProposedAmendment,
    ProposedConclusion,
)
from relab_core.orchestration import DriveStep
from relab_core.runs import PendingHumanGate
from relab_core.sensitivity import MeasurementSensitivity
from relab_core.turns import TurnState

# An arm's attempts, for as many arms as a plan may declare. A card per
# attempt is what a person scrolls; a session that ran more than this has
# more to say than a sidebar is the place to say it in.
MAXIMUM_CHANGES = 24


class ConversationAction(str, Enum):
    """What a person may do next, from a closed set.

    Closed on purpose. A surface renders only what it recognises, so an action
    named outside this set produces nothing -- the same way a review citing a line
    the diff never added produces nothing. That is what keeps a model from
    inventing a control instruction and having it obeyed.
    """

    TAKE_TURN = "take_turn"
    ANSWER_AMENDMENT = "answer_amendment"
    ANSWER_GATE = "answer_gate"
    EVALUATE_HOLDOUT = "evaluate_holdout"
    CONCLUDE = "conclude"
    ACCEPT_PROPOSAL = "accept_proposal"
    # Confirm the decision to stop that this session's records support. Separate
    # from CONCLUDE, which records a decision a person arrived at themselves: the
    # decision confirmed here is the one on the answer, not one the client sent.
    CONFIRM_STOP = "confirm_stop"
    # Ask for one of the alternatives the answer listed. Choosing is not doing:
    # it resolves to a change a person then approves, through the path that
    # already exists for approving one.
    SELECT_ALTERNATIVE = "select_alternative"
    START_NEW_SESSION = "start_new_session"
    # Write the attempt a finished study chose back into the workspace: the
    # recorded bytes that were measured, onto files still as it found them.
    KEEP_RESULT = "keep_result"


class ResultCheckKind(str, Enum):
    """Which of the pre-registered checks this is."""

    # One arm's repeats agreeing with each other within the declared tolerance.
    REPEATABILITY = "repeatability"
    # A candidate run against its paired baseline run, rule by rule.
    COMPARISON = "comparison"


class ArmResult(Contract):
    """What one arm measured, in the order its runs were attached."""

    arm: str = Field(min_length=1, max_length=128)
    runs: int = Field(ge=0)
    values: dict[str, list[float]] = Field(default_factory=dict)


class ResultCheck(Contract):
    """One pre-registered check, as the assessment already decided it."""

    kind: ResultCheckKind
    # The arm, for a repeatability check; "candidate vs baseline" and the pair's
    # position for a comparison.
    subject: str = Field(min_length=1, max_length=200)
    metric: str = Field(min_length=1, max_length=128)
    passed: bool
    reason: str = Field(min_length=1, max_length=400)
    # The numbers the decision was made on, as a person reads them.
    detail: str | None = Field(default=None, max_length=400)


class ConversationResults(Contract):
    """The assessment of a covered design, projected for someone about to decide.

    A projection and nothing more: every value is read from the assessment the
    lifecycle already computed, so this answer and the one that asks for a
    conclusion cannot disagree. It exists because a live study asked a person
    to accept or reject a result and showed them no number at all -- the
    verdict was one line in a folded list of blockers.
    """

    passed: bool
    reason: str = Field(min_length=1, max_length=2000)
    support: str = Field(min_length=1, max_length=64)
    support_reason: str = Field(default="", max_length=2000)
    arms: list[ArmResult] = Field(default_factory=list, max_length=16)
    checks: list[ResultCheck] = Field(default_factory=list, max_length=64)


class ConversationResponse(Contract):
    """One turn's answer: what happened, where it stands, and what may be done."""

    response_version: str = "conversation-response-v1"
    # Which capability the router chose, recorded so a surface -- or a reader
    # afterwards -- can see the branch rather than infer it from the message.
    capability: ConversationCapability
    # The category of help this answer represents. It is descriptive only; the
    # action list remains the sole typed authority a surface may render.
    intent: ConversationIntent = ConversationIntent.QUESTION
    # Read-only intent affordances for the current record-derived lifecycle.
    # These do not grant action authority or bypass approval pins.
    available_intents: list[ConversationIntent] = Field(default_factory=list)
    # Which bounded step the interpreted intent corresponds to, when one is open.
    #
    # A signpost, not an authority. `available_actions` is still the only list a
    # surface may act from, and this is derived from it for the steps that are
    # actions at all -- so an offer can never point at a door the records have
    # not opened. Set only by interpretation; an ordinary answer leaves it None
    # because nobody asked what they were trying to do.
    workflow: ConversationWorkflow | None = None
    # Why there is none, when an intent was interpreted and led nowhere.
    #
    # Typed for the same reason `refusal` is: a session that moved under the
    # interpreter is worth looking at again, and an intent this lifecycle does
    # not afford is not, and a surface cannot tell those apart from prose.
    workflow_unavailable: WorkflowUnavailable | None = None
    # The only prose here.
    message: str = Field(min_length=1, max_length=4000)
    # Absent only before a session exists. Never inferred from the message.
    session_id: str | None = Field(default=None, min_length=1)
    turn_state: TurnState | None = None
    # The proposal a person may accept, when one was made. Carried as the typed
    # document acceptance already validates, never as text to be re-parsed.
    proposal: dict[str, object] | None = None
    # Models on the person's ladder whose replies could not be used, each with
    # why, before the one that answered did (`relab_app.escalation`).
    passed_over: list[str] = Field(default_factory=list, max_length=6)
    # Why an action a person took did nothing, when one did nothing. Set only
    # when something was attempted and declined -- an answer to a question was
    # never refused, it was simply answered.
    #
    # It is a field rather than a sentence inside `message` because a surface has
    # to behave differently: an action that was refused because the session moved
    # on is re-offered from this same answer, and working that out by reading the
    # prose is exactly the coupling the rest of this contract exists to prevent.
    refusal: str | None = Field(default=None, min_length=1, max_length=2000)
    # What an action actually did, step by step, when it did anything.
    #
    # Carried because an answer that only said where a session now stands would
    # make a researcher infer what changed by comparing two screens. Empty is an
    # ordinary answer -- it is what "nothing here was mine to do" looks like, and
    # it is the answer to a question rather than the result of an action.
    performed: list[DriveStep] = Field(default_factory=list, max_length=MAXIMUM_PERFORMED)
    # Why the arms that are holding this up have no usable evidence, one per arm.
    #
    # A conversation that said "arm 'candidate' is blocked" and stopped there
    # would send a person off to another command to find out why, which is the
    # errand this surface exists to remove. The explanation is a projection of the
    # records -- what failed, how often, whether repeating it has stopped being a
    # plan -- and carries no judgement about what to do, because that is a
    # different layer and must not inherit the authority of a fact.
    failures: list[FailureExplanation] = Field(default_factory=list,
                                               max_length=MAXIMUM_BLOCKERS)
    # The change to a pre-registered policy a person is being asked to approve.
    #
    # Carried because offering "answer the amendment" without showing the
    # amendment would ask someone to agree to something they cannot read -- and
    # `moves_deciding_rules` on it is the part that says whether approving would
    # bar acceptance later. That field is written by the layer holding the plan,
    # never by whoever proposed the change, and it travels unchanged.
    amendment: ProposedAmendment | None = None
    # The decision to stop this session, when its records support one and nobody
    # has taken it.
    #
    # Carried for the same reason the amendment is: offering "confirm this" while
    # showing nothing to confirm asks somebody to agree to a decision they cannot
    # read. It carries its own alternatives, which is the part that makes
    # stopping a choice -- a person who can see that an arm was never asked to do
    # anything different is deciding; one who cannot is agreeing.
    conclusion: ProposedConclusion | None = None
    # The runs waiting on a person, as data.
    #
    # The lifecycle already renders these into `blockers` as "run_id: reason",
    # which is prose written for a person to read. Anything that has to *act* on
    # a gate reads this instead: taking a run id back out of a sentence is the
    # one thing no surface here does, and it is why `blocked_arms` exists too.
    gates: list[PendingHumanGate] = Field(default_factory=list, max_length=MAXIMUM_BLOCKERS)
    # Present when the instrument is what stopped this study.
    #
    # Carried because the alternative is what a live session did: report a
    # measurement that executed no check as "no uncovered arm can advance within
    # the selected attempt budget", and send a person to look at the budget, the
    # model or the task. None of those is the verifier. The arms did their part,
    # and running them again cannot repair the thing that measured them.
    measurement_blocker: MeasurementBlocker | None = None
    # Present when the ruler does not claim to check what the study declared.
    #
    # Carried beside the other one rather than folded into it, because the two
    # ask a person for different work: one needs a verifier that checks
    # something, the other needs one that says what it checks. Both are repaired
    # by replacing the measurement, and neither by running another arm.
    measurement_claim_blocker: MeasurementClaimBlocker | None = None
    # What the study's controls showed about its ruler, when it declared any.
    #
    # Reported rather than acted on. A control that showed nothing may mean a
    # blind instrument, a badly written control, or an expectation only a model
    # established, and those want different things from a person -- so this says
    # what happened and leaves the judgement where judgements are made.
    measurement_sensitivity: MeasurementSensitivity | None = None
    # What the covered design showed under its pre-registered rules, once there
    # is enough evidence to assess. Absent before then.
    results: ConversationResults | None = None
    blockers: list[str] = Field(default_factory=list, max_length=MAXIMUM_BLOCKERS)
    blocked_arms: list[str] = Field(default_factory=list, max_length=MAXIMUM_BLOCKERS)
    available_actions: list[ConversationAction] = Field(default_factory=list)
    # What any of this rests on, when it rests on evidence at all.
    evidence: list[EvidenceCitation] = Field(default_factory=list, max_length=MAXIMUM_CITATIONS)
    # What the attempts in this session wrote, and what became of it.
    #
    # Carried because "patch applied and verified" says something happened to a
    # person's code without saying what, and the errand this surface exists to
    # remove is the one that ends in a terminal. A projection of the recorded
    # evidence: which files, how much, and -- the part a card must not blur --
    # whether what was written is in the workspace now. A reverted attempt
    # produced evidence every bit as real and left nothing behind.
    #
    # The diff itself does not travel. It is on the record and a person asks for
    # it on some turns; putting it in every answer is a cost on all of them.
    changes: list[RunChange] = Field(default_factory=list, max_length=MAXIMUM_CHANGES)
    # An explicit, read-only exploration result. It is transient workspace data,
    # not research evidence and not an action the conversation may take.
    inspection: InspectionResult | None = None
    # The immutable workspace-local source for a future explicit plan-change request.
    inspection_context: InspectionContext | None = None
    # The session event this answer was built from. An action taken on the back of
    # it is pinned here, so one that arrives after the session moved on is refused
    # rather than applied to a session this answer never described.
    event_sequence: int | None = Field(default=None, ge=1)
    # And the plan revision in force when it was. Carried for the same reason and
    # checked alongside it: a plan revised between an answer and an action taken
    # on it is a different design, even when no new event was recorded.
    plan_revision: int | None = Field(default=None, ge=0)

    @model_validator(mode="after")
    def says_nothing_it_has_no_session_for(self) -> "ConversationResponse":
        if self.session_id is None and (self.turn_state is not None
                                        or self.blockers or self.blocked_arms
                                        or self.performed or self.failures
                                        or self.gates or self.changes
                                        or self.conclusion is not None
                                        or self.inspection is not None
                                        or self.event_sequence is not None
                                        or self.plan_revision is not None):
            raise ValueError("there is no session for that to be true of")
        if len(set(self.available_actions)) != len(self.available_actions):
            raise ValueError("an action is offered once")
        if self.workflow is not None and self.workflow_unavailable is not None:
            # One or the other. A step that is offered has no reason to be
            # unavailable, and a surface reading both would have to choose.
            raise ValueError("a workflow is either offered or explained away")
        return self
