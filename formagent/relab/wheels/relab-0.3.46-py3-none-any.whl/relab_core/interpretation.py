"""What a session's records let you say, and what they do not.

A report is the archival record: the policy, the evidence and the decision. An
interpretation is the next question — *given all that, what may be claimed?* It is
built only from the records, every claim names the run events behind it, and the
things the records cannot support are stated rather than left to be inferred from
their absence.

The sharpest rule here is a refusal. A session whose deciding rules moved once
results existed carries **no** findings at all. Without that, a moved goalpost
could be laundered into the memory store as a plain sentence, and the next plan
would read it with nothing attached to say where it came from.
"""

from enum import Enum

from pydantic import Field, model_validator

from relab_core.contracts import Contract
from relab_core.memory import MAXIMUM_CITATIONS, EvidenceCitation

MAXIMUM_CLAIMS = 32
# Bounded so an interpretation stays readable, and so its limits fit the
# conditions of the findings drafted from it.
MAXIMUM_LIMITS = 16
MAXIMUM_SCOPE_FACTS = 16


class ClaimKind(str, Enum):
    """What kind of statement this is. Both are about the measured world."""

    # What the declared comparison says about the designated arms.
    OUTCOME = "outcome"
    # What the repeats of one arm say about how much its numbers move.
    SPREAD = "spread"


class InterpretedClaim(Contract):
    """One thing the records support, and the exact events that support it."""

    kind: ClaimKind
    statement: str = Field(min_length=1, max_length=2000)
    # At least one: a claim that cites nothing is not a claim this layer can make.
    citations: list[EvidenceCitation] = Field(min_length=1, max_length=MAXIMUM_CITATIONS)


class SessionInterpretation(Contract):
    """Everything one session's records support, refuse, and cannot reach."""

    interpretation_version: str = "session-interpretation-v1"
    session_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    objective: str = Field(min_length=1)
    # The recorded terminal decision, when the session has one.
    decision: str | None = None
    claims: list[InterpretedClaim] = Field(default_factory=list, max_length=MAXIMUM_CLAIMS)
    # What these records do not let you say. Stated, because a caveat that lives
    # only in a report nobody re-reads is a caveat that stops travelling with the
    # finding the moment someone writes the finding down.
    limits: list[str] = Field(default_factory=list, max_length=MAXIMUM_LIMITS)
    # What is known about where any of this held: the model that reported, the code
    # revision, whether held-out data was ever opened. Facts for whoever has to
    # write the scope, not a scope invented here.
    scope_facts: list[str] = Field(default_factory=list, max_length=MAXIMUM_SCOPE_FACTS)
    # Whether anything here may be carried forward into research memory at all.
    carries_findings: bool = False
    # False for a reason, rather than merely having nothing yet. These are
    # different answers and a caller acts differently on each.
    refused: bool = False
    reason: str = Field(min_length=1)

    @model_validator(mode="after")
    def a_refusal_claims_nothing(self) -> "SessionInterpretation":
        if self.refused and (self.claims or self.carries_findings):
            raise ValueError("a refused interpretation states no claim and carries nothing")
        if self.carries_findings and not self.claims:
            raise ValueError("an interpretation carrying findings has at least one claim")
        if any(not item.strip() for item in [*self.limits, *self.scope_facts]):
            raise ValueError("a stated limit or scope fact must not be blank")
        return self
