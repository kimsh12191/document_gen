"""Persisted coding-task records; completion does not imply research completion."""

from datetime import datetime
from enum import Enum

from pydantic import Field, model_validator

from relab_core.coding.consumer import ReceivedCodingResult
from relab_core.coding.dependency import DependencyInstallDecision, DependencyInstallPolicy
from relab_core.coding.patch import PatchEvidence, PatchProposal, VerificationResult
from relab_core.contracts import Contract, HumanGate, RunState
from relab_core.dependency import DependencyInstallation
from relab_core.generation import ModelIdentity, TokenUsage
from relab_core.provenance import RunConditions
from relab_core.provider import ProviderIncident


class RestoreReason(str, Enum):
    """Why an attempt's applied edit was undone.

    Restoration is not a failure and not a rollback. The attempt succeeded, was
    measured, and was then taken back out of the workspace so the next thing to
    run starts where it did. Three different situations produce it, and telling
    a person "your code is gone" without saying which is how a working study
    reads as a broken one.

    Recorded when it happens rather than derived later. The reason is a fact
    about that moment -- which plan was in force, whether a checkout was
    available -- and a plan revised afterwards would make a later derivation
    confidently wrong.
    """

    # The plan asked for it by name: `restore_between_attempts`.
    PLAN_RESTORES_EACH_ATTEMPT = "plan_restores_each_attempt"
    # Derived. Several attempts create the same files and there is no revision
    # to check out, so undoing each one is what keeps the arms apart.
    ARMS_SHARE_ONE_TREE = "arms_share_one_tree"
    # Somebody asked for this edit to be taken back out.
    ASKED_FOR = "asked_for"


class CodingRun(Contract):
    run_id: str = Field(min_length=1)
    workspace: str
    objective: str = Field(min_length=1)
    request_id: str = Field(min_length=1)
    state: RunState = RunState.CREATED
    result: ReceivedCodingResult | None = None
    human_gate: HumanGate | None = None
    dependency_decision: DependencyInstallDecision | None = None
    dependency_policy: DependencyInstallPolicy | None = None
    dependency_installation: DependencyInstallation | None = None
    dependency_timeout_seconds: float | None = None
    patch_evidence: PatchEvidence | None = None
    execution_error: str | None = None
    # Why a provider call produced nothing usable, when that is what ended the
    # run. Set only for a failure at the provider, and read by the arm accounting
    # to decide whether one of the arm's repeats was spent: a truncated reply
    # produced no code, no patch and no measurement, so it is not an attempt at
    # producing evidence. See `relab_core.provider`.
    provider_incident: ProviderIncident | None = None
    # Why generation failed, when ReLab can say so safely: the message of a
    # `ModelTransportError`, which is ReLab's own sanitized sentence -- "generated
    # content has no final newline", not the provider's body or the prompt.
    # Nothing else is kept here; any other exception is recorded by its type in
    # `execution_error` only, as before. A live study's first attempt was refused
    # and its record said only "ModelTransportError", so which bound it missed
    # was lost with the reply.
    generation_failure_reason: str | None = Field(default=None, min_length=1, max_length=400)
    proposal: PatchProposal | None = None
    verify_argv: list[str] = Field(default_factory=list)
    generation_target: str | None = None
    generation_targets: list[str] = Field(default_factory=list)
    generation_calls: int = Field(default=0, ge=0, le=1)
    generation_timeout_seconds: float | None = None
    generation_model: ModelIdentity | None = None
    generation_usage: TokenUsage | None = None
    generation_reported_model: str | None = Field(default=None, min_length=1, max_length=256)
    # Captured when a patch starts; runs recorded before this field keep it unset.
    conditions: RunConditions | None = None
    # True once this attempt's applied edit was undone to restore the next attempt.
    restored: bool = False
    # Why it was undone. Absent on a run recorded before this was kept, which is
    # why `restored` remains the flag every reader checks: an old record knows
    # that it happened and cannot say why, and inventing a reason for it would
    # be worse than saying nothing.
    restore_reason: "RestoreReason | None" = None
    # A second measurement, kept apart from the verification selection reads.
    holdout_verification: VerificationResult | None = None
    # A persisted claim survives a worker dying before its measurement is recorded.
    holdout_argv: list[str] = Field(default_factory=list)
    holdout_timeout_seconds: float | None = None
    holdout_error: str | None = None
    holdout_abandon_reason: str | None = Field(default=None, min_length=1, max_length=2000)

    @model_validator(mode="after")
    def a_reason_means_it_happened(self) -> "CodingRun":
        # The one way the two could disagree. A reason for an undoing that did
        # not happen would make every reader choose which field to believe.
        if self.restore_reason is not None and not self.restored:
            raise ValueError("a restore reason belongs to a restoration that happened")
        return self


class PendingHumanGate(Contract):
    """One run waiting on a person, with the context needed to decide."""

    gate_id: str = Field(min_length=1)
    run_id: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    reason: str = Field(min_length=1)
    state: RunState
    event_sequence: int = Field(ge=1)


class HumanGateQueue(Contract):
    report_version: str = "human-gate-queue-v1"
    workspace: str = Field(min_length=1)
    gates: list[PendingHumanGate] = Field(default_factory=list)


class RunEvent(Contract):
    run_id: str
    sequence: int = Field(ge=1)
    kind: str
    timestamp: datetime
    snapshot: CodingRun
