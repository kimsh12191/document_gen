"""What a session's references say versus what the run history actually holds."""

from enum import Enum

from pydantic import Field

from relab_core.contracts import Contract


class ReconciliationDisposition(str, Enum):
    """What may be done about a finding right now, decided from evidence."""

    # Work is in progress: exclusion is held, so nothing here is interrupted.
    ACTIVE = "active"
    # Stored records alone settle it; no model, patch or verifier is involved.
    RECOVERABLE = "recoverable"
    # Only a person can decide, because no stored evidence settles it.
    MANUAL = "manual"


class ReconciliationKind(str, Enum):
    """Each value names one specific disagreement, never a general failure."""

    ACTIVE_RUN = "active_run"
    STALE_PIN = "stale_pin"
    INTERRUPTED_PATCH = "interrupted_patch"
    INTERRUPTED_HOLDOUT = "interrupted_holdout"
    STALLED_GENERATION = "stalled_generation"
    UNCLAIMED_REQUEST = "unclaimed_request"
    ORPHANED_REQUEST = "orphaned_request"
    AMBIGUOUS_REQUEST = "ambiguous_request"
    MISSING_RUN = "missing_run"
    MISSING_EVENT = "missing_event"
    FOREIGN_WORKSPACE = "foreign_workspace"


class ReconciliationFinding(Contract):
    kind: ReconciliationKind
    # A run id or a request id, depending on the kind.
    subject: str = Field(min_length=1)
    detail: str = Field(min_length=1)
    disposition: ReconciliationDisposition
    action: str = Field(min_length=1)
    resolved: bool = False


class ReconciliationSummary(Contract):
    """Counts of unresolved findings, so a caller sees the shape before the detail."""

    active: int = Field(default=0, ge=0)
    recoverable: int = Field(default=0, ge=0)
    manual: int = Field(default=0, ge=0)


class SessionReconciliation(Contract):
    report_version: str = "session-reconciliation-v1"
    session_id: str = Field(min_length=1)
    event_sequence: int = Field(ge=1)
    consistent: bool
    summary: ReconciliationSummary = Field(default_factory=ReconciliationSummary)
    findings: list[ReconciliationFinding] = Field(default_factory=list)
