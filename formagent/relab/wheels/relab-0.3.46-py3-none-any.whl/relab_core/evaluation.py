"""Versioned report for historical coding execution evidence, not research quality."""

from enum import Enum

from pydantic import Field, FiniteFloat, model_validator

from relab_core.contracts import Contract


class EvaluationVerdict(str, Enum):
    VERIFIED = "verified"
    FAILED = "failed"
    PENDING = "pending"
    UNVERIFIED = "unverified"


class DecisionSupport(str, Enum):
    """Whether this body of evidence can carry the conclusion somebody wants.

    A different question from whether the rules held, and a live session showed
    why they had been the same question. Ten readings were admitted, every
    pre-registered rule passed, and `pass_rate` took one value in all ten --
    because the verifier's only check was that the module imported, and both
    arms import. The rules held over evidence that distinguished nothing.

    "The rules held" is a fact about the rules. "The candidate is better" is a
    claim about the world, and it needs evidence that could have come out the
    other way.

        SUPPORTS_ACCEPTANCE  the comparison passed, and the deciding metric
                             varied, so it could have failed
        SUPPORTS_REJECTION   the comparison did not pass
        INCONCLUSIVE         the evidence is admissible and answers neither
    """

    SUPPORTS_ACCEPTANCE = "supports_acceptance"
    SUPPORTS_REJECTION = "supports_rejection"
    INCONCLUSIVE = "inconclusive"


class CodingEvaluation(Contract):
    evaluator_version: str = "coding-evidence-v1"
    run_id: str
    event_sequence: int = Field(ge=1)
    verdict: EvaluationVerdict
    reason: str
    patch_id: str | None = None
    executed_checks: int | None = None
    passed_checks: int | None = None
    failed_checks: int | None = None


class CodingMetrics(Contract):
    schema_version: str = "coding-metrics-v1"
    run_id: str
    event_sequence: int = Field(ge=1)
    patch_id: str
    source: str = "verification.stdout"
    metrics: dict[str, FiniteFloat] = Field(min_length=1)


class MetricDirection(str, Enum):
    MAXIMIZE = "maximize"
    MINIMIZE = "minimize"


class MetricRule(Contract):
    name: str = Field(pattern=r"^[A-Za-z_][A-Za-z0-9_.-]*$")
    direction: MetricDirection
    tolerance: FiniteFloat = Field(default=0, ge=0)
    repeatability_tolerance: FiniteFloat = Field(default=0, ge=0)


class MetricRegistry(Contract):
    registry_id: str = Field(min_length=1)
    rules: list[MetricRule] = Field(min_length=1)

    @model_validator(mode="after")
    def unique_rules(self) -> "MetricRegistry":
        names = [rule.name for rule in self.rules]
        if len(names) != len(set(names)):
            raise ValueError("metric rules must have unique names")
        return self


class MetricComparisonItem(Contract):
    name: str
    passed: bool
    reason: str
    candidate_value: FiniteFloat | None = None
    baseline_value: FiniteFloat | None = None
    # A decimal string avoids overflow for differences between finite floats.
    delta: str | None = None


class MetricComparison(Contract):
    evaluator_version: str = "metric-regression-v1"
    registry: MetricRegistry
    candidate: CodingMetrics
    baseline: CodingMetrics
    passed: bool
    items: list[MetricComparisonItem]


class RepeatabilityItem(Contract):
    name: str
    passed: bool
    reason: str
    missing_run_ids: list[str] = Field(default_factory=list)
    minimum: FiniteFloat | None = None
    maximum: FiniteFloat | None = None
    spread: str | None = None


class RepeatabilityReport(Contract):
    evaluator_version: str = "metric-repeatability-v1"
    registry: MetricRegistry
    minimum_runs: int = Field(ge=2)
    samples: list[CodingMetrics]
    passed: bool
    reason: str
    items: list[RepeatabilityItem]
