"""What went wrong with a provider call, as a value rather than as a sentence.

`repeats_per_arm = 3` means "run this arm to a measurable state three times and
look at the spread". It does not mean "call the API at most three times". Those
two readings were being served by one counter, and a live session showed what
that costs:

    arm repeat 1
      -> provider hit its output limit
      -> no generation, no patch, no code
      -> the verifier never ran
      -> no evidence of any kind
      -> nevertheless: "attempt 1 consumed"

Recorded that way it reads as *the baseline implementation failed*, when what
happened is *the provider did not produce an implementation*. Those are different
claims about different things, and only one of them is about the experiment.

## Where an attempt begins

    provider call                    not necessarily an attempt
            |
    a PatchProposal exists   <------ the attempt begins here
            |
    applied, verifier ran            it produces measurement evidence

Every incident below happens *before* that line. None of them spends a repeat --
including the two where the model answered. A refusal is a real answer and not a
measurement: no patch was proposed, nothing ran, no number came back. A repeat
that produced no number is not one of the three a design asked for.

An earlier version of this file put refusals on the other side, and contradicted
its own invariant one paragraph later. The rule is easier to keep than the
exception was: **only a call that produced a proposal spends a repeat.**

## Why it is an enum, and why three kinds

The boundary cannot be drawn on the exception type: a provider that timed out and
a model that declined both arrive as `ModelTransportError`. Reading the message
to tell them apart would put a research accounting rule at the mercy of a
reworded sentence.

Three kinds, because the remedies differ:

    TRANSIENT       timeout, output_limit, transport, incomplete
                    worth trying again

    MODEL_OUTCOME   refused, tool_call, unusable_content
                    the model answered; the same prompt gets the same answer,
                    so retrying is asking a question already answered

    POLICY          content_filter
                    neither, and retrying it automatically is a way of arguing
                    with it

## Why none of this is free

If incidents cost nothing, a provider having a bad afternoon retries without
bound. Each kind spends a budget of its own, and all of them are recorded:

    repeats_per_arm                     measured attempts
    max_transport_failures_per_arm      transient
    max_generation_failures_per_arm     model outcome
    (policy)                            no automatic retry at all

Afterwards the questions have separate answers: how many times was this arm
measured, how many calls were lost to the wire, how many times did the model
decline. Only the first is about the experiment.
"""

from enum import Enum


class IncidentKind(str, Enum):
    """What kind of thing went wrong, which decides what may be done about it.

    Three, because the remedies differ. A transient failure is worth trying
    again. A model that answered will answer the same way to the same prompt, so
    trying again is asking a question already answered. A policy boundary is
    neither, and retrying one automatically is a way of arguing with it.
    """

    TRANSIENT = "transient"
    MODEL_OUTCOME = "model_outcome"
    POLICY = "policy"


class ProviderIncident(str, Enum):
    """Why a provider call produced nothing usable.

    Closed, because each value decides which budget was spent and that is not a
    judgement to make from prose.
    """

    # --- the wire, or a reply that never finished ------------------------------
    TIMEOUT = "timeout"
    # The reply was cut off by the token limit: no complete output exists.
    OUTPUT_LIMIT = "output_limit"
    # Connection failure, unreadable body, a malformed envelope.
    TRANSPORT = "transport"
    # A reply that stopped for a reason the provider did not name, or with no
    # text at all. Nothing was said, so nothing can be judged.
    INCOMPLETE = "incomplete"

    # --- the model's own answer -----------------------------------------------
    # It understood and declined. A real answer, and not a measurement: no patch
    # was proposed, so nothing was run and nothing was measured.
    REFUSED = "refused"
    # It tried to call a tool this gateway does not offer -- a real reply, in a
    # shape the contract does not take.
    TOOL_CALL = "tool_call"
    # A real reply whose content cannot become a patch: not the contracted
    # object, larger than a file may be, or text that is not bounded text -- no
    # final newline, a NUL byte. The call completed and the model answered; what
    # came back is on the near side of the line above, because no proposal exists
    # and so nothing was applied, run or measured.
    #
    # Found live: an arm two identical failures into being stuck spent its third
    # attempt on a reply with no trailing newline, and the `ValueError` that
    # raised left the arm loop and ended the session -- one attempt short of the
    # question it was there to ask.
    UNUSABLE_CONTENT = "unusable_content"

    # --- the provider's policy -------------------------------------------------
    CONTENT_FILTER = "content_filter"


class RequestRefusal(str, Enum):
    """What a provider's refusal of a request (an HTTP 4xx) was about, when its
    body says so in words a server uses (RL-05).

    Closed, and read from the body without keeping it: the body is the
    provider's words. Told apart because each needs a different answer -- a
    prompt too long for the model is not a feature it lacks, and turning tool
    calls off for it only made the next call fail the same way.
    """

    # The prompt is past the model's context window (vLLM: "maximum context length").
    CONTEXT_LENGTH = "context_length"
    # Tool calls are not taken (vLLM without `--enable-auto-tool-choice`).
    TOOLS = "tools"
    # A structured-output schema (`response_format`) is not taken.
    SCHEMA = "schema"
    # Images are not taken: a model that reads text only (0.3.29). Not the tools:
    # taken for them, a picture sent to such a model turned tool calls off for
    # every later loop on that server.
    IMAGES = "images"


KIND: dict[ProviderIncident, IncidentKind] = {
    ProviderIncident.TIMEOUT: IncidentKind.TRANSIENT,
    ProviderIncident.OUTPUT_LIMIT: IncidentKind.TRANSIENT,
    ProviderIncident.TRANSPORT: IncidentKind.TRANSIENT,
    ProviderIncident.INCOMPLETE: IncidentKind.TRANSIENT,
    ProviderIncident.REFUSED: IncidentKind.MODEL_OUTCOME,
    ProviderIncident.TOOL_CALL: IncidentKind.MODEL_OUTCOME,
    ProviderIncident.UNUSABLE_CONTENT: IncidentKind.MODEL_OUTCOME,
    ProviderIncident.CONTENT_FILTER: IncidentKind.POLICY,
}


def produced_an_attempt(incident: ProviderIncident | None) -> bool:
    """Whether this provider call produced an attempt at evidence at all.

    Named for the provider call, because "attempt" alone has come to mean three
    things in this codebase -- an implementation attempt, an experimental
    repeat, and a call to a provider -- and this function knows about exactly
    one of them. Whether an attempt goes on to spend an experimental slot is a
    wider question, asked of the whole run in `relab_core.accounting`.

    An earlier version put a refusal on the other side of this line, reasoning
    that a model which answered had produced an outcome. It had -- but not a
    measurement. No patch was proposed, nothing was applied, no verifier ran, and
    `repeats_per_arm` counts measured attempts. A repeat that produced no number
    is not one of the three the design asked for.

    `None` means the call came back and something later went wrong: a patch that
    would not apply, a verifier that failed. Those *are* the experiment, and an
    attempt was made whatever the verdict.
    """
    return incident is None


def kind_of(incident: ProviderIncident) -> IncidentKind:
    return KIND[incident]
