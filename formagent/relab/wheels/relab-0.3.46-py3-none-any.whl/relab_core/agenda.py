"""Where every session in this workspace stands, in one answer.

Reopening the editor asks one question: *where was I?* Nothing is held between
sessions to answer it -- the answer is derived from the records every time, which
is what makes closing the editor cost nothing and reopening it lose nothing.

The order is the point. Sessions waiting on a person come first, because those
are the ones nothing will move without them; then what was refused, then what can
be run, then what is already running, then what is finished. It is a fixed order
over the turn states, not a judgement about which experiment matters more.
"""

from pydantic import Field, model_validator

from relab_core.contracts import Contract
from relab_core.next_action import NextAction
from relab_core.turns import TurnState

MAXIMUM_ENTRIES = 500

# Most in need of someone first. A total order, so the same workspace lists the
# same way twice and a person can rely on the top of the list.
AGENDA_ORDER = (
    TurnState.AWAITING_HUMAN,
    TurnState.FAILED,
    TurnState.ACTION_QUEUED,
    TurnState.ACTION_RUNNING,
    TurnState.WAITING_EXTERNAL,
    TurnState.COMPLETE,
)


class AgendaEntry(Contract):
    """One session's place in the list, or why it could not be given one."""

    session_id: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    # Absent only when reading it failed; one unreadable session must not hide
    # the rest, so it is listed with its reason rather than dropped or fatal.
    action: NextAction | None = None
    unreadable: str | None = Field(default=None, min_length=1, max_length=2000)

    @model_validator(mode="after")
    def read_or_explained(self) -> "AgendaEntry":
        if (self.action is None) == (self.unreadable is None):
            raise ValueError("an entry carries either what to do next or why it is unknown")
        return self

    @property
    def state(self) -> TurnState | None:
        return None if self.action is None else self.action.turn_state


class WorkspaceAgenda(Contract):
    """Every session, ordered by how much it needs someone."""

    agenda_version: str = "workspace-agenda-v1"
    workspace: str = Field(min_length=1)
    entries: list[AgendaEntry] = Field(default_factory=list, max_length=MAXIMUM_ENTRIES)
    # Sessions whose next step is a person's. Counted rather than left to be
    # totalled by whoever renders the list, so every surface agrees.
    awaiting_human: int = Field(default=0, ge=0)
    # Sessions that could not be read at all. Separate from awaiting_human,
    # because "nobody knows" and "somebody is needed" call for different things.
    unreadable: int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def counted_from_what_is_listed(self) -> "WorkspaceAgenda":
        awaiting = sum(1 for item in self.entries if item.state is TurnState.AWAITING_HUMAN)
        unknown = sum(1 for item in self.entries if item.action is None)
        if (self.awaiting_human, self.unreadable) != (awaiting, unknown):
            raise ValueError("an agenda's counts must match the entries it lists")
        return self

    @property
    def settled(self) -> bool:
        """Whether nothing here needs anyone. Not the same as everything passing."""
        return all(item.state is TurnState.COMPLETE for item in self.entries)
