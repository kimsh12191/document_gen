"""What a run cost the experiment, as distinct from what happened in it.

`repeats_per_arm` counts measured attempts. Three things can end a run without
one, and they had been telling the arm's budget three different stories:

    the provider produced nothing   already accounted for, and does not spend
    the measurement was invalid     new here, and does not spend
    the arm was measured            spends, whatever the number said

The middle one is what a live session found. A verifier ReLab had asked a model
to write executed no check, printed the floor value, and every arm was charged
one of its repeats for it -- so a study with three repeats spent six
implementations proving that one broken ruler was still broken.

Why retrying cannot help is the part worth stating. The verifier is owned by the
plan and frozen before any arm runs, which is what makes the arms comparable: one
instrument, unchanged, for every reading. So a measurement that breaks its
contract breaks it for the whole study, and the next attempt will be measured by
the same file. Spending an arm's budget on that is not caution, it is arithmetic
about a conclusion that is already available.
"""

from relab_core.measurement import MeasurementReading
from relab_core.provider import produced_an_attempt
from relab_core.runs import CodingRun


def spends_experimental_slot(run: CodingRun, reading: MeasurementReading | None) -> bool:
    """Whether this run cost the arm one of the repeats its design asked for.

    The reading is the one the readiness projection took of this run, or None
    for a run that never reached a measurement to read. None does not excuse
    the slot: a patch that would not apply and a verifier that said no are both
    the experiment happening, and they spend a repeat whatever the verdict.
    """
    if not produced_an_attempt(run.provider_incident):
        return False
    return reading is None or reading.usable
