"""How a turn ends.

Every turn of work ends in one of these. There is deliberately no state meaning
"said something and stopped": a collaborator that answers and leaves nothing
running, queued, waiting or finished has not collaborated, it has commented.

The legacy client carries `loopDetector.ts`, whose own comment records a director
that asked the same question for over twenty turns and created nothing. That is
what an unrepresented state looks like from the outside, and the remedy is that
there is nowhere here to put it.
"""

from enum import Enum


class TurnState(str, Enum):
    # Something is running now, started by this turn or still going from before.
    ACTION_RUNNING = "action_running"
    # Something may be performed without asking anyone; nothing is stopping it.
    ACTION_QUEUED = "action_queued"
    # A person has to decide before anything else can happen.
    AWAITING_HUMAN = "awaiting_human"
    # Waiting on something outside this workspace: a provider, a machine, a queue.
    WAITING_EXTERNAL = "waiting_external"
    # There is nothing left to do here.
    COMPLETE = "complete"
    # This turn's work failed and is not retriable without a change.
    FAILED = "failed"
