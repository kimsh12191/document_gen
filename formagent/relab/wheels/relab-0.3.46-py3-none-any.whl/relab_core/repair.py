"""What a failure was, and what has already been tried against it.

ReLab already tells a replacement attempt about the one before it. What it could
not say is that the *same* failure has now happened three times, and which
approaches produced it -- so a third attempt could repeat the first one's mistake
with no way of knowing.

Two failures are "the same" when their fingerprints match. The fingerprint is
deliberately conservative: it errs toward calling two failures different, because
claiming a session is stuck when it is progressing would stop work that was
getting somewhere, and the cost of missing a repeat is only that a person is told
later than they might have been.
"""

from pydantic import Field, model_validator

from relab_core.contracts import Contract

MAXIMUM_ATTEMPTS = 32
# Enough repeats of one failure to say something is not working. Two could be
# coincidence -- the same flake twice; three of the same thing is a pattern.
STUCK_AFTER = 3


class FailureFingerprint(Contract):
    """What makes two failures the same failure."""

    fingerprint_version: str = "failure-fingerprint-v1"
    # A digest of the normalised output, so the fingerprint is short enough to
    # compare and carries nothing a person would have to read.
    digest: str = Field(min_length=8, max_length=64)
    exit_code: int | None = None
    timed_out: bool = False
    # The normalised text the digest was taken over, kept so a person can see
    # *why* two failures were called the same, rather than trusting a hash.
    signature: str = Field(default="", max_length=4000)


class RepairAttempt(Contract):
    """One attempt that produced no usable evidence, and what it failed with."""

    run_id: str = Field(min_length=1)
    # The pinned event, so an attempt can be cited and gone and looked at. A
    # run id alone names a run, not the state of it anyone was reading.
    event_sequence: int = Field(ge=1)
    arm: str = Field(min_length=1)
    # Absent when the attempt failed before producing a verification to fingerprint.
    fingerprint: FailureFingerprint | None = None
    # Identity of the edit this attempt proposed, up to how it was written down.
    # Absent when no patch was produced. Two attempts failing the same way from
    # the same edit is a model repeating itself; from different edits it is a
    # model exploring a space where everything fails alike. Different problems.
    patch_digest: str | None = Field(default=None, min_length=8, max_length=64)
    reason: str = Field(min_length=1, max_length=2000)


class RepairHistory(Contract):
    """Every failed attempt for one arm, and whether they are the same failure."""

    history_version: str = "repair-history-v1"
    session_id: str = Field(min_length=1)
    arm: str = Field(min_length=1)
    attempts: list[RepairAttempt] = Field(default_factory=list, max_length=MAXIMUM_ATTEMPTS)

    @model_validator(mode="after")
    def one_arm(self) -> "RepairHistory":
        if any(item.arm != self.arm for item in self.attempts):
            raise ValueError("a repair history holds the attempts of one arm")
        if len({item.run_id for item in self.attempts}) != len(self.attempts):
            raise ValueError("a run appears in a repair history once")
        return self

    @property
    def repeated(self) -> dict[str, int]:
        """How many times each distinct failure has occurred, by digest."""
        counts: dict[str, int] = {}
        for item in self.attempts:
            if item.fingerprint is not None:
                counts[item.fingerprint.digest] = counts.get(item.fingerprint.digest, 0) + 1
        return counts

    @property
    def stuck_on(self) -> str | None:
        """The failure this arm keeps hitting, if there is one.

        Not "has failed a lot" -- the *same* failure, enough times that trying the
        same thing again is not a plan. A run of different failures is an arm
        making progress through them.
        """
        for digest, count in self.repeated.items():
            if count >= STUCK_AFTER:
                return digest
        return None

    def matching(self, digest: str) -> list[RepairAttempt]:
        """The attempts that failed this exact way, in the order they happened."""
        return [item for item in self.attempts
                if item.fingerprint is not None and item.fingerprint.digest == digest]
