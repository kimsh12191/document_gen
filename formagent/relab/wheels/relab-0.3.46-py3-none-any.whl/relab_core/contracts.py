"""Initial shared lifecycle. Legacy wire contracts remain versioned independently."""

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class Contract(BaseModel):
    model_config = ConfigDict(extra="forbid")


class RunState(str, Enum):
    CREATED = "created"
    RUNNING = "running"
    AWAITING_HUMAN = "awaiting_human"
    AWAITING_DEPENDENCY = "awaiting_dependency"
    DEPENDENCY_INSTALLED = "dependency_installed"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class HumanGate(Contract):
    gate_id: str = Field(min_length=1)
    run_id: str = Field(min_length=1)
    reason: str = Field(min_length=1)
    resolved: bool = False


class ExecutionRequest(Contract):
    run_id: str = Field(min_length=1)
    workspace: str = Field(min_length=1)
    argv: list[str] = Field(min_length=1)
    timeout_seconds: float = Field(default=60, gt=0, le=3600)


class ExecutionResult(Contract):
    run_id: str
    state: RunState
    returncode: int | None
    stdout: str
    stderr: str
