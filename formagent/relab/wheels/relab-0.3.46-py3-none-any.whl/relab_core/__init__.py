"""Provider-independent contracts for the incremental ReLab migration."""

