"""What a stopped session could do instead, as things that can be chosen.

The alternatives were sentences. A person read "this arm has only ever been
asked to do one thing", agreed that was worth trying, and then went looking for
the command that would do it -- which is the errand the conversation exists to
remove, arriving at the exact moment somebody is deciding whether to give up.

**Nothing here generates alternatives.** They are the same facts the records
already supported, given an identity so they can be pointed at. There is no
candidate-space engine, no ranking, and no notion of a best one: a bounded list
of what is available is the whole claim, and an optimiser would be answering a
question nobody asked.

**Choosing one is not performing it.** Each executable alternative resolves to a
`ProposedAmendment`, which a person then reads and approves through the path
that already exists. Selecting means "show me that change", not "make it" -- so
nothing reaches the plan without having been read, and this module adds no way
to change a plan that was not already there.
"""

from enum import Enum

from pydantic import Field, model_validator

from relab_core.contracts import Contract

# Bounded like every other list a surface renders.
MAXIMUM_ALTERNATIVES = 8


class AlternativeAction(str, Enum):
    """The closed set of things a stopped session offers instead of stopping.

    Closed for the same reason every other vocabulary here is: a surface renders
    what it recognises, so an action named outside this set produces nothing.
    """

    # Ask one arm to attempt something different. Resolves to the retask an
    # advisor proposes, which is C3.2's path and its approval.
    RETASK_ARM = "retask_arm"
    # Ask the design for more usable runs per arm, which also buys the attempts
    # to get them. An amendment that demands more evidence, so it moves no
    # goalpost and leaves the session acceptable on its merits.
    INCREASE_REPEATS = "increase_repeats"
    # Try a different model. Visible here and not performed here: choosing a
    # model per role, with the provenance and the budget that implies, is C6.
    # Leaving it out entirely would hide a real option; making it executable
    # here would put model routing inside the candidate space.
    CHANGE_MODEL = "change_model"


# What this layer can turn into a change a person may approve. The rest are real
# options that are answered somewhere else, and the difference is a fact about
# how much is built rather than about what the session affords.
PERFORMABLE: frozenset[AlternativeAction] = frozenset({
    AlternativeAction.RETASK_ARM, AlternativeAction.INCREASE_REPEATS,
})


class Alternative(Contract):
    """One thing a session could do instead of stopping, and how to ask for it."""

    alternative_version: str = "alternative-v1"
    # Stable for as long as the alternative is: re-derived from the same state it
    # was offered from, it comes out the same, and a selection is matched against
    # a fresh derivation rather than trusted from the request. Deliberately not
    # a digest -- "what was offered and what was chosen" has to be legible in the
    # record later, and an opaque id makes that a lookup nobody performs.
    alternative_id: str = Field(min_length=1, max_length=200)
    action: AlternativeAction
    # Which arm, for the alternatives that are about one.
    arm: str | None = Field(default=None, min_length=1)
    # What it is, in the language of what a person may record. Never advice:
    # explaining, interpreting and deciding stay three layers, and a
    # recommendation rendered beside a fact borrows its authority.
    rationale: str = Field(min_length=1, max_length=2000)
    # The answer this was offered from. An alternative chosen against a session
    # that has moved on is refused, and this is what that is checked against.
    source_event_sequence: int = Field(ge=1)

    @model_validator(mode="after")
    def names_an_arm_when_it_is_about_one(self) -> "Alternative":
        if (self.action is AlternativeAction.RETASK_ARM) != (self.arm is not None):
            raise ValueError("retasking is about one arm; nothing else is about an arm")
        if self.alternative_id != identify(self.action, self.arm):
            raise ValueError("an alternative's id is derived from what it is, not chosen")
        return self

    @property
    def performable(self) -> bool:
        """Whether choosing this here turns into a change a person may approve."""
        return self.action in PERFORMABLE


def identify(action: AlternativeAction, arm: str | None) -> str:
    """The id of this alternative, derived so both sides compute the same one.

    It does not include the event it was offered at. An id that changed whenever
    anything happened would make every selection stale, and staleness is already
    checked -- by the pin every action carries, against the answer that offered
    it. Two different questions, and one of them is not the id's.
    """
    return action.value if arm is None else f"{action.value}:{arm}"
