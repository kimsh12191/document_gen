"""Testing the ruler: what it must be able to tell apart, declared in advance.

MQ1 asks whether the instrument *says* it checks what the study needs. That is
a weak signal by construction -- the claim is written by the same pipeline that
writes the arms -- and its value is asymmetric: not claiming is a strong
finding, claiming is a cheap sentence. A verifier that imports a module and
declares both requirements reaches `FULLY_CLAIMED`, and a test is named after
that limit.

This is what could earn the word the other axis cannot: a ruler shown to
separate something it ought to separate.

    MQ1   did it say it checks this
    MQ2   did it actually tell a broken one from a working one

## Where the strength comes from, and where it does not

A control is two subjects and an expected relation between their measurements.
The subjects matter less than the relation. If the same model writes the
verifier, writes the good subject, writes the broken one *and* declares which
should score higher, then two files scoring differently proves only that the
model was internally consistent -- it could have written all four to agree.

So provenance is part of the contract, and it is about the *expectation* more
than about the subject. A control whose expected relation nobody but a model
established may be run, and it may not earn a demonstration. What earns one is
an expectation a person approved, or one that follows from a named,
deterministic change.

## Why this is not part of the measurement

`MeasurementSetup` is instrument identity, frozen into the snapshot every
reading is pinned to. A control is not a component of the instrument; it is a
design for testing one, and it sits beside the requirements for the same
reason those do:

    changing a control       changes what sensitivity has been shown
    changing the instrument  retires every reading taken under it

Those must not be the same act, and a type that lived inside the setup would
make them one.
"""

from enum import Enum

from pydantic import Field, model_validator

from relab_core.contracts import Contract

# A control subject is a file a verifier measures, carried in the plan so the
# control is pre-registered rather than assembled when somebody runs it. Bounded
# because a plan is a document a person reads and argues with.
MAXIMUM_SUBJECT_BYTES = 8192
# Enough to aim at every requirement a design may declare, twice.
MAXIMUM_CONTROLS = 32


class ControlSubjectOrigin(str, Enum):
    """Where a control's file came from."""

    # A person wrote it, or brought it.
    USER_PROVIDED = "user_provided"
    # Taken from something already recorded in this workspace.
    RECORDED_REFERENCE = "recorded_reference"
    # Produced from the good subject by a named, mechanical change.
    DETERMINISTIC_DERIVATION = "deterministic_derivation"
    # A model wrote it.
    MODEL_PROPOSED = "model_proposed"


class ExpectationAuthority(str, Enum):
    """Who established that one subject should measure better than the other.

    The axis that decides whether a demonstration can be earned, and separate
    from who wrote the files. A model may draft a control; a model alone may not
    also be the thing that says which way the answer should come out.
    """

    # Somebody looked at both subjects and agreed which should score better.
    HUMAN_APPROVED = "human_approved"
    # It follows from the named change rather than from anybody's opinion: a
    # subject that had its subtraction replaced by addition must measure worse
    # under a rule that checks subtraction.
    #
    # **Not mintable from a derivation.** `DETERMINISTIC_DERIVATION` says how the
    # broken subject was produced, which is mechanical and checkable by reading
    # it. This says the change must make the measurement worse, which needs the
    # requirement's meaning -- and ReLab deliberately does not parse a
    # requirement statement, so there is no oracle here that could establish it.
    # A mechanical change unrelated to the requirement is still a mechanical
    # change, and it would demonstrate nothing.
    #
    # So nothing issues this automatically today. A planner's reply is forced to
    # `MODEL_PROPOSED` at the boundary that reads it, and earning this will take
    # an oracle that does not exist yet rather than a file that was edited by a
    # rule.
    DETERMINISTIC = "deterministic"
    # A model said so, and nothing else did.
    MODEL_PROPOSED = "model_proposed"

    @property
    def earns_demonstration(self) -> bool:
        """Whether a separation observed under this authority may be believed.

        A model that wrote the verifier, both subjects and the expected relation
        could have written all four to agree, so an observed difference says
        they agree and not that the ruler is sensitive. The run still happens
        and the numbers are still recorded -- what it cannot do is earn the
        word.
        """
        return self is not ExpectationAuthority.MODEL_PROPOSED


class ControlSubject(Contract):
    """One file a control measures, as the plan pre-registered it."""

    path: str = Field(min_length=1, max_length=1024)
    content: str = Field(min_length=1, max_length=MAXIMUM_SUBJECT_BYTES)
    origin: ControlSubjectOrigin
    # What was changed to make this one, for a derived subject. Read by a person
    # deciding whether the derivation is the reason the numbers differ.
    derivation: str | None = Field(default=None, min_length=1, max_length=400)

    @model_validator(mode="after")
    def derived_subjects_say_how(self) -> "ControlSubject":
        derived = self.origin is ControlSubjectOrigin.DETERMINISTIC_DERIVATION
        if derived and self.derivation is None:
            raise ValueError("a derived control subject names the change that made it")
        return self


class ControlProvenance(Contract):
    """Where a control came from, and what may be concluded because of it."""

    good_origin: ControlSubjectOrigin
    bad_origin: ControlSubjectOrigin
    # The one that decides whether a separation earns anything.
    expectation_authority: ExpectationAuthority


class SensitivityExpectation(Contract):
    """How far apart the two subjects must measure for this to have shown anything.

    A metric and a distance, and the direction comes from the registry rule of
    that name rather than being restated here -- a control declaring its own
    direction could disagree with the study it is calibrating, and then nobody
    could say which one the measurement was judged by.

    Deliberately not `compare_metrics`. That rule asks whether a candidate is no
    worse than a baseline, so two identical readings satisfy it -- which is the
    exact opposite of the question here. A ruler that cannot tell the subjects
    apart produces identical readings, and this has to notice.
    """

    metric: str = Field(pattern=r"^[A-Za-z_][A-Za-z0-9_.-]*$")
    # How much better the good subject must measure than the broken one. Strictly
    # positive: a separation of zero is satisfied by a ruler that measures
    # nothing, which is the state this exists to detect.
    minimum_separation: float = Field(gt=0)


class MeasurementControl(Contract):
    """Two subjects, one requirement, and the difference the ruler must show.

    One requirement each, in this version and on purpose. A broken subject that
    breaks two requirements at once produces a lower reading and no way to say
    which of the two the ruler noticed -- so "REQ-ADD is demonstrated and
    REQ-SUBTRACT is not" would stop being sayable, and that sentence is the
    whole point of declaring controls per requirement.
    """

    control_id: str = Field(pattern=r"^[A-Z][A-Z0-9]*(-[A-Z0-9]+)*$",
                            min_length=2, max_length=48)
    # The requirement this control is aimed at, which the plan declares.
    requirement_id: str = Field(min_length=2, max_length=48)
    good_subject: ControlSubject
    bad_subject: ControlSubject
    expectation: SensitivityExpectation
    provenance: ControlProvenance

    @model_validator(mode="after")
    def two_subjects_that_differ(self) -> "MeasurementControl":
        if self.good_subject.path != self.bad_subject.path:
            # The verifier measures a path. Two subjects at different paths are
            # not two versions of the thing under test, they are two things.
            raise ValueError("a control's subjects are two versions of one file")
        if self.good_subject.content == self.bad_subject.content:
            raise ValueError("a control's subjects must differ")
        if self.provenance.good_origin is not self.good_subject.origin:
            raise ValueError("the provenance must agree with the good subject's origin")
        if self.provenance.bad_origin is not self.bad_subject.origin:
            raise ValueError("the provenance must agree with the broken subject's origin")
        return self


def controls_named_once(
    controls: "list[MeasurementControl] | None",
) -> "list[MeasurementControl] | None":
    """The declared controls, refusing the shapes that mean nothing.

    Absent is not empty, the same rule requirements keep: a plan that declared
    no controls has not been calibrated, and one declaring an empty list would
    be claiming something nobody wrote down.
    """
    if controls is None:
        return None
    if not controls:
        raise ValueError("declare at least one measurement control, or none at all")
    named = [item.control_id for item in controls]
    if len(set(named)) != len(named):
        raise ValueError("a measurement control is declared once")
    return controls
