"""Non-authoritative, user-visible conversation history.

These records are never instructions to execute an action. Current research
state and action pins must always be obtained from the research session.
"""

from datetime import datetime
from typing import Literal

from pydantic import Field

from relab_core.contracts import Contract


class ConversationMessage(Contract):
    history_version: Literal["conversation-history-v1"] = "conversation-history-v1"
    thread_id: str = Field(min_length=1, max_length=200)
    sequence: int = Field(ge=1)
    role: Literal["user", "assistant"]
    text: str = Field(min_length=1, max_length=100_000)
    timestamp: datetime
    session_id: str | None = Field(default=None, min_length=1, max_length=200)


class ConversationHistoryTurn(Contract):
    """The two text parts of one successful conversational exchange."""

    user_text: str = Field(min_length=1, max_length=100_000)
    assistant_text: str = Field(min_length=1, max_length=100_000)
