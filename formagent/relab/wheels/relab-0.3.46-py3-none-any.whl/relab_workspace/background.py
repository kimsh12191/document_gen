"""Background programs a coding loop starts in this workspace: where they log, how they stop.

The process itself is the execution package's (`relab_execution.background`),
which the application layer does not reach; this is the workspace's side of
it -- the log under `.relab/processes/`, and the sandbox policy each kind of
command gets.
"""

from pathlib import Path

from relab_core.coding.sandbox import NetworkPolicy, SandboxBackend, SandboxPolicy
from relab_execution.background import BackgroundProcess, kill_tree
from relab_execution.job import alive, exit_code, start_job
from relab_execution.output_text import output_text
from relab_execution.sandbox import LOCAL_VERIFY_ENV_ALLOWLIST
from relab_workspace.private_state import state_dir

__all__ = ["BackgroundProcess", "alive", "exit_code", "job_exit_file", "kill_tree", "output_text", "process_log",
           "start_background", "start_command", "start_kept"]


def process_log(workspace: Path, loop_id: str, name: str) -> Path:
    return state_dir(workspace) / "processes" / f"{loop_id}-{name}.log"


def job_exit_file(workspace: Path, loop_id: str, name: str) -> Path:
    return state_dir(workspace) / "processes" / f"{loop_id}-{name}.exit"


def start_kept(workspace: Path, argv: list[str], log: Path, exit_file: Path, *,
               extra_environment: "list[str] | tuple[str, ...]" = ()) -> int:
    """Start `argv` as a job that outlives this process (P5); its runner's pid."""
    policy = SandboxPolicy(backend=SandboxBackend.LOCAL_PROCESS, network=NetworkPolicy.INHERIT,
                           environment_allowlist=[*LOCAL_VERIFY_ENV_ALLOWLIST,
                                                  *extra_environment])
    return start_job(argv, workspace=workspace, log=log, exit_file=exit_file, policy=policy,
                     environment={"PYTHONUNBUFFERED": "1"})


def start_command(home: Path, argv: list[str], *, log: Path, out_file: Path, err_file: Path,
                  exit_file: Path, extra_environment: "list[str] | tuple[str, ...]" = ()) -> tuple[int, Path]:
    """Start one command of a coding loop under the job runner, seeing what a verifier
    sees -- `home` as its import root, Python's caches kept out of the workspace -- so
    that, past its time, it can go on as a job rather than be stopped (0.2.70).
    The runner's pid, and the cache folder to remove once it ended."""
    import tempfile

    from relab_workspace.verifier_environment import IMPORT_PATH_ENV_VAR, import_root

    cache = Path(tempfile.mkdtemp(prefix="relab-verify-pycache-"))
    policy = SandboxPolicy(backend=SandboxBackend.LOCAL_PROCESS, network=NetworkPolicy.INHERIT,
                           environment_allowlist=[*LOCAL_VERIFY_ENV_ALLOWLIST, *extra_environment,
                                                  IMPORT_PATH_ENV_VAR, "PYTHONPYCACHEPREFIX"])
    pid = start_job(argv, workspace=home, log=log, exit_file=exit_file, policy=policy,
                    environment={"PYTHONUNBUFFERED": "1", "PYTHONPYCACHEPREFIX": str(cache),
                                 **import_root(home)},
                    out_file=out_file, err_file=err_file)
    return pid, cache


def start_background(workspace: Path, argv: list[str], log: Path, *,
                     extra_environment: "list[str] | tuple[str, ...]" = ()) -> BackgroundProcess:
    """Start `argv` in the workspace, seeing what a verifier sees plus `extra_environment`."""
    policy = SandboxPolicy(backend=SandboxBackend.LOCAL_PROCESS, network=NetworkPolicy.INHERIT,
                           environment_allowlist=[*LOCAL_VERIFY_ENV_ALLOWLIST,
                                                  *extra_environment])
    # A Python program writing to a file buffers what it prints; a server's
    # "listening on" would arrive when it stopped, which is too late to read.
    return BackgroundProcess(argv, workspace=workspace, log=log, policy=policy,
                             environment={"PYTHONUNBUFFERED": "1"})
