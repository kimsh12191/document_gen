"""Atomic append-only snapshots for the initial coding-task lifecycle."""

import sqlite3
from contextlib import closing
from pathlib import Path

from relab_core.coding.base import utc_now
from relab_core.runs import CodingRun, RunEvent
from relab_workspace.private_state import state_dir


class RunStore:
    def __init__(self, workspace: Path) -> None:
        root = workspace.resolve(strict=True)
        state = state_dir(root)
        self.path = state / "runs.db"
        if not root.is_dir() or state.is_symlink() or self.path.is_symlink():
            raise ValueError("invalid workspace state location")
        state.mkdir(exist_ok=True)
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("CREATE TABLE IF NOT EXISTS run_events ("
                       "run_id TEXT, sequence INTEGER, payload TEXT NOT NULL, "
                       "PRIMARY KEY(run_id, sequence))")
            db.commit()

    def events(self, run_id: str) -> list[RunEvent]:
        with closing(sqlite3.connect(self.path)) as db:
            rows = db.execute(
                "SELECT payload FROM run_events WHERE run_id=? ORDER BY sequence", (run_id,)
            ).fetchall()
        return [RunEvent.model_validate_json(row[0]) for row in rows]

    def run_ids(self) -> list[str]:
        """Every run recorded in this workspace, ordered so listings are stable."""
        with closing(sqlite3.connect(self.path)) as db:
            rows = db.execute("SELECT DISTINCT run_id FROM run_events ORDER BY run_id").fetchall()
        return [row[0] for row in rows]

    def runs_for_request(self, request_id: str) -> list[str]:
        """Creation events claiming this request; the column is not unique by construction."""
        matches = set()
        with closing(sqlite3.connect(self.path)) as db:
            # Creation is always sequence 1, and kind lives inside the persisted JSON.
            for (payload,) in db.execute("SELECT payload FROM run_events WHERE sequence=1"):
                event = RunEvent.model_validate_json(payload)
                if event.kind == "coding.created" and event.snapshot.request_id == request_id:
                    matches.add(event.run_id)
        return sorted(matches)

    def load(self, run_id: str) -> CodingRun:
        events = self.events(run_id)
        if not events:
            raise LookupError(f"run not found: {run_id}")
        return events[-1].snapshot

    def create_for_request(self, snapshot: CodingRun) -> CodingRun:
        """Atomically adopt or create a session request without changing legacy imports."""
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("BEGIN IMMEDIATE")
            matches = []
            for (payload,) in db.execute("SELECT payload FROM run_events WHERE sequence=1"):
                event = RunEvent.model_validate_json(payload)
                if (event.kind == "coding.created"
                        and event.snapshot.request_id == snapshot.request_id):
                    matches.append(event.snapshot)
            if len(matches) > 1:
                raise ValueError(
                    f"several runs already claim {snapshot.request_id}; inspect run history"
                )
            if matches:
                prior = matches[0]
                if prior.workspace != snapshot.workspace or prior.objective != snapshot.objective:
                    raise ValueError("request claim does not match workspace and objective")
                return prior
            event = RunEvent(
                run_id=snapshot.run_id, sequence=1, kind="coding.created",
                timestamp=utc_now(), snapshot=snapshot,
            )
            db.execute("INSERT INTO run_events VALUES (?, ?, ?)",
                       (snapshot.run_id, 1, event.model_dump_json()))
            db.commit()
        return snapshot

    def append(self, snapshot: CodingRun, kind: str, expected_sequence: int) -> RunEvent:
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("BEGIN IMMEDIATE")
            current = db.execute(
                "SELECT COALESCE(MAX(sequence), 0) FROM run_events WHERE run_id=?",
                (snapshot.run_id,),
            ).fetchone()[0]
            if current != expected_sequence:
                raise ValueError("run changed; reload before applying another result")
            if kind == "coding.dependency_install_started":
                self._check_install_budget(db, snapshot)
            event = RunEvent(
                run_id=snapshot.run_id, sequence=current + 1, kind=kind,
                timestamp=utc_now(), snapshot=snapshot,
            )
            db.execute("INSERT INTO run_events VALUES (?, ?, ?)",
                       (snapshot.run_id, event.sequence, event.model_dump_json()))
            db.commit()
        return event

    @staticmethod
    def _check_install_budget(db: sqlite3.Connection, snapshot: CodingRun) -> None:
        """Reserve a request by appending its start event in this same transaction.

        Prior starts consume budget even when the worker failed or disappeared.
        Read legacy events directly so upgrades cannot reset existing consumption.
        """
        if (
            snapshot.dependency_policy is None or snapshot.result is None
            or snapshot.result.failure is None
            or snapshot.result.failure.dependency_install_request is None
        ):
            raise ValueError("installation claim requires a stored request and policy")
        request = snapshot.result.failure.dependency_install_request
        limit = snapshot.dependency_policy.max_requests
        consumed: set[str] = set()
        # Kind is inside the persisted JSON, not a separate indexed SQL column.
        # Parse snapshots for portability rather than depending on SQLite JSON1.
        for (payload,) in db.execute("SELECT payload FROM run_events"):
            event = RunEvent.model_validate_json(payload)
            if event.kind != "coding.dependency_install_started":
                continue
            prior = event.snapshot
            if (prior.result is None or prior.result.failure is None
                    or prior.result.failure.dependency_install_request is None
                    or prior.dependency_policy is None):
                raise ValueError("incomplete historical install claim; inspect history manually")
            previous = prior.result.failure.dependency_install_request
            if previous.request_id == request.request_id:
                raise ValueError("dependency request already claimed in this workspace")
            if previous.session_id == request.session_id:
                consumed.add(previous.request_id)
                limit = min(limit, prior.dependency_policy.max_requests)
        if len(consumed) >= limit:
            raise ValueError("dependency session request budget exhausted")
