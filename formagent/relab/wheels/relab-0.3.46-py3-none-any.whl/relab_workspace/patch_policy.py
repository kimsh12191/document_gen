"""Patch validation — independent re-implementation of AutoResearch's
proven `validate_patch` (this session adversarially tested the original:
tamper-after-approval detection, base-hash mismatch rejection,
symlink/rename/escape rejection all held up; the same rigor applies here).

No mutation happens in this module. `PatchRejectedError` is the only
outcome besides success — a rejected proposal never touches the
filesystem.
"""

import hashlib
import re
from enum import Enum
from pathlib import Path

from relab_core.coding.patch import MISSING_FILE_HASH, PatchProposal, PathPolicy
from relab_core.coding.workspace import WorkspacePolicy

_DIFF_HEADER = re.compile(r"^diff --git a/(?P<old>\S+) b/(?P<new>\S+)$")
_OLD_FILE_HEADER = re.compile(r"^--- (?P<path>\S+)")
_NEW_FILE_HEADER = re.compile(r"^\+\+\+ (?P<path>\S+)")


class PatchRejectionCode(str, Enum):
    RENAME_UNSUPPORTED = "rename_unsupported"
    INVALID_DIFF_PATH = "invalid_diff_path"
    INVALID_HEADERS = "invalid_headers"
    BASE_HASHES_MISMATCH = "base_hashes_mismatch"
    OUTSIDE_MUTABLE_ROOT = "outside_mutable_root"
    PROTECTED_PATH = "protected_path"
    WORKSPACE_ESCAPE = "workspace_escape"
    SYMLINK_MUTATION = "symlink_mutation"
    BASE_HASH_MISMATCH = "base_hash_mismatch"


class PatchRejectedError(ValueError):
    def __init__(self, message: str, *, code: PatchRejectionCode) -> None:
        super().__init__(message)
        self.code = code


def touched_files(diff: str) -> list[str]:
    """Parse every `diff --git a/X b/Y` header and cross-check it against
    the corresponding `---`/`+++` unified-diff headers. Renames are
    rejected outright — a single `PatchProposal` is scoped to content
    changes, never a move."""

    lines = diff.splitlines()
    paths: list[str] = []
    for index, line in enumerate(lines):
        match = _DIFF_HEADER.match(line)
        if not match:
            continue
        old_path, new_path = match.group("old"), match.group("new")
        if old_path != new_path:
            raise PatchRejectedError(
                "renames are not supported", code=PatchRejectionCode.RENAME_UNSUPPORTED
            )
        relative = _normalize_path(new_path)

        old_header = _find_header(lines, index, _OLD_FILE_HEADER)
        new_header = _find_header(lines, index, _NEW_FILE_HEADER)
        if old_header is None or new_header is None:
            raise PatchRejectedError(
                "unified diff headers do not match git file headers",
                code=PatchRejectionCode.INVALID_HEADERS,
            )
        if not (old_header == "/dev/null" or old_header in (f"a/{new_path}",)):
            raise PatchRejectedError(
                "unified diff headers do not match git file headers",
                code=PatchRejectionCode.INVALID_HEADERS,
            )
        if not (new_header == "/dev/null" or new_header in (f"b/{new_path}",)):
            raise PatchRejectedError(
                "unified diff headers do not match git file headers",
                code=PatchRejectionCode.INVALID_HEADERS,
            )

        paths.append(relative)
    return paths


def _find_header(lines: list[str], start: int, pattern: re.Pattern[str]) -> str | None:
    """Scan this file's header block for a `---`/`+++` line, stopping at the
    next file's `diff --git`. A fixed 5-line window used to be enough for
    AutoCode's own difflib output but wrongly rejected valid
    externally-authored diffs -- git emits `old mode`/`new mode`/
    `similarity index`/`index`/`GIT binary patch` lines here, and four of
    them already overflows a 5-line window. `autocode apply` accepts
    third-party proposals, so the window has to follow git's real format
    rather than our own generator's habits."""

    for line in lines[start + 1 :]:
        if _DIFF_HEADER.match(line):
            break
        match = pattern.match(line)
        if match:
            return match.group("path")
    return None


def _normalize_path(raw: str) -> str:
    candidate = raw.replace("\\", "/")
    path = Path(candidate)
    # `.` is checked against the raw segments, not path.parts: pathlib
    # silently collapses "." away, so the parts-based check was dead code
    # and `a/./b.py` was accepted as a second valid spelling of `a/b.py`.
    # One file must have exactly one spelling here, since these strings
    # are the keys base_hashes is matched against.
    segments = candidate.split("/")
    if path.is_absolute() or ".." in path.parts or "." in segments or "" in segments[1:]:
        raise PatchRejectedError(
            f"invalid diff path: {raw}", code=PatchRejectionCode.INVALID_DIFF_PATH
        )
    return candidate


def _is_within(relative: Path, root: str) -> bool:
    if root == ".":
        return True
    root_parts = Path(root.replace("\\", "/")).parts
    return relative.parts[: len(root_parts)] == root_parts


class WorkspacePolicyError(ValueError):
    """A caller's declared workspace policy cannot be honoured as asked."""


def resolve_path_policy(
    requested: WorkspacePolicy | None, *, base: PathPolicy | None = None
) -> PathPolicy:
    """Fold a caller's declared policy into the one this engine enforces
    (doc/ROADMAP.md v0.21).

    Mutability narrows, protection accumulates -- see
    `autocode/schema/workspace.py` for why those are the only two safe
    directions. A requested mutable root outside the base is raised, not
    clipped: a caller that asked to edit `../shared` and got a session
    quietly confined to `.` would have no way to tell that from one that
    worked.

    Containment is decided by `_is_within()`, the same predicate
    `validate_patch()` below uses on every touched file. Resolving with a
    different rule than the one that enforces is how a policy comes to be
    satisfied on paper and not in fact.
    """

    base = base or PathPolicy()
    if requested is None:
        return base

    for root in requested.mutable_roots:
        if not any(_is_within(Path(root), permitted) for permitted in base.mutable_roots):
            raise WorkspacePolicyError(
                f"requested mutable root is outside this engine's mutable roots: {root}"
            )
    # A requested mutable root that is already protected can never hold a
    # patch, so the session would burn its whole budget on rejections.
    # Cheaper to say so now than to let it fail attempt by attempt.
    protected = list(dict.fromkeys([*base.protected_roots, *requested.protected_roots]))
    for root in requested.mutable_roots:
        blocked = [guard for guard in protected if _is_within(Path(root), guard)]
        if blocked:
            raise WorkspacePolicyError(
                f"requested mutable root is inside a protected root: {root} "
                f"(protected by {blocked[0]})"
            )
    return PathPolicy(mutable_roots=list(requested.mutable_roots), protected_roots=protected)


def validate_patch(root: Path, proposal: PatchProposal, policy: PathPolicy | None = None) -> None:
    policy = policy or PathPolicy()
    paths = touched_files(proposal.diff)
    if set(paths) != set(proposal.base_hashes):
        raise PatchRejectedError(
            "base hashes must exactly match touched files",
            code=PatchRejectionCode.BASE_HASHES_MISMATCH,
        )

    for relative_str in paths:
        relative = Path(relative_str)
        if not any(_is_within(relative, mutable) for mutable in policy.mutable_roots):
            raise PatchRejectedError(
                f"path is not within a mutable root: {relative_str}",
                code=PatchRejectionCode.OUTSIDE_MUTABLE_ROOT,
            )
        if any(_is_within(relative, protected) for protected in policy.protected_roots):
            raise PatchRejectedError(
                f"path is within a protected root: {relative_str}",
                code=PatchRejectionCode.PROTECTED_PATH,
            )

        target = root / relative
        try:
            target.relative_to(root)
        except ValueError as error:
            raise PatchRejectedError(
                f"path escapes workspace root: {relative_str}",
                code=PatchRejectionCode.WORKSPACE_ESCAPE,
            ) from error
        # Check every component, not just the leaf: a symlinked *parent*
        # directory (mutable/link_to_outside/file.py) passed both this
        # check and the purely-lexical relative_to() above, so a write
        # could still land outside the workspace through it.
        if target.is_symlink() or any(
            parent.is_symlink() for parent in target.parents if root in parent.parents
        ):
            raise PatchRejectedError(
                f"symbolic link mutation is not allowed: {relative_str}",
                code=PatchRejectionCode.SYMLINK_MUTATION,
            )

        actual_hash = _current_hash(target)
        expected_hash = proposal.base_hashes[relative_str]
        if actual_hash != expected_hash:
            raise PatchRejectedError(
                f"base hash mismatch: {relative_str}", code=PatchRejectionCode.BASE_HASH_MISMATCH
            )


def _current_hash(target: Path) -> str:
    if target.is_symlink() or not target.is_file():
        return MISSING_FILE_HASH
    return hashlib.sha256(target.read_bytes()).hexdigest()
