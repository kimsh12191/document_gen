"""Cooperative, process-scoped exclusion for local workspace mutations."""

import hashlib
import math
import os
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from relab_workspace.private_state import state_dir


@contextmanager
def workspace_lock(workspace: Path) -> Iterator[None]:
    """Fail fast on contention; connection close/process exit releases the lock.

    Keep the database file in place: unlinking a held lock can split ownership.
    This protects cooperating services, not arbitrary editors or network shares.
    """
    with tree_lock(workspace):
        yield


@contextmanager
def tree_lock(workspace: Path, target: Path | None = None) -> Iterator[None]:
    """Exclude mutations of the tree that is actually written to.

    An attempt working in its own throwaway checkout contends with nobody, so
    taking the workspace's exclusion for it would serialize isolated attempts
    that cannot conflict. The lock file stays in the workspace either way: the
    checkout is discarded, the workspace is what endures.
    """
    root = workspace.resolve(strict=True)
    if target is None or target.resolve(strict=True) == root:
        name, busy = "workspace-lock.db", "workspace"
    else:
        # Case is normalized where the platform ignores it, so one tree is one lock.
        digest = hashlib.sha256(
            os.path.normcase(str(target.resolve(strict=True))).encode("utf-8")).hexdigest()
        name, busy = f"tree-lock-{digest}.db", "checkout"
    with _local_lock(root, name, f"{busy} is busy; another patch operation holds the lock"):
        yield


@contextmanager
def session_execution_lock(workspace: Path, session_id: str) -> Iterator[None]:
    """Exclude execution and policy writes for one session, not its evidence appends."""
    with _local_lock(workspace, _session_lock_name(session_id),
                     "research session is busy; execution or a policy change holds the lock"):
        yield


def _session_lock_name(session_id: str) -> str:
    # IDs are contract data, never filesystem paths (including legacy/imported IDs).
    return f"session-lock-{hashlib.sha256(session_id.encode('utf-8')).hexdigest()}.db"


def session_execution_held(workspace: Path, session_id: str) -> bool:
    """Whether another process is executing this session right now.

    A lock that was never created cannot be held, so this creates nothing: asking
    the question must not leave a file behind that answering it would.
    """
    return _held(workspace, _session_lock_name(session_id))


def workspace_mutation_held(workspace: Path) -> bool:
    """Whether a patch operation holds workspace exclusion right now."""
    return _held(workspace, "workspace-lock.db")


REPOSITORY_LOCK = "relab-worktree-lock.db"
MAXIMUM_WAIT_SECONDS = 300.0


@contextmanager
def repository_lock(
    common_directory: Path, *, wait_seconds: float = 30.0,
) -> Iterator[None]:
    """Exclude worktree administration across every workspace sharing one repository.

    `git worktree prune` is repository-wide: it can remove a registration another
    process is still setting up. Every workspace that is a worktree of one
    repository resolves to the same common directory, so the lock lives there
    rather than under any one workspace, which is what makes it shared at all.

    Unlike the workspace and session locks this **waits**. Administration is
    short and a peer holding it is expected rather than exceptional, so failing
    the moment one does would refuse work that was about to be possible.
    """
    if not math.isfinite(wait_seconds) or not 0 <= wait_seconds <= MAXIMUM_WAIT_SECONDS:
        raise ValueError(
            f"worktree lock wait must be finite and at most {MAXIMUM_WAIT_SECONDS} seconds")
    directory = common_directory.resolve(strict=True)
    database = directory / REPOSITORY_LOCK
    if not directory.is_dir() or database.is_symlink():
        raise ValueError("repository lock storage must be a local directory/file")
    with _database_lock(
        database, "repository is busy; another worktree operation holds the lock",
        wait_seconds,
    ):
        yield


@contextmanager
def state_file_lock(workspace: Path, name: str, *, wait_seconds: float = 30.0) -> Iterator[None]:
    """Serialize one private state file's read, change and replace across processes.

    Like the repository lock this **waits**: two benchmarks in one workspace each
    register as they go, and finding the other mid-write is expected. Without it
    both read the same index, one replace loses the other's entry, and on Windows
    a replace while the other has the file open is refused outright (P3, 0.3.24).
    """
    root = workspace.resolve(strict=True)
    state = state_dir(root)
    database = state / f"{hashlib.sha256(name.encode('utf-8')).hexdigest()[:16]}-state-lock.db"
    if state.is_symlink() or database.is_symlink():
        raise ValueError("state lock storage must be local directories/files")
    state.mkdir(parents=True, exist_ok=True)
    with _database_lock(database, f"{name} is busy; another process is writing it", wait_seconds):
        yield


def _held(workspace: Path, filename: str) -> bool:
    database = state_dir(workspace.resolve(strict=True)) / filename
    if database.is_symlink() or not database.is_file():
        return False
    connection = sqlite3.connect(database, timeout=0)
    try:
        connection.execute("BEGIN IMMEDIATE")
    except sqlite3.OperationalError as error:
        if "locked" in str(error).lower() or "busy" in str(error).lower():
            return True
        raise
    finally:
        connection.close()
    return False


@contextmanager
def _local_lock(workspace: Path, filename: str, busy_message: str) -> Iterator[None]:
    root = workspace.resolve(strict=True)
    state = state_dir(root)
    database = state / filename
    if not root.is_dir() or state.is_symlink() or database.is_symlink():
        raise ValueError("workspace lock storage must be local directories/files")
    state.mkdir(exist_ok=True)
    with _database_lock(database, busy_message, 0):
        yield


@contextmanager
def _database_lock(database: Path, busy_message: str, wait_seconds: float) -> Iterator[None]:
    """Hold one lock database; closing the connection or exiting releases it."""
    connection = sqlite3.connect(database, timeout=wait_seconds)
    try:
        try:
            connection.execute("BEGIN IMMEDIATE")
        except sqlite3.OperationalError as error:
            if "locked" in str(error).lower() or "busy" in str(error).lower():
                raise ValueError(busy_message) from error
            raise
        yield
    finally:
        connection.close()
