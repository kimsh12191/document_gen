"""One explicit wheel install, from an index or a local wheelhouse."""

import json
import math
import os
import re
from pathlib import Path

from relab_core.coding.dependency import (
    DependencyDecision,
    DependencyInstallDecision,
    DependencyInstallOutcome,
    DependencyInstallPolicy,
    DependencyInstallRequest,
)
from relab_core.coding.sandbox import SandboxRequest, SandboxResult, SandboxStatus
from relab_core.dependency import DependencyInstallation
from relab_execution.sandbox import LocalProcessSandbox, Sandbox, build_sandbox_policy
from relab_workspace.dependency_policy import validate_dependency_target

_PROBE = (
    "import json,sys,importlib.util; "
    "print(json.dumps({'prefix':sys.prefix,'base_prefix':sys.base_prefix,"
    "'version':list(sys.version_info[:2]),'pip':importlib.util.find_spec('pip') is not None}))"
)
_VERSION = (
    "import json,sys; from importlib.metadata import version; "
    "print(json.dumps({'version':version(sys.argv[1])}))"
)


def install_dependency(
    workspace: Path, request: DependencyInstallRequest, decision: DependencyInstallDecision,
    policy: DependencyInstallPolicy, *, timeout_seconds: float = 300,
    sandbox: Sandbox | None = None,
) -> DependencyInstallation:
    """Caller must hold workspace_lock and persist an atomic install-start claim."""
    if decision.decision != DependencyDecision.APPROVE or decision.request_id != request.request_id:
        raise ValueError("installation requires matching explicit approval")
    if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
        raise ValueError("timeout must be finite and positive")
    if not policy.network_allowed and policy.wheelhouse is None:
        raise ValueError(
            "installation requires network_allowed=true or a declared offline wheelhouse")
    if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?", request.dependency):
        raise ValueError("only a plain distribution name is supported")
    constraint = request.version_constraint or ""
    if constraint and not re.fullmatch(r"==[0-9]+(?:\.[0-9]+)*", constraint):
        raise ValueError("only exact numeric version pins (==1.2.3) are supported")
    target = validate_dependency_target(workspace, request, policy)
    executor = sandbox if sandbox is not None else LocalProcessSandbox()
    execution_policy = build_sandbox_policy()
    execution_policy.environment_allowlist.append("PIP_CONFIG_FILE")
    commands: list[list[str]] = []
    results: list[SandboxResult] = []

    def execute(argv: list[str]) -> SandboxResult:
        commands.append(argv)
        result = executor.run(SandboxRequest(
            id=f"{request.request_id}-install-{len(commands)}", argv=argv,
            timeout_seconds=timeout_seconds, environment={"PIP_CONFIG_FILE": os.devnull},
        ), policy=execution_policy, workspace=workspace)
        results.append(result)
        return result

    def finish(succeeded: bool, message: str, version: str | None = None) -> DependencyInstallation:
        return DependencyInstallation(
            outcome=DependencyInstallOutcome(
                request_id=request.request_id, dependency=request.dependency,
                environment=request.environment, installer=request.installer,
                decided_by=decision.decided_by, succeeded=succeeded, message=message,
                resolved_version=version,
            ), commands=commands, results=results,
        )

    probe = execute([target.python_path, "-I", "-c", _PROBE])
    if probe.status != SandboxStatus.SUCCEEDED:
        return finish(False, "target interpreter probe failed")
    try:
        info = json.loads(probe.stdout)
        if (
            Path(info["prefix"]).resolve() != Path(target.environment_path)
            or Path(info["base_prefix"]).resolve() == Path(info["prefix"]).resolve()
            or not isinstance(info["version"], list) or len(info["version"]) != 2
            or not all(type(value) is int for value in info["version"])
            or tuple(info["version"]) < (3, 10) or info["pip"] is not True
        ):
            return finish(False, "interpreter identity/version/pip validation failed")
    except (ValueError, KeyError, TypeError, OSError):
        return finish(False, "invalid interpreter probe response")
    # An offline install must reach no index at all, not merely prefer the wheelhouse.
    source = (["--index-url", "https://pypi.org/simple"] if target.wheelhouse_path is None
              else ["--no-index", "--find-links", target.wheelhouse_path])
    result = execute([
        target.python_path, "-I", "-m", "pip", "--require-virtualenv",
        "--disable-pip-version-check", "--no-input", "--no-cache-dir",
        "install", "--only-binary=:all:", "--no-deps", *source,
        "--", request.dependency + constraint,
    ])
    if result.status != SandboxStatus.SUCCEEDED:
        return finish(False, "pip installation failed; environment may be partially modified")
    version_result = execute([target.python_path, "-I", "-c", _VERSION, request.dependency])
    if version_result.status != SandboxStatus.SUCCEEDED:
        return finish(False, "installation returned success but version lookup failed")
    try:
        version = json.loads(version_result.stdout)["version"]
        if not isinstance(version, str) or not version.strip():
            raise ValueError("invalid version")
    except (ValueError, KeyError, TypeError):
        return finish(False, "invalid installed version response")
    if constraint and version != constraint[2:]:
        return finish(False, "installed version differs from approved exact pin", version)
    return finish(True, "installed distribution confirmed; coding resume is pending", version)
