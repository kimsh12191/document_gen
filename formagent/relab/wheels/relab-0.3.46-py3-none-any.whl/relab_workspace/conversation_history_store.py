"""Workspace-local conversation text, separate from research evidence."""

import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from relab_core.conversation_history import ConversationHistoryTurn, ConversationMessage
from relab_workspace.private_state import private_file


class ConversationHistoryStore:
    def __init__(self, workspace: Path) -> None:
        root = workspace.resolve(strict=True)
        if not root.is_dir() or (root / ".relab").is_symlink():
            raise ValueError("invalid conversation history storage location")
        # The person's own chat, not the workspace's: others can open it (0.2.62).
        self.path = private_file(root, "conversation_history.db")
        if self.path.is_symlink():
            raise ValueError("invalid conversation history storage location")
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("CREATE TABLE IF NOT EXISTS messages ("
                       "thread_id TEXT NOT NULL, sequence INTEGER NOT NULL, "
                       "payload TEXT NOT NULL, PRIMARY KEY(thread_id, sequence))")
            db.commit()

    def thread_ids(self) -> list[str]:
        with closing(sqlite3.connect(self.path)) as db:
            rows = db.execute("SELECT DISTINCT thread_id FROM messages ORDER BY thread_id")
            return [row[0] for row in rows]

    def messages(self, thread_id: str, *, limit: int | None = None) -> list[ConversationMessage]:
        if limit is not None and not 1 <= limit <= 50:
            raise ValueError("conversation history limit must be between 1 and 50")
        with closing(sqlite3.connect(self.path)) as db:
            if limit is None:
                rows = db.execute("SELECT payload FROM messages WHERE thread_id=? "
                                  "ORDER BY sequence", (thread_id,)).fetchall()
            else:
                rows = db.execute("SELECT payload FROM messages WHERE thread_id=? "
                                  "ORDER BY sequence DESC LIMIT ?", (thread_id, limit)).fetchall()
                rows.reverse()
            return [ConversationMessage.model_validate_json(row[0]) for row in rows]

    def append(self, thread_id: str, role: Literal["user", "assistant"], text: str,
               *, expected_sequence: int, session_id: str | None = None
               ) -> ConversationMessage:
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("BEGIN IMMEDIATE")
            current = db.execute("SELECT COALESCE(MAX(sequence), 0) FROM messages "
                                 "WHERE thread_id=?", (thread_id,)).fetchone()[0]
            if current != expected_sequence:
                raise ValueError("conversation changed; reload before appending")
            message = ConversationMessage(
                thread_id=thread_id, sequence=current + 1, role=role, text=text,
                timestamp=datetime.now(timezone.utc), session_id=session_id,
            )
            db.execute("INSERT INTO messages VALUES (?, ?, ?)",
                       (thread_id, message.sequence, message.model_dump_json()))
            db.commit()
            return message

    def append_turn(self, thread_id: str, turn: ConversationHistoryTurn, *,
                    expected_sequence: int, session_id: str) -> list[ConversationMessage]:
        """Record both sides or neither, including when a writer has moved on."""
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("BEGIN IMMEDIATE")
            current = db.execute("SELECT COALESCE(MAX(sequence), 0) FROM messages "
                                 "WHERE thread_id=?", (thread_id,)).fetchone()[0]
            if current != expected_sequence:
                raise ValueError("conversation changed; reload before appending")
            timestamp = datetime.now(timezone.utc)
            messages = [
                ConversationMessage(thread_id=thread_id, sequence=current + 1,
                                    role="user", text=turn.user_text,
                                    timestamp=timestamp, session_id=session_id),
                ConversationMessage(thread_id=thread_id, sequence=current + 2,
                                    role="assistant", text=turn.assistant_text,
                                    timestamp=timestamp, session_id=session_id),
            ]
            db.executemany("INSERT INTO messages VALUES (?, ?, ?)",
                           [(thread_id, item.sequence, item.model_dump_json())
                            for item in messages])
            db.commit()
            return messages

    def clear(self, thread_id: str) -> None:
        """Explicitly forget one transcript; research evidence is unaffected."""
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("DELETE FROM messages WHERE thread_id=?", (thread_id,))
            db.commit()
