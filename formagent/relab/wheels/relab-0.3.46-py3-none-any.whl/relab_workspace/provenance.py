"""Capture the conditions a run executes under, from the workspace as it stands now.

This inspects; it never changes the workspace or the repository. Git is read with
bounded read-only commands, and an absent or failing Git leaves the revision unset
rather than failing the run it is describing.
"""

import hashlib
import platform
import subprocess
import sys
from pathlib import Path, PurePosixPath, PureWindowsPath

from relab_core.coding.sandbox import SandboxPolicy
from relab_core.provenance import MAXIMUM_DATA_PATHS, RunConditions

GIT_TIMEOUT_SECONDS = 10
_DIGEST_CHUNK = 1 << 20


def capture_conditions(
    workspace: Path, data_paths: list[str] | None = None,
    target_paths: list[str] | None = None, sandbox: SandboxPolicy | None = None,
    holdout_paths: list[str] | None = None, verify_argv: list[str] | None = None,
) -> RunConditions:
    declared = list(data_paths or [])
    held = list(holdout_paths or [])
    for paths, name in ((declared, "data"), (held, "holdout data")):
        if len(paths) > MAXIMUM_DATA_PATHS:
            raise ValueError(f"declare at most {MAXIMUM_DATA_PATHS} {name} paths")
        if len(paths) != len({path.casefold() for path in paths}):
            raise ValueError(f"declared {name} paths must be distinct (case-insensitive)")
    root = workspace.resolve(strict=True)
    revision, dirty = _repository(root)
    return RunConditions(
        python_version=platform.python_version(),
        platform=f"{sys.platform}/{platform.machine() or 'unknown'}",
        code_revision=revision, code_dirty=dirty,
        data_digests={path: _digest(root, path) for path in declared},
        holdout_data_digests={path: _digest(root, path) for path in held},
        # A target that does not exist yet is a starting state too, not a gap.
        target_digests={path: _optional_digest(root, path)
                        for path in (target_paths or [])},
        verification_argv=list(verify_argv or []),
        sandbox_backend=(sandbox.backend.value if sandbox is not None else "local_process"),
        docker_image=(sandbox.docker_image if sandbox is not None else None),
    )


def changed_data(workspace: Path, conditions: RunConditions) -> list[str]:
    """Declared data paths that no longer match what was captured for this run.

    Conditions are captured before an attempt runs, so on their own they say what
    the data was, not what the verifier read. Digesting again at the end is what
    turns the first reading into a claim the record can support.

    A path that has become unreadable counts as changed: the record cannot say the
    verifier read what it said it read, and that is the question being asked.
    """
    return _changed(workspace, conditions.data_digests)


def changed_holdout_data(workspace: Path, conditions: RunConditions) -> list[str]:
    """Held-out data the attempt altered, which is the attempt writing its own answers."""
    return _changed(workspace, conditions.holdout_data_digests)


def _changed(workspace: Path, digests: dict[str, str]) -> list[str]:
    root = workspace.resolve(strict=True)
    changed = []
    for path, digest in sorted(digests.items()):
        try:
            current = _digest(root, path)
        except (OSError, ValueError):
            changed.append(path)
            continue
        if current != digest:
            changed.append(path)
    return changed


def _repository(root: Path) -> tuple[str | None, bool | None]:
    """A revision without its dirty flag would claim more than the record supports."""
    revision = _git(root, ["rev-parse", "HEAD"])
    if revision is None:
        return None, None
    # ReLab's own state lives in the workspace but is not the code under study.
    status = _git(root, ["status", "--porcelain", "--", ".", ":(exclude).relab"])
    if status is None:
        return None, None
    return revision, bool(status)


def _git(root: Path, arguments: list[str]) -> str | None:
    try:
        completed = subprocess.run(
            ["git", "-C", str(root), *arguments], capture_output=True, text=True,
            timeout=GIT_TIMEOUT_SECONDS, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if completed.returncode != 0:
        return None
    return completed.stdout.strip()


def _optional_digest(root: Path, raw: str) -> str | None:
    """An attempt may create its target, so absence is recorded rather than refused."""
    try:
        return _digest(root, raw)
    except OSError:
        return None


def _digest(root: Path, raw: str) -> str:
    """Declared data must be a readable file inside the workspace, never a directory."""
    relative = PurePosixPath(raw.replace("\\", "/"))
    if (
        relative.is_absolute() or PureWindowsPath(raw).drive
        or ".." in relative.parts or not relative.parts or ":" in raw
    ):
        raise ValueError(f"declared data path must be workspace-relative: {raw}")
    target = root.joinpath(*relative.parts)
    if target.is_symlink():
        raise ValueError(f"declared data path must not be a symbolic link: {raw}")
    resolved = target.resolve(strict=True)
    if not resolved.is_file() or not resolved.is_relative_to(root):
        raise ValueError(f"declared data path must be a file inside the workspace: {raw}")
    digest = hashlib.sha256()
    with resolved.open("rb") as handle:
        for chunk in iter(lambda: handle.read(_DIGEST_CHUNK), b""):
            digest.update(chunk)
    return digest.hexdigest()
