"""Where a verifier imports from: the root of the tree it measures.

Every verifier command runs from the workspace root -- `python
addition_project/tests/verify.py` -- and the verifiers models write import what
they measure the way that command reads: `addition_project.solution`,
`addition_project.tests.reference_cases`. Python does not put the working
directory on the import path for a script, only the script's own folder, so
every such import failed. Live, three new projects in a row calibrated to
nothing: one verifier stopped with "Failed to import reference_cases", another
counted every check failed and measured the good and the broken subject both at
0.0, and the arms behind it scored the same however they were written.

So the root goes on the import path, for every run of a verifier -- the
calibration's copy, the claim probe's copy and the measured run alike, so the
three measure the same way. Only the root: the host's own `PYTHONPATH` is not
passed through, as no other variable is that the policy does not name.
"""

from pathlib import Path

IMPORT_PATH_ENV_VAR = "PYTHONPATH"


def import_root(root: Path | str) -> dict[str, str]:
    """The environment that makes `root` the place a verifier imports from."""
    return {IMPORT_PATH_ENV_VAR: str(root)}
