"""Where findings live. One store per workspace, and nothing is ever deleted."""

import sqlite3
from contextlib import closing
from pathlib import Path

from relab_core.memory import MemoryItem
from relab_workspace.private_state import state_dir


class MemoryStore:
    def __init__(self, workspace: Path) -> None:
        root = workspace.resolve(strict=True)
        self.workspace = root
        state = state_dir(root)
        self.path = state / "memory.db"
        if not root.is_dir() or state.is_symlink() or self.path.is_symlink():
            raise ValueError("invalid research memory storage location")
        state.mkdir(exist_ok=True)
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("CREATE TABLE IF NOT EXISTS findings ("
                       "memory_id TEXT PRIMARY KEY, payload TEXT NOT NULL)")
            db.commit()

    def add(self, item: MemoryItem) -> MemoryItem:
        """Record one finding. A finding is written once and not rewritten."""
        try:
            with closing(sqlite3.connect(self.path)) as db:
                db.execute("INSERT INTO findings(memory_id, payload) VALUES (?, ?)",
                           (item.memory_id, item.model_dump_json()))
                db.commit()
        except sqlite3.IntegrityError as error:
            raise ValueError(f"a finding with this id is already recorded: {item.memory_id}"
                             ) from error
        return item

    def load(self, memory_id: str) -> MemoryItem:
        with closing(sqlite3.connect(self.path)) as db:
            row = db.execute("SELECT payload FROM findings WHERE memory_id=?",
                             (memory_id,)).fetchone()
        if row is None:
            raise LookupError(f"finding not found: {memory_id}")
        return MemoryItem.model_validate_json(row[0])

    def all(self) -> list[MemoryItem]:
        """Every finding, in a stable order so a listing does not shuffle."""
        with closing(sqlite3.connect(self.path)) as db:
            rows = db.execute("SELECT payload FROM findings ORDER BY memory_id").fetchall()
        return [MemoryItem.model_validate_json(row[0]) for row in rows]

    def supersede(self, memory_id: str, replacement: str) -> MemoryItem:
        """Mark one finding replaced by another. The old one stays readable.

        This is the one field that changes after a finding is written, and it
        only ever goes from unset to set: what was believed, and when, is part of
        the record of how a conclusion was reached.
        """
        with closing(sqlite3.connect(self.path)) as db:
            # Read and write in one transaction: this is the only field that ever
            # changes, and two callers naming different replacements must not both
            # see it unset and have the later one silently win.
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT payload FROM findings WHERE memory_id=?",
                             (memory_id,)).fetchone()
            if row is None:
                raise LookupError(f"finding not found: {memory_id}")
            item = MemoryItem.model_validate_json(row[0])
            if item.superseded_by is not None:
                if item.superseded_by == replacement:
                    return item
                raise ValueError(
                    f"{memory_id} is already superseded by {item.superseded_by}")
            updated = item.model_copy(update={"superseded_by": replacement})
            db.execute("UPDATE findings SET payload=? WHERE memory_id=?",
                       (updated.model_dump_json(), memory_id))
            db.commit()
        return updated
