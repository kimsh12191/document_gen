"""Batch candidate discovery with unchanged bounded Python observation semantics."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from relab_core.inspection import MAXIMUM_MATCHES, LineMatch
from relab_core.targets import PROTECTED_SEGMENTS, UNSEARCHED_DIRECTORIES, unusable_path
from relab_workspace.file_index import WorkspaceFileIndex, safe_files
from relab_workspace.inspection import _search_workspace_python, search_shared
from relab_workspace.rg_process import ripgrep, run_rg


@dataclass(frozen=True)
class CodeSearchQuery:
    query: str
    regex: bool = False
    glob: str | None = None
    path: str | None = None
    limit: int = MAXIMUM_MATCHES


@dataclass
class CodeSearchResult:
    query: str
    matches: list[LineMatch] = field(default_factory=list)
    files_searched: int | None = 0
    truncated: bool = False
    backend: Literal["ripgrep", "python"] = "python"
    error: str | None = None
    stopped_by: Literal["matches", "files", "time"] | None = None


class CodeSearchService:
    def __init__(self, workspace: Path, index: WorkspaceFileIndex | None = None) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.index = index or WorkspaceFileIndex(self.workspace)

    def search_many(self, queries: list[CodeSearchQuery], *,
                    parallel: bool = True) -> list[CodeSearchResult]:
        if not queries:
            return []
        if len(queries) > 20:
            raise ValueError("at most 20 search queries in a batch")
        # Literal queries share one subprocess. Regex uses the bounded Python
        # engine because rg's regex dialect and long-line semantics differ.
        program = ripgrep()
        groups: dict[str | None, list[str]] = {}
        for query in queries:
            if query.regex or not query.query or len(query.query) > 200 or any(
                    c in query.query for c in ("\n", "\r", "\0")):
                continue
            scope = query.path
            if scope is not None:
                if unusable_path(scope) is not None:
                    continue
                parts = scope.split("/")
                if any(self.workspace.joinpath(*parts[:i]).is_symlink()
                       for i in range(1, len(parts) + 1)):
                    continue
                if not (self.workspace / scope).is_dir():
                    continue
            groups.setdefault(scope, []).append(query.query)
        accelerated: dict[str | None, list[str]] = {}
        if program:
            for scope, patterns in groups.items():
                command = [program, "--files-with-matches", "--fixed-strings", "--no-ignore",
                           "--hidden", "--null", "--no-config", "--no-messages"]
                for name in sorted(UNSEARCHED_DIRECTORIES | PROTECTED_SEGMENTS):
                    command += ["--iglob", f"!{name}/"]
                for pattern in patterns:
                    command += ["--regexp", pattern]
                command += ["--", "."]
                data = run_rg(command, self.workspace / scope if scope else self.workspace)
                if data is not None:
                    names = data.decode("utf-8", errors="replace").replace("\\", "/").split("\0")
                    relative = [(scope + "/" if scope else "") + name.removeprefix("./")
                                for name in names if name]
                    # Checked here, in this call; not again below.
                    accelerated[scope] = sorted(safe_files(self.workspace, sorted(set(relative))),
                                                key=lambda n: (n.split("/")[:-1], n.split("/")[-1]))

        def search(query: CodeSearchQuery) -> CodeSearchResult:
            use_rg = (query.path in accelerated and not query.regex
                      and query.query in groups.get(query.path, []))
            names = accelerated[query.path] if use_rg else self.index.files()
            assert names is not None
            scoped = [name for name in names
                      if query.path is None or name.startswith(query.path + "/")]
            # The index's names are only a listing: each is checked now, as it is used.
            candidates = [self.workspace / name
                          for name in (scoped if use_rg else safe_files(self.workspace, scoped))]
            try:
                found = _search_workspace_python(
                    self.workspace, query.query, scope=query.path, limit=query.limit,
                    regex=query.regex, glob=query.glob, candidates=candidates)
                return CodeSearchResult(query.query, found.matches,
                                        None if use_rg and not candidates else found.files_searched,
                                        found.truncated, "ripgrep" if use_rg else "python",
                                        stopped_by=found.stopped_by)
            except (ValueError, OSError) as error:
                return CodeSearchResult(query.query, error=str(error))

        # The queries searched here rather than by ripgrep's names: one pass over
        # the files for all of them (P1, measured 13-15x faster for five on Linux).
        walking = [position for position, query in enumerate(queries)
                   if not (query.path in accelerated and not query.regex
                           and query.query in groups.get(query.path, []))]
        results: list[CodeSearchResult | None] = [None] * len(queries)
        if len(walking) > 1:
            names = list(self.index.files())
            scopes = {queries[position].path for position in walking}
            if None not in scopes:
                names = [name for name in names
                         if any(name.startswith(str(scope) + "/") for scope in scopes)]
            candidates = [self.workspace / name for name in safe_files(self.workspace, names)]
            try:
                found = search_shared(self.workspace, [
                    (queries[position].query, queries[position].regex, queries[position].glob,
                     queries[position].path, queries[position].limit) for position in walking],
                    candidates)
            except OSError as error:
                found = [ValueError(str(error))] * len(walking)
            for position, answer in zip(walking, found):
                query = queries[position]
                results[position] = (CodeSearchResult(query.query, error=str(answer))
                                     if isinstance(answer, ValueError) else CodeSearchResult(
                                         query.query, answer.matches, answer.files_searched,
                                         answer.truncated, "python", stopped_by=answer.stopped_by))
        left = [query for position, query in enumerate(queries) if results[position] is None]
        if not parallel or len(left) <= 1:
            done = [search(query) for query in left]
        else:
            with ThreadPoolExecutor(max_workers=min(8, len(left))) as pool:
                done = list(pool.map(search, left))
        rest = iter(done)
        return [result if result is not None else next(rest) for result in results]
