from pathlib import Path

from relab_core.coding.patch import (
    PatchEvidence,
    PatchProposal,
    PathPolicy,
    VerificationResult,
)
from relab_core.coding.sandbox import SandboxBackend, SandboxPolicy
from relab_core.operations import OperationObserver
from relab_execution.sandbox import build_sandbox_policy
from relab_workspace.locking import tree_lock, workspace_lock
from relab_workspace.patch_store import PatchEvidenceStore
from relab_workspace.patcher import Patcher
from relab_workspace.private_state import state_dir
from relab_workspace.snapshot_store import SnapshotStore


class WorkspacePatchService:
    """Apply an explicitly requested patch with mandatory verification and evidence."""

    def apply(
        self, workspace: Path, proposal: PatchProposal, *, verify_argv: list[str],
        timeout_seconds: float = 300, sandbox_policy: SandboxPolicy | None = None,
        execution_root: Path | None = None, subject_paths: list[str] | None = None,
        measurement_snapshot_id: str | None = None,
        observe: OperationObserver | None = None,
    ) -> PatchEvidence:
        """Evidence is always recorded in the workspace, whichever tree is patched.

        `execution_root` lets an attempt run in an isolated checkout while its
        audit trail and exclusion stay with the workspace that owns them.

        `subject_paths` is what this attempt declared it was writing, passed
        down so the tree can be observed at the verification boundary. The
        caller names them because the caller is what knows the design; this
        layer only knows a diff, and a diff is not a measurement subject.
        """
        root = workspace.resolve(strict=True)
        target = root if execution_root is None else execution_root.resolve(strict=True)
        # Exclusion follows the tree being written to, not the tree that owns the record.
        with tree_lock(root, target):
            return self._apply_locked(
                root, proposal, verify_argv=verify_argv,
                timeout_seconds=timeout_seconds, sandbox_policy=sandbox_policy,
                target=target, subject_paths=subject_paths,
                measurement_snapshot_id=measurement_snapshot_id, observe=observe,
            )

    def measure(
        self, workspace: Path, argv: list[str], *, timeout_seconds: float = 300,
        sandbox_policy: SandboxPolicy | None = None,
        execution_root: Path | None = None,
    ) -> VerificationResult:
        """Measure the selected tree under the same target exclusion as a patch."""
        root = workspace.resolve(strict=True)
        target = root if execution_root is None else execution_root.resolve(strict=True)
        with tree_lock(root, target):
            return Patcher().measure(target, argv, timeout_seconds=timeout_seconds,
                                     sandbox_policy=sandbox_policy)

    def restore(self, workspace: Path, proposal: PatchProposal) -> bool:
        """Undo one recorded patch under the same exclusion that applied it."""
        root = workspace.resolve(strict=True)
        with workspace_lock(root):
            return Patcher().restore(root, proposal.diff)

    def _apply_locked(
        self, root: Path, proposal: PatchProposal, *, verify_argv: list[str],
        timeout_seconds: float, sandbox_policy: SandboxPolicy | None, target: Path,
        subject_paths: list[str] | None = None, measurement_snapshot_id: str | None = None,
        observe: OperationObserver | None = None,
    ) -> PatchEvidence:
        state = state_dir(root)
        database = state / "patches.db"
        if not root.is_dir() or state.is_symlink() or database.is_symlink():
            raise ValueError("workspace and evidence storage must be local directories/files")
        store = PatchEvidenceStore(database)
        store.initialize()
        # Beside the evidence, in the workspace that owns the record, and
        # written inside the same lock that applies the patch.
        snapshots = SnapshotStore(state / "snapshots.db")
        try:
            store.load(proposal.request_id)
        except LookupError:
            pass
        else:
            raise ValueError("patch request has already been recorded")
        policy = PathPolicy()
        policy.protected_roots.append(".relab")
        return Patcher(store, snapshots).apply(
            target, proposal, policy=policy, verify_argv=verify_argv,
            timeout_seconds=timeout_seconds, sandbox_policy=sandbox_policy,
            subject_paths=subject_paths, measurement_snapshot_id=measurement_snapshot_id,
            observe=observe,
        )


def build_verification_policy(backend: str, docker_image: str | None) -> SandboxPolicy:
    """Reach the one policy builder without crossing the app/execution boundary."""
    return build_sandbox_policy(backend=SandboxBackend(backend), docker_image=docker_image)
