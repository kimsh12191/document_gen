"""Read-only checks for an explicitly declared project-local dependency target."""

import os
import re
from pathlib import Path, PurePosixPath, PureWindowsPath

from relab_core.coding.dependency import DependencyInstallPolicy, DependencyInstallRequest
from relab_core.dependency import DependencyPreflight


def validate_dependency_target(
    workspace: Path, request: DependencyInstallRequest, policy: DependencyInstallPolicy,
) -> DependencyPreflight:
    """Inspect metadata only; never execute an interpreter or install a package."""
    if request.environment != policy.environment:
        raise ValueError("policy environment does not match the approved request")
    if request.installer != "pip":
        raise ValueError("only the pip installer is supported")
    # A wheelhouse satisfies a network-requiring request more strictly than the network
    # does: the install then runs with --no-index and can reach no index at all.
    if request.network_required and not policy.network_allowed and policy.wheelhouse is None:
        raise ValueError(
            "dependency request requires network permission or an offline wheelhouse")
    if policy.wheelhouse is not None and policy.network_allowed:
        raise ValueError("declare either a wheelhouse or network access, not both")
    root = workspace.resolve(strict=True)
    target = _contained(root, policy.environment.path, "dependency environment")
    wheelhouse = (None if policy.wheelhouse is None
                  else _contained(root, policy.wheelhouse, "dependency wheelhouse"))
    config = target / "pyvenv.cfg"
    if config.is_symlink() or not config.is_file():
        raise ValueError("dependency target requires a local pyvenv.cfg")
    values: dict[str, str] = {}
    for line in config.read_text(encoding="utf-8-sig").splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            key = key.strip().lower()
            if key in values:
                raise ValueError("duplicate venv metadata key")
            values[key] = value.strip()
    if values.get("include-system-site-packages", "").lower() != "false":
        raise ValueError("dependency environment must disable system site packages")
    version = values.get("version", "")
    match = re.fullmatch(r"(\d+)\.(\d+)(?:\.[0-9A-Za-z.+-]+)?", version)
    if match is None or (int(match[1]), int(match[2])) < (3, 10):
        raise ValueError("dependency environment must declare Python 3.10 or newer")
    # Preserve the venv entry path: resolving a normal Unix python symlink would
    # point to the base interpreter and lose the venv selection.
    python = target / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not python.is_file() or not python.parent.resolve(strict=True).is_relative_to(target):
        raise ValueError("dependency environment lacks a local interpreter entry point")
    return DependencyPreflight(
        request_id=request.request_id, environment_path=str(target), python_path=str(python),
        declared_python_version=version, network_allowed=policy.network_allowed,
        wheelhouse_path=None if wheelhouse is None else str(wheelhouse),
    )


def _contained(root: Path, raw: str, label: str) -> Path:
    """Both declared directories stay workspace-relative and inside the workspace."""
    relative = PurePosixPath(raw.replace("\\", "/"))
    if (
        relative.is_absolute() or PureWindowsPath(raw).drive
        or ".." in relative.parts or not relative.parts or ":" in raw
    ):
        raise ValueError(f"{label} must be a workspace-relative subdirectory")
    target = root.joinpath(*relative.parts)
    if target.is_symlink():
        raise ValueError(f"{label} must not be a symbolic link")
    target = target.resolve(strict=True)
    if not root.is_dir() or not target.is_dir() or target == root or not target.is_relative_to(root):
        raise ValueError(f"{label} escapes the workspace or is not a directory")
    return target
