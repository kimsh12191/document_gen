"""Reading a workspace file to find something out, which is not reading it to change it.

`edit_context` next door reads a file a model is about to rewrite. Its rules come
from that: the path must be Python, the bytes must end in a newline, and the
errors say "generation target" -- because a patch is built against what it
returns and a patch needs all of those.

None of them are reading rules. A planner asking what `tools/verify.py` imports,
or whether `pyproject.toml` names a test runner, is not about to write anything,
and a file without a trailing newline is one it should still be allowed to see.
Extending the generation reader to cover this would have widened the rules that
keep a patch sound, to serve a caller that never makes one.

So: two capabilities, one path-safety primitive. `unusable_path` holds what they
share -- relative, canonical, and away from `.git`, `.env` and the rest -- and
each adds its own. Generation adds "and it is Python". This adds nothing, which
is the point.

    read_edit_target()      a read for a mutation candidate
    read_workspace_file()   a read for an observation

What this does not do is decide *whether* a file should be read. That belongs to
the layer that validates a model's request, and putting it here would give the
reader an opinion about purpose that it has no way to form.
"""

import fnmatch
import hashlib
import importlib
import os
import re
import shutil
import subprocess
import time
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from relab_core.inspection import (
    MAXIMUM_MATCH_CHARACTERS,
    MAXIMUM_MATCHES,
    MAXIMUM_READ_BYTES,
    MAXIMUM_SEARCHED_BYTES,
    MAXIMUM_SEARCHED_FILES,
    FileObservation,
    LineMatch,
    SearchObservation,
)
from relab_core.targets import UNSEARCHED_DIRECTORIES, unusable_path


def _whole_characters(data: bytes) -> bytes:
    """UTF-8 bytes cut anywhere, without the part of a character the cut left at the end."""
    # A character is at most four bytes: look back at most three for where the last one began.
    for back in range(1, min(4, len(data)) + 1):
        lead = data[-back]
        if lead & 0b1100_0000 != 0b1000_0000:  # not a continuation byte: a character starts here
            width = 1 if lead < 0x80 else 2 if lead >> 5 == 0b110 else 3 if lead >> 4 == 0b1110 else 4
            return data if width <= back else data[:-back]
    return data


def read_workspace_file(
    workspace: Path, relative: str, *, limit: int = MAXIMUM_READ_BYTES,
) -> FileObservation:
    """One file, bounded, with a digest of exactly what was read.

    Refuses rather than lossily decodes. A planner shown mojibake reasons about
    mojibake, and a binary file summarised as its nearest Latin-1 reading is
    worse than a refusal saying it could not be read as text.
    """
    if type(limit) is not int or not 1 <= limit <= MAXIMUM_READ_BYTES:
        raise ValueError(f"read limit must be an integer between 1 and {MAXIMUM_READ_BYTES}")
    wrong = unusable_path(relative)
    if wrong is not None:
        raise ValueError(f"cannot read {wrong}")
    parts = relative.split("/")
    root = workspace.resolve(strict=True)
    for index in range(1, len(parts) + 1):
        # Checked segment by segment: a link partway along the path reaches
        # outside the workspace just as effectively as one at the end.
        if root.joinpath(*parts[:index]).is_symlink():
            raise ValueError(f"cannot read {relative!r}: it traverses a symbolic link")
    where = root.joinpath(*parts)
    if not where.is_file():
        raise ValueError(f"cannot read {relative!r}: it is not a file in this workspace")
    if not where.resolve(strict=True).is_relative_to(root):
        raise ValueError(f"cannot read {relative!r}: it leaves the workspace")
    with where.open("rb") as stream:
        # One byte past the limit, so "was there more" is answered by the read
        # rather than by a second look at a file that may have changed between.
        data = stream.read(limit + 1)
    truncated = len(data) > limit
    data = data[:limit]
    if truncated:
        # Cut at the limit, the last character may be cut too (0.3.34): a Korean file past
        # it, three bytes a character, was refused as "not UTF-8" two times in three, and
        # then as a binary file. Its last whole character is where the read ends.
        data = _whole_characters(data)
    try:
        content = data.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ValueError(f"cannot read {relative!r}: it is not UTF-8 text") from error
    if "\x00" in content:
        raise ValueError(f"cannot read {relative!r}: it is not UTF-8 text")
    return FileObservation(
        path=relative, content=content,
        digest=hashlib.sha256(data).hexdigest(),
        bytes_read=len(data), truncated=truncated,
    )


# A pattern search reads each line only this far, may take this long in all,
# and may repeat without bound this many times: see `pattern_for`.
PATTERN_LINE_CHARACTERS = 400
PATTERN_SECONDS = 5.0
PATTERN_UNBOUNDED = 3


def pattern_for(query: str) -> "re.Pattern[str]":
    """A regular expression this search will run, or ValueError saying why not.

    A backtracking engine is a denial of service written by whoever types the
    pattern, so only the shapes that cannot explode are taken: no quantifier
    inside a quantified group (`(a+)+`), no alternation under a quantifier
    (`(a|aa)*`), no backreference, and at most three unbounded repeats. With
    lines cut at 400 characters and a time budget on the whole search, what
    is left is bounded -- and is what a code search needs: `def \\w+\\(`,
    `class .*Error`, `import (os|sys)$`.
    """
    try:
        compiled = re.compile(query)
    except re.error as error:
        raise ValueError(f"not a regular expression: {error}") from error
    # By name: the parser moved in 3.11, and the oldest Python here is 3.10.
    try:
        parser: Any = importlib.import_module("re._parser")
    except ImportError:
        parser = importlib.import_module("sre_parse")
    unbounded = 0

    def walk(items: object, under_repeat: bool) -> None:
        nonlocal unbounded
        for op, value in items:  # type: ignore[attr-defined]
            name = str(op)
            if name in ("MAX_REPEAT", "MIN_REPEAT", "POSSESSIVE_REPEAT"):
                _low, high, inner = value
                repeats = high is parser.MAXREPEAT or high > 1
                if repeats and under_repeat:
                    raise ValueError("a repeat inside a repeated group can take forever; "
                                     "write it without the nesting")
                if high is parser.MAXREPEAT:
                    unbounded += 1
                walk(inner, under_repeat or repeats)
            elif name == "SUBPATTERN":
                walk(value[-1], under_repeat)
            elif name == "BRANCH":
                if under_repeat:
                    raise ValueError("an alternation inside a repeat can take forever; "
                                     "search for each alternative, or drop the repeat")
                for branch in value[1]:
                    walk(branch, under_repeat)
            elif name in ("GROUPREF", "GROUPREF_EXISTS"):
                raise ValueError("a backreference is not searched for")
            elif name in ("ASSERT", "ASSERT_NOT"):
                walk(value[1], under_repeat)
            elif name == "ATOMIC_GROUP":
                walk(value, under_repeat)

    walk(parser.parse(query), False)
    if unbounded > PATTERN_UNBOUNDED:
        raise ValueError(f"at most {PATTERN_UNBOUNDED} unbounded repeats (*, +) in one pattern")
    return compiled


def matches_glob(relative: str, glob: str) -> bool:
    """`*.py` by file name anywhere; `src/*.ts` or `src/**/*.ts` by the whole path."""
    if "/" not in glob:
        return fnmatch.fnmatch(relative.rsplit("/", 1)[-1], glob)
    return fnmatch.fnmatch(relative, glob) or fnmatch.fnmatch(relative, glob.replace("**/", ""))



def _checked_search(root: Path, query: str, *, scope: str | None, limit: int,
                    glob: str | None) -> Path:
    """The folder a search may look in, after every check its request must pass."""
    if not query or len(query) > 200:
        raise ValueError("a search query must be 1 to 200 characters")
    if glob is not None and (not glob or len(glob) > 100):
        raise ValueError("a file filter must be 1 to 100 characters")
    if type(limit) is not int or not 1 <= limit <= MAXIMUM_MATCHES:
        raise ValueError(f"a search may return between 1 and {MAXIMUM_MATCHES} matches")
    under = root
    if scope is not None:
        wrong = unusable_path(scope)
        if wrong is not None:
            raise ValueError(f"cannot search {wrong}")
        under = root.joinpath(*scope.split("/"))
        if any(root.joinpath(*scope.split("/")[:i]).is_symlink()
               for i in range(1, len(scope.split("/")) + 1)):
            raise ValueError("cannot search through a symbolic link")
        if not under.resolve().is_relative_to(root):
            raise ValueError("cannot search outside the workspace")
        if not under.is_dir():
            raise ValueError(f"cannot search {scope!r}: it is not a directory here")
    return under

def _search_workspace_python(
    workspace: Path, query: str, *, scope: str | None = None,
    limit: int = MAXIMUM_MATCHES, regex: bool = False, glob: str | None = None,
    candidates: list[Path] | None = None,
) -> SearchObservation:
    """Which lines in this workspace contain `query`, and where.

    A literal substring, not a pattern. `rank_paths` already answers "which files
    look related to this goal" and that is not what is missing -- what is missing
    is *content*: how an existing harness imports the thing it tests, which file
    mentions `pass_rate`, whether `old_verify.py` still refers to anything. Those
    are answered by looking inside, and the caller knows the words.

    Literal because a regular expression is a small language with a large blast
    radius: catastrophic backtracking is a denial of service written by whoever
    typed the query, and a planner reaching for `.*` gets no more than it can
    have by asking twice.

    Bounded everywhere, because the answer reaches a prompt and a record: matches,
    the length of each line, bytes read per file, and files opened. Every bound is
    reported rather than silently applied -- a truncated search and an exhaustive
    one support different conclusions.

    Reads nothing it should not. `.git`, `.env` and the rest are refused by the
    same rule a read obeys, and noise directories are never descended into.

    `regex` asks for a pattern instead, of the shapes `pattern_for` takes, on
    lines cut short and under a time budget; `glob` keeps to the files whose
    name or path matches it.
    """
    if not query or len(query) > 200:
        raise ValueError("a search query must be 1 to 200 characters")
    pattern = pattern_for(query) if regex else None
    deadline = time.monotonic() + PATTERN_SECONDS
    root = workspace.resolve(strict=True)
    under = _checked_search(root, query, scope=scope, limit=limit, glob=glob)

    matches: list[LineMatch] = []
    searched = 0
    truncated = False
    stopped_by: Literal["matches", "files", "time"] | None = None
    # A literal is first looked for with ripgrep, when this host has it -- VS
    # Code ships one, and the editor names it (`RELAB_RG`) -- and only the files
    # it names are opened. Opening and hashing every file to find "from model"
    # took seconds a search on a server holding data and models, where Cline,
    # with ripgrep, took none. The files are then read here exactly as before,
    # so the answer is the same either way.
    found = candidates
    for path in (found if found is not None else _searchable(under, root)):
        if searched >= MAXIMUM_SEARCHED_FILES:
            truncated, stopped_by = True, "files"
            break
        relative = path.relative_to(root).as_posix()
        # The same permission rule a read obeys. A file whose *path* is protected
        # is not searched, whatever the walk turned up.
        if unusable_path(relative) is not None:
            continue
        if glob is not None and not matches_glob(relative, glob):
            continue
        if pattern is not None and time.monotonic() > deadline:
            truncated, stopped_by = True, "time"
            break
        try:
            with path.open("rb") as stream:
                data = stream.read(MAXIMUM_SEARCHED_BYTES)
        except OSError:
            # Unreadable now: a permission, a race with something deleting it.
            # Not an answer and not a failure of the query.
            continue
        try:
            content = data.decode("utf-8")
        except UnicodeDecodeError:
            # Binary. Skipped rather than reported: a match inside a compiled
            # artefact is a coincidence about bytes, not a fact about the project.
            continue
        if "\x00" in content:
            continue
        searched += 1
        # Hashed only when something in it matched: most files searched do not.
        digest = ""
        for number, line in enumerate(content.splitlines(), start=1):
            if pattern is not None:
                if pattern.search(line[:PATTERN_LINE_CHARACTERS]) is None:
                    continue
            elif query not in line:
                continue
            if len(matches) >= limit:
                truncated, stopped_by = True, "matches"
                break
            digest = digest or hashlib.sha256(data).hexdigest()
            matches.append(LineMatch(
                path=relative, line=number,
                text=line.strip()[:MAXIMUM_MATCH_CHARACTERS], digest=digest))
        if truncated:
            break
    return SearchObservation(
        query=query, matches=matches, files_searched=searched, truncated=truncated,
        stopped_by=stopped_by)



@dataclass
class _Shared:
    """One query's own state in a search that reads each file once for several (P1)."""

    query: str
    pattern: "re.Pattern[str] | None"
    scope: str | None
    glob: str | None
    limit: int
    deadline: float
    matches: list[LineMatch] = field(default_factory=list)
    searched: int = 0
    stopped_by: Literal["matches", "files", "time"] | None = None


def search_shared(workspace: Path, requests: list[tuple[str, bool, str | None, str | None, int]],
                  candidates: list[Path]) -> list[SearchObservation | ValueError]:
    """Several searches over the same files, each file read and decoded once for all of them.

    Measured on a 36-CPU Linux server (0.2.32): five queries took 13-15 times one,
    each reading and decoding the same files in a thread of its own. Each query
    keeps its own scope, filter, bounds and order, so its answer is the one it
    would have had alone; only a regex's time bound can fall differently, as it
    can between any two runs. `requests` are (query, regex, glob, scope, limit);
    `candidates` the files any of them may search, in the order a search takes.
    """
    root = workspace.resolve(strict=True)
    answers: list[SearchObservation | ValueError | None] = []
    states: list[tuple[int, _Shared]] = []
    for position, (query, regex, glob, scope, limit) in enumerate(requests):
        try:
            _checked_search(root, query, scope=scope, limit=limit, glob=glob)
            pattern = pattern_for(query) if regex else None
        except ValueError as error:
            answers.append(error)
            continue
        answers.append(None)
        states.append((position, _Shared(query, pattern, scope, glob, limit,
                                         time.monotonic() + PATTERN_SECONDS)))
    active = [state for _, state in states]
    for path in candidates:
        if not active:
            break
        relative = path.relative_to(root).as_posix()
        refused: bool | None = None
        wanting: list[_Shared] = []
        for state in list(active):
            if state.scope is not None and not relative.startswith(state.scope + "/"):
                continue
            # In the order a search alone takes them: its file bound first.
            if state.searched >= MAXIMUM_SEARCHED_FILES:
                state.stopped_by = "files"
                active.remove(state)
                continue
            if refused is None:
                refused = unusable_path(relative) is not None
            if refused:
                continue
            if state.glob is not None and not matches_glob(relative, state.glob):
                continue
            if state.pattern is not None and time.monotonic() > state.deadline:
                state.stopped_by = "time"
                active.remove(state)
                continue
            wanting.append(state)
        if not wanting:
            continue
        try:
            with path.open("rb") as stream:
                data = stream.read(MAXIMUM_SEARCHED_BYTES)
            content = data.decode("utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if "\x00" in content:
            continue
        lines = content.splitlines()
        digest = ""
        for state in wanting:
            state.searched += 1
            for number, line in enumerate(lines, start=1):
                if state.pattern is not None:
                    if state.pattern.search(line[:PATTERN_LINE_CHARACTERS]) is None:
                        continue
                elif state.query not in line:
                    continue
                if len(state.matches) >= state.limit:
                    state.stopped_by = "matches"
                    break
                digest = digest or hashlib.sha256(data).hexdigest()
                state.matches.append(LineMatch(
                    path=relative, line=number,
                    text=line.strip()[:MAXIMUM_MATCH_CHARACTERS], digest=digest))
            if state.stopped_by == "matches":
                active.remove(state)
    for position, state in states:
        answers[position] = SearchObservation(
            query=state.query, matches=state.matches, files_searched=state.searched,
            truncated=state.stopped_by is not None, stopped_by=state.stopped_by)
    return [answer for answer in answers if answer is not None]

# How long ripgrep may take before the search walks the files itself.
RIPGREP_SECONDS = 20.0


def _ripgrep() -> str | None:
    named = os.environ.get("RELAB_RG", "").strip()
    if named and Path(named).is_file():
        return named
    return shutil.which("rg")


def _found_by_ripgrep(under: Path, root: Path, query: str) -> list[Path] | None:
    """The files under `under` holding `query`, in the walk's order; None to walk instead.

    Asked for every file, ignore files and hidden ones included, never
    following a link, skipping the directories a walk skips; whatever it
    names is still checked against the same rules before it is read.
    """
    program = _ripgrep()
    if program is None:
        return None
    command = [program, "--files-with-matches", "--fixed-strings", "--no-ignore", "--hidden",
               "--no-messages", "--null", "--no-config"]
    for name in sorted(UNSEARCHED_DIRECTORIES):
        command += ["--glob", f"!{name}/"]
    command += ["--regexp", query, "--", "."]
    try:
        done = subprocess.run(command, cwd=under, capture_output=True, timeout=RIPGREP_SECONDS,
                              check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    # 1: nothing matched. 2: an error -- some files unreadable -- with what it found.
    if done.returncode == 1 and not done.stdout:
        return []
    if done.returncode not in (0, 1, 2) or (done.returncode == 2 and not done.stdout):
        return None
    paths: list[Path] = []
    for named in done.stdout.decode("utf-8", errors="replace").split("\0"):
        named = named.strip().removeprefix("./").removeprefix(".\\")
        if not named:
            continue
        path = under.joinpath(*named.replace("\\", "/").split("/"))
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root):
            continue
        paths.append(path)
    # The walk's order: a folder's files, then its folders', each by name.
    relative = [(path.relative_to(under).parts, path) for path in paths]
    return [path for _, path in sorted(relative, key=lambda item: (item[0][:-1], item[0][-1]))]


def _searchable(under: Path, root: Path) -> "Iterator[Path]":
    """Every regular file worth opening, in a stable order, never following links.

    Sorted so two searches of an unchanged tree answer identically -- an
    observation that reorders itself is one nobody can compare against a later
    one. Directories that are noise are not descended into at all, which is
    cheaper than reading their contents to discard them.
    """
    for directory, names, filenames in os.walk(under):
        names[:] = sorted(name for name in names
                          if name not in UNSEARCHED_DIRECTORIES
                          and not (Path(directory) / name).is_symlink())
        here = Path(directory)
        for filename in sorted(filenames):
            path = here / filename
            if path.is_symlink() or not path.is_file():
                continue
            if not path.resolve().is_relative_to(root):
                continue
            yield path


def search_workspace(
    workspace: Path, query: str, *, scope: str | None = None,
    limit: int = MAXIMUM_MATCHES, regex: bool = False, glob: str | None = None,
) -> SearchObservation:
    """Compatible search observations, accelerated by the service's safe candidates."""
    from relab_workspace.code_search import CodeSearchQuery, CodeSearchService

    result = CodeSearchService(workspace).search_many([
        CodeSearchQuery(query=query, path=scope, limit=limit, regex=regex, glob=glob)])[0]
    if result.error is not None:
        raise ValueError(result.error)
    return SearchObservation(query=query, matches=result.matches,
                             files_searched=result.files_searched, truncated=result.truncated)
