"""The transactional patch lifecycle (doc/ROADMAP.md v0.5/v0.6):

    validate -> git apply --check -> apply -> verify (mandatory, sandboxed)
        -> APPLIED, or auto `git apply --reverse` -> REVERTED / REVERT_FAILED

The LLM never gets filesystem or process authority — it only ever
produced the `PatchProposal` this module consumes (AGENTS.md rule 3).
Every attempt, including a rejection, is persisted to a `PatchEvidenceStore`.

`verify_argv` runs through the Sandbox policy (`autocode/runtime/sandbox.py`)
as of v0.6, never a raw `subprocess.run` call.
"""

import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import tempfile
from pathlib import Path, PurePosixPath, PureWindowsPath
from uuid import uuid4

from relab_core.coding.patch import (
    MeasuredSubject,
    PatchEvidence,
    PatchProposal,
    PatchStatus,
    PathPolicy,
    VerificationResult,
)
from relab_core.coding.sandbox import (
    SandboxBackend,
    SandboxPolicy,
    SandboxRequest,
    SandboxStatus,
)
from relab_core.coding.termination import TerminationCode
from relab_core.operations import (
    MAXIMUM_SUBJECTS,
    OperationKind,
    OperationObserver,
    PatchDetail,
    VerificationDetail,
    narrate,
)
from relab_core.snapshots import (
    MAXIMUM_SNAPSHOT_BYTES,
    MAXIMUM_SNAPSHOT_TOTAL,
    FileSnapshot,
    SnapshotOmission,
)
from relab_execution.sandbox import (
    DockerSandbox,
    LocalProcessSandbox,
    Sandbox,
    build_sandbox_policy,
)
from relab_workspace.patch_policy import PatchRejectedError, touched_files, validate_patch
from relab_workspace.patch_store import PatchEvidenceStore
from relab_workspace.requirement_claims import read_requirement_claims
from relab_workspace.snapshot_store import SnapshotStore
from relab_workspace.verifier_environment import IMPORT_PATH_ENV_VAR, import_root

# A file the tree would not give up. Distinct from `None`, which is a file
# that is genuinely not there -- a created file's `before` is an absence and
# not a failure, and recording the two alike would lose the difference.
UNREADABLE = b"\x00unreadable"

# v0.14 verification honesty (doc/ROADMAP.md): a verify command MAY write
# `{"executed_checks": N}` as JSON to the path this env var points at. Only
# wired for the local-process backend -- a Docker container only ever sees
# `/workspace` (see `build_sandbox_policy`'s own note on why host PATH/
# ComSpec are not forwarded there either), and a host temp-file path is
# meaningless inside it. `executed_checks` stays `None` under Docker until
# that path translation exists; exit-code-only semantics apply there,
# unchanged from before v0.14.
_VERIFY_REPORT_ENV_VAR = "AUTOCODE_VERIFY_REPORT"

# An arm writes at most eight files; a verifier naming more subjects than
# that is not describing this experiment.
_MAXIMUM_REPORTED_SUBJECTS = 16

# Read in blocks; a measured artifact can be a data file as well as a module.
_DIGEST_CHUNK = 1024 * 1024

# CPython decides a cached `.pyc` is current from the source's size and its
# mtime *in whole seconds*. A person editing by hand almost never defeats
# that. ReLab does it routinely: two attempts at the same function are often
# the same length, and they are written seconds apart or less -- so the second
# attempt's verifier can import the first attempt's bytecode and measure code
# that is no longer on disk. Observed, not theorised: in the C3.1 slice, `a +
# b` was written, the verifier ran, and `add(2, 3)` returned -1.
#
# A per-verification cache directory settles it in both directions. Nothing is
# carried between attempts, and any stale `__pycache__` already in the
# workspace is bypassed rather than read, because this prefix replaces in-tree
# caching entirely. It costs a recompile per verification, which is the right
# side of the trade when the alternative is evidence about the wrong code.
#
# Local-process only, for the same reason as the report path above: a host
# directory means nothing inside a container.
_PYCACHE_PREFIX_ENV_VAR = "PYTHONPYCACHEPREFIX"


class Patcher:
    def __init__(
        self, evidence_store: PatchEvidenceStore | None = None,
        snapshot_store: SnapshotStore | None = None,
    ) -> None:
        self.evidence_store = evidence_store
        # Where a file's two states are kept. Absent for a caller that only
        # wants the patch applied; the evidence then records no snapshots, and
        # says that by having none rather than by claiming an omission.
        self.snapshot_store = snapshot_store

    def apply(
        self,
        root: Path,
        proposal: PatchProposal,
        *,
        policy: PathPolicy | None = None,
        verify_argv: list[str],
        timeout_seconds: float = 300.0,
        sandbox_policy: SandboxPolicy | None = None,
        subject_paths: list[str] | None = None,
        measurement_snapshot_id: str | None = None,
        observe: OperationObserver | None = None,
    ) -> PatchEvidence:
        root = root.resolve()
        # What a person watching is told is happening. Clamped rather than
        # checked: a progress line must not be able to refuse a patch, and the
        # bounds upstream already keep a real attempt well inside these.
        targets = sorted(proposal.base_hashes)[:MAXIMUM_SUBJECTS]
        argv = verify_argv[:64]
        # What the patch says it touches, which `validate_patch` has already
        # checked against what it declared it would.
        touched = sorted(proposal.base_hashes)
        snapshots: list[FileSnapshot] = []
        try:
            validate_patch(root, proposal, policy)
        except PatchRejectedError as error:
            return self._record(
                proposal,
                status=PatchStatus.REJECTED,
                error=str(error),
                termination_code=TerminationCode.PATCH_POLICY_REJECTED,
                failure_details={"rejection_code": error.code.value},
            )

        if not verify_argv:
            return self._record(
                proposal, status=PatchStatus.REJECTED, error="verification argv is required"
            )

        patch_path: Path | None = None
        try:
            # Narrated from here: the tree is about to change. What git said
            # about refusing is recorded as evidence and deliberately not
            # repeated here -- this journal names what was done and never
            # carries the output of doing it.
            with narrate(observe, OperationKind.PATCH_APPLICATION,
                         PatchDetail(targets=targets,
                                     patch_id=proposal.request_id)) as writing:
                with tempfile.NamedTemporaryFile(
                    "w", suffix=".patch", delete=False, encoding="utf-8", newline="\n"
                ) as handle:
                    handle.write(proposal.diff)
                    patch_path = Path(handle.name)

                check = self._git_apply(root, patch_path, extra_args=["--check"])
                if check.returncode != 0:
                    writing.failed("the patch does not fit this tree")
                    return self._record(
                        proposal,
                        status=PatchStatus.REJECTED,
                        error=f"git apply --check failed: {check.stderr}",
                    )

                # The tree as the patch found it. Read here because this is
                # the last moment it is true, and because an attempt that is
                # reverted in a few seconds leaves nowhere else to read it from.
                before = _read_all(root, touched)
                apply_result = self._git_apply(root, patch_path)
                if apply_result.returncode != 0:
                    writing.failed("the patch could not be written")
                    return self._record(
                        proposal,
                        status=PatchStatus.REJECTED,
                        error=f"git apply failed: {apply_result.stderr}",
                    )
                snapshots = self._snapshots(touched, before, _read_all(root, touched))

            # The patch is on disk from here on. EVERY exit from this point
            # must go through _revert_and_record(), including one caused by
            # the verification machinery itself failing rather than by a
            # failing verification -- found live (twice): an OSError raised
            # inside the sandbox unwound past both the revert branch and the
            # evidence write, leaving a real mutation applied and completely
            # unaudited (AGENTS.md rules 3/5). The first fix for this caught
            # one specific cause; this catches the whole class instead.
            try:
                # The event that never existed: verification happens between two
                # records nobody splits, so until now `coding.patch_started` stood
                # for the model call, the write and the verifier run at once.
                with narrate(observe, OperationKind.VERIFICATION,
                             VerificationDetail(argv=argv)) as running:
                    verification = self._verify(root, verify_argv, timeout_seconds,
                                                sandbox_policy, subject_paths,
                                                measurement_snapshot_id)
                    running.detail = VerificationDetail(
                        argv=argv, exit_code=verification.exit_code,
                        timed_out=verification.timed_out)
                    # A verifier that ran and reported a failing check completed.
                    # Only one that never reached its own end did not, and what
                    # either supports is for the layers that judge evidence.
                    if verification.timed_out:
                        running.failed(
                            "the verifier did not finish inside its timeout")
            except BaseException as error:
                # BaseException, not Exception, is deliberate: a Ctrl-C
                # mid-verification must not leave the workspace mutated
                # either. Non-Exception causes are re-raised after the
                # workspace is restored and the attempt recorded.
                unfinished = VerificationResult(
                    argv=verify_argv,
                    exit_code=None,
                    stderr=f"verification could not complete: {type(error).__name__}: {error}",
                    passed=False,
                )
                evidence = self._revert_and_record(
                    root,
                    patch_path,
                    proposal,
                    unfinished,
                    termination_code=TerminationCode.SANDBOX_EXECUTION_ERROR,
                    failure_details={"exception_type": type(error).__name__},
                    snapshots=snapshots,
                )
                if not isinstance(error, Exception):
                    raise
                return evidence

            if verification.passed:
                return self._record(proposal, status=PatchStatus.APPLIED,
                                    verification=verification, snapshots=snapshots)
            return self._revert_and_record(root, patch_path, proposal, verification,
                                           snapshots=snapshots)
        finally:
            if patch_path is not None:
                patch_path.unlink(missing_ok=True)

    def measure(
        self, root: Path, argv: list[str], *, timeout_seconds: float = 300.0,
        sandbox_policy: SandboxPolicy | None = None, live_log: Path | None = None,
    ) -> VerificationResult:
        """Run a command for its output alone; it applies and reverses nothing.

        `live_log`: a file what it prints is also appended to as it comes, for a
        person to watch (0.2.66); the result is the same without it.
        """
        if not argv or not all(argv):
            raise ValueError("measurement argv is required")
        return self._verify(root, argv, timeout_seconds, sandbox_policy, live_log=live_log)

    def restore(self, root: Path, diff: str) -> bool:
        """Undo an already-applied diff, or report that it no longer applies cleanly.

        This never forces: a tree that has moved on since the patch was applied
        keeps whatever it now holds, and the caller decides what that means.
        """
        patch_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                "w", suffix=".patch", delete=False, encoding="utf-8", newline="\n"
            ) as handle:
                handle.write(diff)
                patch_path = Path(handle.name)
            if self._git_apply(root, patch_path,
                               extra_args=["--reverse", "--check"]).returncode != 0:
                return False
            return self._git_apply(root, patch_path, extra_args=["--reverse"]).returncode == 0
        finally:
            if patch_path is not None:
                patch_path.unlink(missing_ok=True)

    def _revert_and_record(
        self,
        root: Path,
        patch_path: Path,
        proposal: PatchProposal,
        verification: VerificationResult,
        termination_code: TerminationCode | None = None,
        failure_details: dict[str, str] | None = None,
        snapshots: list[FileSnapshot] | None = None,
    ) -> PatchEvidence:
        """Undo an already-applied patch and persist the attempt. The single
        exit point for every non-APPLIED outcome after `git apply` has
        succeeded, so no future branch can skip either half again."""

        # The snapshots were taken before this ran, which is the whole point
        # of them: an attempt undone leaves nothing in the tree, and what it
        # wrote is readable afterwards only because it was kept at the time.
        revert = self._git_apply(root, patch_path, extra_args=["--reverse"])
        if revert.returncode == 0:
            return self._record(
                proposal,
                status=PatchStatus.REVERTED,
                verification=verification,
                termination_code=termination_code,
                failure_details=failure_details,
                snapshots=snapshots,
            )
        return self._record(
            proposal,
            status=PatchStatus.REVERT_FAILED,
            verification=verification,
            error=f"verification failed and revert also failed: {revert.stderr}",
            termination_code=termination_code,
            failure_details=failure_details,
            snapshots=snapshots,
        )

    def _git_apply(
        self, root: Path, patch_path: Path, *, extra_args: list[str] | None = None
    ) -> subprocess.CompletedProcess[str]:
        argv = ["git", "apply", "--whitespace=nowarn", *(extra_args or []), str(patch_path)]
        return subprocess.run(
            argv, cwd=root, capture_output=True, text=True, encoding="utf-8", check=False
        )

    def _verify(
        self,
        root: Path,
        argv: list[str],
        timeout_seconds: float,
        sandbox_policy: SandboxPolicy | None,
        subject_paths: list[str] | None = None,
        measurement_snapshot_id: str | None = None,
        live_log: Path | None = None,
    ) -> VerificationResult:
        # A caller that passes nothing gets the local-process default. That
        # is NOT the same as "no sandbox": the process still runs with a
        # bounded cwd, an explicit environment allowlist, and a timeout --
        # it just cannot deny network access, which only the Docker backend
        # can really enforce. `autocode implement/apply/generate-tests`
        # expose `--sandbox-backend docker --docker-image ...` to get that.
        policy = sandbox_policy or build_sandbox_policy()

        report_path: Path | None = None
        cache_prefix: Path | None = None
        request_environment: dict[str, str] = {}
        if policy.backend is SandboxBackend.LOCAL_PROCESS:
            fd, raw_path = tempfile.mkstemp(suffix=".json", prefix="autocode-verify-report-")
            os.close(fd)
            report_path = Path(raw_path)
            report_path.unlink(missing_ok=True)  # the verify command creates it fresh, if at all
            cache_prefix = Path(tempfile.mkdtemp(prefix="relab-verify-pycache-"))
            request_environment = {_VERIFY_REPORT_ENV_VAR: str(report_path),
                                   _PYCACHE_PREFIX_ENV_VAR: str(cache_prefix),
                                   **import_root(root)}
            allowlist = [*policy.environment_allowlist,
                         _VERIFY_REPORT_ENV_VAR, _PYCACHE_PREFIX_ENV_VAR,
                         IMPORT_PATH_ENV_VAR]
            policy = policy.model_copy(update={"environment_allowlist": allowlist})
        else:
            # The same root, where the container mounts it.
            request_environment = import_root("/workspace")
            policy = policy.model_copy(update={"environment_allowlist": [
                *policy.environment_allowlist, IMPORT_PATH_ENV_VAR]})

        # The verification boundary: the patch is on disk and the command has
        # not run. What the workspace holds for each declared subject right now
        # is what the measurement was taken of, and it is observed here because
        # this is the only moment it is true.
        measured = {path: _file_digest(root, path) for path in subject_paths or []}

        request = SandboxRequest(
            id=f"verify-{uuid4()}",
            argv=argv,
            timeout_seconds=timeout_seconds,
            environment=request_environment,
        )
        if policy.backend is SandboxBackend.LOCAL_PROCESS:
            sandbox: Sandbox = LocalProcessSandbox()
        else:
            sandbox = DockerSandbox()
        try:
            result = (sandbox.run(request, policy=policy, workspace=root, live_log=live_log)
                      if live_log is not None and isinstance(sandbox, LocalProcessSandbox)
                      else sandbox.run(request, policy=policy, workspace=root))
            report = (
                _read_verify_report(report_path)
                if report_path
                else {"executed_checks": None, "passed_checks": None, "failed_checks": None}
            )
            executed_checks = report["executed_checks"]
            subjects = _read_reported_subjects(report_path, root) if report_path else []
            # Read from the same file, by the reader that gives meaning to this
            # key and to nothing else in it.
            claimed = read_requirement_claims(report_path) if report_path else None
        finally:
            if report_path is not None:
                report_path.unlink(missing_ok=True)
            if cache_prefix is not None:
                shutil.rmtree(cache_prefix, ignore_errors=True)
        return VerificationResult(
            argv=argv,
            exit_code=result.exit_code,
            stdout=result.stdout,
            stderr=result.stderr,
            timed_out=result.status is SandboxStatus.TIMED_OUT,
            # `executed_checks != 0` is True both when it genuinely passed
            # a positive count AND when it is None (never reported) --
            # only an explicit, reported zero forces this False.
            passed=result.status is SandboxStatus.SUCCEEDED and executed_checks != 0,
            executed_checks=executed_checks,
            passed_checks=report["passed_checks"],
            failed_checks=report["failed_checks"],
            reported_subjects=subjects,
            claimed_requirements=claimed,
            measured_digests=measured,
            measurement_snapshot_id=measurement_snapshot_id,
        )

    def _snapshots(
        self, touched: list[str],
        before: dict[str, bytes | None], after: dict[str, bytes | None],
    ) -> list[FileSnapshot]:
        """What each file held either side, filed under its own digest.

        Never raises. A workspace that cannot keep these still runs the study
        and still records the patch; what it loses is the ability to show a
        comparison afterwards, and the record says so per file rather than
        leaving somebody to infer it from a missing blob.
        """
        store = self.snapshot_store
        if store is None:
            return []
        budget, kept = MAXIMUM_SNAPSHOT_TOTAL, []
        for path in touched:
            sides = (before.get(path), after.get(path))
            omitted = _why_not_kept(sides, budget)
            digests: list[str | None] = []
            for side in sides:
                # A side nobody could read has no digest either. This record
                # says which file and which two states of it; naming bytes that
                # were never read would be the record asserting one of them.
                if side is None or side is UNREADABLE:
                    digests.append(None)
                    continue
                try:
                    digests.append(store.put(side) if omitted is None else _digest(side))
                except (OSError, sqlite3.Error):
                    # The bytes could not be kept. The identity still can be,
                    # and the record is honest about which of the two it has.
                    digests.append(_digest(side))
                    omitted = SnapshotOmission.UNREADABLE
            if omitted is None:
                budget -= sum(len(side) for side in sides if side is not None)
            kept.append(FileSnapshot(
                path=path, before_digest=digests[0], after_digest=digests[1],
                omitted=omitted))
        return kept

    def _record(
        self,
        proposal: PatchProposal,
        *,
        status: PatchStatus,
        verification: VerificationResult | None = None,
        error: str | None = None,
        termination_code: TerminationCode | None = None,
        failure_details: dict[str, str] | None = None,
        snapshots: list[FileSnapshot] | None = None,
    ) -> PatchEvidence:
        try:
            touched = touched_files(proposal.diff)
        except PatchRejectedError:
            touched = []
        evidence = PatchEvidence(
            patch_id=proposal.request_id,
            diff=proposal.diff,
            touched_files=touched,
            snapshots=snapshots or [],
            verification=verification,
            status=status,
            error=error,
            termination_code=termination_code,
            failure_details=failure_details or {},
        )
        if self.evidence_store is not None:
            self.evidence_store.save(evidence)
        return evidence


def _digest(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _read_all(root: Path, paths: list[str]) -> dict[str, bytes | None]:
    """Each file's bytes right now, or None where the tree holds nothing.

    A file that cannot be read is `False`, which is neither its content nor an
    absence -- `_why_not_kept` turns that into a stated omission rather than
    letting "there was no file here" stand in for "this could not be read".
    """
    found: dict[str, bytes | None] = {}
    for path in paths:
        target = root / path
        try:
            found[path] = target.read_bytes() if target.is_file() else None
        except OSError:
            found[path] = UNREADABLE
    return found


def _why_not_kept(
    sides: tuple[bytes | None, bytes | None], budget: int,
) -> SnapshotOmission | None:
    """Whether these bytes may be kept, and what to say when they may not."""
    if any(side is UNREADABLE for side in sides):
        return SnapshotOmission.UNREADABLE
    present = [side for side in sides if side is not None]
    if any(len(side) > MAXIMUM_SNAPSHOT_BYTES for side in present) \
            or sum(map(len, present)) > budget:
        return SnapshotOmission.TOO_LARGE
    for side in present:
        try:
            side.decode("utf-8")
        except UnicodeDecodeError:
            return SnapshotOmission.NOT_TEXT
    return None


def _file_digest(root: Path, path: str) -> str | None:
    """What this workspace holds at `path`, or None when it holds nothing there.

    None is an observation. A declared subject that is not on disk when the
    verifier starts is exactly the case a verifier claiming to have measured it
    must be caught by, so "absent" has to be a value rather than an omission.

    Anything unreadable -- a directory, a broken link, a permission error --
    also reads as None. This is provenance, and a path that cannot be read
    cannot have been measured either.
    """
    candidate = root.joinpath(*PurePosixPath(path.replace("\\", "/")).parts)
    digest = hashlib.sha256()
    try:
        with candidate.open("rb") as handle:
            for chunk in iter(lambda: handle.read(_DIGEST_CHUNK), b""):
                digest.update(chunk)
    except OSError:
        return None
    return digest.hexdigest()


def _reported_path(raw: str, root: Path) -> str | None:
    """One spelling of a path, read as the workspace-relative one ReLab records.

    Three conversions, and each is a fact rather than a guess:

        src\\calculator.py                 a separator, on Windows
        ./calculator/impl.py               a relative path said explicitly
        C:/workspace/calculator/impl.py    an absolute path inside the workspace

    Two live runs, two models, two spellings -- `os.path.join` in one and a
    resolved absolute path in the other -- and both named the artifact under
    test correctly. How a script refers to a file is not a claim about what it
    measured, and ReLab had been reading it as one.

    What is *not* converted is a path outside the workspace. That is not this
    study's artifact under a different name; it is a different file, and saying
    so is the whole point of asking what was measured.
    """
    named = PurePosixPath(raw.replace("\\", "/"))
    if named.is_absolute() or PureWindowsPath(raw).drive:
        try:
            inside = Path(raw).resolve().relative_to(root.resolve())
        except (OSError, ValueError):
            return None
        return inside.as_posix()
    parts = [part for part in named.parts if part != "."]
    if not parts or ".." in parts:
        return None
    return PurePosixPath(*parts).as_posix()


def _read_reported_subjects(report_path: Path, root: Path) -> list[MeasuredSubject]:
    r"""What the verify command said it measured, read from the same report.

    Every entry must name a path and a digest. One that names only a path has
    not reported provenance -- it has reported an intention -- so it is dropped
    rather than carried as a subject with an empty digest, which would be a
    third state nothing knows how to read.

    Separators are normalised, and a live run is why. A real model wrote
    `os.path.join('src', 'calculator.py')`, which is the correct way to name a
    file from a script, and on Windows produces `src\calculator.py`. ReLab
    records workspace paths with forward slashes, so the comparison found
    nothing and reported the verifier as having measured something it had not
    named -- when it had named exactly the artifact under test, with the right
    digest. The spelling of a separator is not a claim about what was measured.

    Bounded, because this is model-written text arriving through a file.
    """
    try:
        payload = json.loads(report_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(payload, dict):
        return []
    reported = payload.get("subjects")
    if not isinstance(reported, list):
        return []
    subjects = []
    for item in reported[:_MAXIMUM_REPORTED_SUBJECTS]:
        if not isinstance(item, dict):
            continue
        path, digest = item.get("path"), item.get("digest")
        if not isinstance(path, str) or not isinstance(digest, str):
            continue
        if not path.strip() or not digest.strip() or len(path) > 1024 or len(digest) > 128:
            continue
        named = _reported_path(path.strip(), root)
        if named is None:
            continue
        subjects.append(MeasuredSubject(path=named, digest=digest.strip()))
    return subjects


def _read_verify_report(report_path: Path) -> dict[str, int | None]:
    """Read the optional `AUTOCODE_VERIFY_REPORT` JSON.

    v0.22 reads two more keys than v0.14 did, `passed_checks` and
    `failed_checks`, and reads them the same way: only what the verify
    command actually reported. They are not derived from
    `executed_checks` and an exit code -- a suite can exit non-zero with
    most checks passing, and inventing the split would put a number in
    `AttemptProgress` that nothing measured.

    Missing, malformed, and negative all read as `None`, which means "not
    reported". A reported `0` is a real answer and survives.
    """

    absent: dict[str, int | None] = {
        "executed_checks": None,
        "passed_checks": None,
        "failed_checks": None,
    }
    try:
        raw = report_path.read_text(encoding="utf-8")
    except OSError:
        return absent
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return absent
    if not isinstance(payload, dict):
        return absent
    return {key: _non_negative_int(payload.get(key)) for key in absent}


def _non_negative_int(value: object) -> int | None:
    # `bool` is an `int` in Python, and `True` is not a check count.
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        return None
    return value
