"""Reading the journal of what was going on. The only thing that can.

Writing lives next door in `operation_recorder`, which explains what the
journal is for and why it has no authority. This half exists separately so the
rule can be checked rather than remembered: a module that concludes anything
may hold a recorder and narrate freely, and importing *this* is what
`tests/contract/test_journal_authority.py` refuses across the decision layer.

A progress note read back by something that decides would be evidence, and the
first time it disagreed with `runs.db` the record would hold two answers with no
way to choose between them.
"""

import sqlite3
from contextlib import closing

from relab_core.operations import OperationEvent
from relab_workspace.operation_recorder import Journal


class OperationStore(Journal):
    def events(self, *, limit: int | None = None) -> list[OperationEvent]:
        """Everything recorded, oldest first, or the newest `limit` of it.

        An unreadable or half-written journal reads as an empty one, and a record
        that does not read -- written by another version, cut short -- is passed
        over, not the journal with it. Found in use (0.2.39): records an earlier
        version wrote with a field this one does not know made every read come
        back empty, and the chat showed no progress at all. Nothing concludes
        from these records, so a gap in them costs a person some progress
        lines; raising here would cost them the timeline.
        """
        try:
            return self._read(limit)
        except (OSError, sqlite3.Error, ValueError):
            return []

    def _read(self, limit: int | None) -> list[OperationEvent]:
        with closing(sqlite3.connect(self.path)) as db:
            if limit is None:
                rows = db.execute(
                    "SELECT payload FROM operation_events ORDER BY sequence").fetchall()
            else:
                rows = list(reversed(db.execute(
                    "SELECT payload FROM operation_events ORDER BY sequence DESC LIMIT ?",
                    (limit,)).fetchall()))
        read: list[OperationEvent] = []
        for row in rows:
            try:
                read.append(OperationEvent.model_validate_json(row[0]))
            except ValueError:
                continue
        return read
