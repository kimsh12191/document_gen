"""Immutable, append-only audit trail for every patch attempt.

Every outcome is persisted — `proposed`/`rejected`/`applied`/`reverted`/
`revert_failed` — never only successes (AGENTS.md rule 5: rejection is
not a silent no-op).
"""

import sqlite3
from contextlib import closing
from pathlib import Path

from relab_core.coding.patch import PatchEvidence, PatchStatus
from relab_core.runs import CodingRun
from relab_workspace.private_state import state_dir


class PatchEvidenceStore:
    def __init__(self, path: Path) -> None:
        self.path = path

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._connect()) as connection:
            connection.execute(
                "CREATE TABLE IF NOT EXISTS patch_evidence ("
                "patch_id TEXT PRIMARY KEY, payload TEXT NOT NULL)"
            )
            connection.commit()

    def save(self, evidence: PatchEvidence) -> PatchEvidence:
        self.initialize()
        try:
            with closing(self._connect()) as connection:
                connection.execute(
                    "INSERT INTO patch_evidence(patch_id, payload) VALUES (?, ?)",
                    (evidence.patch_id, evidence.model_dump_json()),
                )
                connection.commit()
        except sqlite3.IntegrityError as error:
            raise ValueError(
                f"patch evidence is immutable and already exists: {evidence.patch_id}"
            ) from error
        return evidence

    def load(self, patch_id: str) -> PatchEvidence:
        self.initialize()
        with closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT payload FROM patch_evidence WHERE patch_id = ?", (patch_id,)
            ).fetchone()
        if row is None:
            raise LookupError(f"patch evidence not found: {patch_id}")
        return PatchEvidence.model_validate_json(row[0])

    def list(self) -> list[PatchEvidence]:
        self.initialize()
        with closing(self._connect()) as connection:
            rows = connection.execute(
                "SELECT payload FROM patch_evidence ORDER BY patch_id"
            ).fetchall()
        return [PatchEvidence.model_validate_json(row[0]) for row in rows]

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.path)


def reconcilable_evidence(workspace: Path, run: CodingRun) -> tuple[PatchEvidence | None, str]:
    """Decide whether stored evidence settles an interrupted patch, without writing.

    Returning None never means "assume it failed": it means the record does not
    answer the question, and only a person can.
    """
    if run.proposal is None or not run.verify_argv:
        return None, "no recorded proposal and verifier to reconcile against"
    path = state_dir(workspace) / "patches.db"
    if path.is_symlink() or not path.is_file():
        return None, "patch evidence storage is unavailable"
    try:
        evidence = PatchEvidenceStore(path).load(run.proposal.request_id)
    except (LookupError, ValueError, sqlite3.Error):
        return None, "no stored patch evidence for the recorded proposal"
    if evidence.diff != run.proposal.diff:
        return None, "stored evidence does not match the recorded proposal"
    if evidence.status == PatchStatus.APPLIED and (
        evidence.verification is None or not evidence.verification.passed
    ):
        return None, "applied evidence lacks successful verification"
    if evidence.verification is not None and evidence.verification.argv != run.verify_argv:
        return None, "stored evidence verifier does not match the recorded verifier"
    return evidence, f"stored evidence records {evidence.status.value}"
