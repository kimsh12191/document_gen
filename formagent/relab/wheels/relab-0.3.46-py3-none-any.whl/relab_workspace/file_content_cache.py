"""Bounded file observations cached by metadata, with permission rechecked on every hit."""
from collections import OrderedDict
from pathlib import Path
from threading import RLock

from relab_core.inspection import FileObservation
from relab_workspace.file_index import safe_file
from relab_workspace.inspection import read_workspace_file


class FileContentCache:
    def __init__(self, workspace: Path, capacity: int = 32) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.capacity = capacity
        self._cache: OrderedDict[str, tuple[tuple[int, int, int, int], FileObservation]] = OrderedDict()
        self._lock = RLock()

    def get(self, path: str) -> FileObservation:
        with self._lock:
            if not safe_file(self.workspace, path, exclude_noise=False):
                self._cache.pop(path, None)
                raise ValueError("cannot read unsafe or missing workspace file")
            target = self.workspace / path
            stat = target.stat()
            key = (stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_ino)
            cached = self._cache.get(path)
            if cached is not None and cached[0] == key:
                self._cache.move_to_end(path)
                return cached[1].model_copy(deep=True)
            observation = read_workspace_file(self.workspace, path)
            # Never cache a read raced by an external writer.
            after = target.stat()
            if key == (after.st_size, after.st_mtime_ns, after.st_ctime_ns, after.st_ino):
                self._cache[path] = (key, observation)
                self._cache.move_to_end(path)
                while len(self._cache) > self.capacity:
                    self._cache.popitem(last=False)
            return observation.model_copy(deep=True)

    def invalidate(self, path: str | None = None) -> None:
        with self._lock:
            if path is None:
                self._cache.clear()
            else:
                self._cache.pop(path, None)
