"""Immutable workspace-local contexts produced by explicit exploration."""

import sqlite3
from contextlib import closing
from pathlib import Path

from relab_core.inspection import InspectionContext
from relab_workspace.private_state import state_dir


class InspectionContextStore:
    def __init__(self, workspace: Path) -> None:
        root = workspace.resolve(strict=True)
        state = state_dir(root)
        self.path = state / "inspection_contexts.db"
        if not root.is_dir() or state.is_symlink() or self.path.is_symlink():
            raise ValueError("invalid inspection context storage location")
        state.mkdir(exist_ok=True)
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("CREATE TABLE IF NOT EXISTS contexts (context_id TEXT PRIMARY KEY, payload TEXT NOT NULL)")
            db.commit()

    def add(self, context: InspectionContext) -> InspectionContext:
        try:
            with closing(sqlite3.connect(self.path)) as db:
                db.execute("INSERT INTO contexts(context_id, payload) VALUES (?, ?)",
                           (context.context_id, context.model_dump_json()))
                db.commit()
        except sqlite3.IntegrityError as error:
            raise ValueError(f"inspection context already recorded: {context.context_id}") from error
        return context

    def load(self, context_id: str) -> InspectionContext:
        with closing(sqlite3.connect(self.path)) as db:
            row = db.execute("SELECT payload FROM contexts WHERE context_id=?", (context_id,)).fetchone()
        if row is None:
            raise LookupError(f"inspection context not found: {context_id}")
        return InspectionContext.model_validate_json(row[0])
