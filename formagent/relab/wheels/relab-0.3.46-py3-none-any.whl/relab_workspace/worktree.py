"""A throwaway checkout of one revision, so an attempt cannot touch the caller's tree.

Isolation here is structural rather than checked: the attempt reads, edits and
verifies inside its own worktree, and that worktree is removed afterwards. The
caller's working tree is never written to, so nothing needs restoring.
"""

import json
import shutil
import subprocess
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from relab_core.checkouts import CheckoutRecord
from relab_workspace.locking import repository_lock
from relab_workspace.private_state import state_dir

GIT_TIMEOUT_SECONDS = 120
WORKTREE_DIRECTORY = "worktrees"
# Adding and removing a worktree writes one administrative area shared by every
# workspace of the repository, so those steps are serialized across processes.
# The attempt between them is not.
ADMINISTRATION_WAIT_SECONDS = 30.0
MARKER_SUFFIX = ".checkout.json"


@contextmanager
def isolated_worktree(
    workspace: Path, revision: str, *, owner: str | None = None,
    session: str | None = None,
) -> Iterator[Path]:
    """Check `revision` out beside the workspace and remove it when done.

    A worktree holds only what the revision contains: uncommitted and untracked
    files are absent by construction, which is what makes the starting state
    identical for every attempt.

    `owner` and `session` are written beside the checkout so that one left by an
    interrupted process can be attributed later. Removal here is a `finally`,
    which a killed process never reaches -- see `abandoned_checkouts`.
    """
    root = workspace.resolve(strict=True)
    parent = _checkout_directory(root)
    parent.mkdir(parents=True, exist_ok=True)
    path = parent / uuid4().hex
    common = _common_directory(root)
    with repository_lock(common, wait_seconds=ADMINISTRATION_WAIT_SECONDS):
        created = _git(root, ["worktree", "add", "--detach", "--quiet", str(path), revision])
    if created.returncode != 0:
        raise ValueError(
            "could not create an isolated worktree; the workspace needs a Git repository "
            f"holding {revision}"
        )
    _write_marker(parent / f"{path.name}{MARKER_SUFFIX}", owner, session)
    try:
        yield path.resolve(strict=True)
    finally:
        remove_checkout(root, path.name)


def abandoned_checkouts(workspace: Path) -> list[CheckoutRecord]:
    """Every checkout still present, which is every one nothing removed.

    A checkout is removed at the end of the attempt that made it, so one that is
    here is either in use right now or was left by a process that did not finish.
    Deciding which is not this function's to do; it reports what is there.
    """
    root = workspace.resolve(strict=True)
    parent = state_dir(root) / WORKTREE_DIRECTORY
    if parent.is_symlink() or not parent.is_dir():
        return []
    records = []
    for path in sorted(parent.iterdir()):
        if path.is_symlink() or not path.is_dir():
            continue
        records.append(_record(path, parent / f"{path.name}{MARKER_SUFFIX}"))
    return records


def remove_checkout(workspace: Path, name: str) -> bool:
    """Remove one checkout and its marker; pruning is repository-wide, so it locks."""
    root = workspace.resolve(strict=True)
    parent = _checkout_directory(root)
    path = parent / name
    if path.parent.resolve() != parent or path.is_symlink():
        raise ValueError("a checkout to remove must be one this workspace made")
    marker = parent / f"{name}{MARKER_SUFFIX}"
    with repository_lock(_common_directory(root), wait_seconds=ADMINISTRATION_WAIT_SECONDS):
        # Forced because the attempt deliberately leaves edits behind in here.
        _git(root, ["worktree", "remove", "--force", str(path)])
        _git(root, ["worktree", "prune"])
    # Git refuses a worktree it no longer recognizes, so the directory may remain.
    if path.is_dir():
        shutil.rmtree(path, ignore_errors=True)
    marker.unlink(missing_ok=True)
    return not path.exists()


def _checkout_directory(root: Path) -> Path:
    state = state_dir(root)
    parent = state / WORKTREE_DIRECTORY
    if state.is_symlink() or parent.is_symlink():
        raise ValueError("worktree storage must be local directories")
    return parent


def _write_marker(marker: Path, owner: str | None, session: str | None) -> None:
    marker.write_text(json.dumps({
        "owner_run_id": owner, "session_id": session,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }), encoding="utf-8")


def _record(path: Path, marker: Path) -> CheckoutRecord:
    """A marker that is missing or unreadable leaves the checkout unattributed.

    Guessing an owner from a directory name would be worse than saying nothing:
    the whole use of the attribution is deciding whether removal is safe.
    """
    stored: dict[str, object] = {}
    if marker.is_file() and not marker.is_symlink():
        try:
            loaded = json.loads(marker.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            loaded = None
        if isinstance(loaded, dict):
            stored = loaded
    created = stored.get("created_at")
    return CheckoutRecord(
        name=path.name, path=str(path),
        owner_run_id=_text(stored.get("owner_run_id")),
        session_id=_text(stored.get("session_id")),
        created_at=_moment(created if isinstance(created, str) else None),
    )


def _text(value: object) -> str | None:
    return value if isinstance(value, str) and value.strip() else None


def _moment(value: str | None) -> datetime | None:
    if value is None:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def _common_directory(root: Path) -> Path:
    """Where every worktree of this repository keeps the state they all share."""
    completed = _git(root, ["rev-parse", "--git-common-dir"])
    if completed.returncode != 0:
        raise ValueError(
            "could not create an isolated worktree; the workspace needs a Git repository")
    directory = Path(completed.stdout.strip())
    return directory if directory.is_absolute() else (root / directory).resolve()


def workspace_revision(workspace: Path) -> str | None:
    """The commit an isolated attempt would start from, or None without one."""
    completed = _git(workspace.resolve(strict=True), ["rev-parse", "HEAD"])
    return completed.stdout.strip() if completed.returncode == 0 else None


def _git(root: Path, arguments: list[str]) -> "subprocess.CompletedProcess[str]":
    try:
        return subprocess.run(
            ["git", "-C", str(root), *arguments], capture_output=True, text=True,
            timeout=GIT_TIMEOUT_SECONDS, check=False,
        )
    except (OSError, subprocess.SubprocessError) as error:
        raise ValueError(f"git worktree command failed: {type(error).__name__}") from error
