"""Asking a ruler what it was built to check, before any arm has run.

Deliberately not part of reading a measurement. The measurement reader answers
"did a measurement happen" -- executed checks, subjects, digests, an exit code --
and every one of those is about a run against an implementation. This is the
question before that one: what does this instrument say it examines, asked of
the instrument alone.

So it is a separate reader and a separate run, and neither borrows from the
other. A probe that went through the measurement path would produce a reading,
and a reading of a verifier run against nothing is a reading of nothing -- which
is exactly the shape of result this whole axis exists to stop being mistaken for
a measurement.

## What the probe is allowed to conclude

One thing: the list of requirement identifiers the verifier declared. Not
whether the verifier works, not whether anything passed, not whether a check
executed. The exit code is expected to be non-zero -- the arms have written
nothing, so anything the instrument measures is absent -- and it is discarded
rather than interpreted.

    claims written, verifier exited 1     an observation
    claims written, verifier exited 0     an observation, and still not a measurement
    no claims written                     nothing observed, which is not a claim of none

## Why it runs somewhere else

A probe is not part of the study, so it must leave nothing in it. A verifier may
write caches, coverage files, temporary databases -- ordinary things for a test
command to do, and all of them side effects on a workspace whose state is
evidence. It runs in a directory this module makes and deletes.

That directory holds the frozen ruler's own files and nothing else, which is not
only frugal: it is the contract being enforced. A verifier that cannot say what
it checks without the implementation present has made its declaration depend on
the arm, and a declaration that depends on the arm is the thing this is here to
prevent.
"""

import json
import shutil
import tempfile
from pathlib import Path

from relab_core.coding.sandbox import SandboxPolicy, SandboxRequest, SandboxStatus
from relab_core.measurement import MAXIMUM_CLAIMS
from relab_execution.sandbox import LocalProcessSandbox, build_sandbox_policy
from relab_workspace.verifier_environment import IMPORT_PATH_ENV_VAR, import_root

# The same channel the verify report already travels on. One file, two readers,
# and they read different keys for different questions.
_REPORT_ENV_VAR = "AUTOCODE_VERIFY_REPORT"

# Long enough for an instrument to say what it is, short enough that a probe
# cannot become the thing that holds up a study. It is not running the
# experiment; it is asking a question before one starts.
PROBE_TIMEOUT_SECONDS = 60.0


def read_requirement_claims(report_path: Path) -> list[str] | None:
    """Which requirements a verify report declares, and nothing else from it.

    `None` is "said nothing about requirements", which is not "said it checks
    none". The first is a verifier written before any of this was asked of one;
    the second would be a claim, and no verifier here has made it.

    What arrives is kept as it arrives. Repeats stay, and an identifier no plan
    declares stays: this records what was claimed, and deciding what a claim is
    worth needs the design, which this layer does not have and must not acquire.
    Dropping an unrecognised one would throw away exactly the material a later
    reading needs, because a requirement declared next week may be one this
    verifier already said it checks.
    """
    try:
        payload = json.loads(report_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    reported = payload.get("claimed_requirements")
    if not isinstance(reported, list):
        return None
    return [item.strip() for item in reported[:MAXIMUM_CLAIMS]
            if isinstance(item, str) and item.strip()]


def probe_requirement_claims(
    workspace: Path, artifacts: list[str], argv: list[str], *,
    timeout_seconds: float = PROBE_TIMEOUT_SECONDS,
    sandbox_policy: SandboxPolicy | None = None,
) -> tuple[list[str] | None, list[str]]:
    """Run the ruler alone, and read only what it says it checks.

    Returns the claims and whatever was wrong with the asking. The second is for
    a person: a probe that heard nothing should say whether the instrument
    declined to answer or never got far enough to be asked.

    Never raises. A probe that failed is a question that went unanswered, and
    an unanswered question is not a finding about a study.
    """
    limitations: list[str] = []
    room = Path(tempfile.mkdtemp(prefix="relab-claim-probe-"))
    try:
        for name in artifacts:
            source = workspace / name
            target = room / name
            target.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copyfile(source, target)
            except OSError:
                limitations.append(f"the ruler's {name} could not be read for the probe")
                return None, limitations
        report = room / "claims.json"
        policy = sandbox_policy or build_sandbox_policy()
        policy = policy.model_copy(update={
            "environment_allowlist": [*policy.environment_allowlist, _REPORT_ENV_VAR,
                                      IMPORT_PATH_ENV_VAR]})
        try:
            result = LocalProcessSandbox().run(
                SandboxRequest(id="requirement-claim-probe", argv=argv,
                               timeout_seconds=timeout_seconds,
                               environment={_REPORT_ENV_VAR: str(report),
                                            **import_root(room)}),
                policy=policy, workspace=room)
        except (OSError, ValueError) as error:
            limitations.append(
                f"the ruler could not be asked what it checks: {type(error).__name__}")
            return None, limitations
        if result.status is SandboxStatus.TIMED_OUT:
            # It may still have declared before it hung, so the file is read
            # either way; this only says the asking did not finish cleanly.
            limitations.append("the ruler did not finish being asked what it checks")
        claimed = read_requirement_claims(report)
        if claimed is None:
            limitations.append(
                "the ruler reported nothing about which requirements it checks")
        return claimed, limitations
    finally:
        shutil.rmtree(room, ignore_errors=True)
