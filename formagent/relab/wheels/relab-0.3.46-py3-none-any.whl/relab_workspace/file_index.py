"""A service-owned, bounded-lifetime listing; cached paths never grant permission."""
import os
import stat
import sys
import time
from collections.abc import Iterable
from pathlib import Path
from threading import RLock

from relab_core.targets import PROTECTED_SEGMENTS, UNSEARCHED_DIRECTORIES, unusable_path
from relab_workspace.rg_process import ripgrep, run_rg


def safe_file(root: Path, relative: str, *, exclude_noise: bool = True) -> bool:
    if unusable_path(relative) is not None:
        return False
    parts = relative.split("/")
    if exclude_noise and any(part in UNSEARCHED_DIRECTORIES for part in parts[:-1]):
        return False
    try:
        if any(root.joinpath(*parts[:i]).is_symlink() for i in range(1, len(parts) + 1)):
            return False
        target = root.joinpath(*parts)
        return target.is_file() and target.resolve(strict=True).is_relative_to(root)
    except OSError:
        return False


def safe_files(root: Path, names: Iterable[str], *, exclude_noise: bool = True) -> list[str]:
    """The names `safe_file` allows, in their order, checked now (RL-03).

    The same rule, decided once per folder instead of once per file: each
    search checked every file of the index again, and `safe_file` looks at
    every folder on a file's way for a link and resolves the file -- 1.3 of
    a 1.7-second search over 5,000 files. Here a folder reached with no link
    or junction on the way (it resolves to itself) is looked at once per
    call; in one, a file needs only to be a plain file, not a link or another
    reparse point. A folder holding many of the names is listed once instead
    of asked about file by file: the listing carries what each entry is, with
    no call per file on Windows. Anything else is decided by `safe_file`
    itself. Nothing is kept between calls: a folder made a link after this
    call is seen by the next. `root` must already be resolved.
    """
    asked: list[tuple[str, list[str], tuple[str, ...]]] = []
    many: dict[tuple[str, ...], int] = {}
    for name in names:
        if unusable_path(name) is not None:
            continue
        parts = name.split("/")
        folder = tuple(parts[:-1])
        if exclude_noise and any(part in UNSEARCHED_DIRECTORIES for part in folder):
            continue
        asked.append((name, parts, folder))
        many[folder] = many.get(folder, 0) + 1
    kept: list[str] = []
    folders: dict[tuple[str, ...], bool] = {}
    listed: dict[tuple[str, ...], dict[str, bool | None]] = {}
    for name, parts, folder in asked:
        plain = folders.get(folder)
        if plain is None:
            plain = folders[folder] = _plain_folder(root, folder)
        if not plain:
            if safe_file(root, name, exclude_noise=exclude_noise):
                kept.append(name)
            continue
        if many[folder] >= LIST_FROM and folder not in listed:
            listed[folder] = _plain_entries(root.joinpath(*folder))
        entry = listed.get(folder, {}).get(parts[-1], MISSING)
        if entry is MISSING:
            entry = _plain_entry(root.joinpath(*parts))
        if entry is None:
            # A reparse point that is not a link, or what it is unknown: the full rule.
            if safe_file(root, name, exclude_noise=exclude_noise):
                kept.append(name)
        elif entry:
            kept.append(name)
    return kept


# A folder holding at least this many of the names asked about is listed once.
LIST_FROM = 16
MISSING = object()


def _plain_entry(path: Path) -> bool | None:
    """Whether a path is a plain file -- not a link -- by lstat; None for another reparse point."""
    try:
        found = os.lstat(path)
    except OSError:
        return False
    if getattr(found, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        return None
    return stat.S_ISREG(found.st_mode)


def _plain_entries(folder: Path) -> dict[str, bool | None]:
    """What each entry of a folder is, from one listing: as `_plain_entry` says of it.

    A name the listing does not hold (spelled in another case, made since) is
    not answered here; the caller asks `_plain_entry`.
    """
    said: dict[str, bool | None] = {}
    try:
        with os.scandir(folder) as entries:
            for entry in entries:
                if entry.is_symlink() or not entry.is_file(follow_symlinks=False):
                    said[entry.name] = False
                elif sys.platform == "win32" and entry.stat(follow_symlinks=False).st_file_attributes \
                        & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                    said[entry.name] = None
                else:
                    said[entry.name] = True
    except OSError:
        return {}
    return said


def _plain_folder(root: Path, folder: tuple[str, ...]) -> bool:
    """Whether a folder under `root` is reached with no link or junction on the way."""
    try:
        if any(root.joinpath(*folder[:index]).is_symlink() for index in range(1, len(folder) + 1)):
            return False
        target = root.joinpath(*folder)
        return target.is_dir() and target.resolve(strict=True) == target
    except OSError:
        return False


class WorkspaceFileIndex:
    def __init__(self, workspace: Path, ttl_seconds: float = 15.0) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.ttl_seconds = ttl_seconds
        self._files: tuple[str, ...] | None = None
        self._expires = 0.0
        self._lock = RLock()

    def files(self) -> tuple[str, ...]:
        with self._lock:
            if self._files is None or time.monotonic() >= self._expires:
                return self.refresh()
            return self._files

    def refresh(self) -> tuple[str, ...]:
        with self._lock:
            program = ripgrep()
            data = None
            if program:
                command = [program, "--files", "--hidden", "--no-ignore", "--null", "--no-config"]
                for name in sorted(UNSEARCHED_DIRECTORIES | PROTECTED_SEGMENTS):
                    command += ["--iglob", f"!{name}/"]
                data = run_rg(command, self.workspace)
            if data is not None:
                names = data.decode("utf-8", errors="replace").replace("\\", "/").split("\0")
            else:
                names = []
                for directory, folders, files in os.walk(self.workspace):
                    folders[:] = sorted(name for name in folders
                                        if name not in UNSEARCHED_DIRECTORIES
                                        and not (Path(directory) / name).is_symlink())
                    names.extend((Path(directory) / name).relative_to(self.workspace).as_posix()
                                 for name in files)
            listed = sorted({name.removeprefix("./") for name in names if name})
            self._files = tuple(sorted(safe_files(self.workspace, listed),
                                       key=lambda name: (name.split("/")[:-1], name.split("/")[-1])))
            self._expires = time.monotonic() + self.ttl_seconds
            return self._files

    def invalidate(self, paths: Iterable[str] | None = None) -> None:
        with self._lock:
            if paths is None or self._files is None:
                self._files = None
                return
            names = set(self._files)
            for path in paths:
                names.discard(path)
                if safe_file(self.workspace, path):
                    names.add(path)
            self._files = tuple(sorted(names, key=lambda n: (n.split("/")[:-1], n.split("/")[-1])))
