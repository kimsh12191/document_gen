"""Where ReLab keeps what it keeps: with the person, not in the workspace (0.2.62).

Asked for in use: on a team's servers, sharing a NAS, each person works in a
copy of their own that the others can open -- and so could read the chat in
its `.relab/`; and most link their `~/.vscode-server` to a folder of their own
on the NAS, so what is kept there follows them from server to server. ReLab's
records of a workspace -- conversations, coding loop records, snapshots for
undo, logs of programs it started, scores, lessons, research sessions -- are
kept under the person's own folder:

    $RELAB_PRIVATE_HOME (or ~/.relab)/workspaces/<16 hex of the workspace's path>/

The editor sets `RELAB_PRIVATE_HOME` to its own storage under ~/.vscode-server
(or the folder the settings name). Folders are made readable by their owner
only, where the system has modes. What a workspace kept in `.relab/` before is
moved here the first time, except what people write and keep with the project:
its rules (`RELAB.md`, `projects/`) and its MCP servers (`mcp.json`).

`RELAB_STATE_IN_WORKSPACE=1` keeps everything in the workspace's `.relab/`, as
before: for the test suite, and for a benchmark's throwaway workspaces.
"""

import hashlib
import os
import shutil
from pathlib import Path

PRIVATE_ENV = "RELAB_PRIVATE_HOME"
IN_WORKSPACE_ENV = "RELAB_STATE_IN_WORKSPACE"
# Written by people and kept with the project: never moved out of it. `config.json`
# is the project's settings for `relab chat` (0.3.8).
KEPT_IN_WORKSPACE = frozenset({"RELAB.md", "projects", "mcp.json", "config.json"})
MOVED = "moved-from-workspace"


def private_base() -> Path:
    given = os.environ.get(PRIVATE_ENV, "").strip()
    return Path(given).expanduser() if given else Path.home() / ".relab"


def in_workspace() -> bool:
    return os.environ.get(IN_WORKSPACE_ENV, "").strip() not in ("", "0")


def _owner_only(path: Path) -> None:
    if os.name == "posix":
        try:
            path.chmod(0o700)
        except OSError:
            pass


def workspace_key(workspace: Path) -> str:
    """The folder name a workspace's records are kept under, in any records base."""
    return hashlib.sha256(str(workspace.resolve()).encode("utf-8")).hexdigest()[:16]


def private_path(workspace: Path) -> Path:
    """Where this person's folder for this workspace is; made by `private_root`."""
    return private_base() / "workspaces" / workspace_key(workspace)


# The editor's own storage, where it keeps records unless its settings name a folder.
EDITOR_STORAGE = "iyyun.relab"


def editor_bases() -> list[Path]:
    """The editor's records bases on this machine that exist (0.3.25).

    Found in use: loops run in the editor on a server were not there for
    `relab code list` in its terminal, which looked in ~/.relab while the
    editor had set the base to its storage under ~/.vscode-server.
    """
    home = Path.home()
    places = [home / ".vscode-server" / "data" / "User" / "globalStorage",
              home / ".config" / "Code" / "User" / "globalStorage",
              home / "Library" / "Application Support" / "Code" / "User" / "globalStorage"]
    appdata = os.environ.get("APPDATA", "").strip()
    if appdata:
        places.append(Path(appdata) / "Code" / "User" / "globalStorage")
    return [place / EDITOR_STORAGE for place in places if (place / EDITOR_STORAGE).is_dir()]


def private_root(workspace: Path) -> Path:
    """This person's folder for this workspace, made when first asked for."""
    root = private_path(workspace)
    base = private_base()
    root.mkdir(parents=True, exist_ok=True)
    for folder in (base, base / "workspaces", root):
        _owner_only(folder)
    named = root / "workspace.txt"
    if not named.exists():
        # For a person looking in the folder: which workspace this is.
        named.write_text(str(workspace.resolve()) + "\n", encoding="utf-8")
    return root


def _move_in(workspace: Path, root: Path) -> None:
    """What the workspace's `.relab/` kept, moved here once; what people wrote stays."""
    if (root / MOVED).exists():
        return
    old = workspace.resolve() / ".relab"
    if old.is_dir() and not old.is_symlink():
        for item in old.iterdir():
            if item.name in KEPT_IN_WORKSPACE or item.is_symlink():
                continue
            target = root / item.name
            if target.exists():
                if item.is_dir() and target.is_dir():
                    for inner in item.iterdir():
                        if not (target / inner.name).exists() and not inner.is_symlink():
                            shutil.move(str(inner), str(target / inner.name))
                    try:
                        item.rmdir()
                    except OSError:
                        pass
                continue
            try:
                shutil.move(str(item), str(target))
            except OSError:
                # In use by a process of an earlier version: tried again next time.
                return
        try:
            old.rmdir()
        except OSError:
            pass
    (root / MOVED).write_text("1\n", encoding="utf-8")


def state_dir(workspace: Path) -> Path:
    """Where ReLab keeps its records of this workspace."""
    if in_workspace():
        state = workspace.resolve() / ".relab"
        state.mkdir(exist_ok=True)
        return state
    root = private_root(workspace)
    _move_in(workspace, root)
    return root


def has_state(workspace: Path) -> bool:
    """Whether ReLab has kept anything for this workspace, without making a folder to say so."""
    old = workspace.resolve() / ".relab"
    if in_workspace():
        return old.exists()
    return private_path(workspace).exists() or (old.is_dir() and any(
        item.name not in KEPT_IN_WORKSPACE for item in old.iterdir()))


def private_folder(workspace: Path, name: str) -> Path:
    folder = state_dir(workspace) / name
    folder.mkdir(parents=True, exist_ok=True)
    _owner_only(folder)
    return folder


def private_file(workspace: Path, name: str) -> Path:
    return state_dir(workspace) / name
