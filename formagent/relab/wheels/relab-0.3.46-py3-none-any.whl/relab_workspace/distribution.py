"""Build and check an offline distribution bundle; never reach an index.

The bundle is built the way an air-gapped install must later happen: the wheel
is built without downloading a build backend, and every dependency wheel comes
from a directory the caller names. Nothing here fetches anything, so a bundle
that is not self-sufficient says so instead of quietly working on the machine
that built it and failing on the one that needs it.
"""

import hashlib
import re
import shutil
import subprocess
import sys
import zipfile
from email.parser import Parser
from pathlib import Path

from relab_core.distribution import (
    BundledFile,
    BundledRequirement,
    BundleVerification,
    DistributionBundle,
)

BUILD_TIMEOUT_SECONDS = 600
MANIFEST = "bundle.json"
MAXIMUM_WHEELS = 200
_NAME = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?")


def build_bundle(
    source: Path, into: Path, *, find_links: list[Path] | None = None,
) -> DistributionBundle:
    """Build the wheel, collect the dependencies named, and record what resulted."""
    origin = source.resolve(strict=True)
    target = into.resolve()
    if target.is_symlink() or (target.exists() and not target.is_dir()):
        raise ValueError("bundle storage must be a local directory")
    target.mkdir(parents=True, exist_ok=True)
    built = _build_wheel(origin, target)
    for directory in find_links or []:
        _collect(directory, target)
    fields, declared = _metadata(built)
    requirements = _requirements(declared, target)
    manifest = DistributionBundle(
        name=fields.get("Name") or "unknown",
        version=fields.get("Version") or "0",
        requires_python=fields.get("Requires-Python"),
        files=_files(target), requirements=requirements,
        unjudged=[item.requirement for item in requirements
                  if item.environment_marker is not None],
        self_sufficient=all(item.satisfied for item in requirements
                            if item.environment_marker is None),
    )
    (target / MANIFEST).write_text(manifest.model_dump_json(indent=2), encoding="utf-8")
    return manifest


def verify_bundle(directory: Path) -> BundleVerification:
    """Re-read the bundle from its files; the manifest is a claim, not evidence."""
    root = directory.resolve(strict=True)
    stored = root / MANIFEST
    if stored.is_symlink() or not stored.is_file():
        raise ValueError(f"bundle has no {MANIFEST}; it was not built by this command")
    manifest = DistributionBundle.model_validate_json(stored.read_text(encoding="utf-8"))
    missing, altered = [], []
    for item in manifest.files:
        path = root / item.name
        if path.is_symlink() or not path.is_file():
            missing.append(item.name)
        elif _digest(path) != item.sha256 or path.stat().st_size != item.size:
            altered.append(item.name)
    named = {item.name for item in manifest.files}
    unexpected = sorted(item.name for item in _files(root) if item.name not in named)
    return BundleVerification(
        bundle=manifest, missing=missing, altered=altered, unexpected=unexpected,
        intact=not missing and not altered,
    )


def _build_wheel(source: Path, into: Path) -> Path:
    """No build isolation: downloading a backend is exactly what a bundle cannot do."""
    before = set(into.glob("*.whl"))
    completed = subprocess.run(
        [sys.executable, "-m", "pip", "wheel", "--no-deps", "--no-build-isolation",
         "--wheel-dir", str(into), "--", str(source)],
        capture_output=True, text=True, timeout=BUILD_TIMEOUT_SECONDS, check=False,
    )
    produced = sorted(set(into.glob("*.whl")) - before)
    if completed.returncode != 0 or len(produced) != 1:
        detail = (completed.stderr or completed.stdout).strip()[-800:]
        raise ValueError(f"could not build the distribution wheel: {detail}")
    return produced[0]


def _collect(directory: Path, into: Path) -> None:
    source = directory.resolve(strict=True)
    if not source.is_dir():
        raise ValueError(f"dependency wheels must come from a directory: {source}")
    wheels = sorted(source.glob("*.whl"))
    if len(wheels) > MAXIMUM_WHEELS:
        raise ValueError(f"a bundle may collect at most {MAXIMUM_WHEELS} wheels")
    for wheel in wheels:
        if wheel.is_symlink():
            raise ValueError(f"a bundled wheel must be a real file: {wheel.name}")
        destination = into / wheel.name
        if destination.exists() and _digest(destination) != _digest(wheel):
            raise ValueError(f"two different wheels claim the same name: {wheel.name}")
        shutil.copyfile(wheel, destination)


def _metadata(wheel: Path) -> tuple[dict[str, str], list[str]]:
    """Describe the wheel from its own METADATA, not from what a source file said."""
    with zipfile.ZipFile(wheel) as archive:
        names = [name for name in archive.namelist()
                 if name.endswith(".dist-info/METADATA")]
        if len(names) != 1:
            raise ValueError("the built wheel carries no single METADATA to describe it")
        text = archive.read(names[0]).decode("utf-8", errors="replace")
    message = Parser().parsestr(text)
    fields = {key: message.get(key) for key in ("Name", "Version", "Requires-Python")}
    declared = [line for line in message.get_all("Requires-Dist") or [] if line.strip()]
    return {key: value for key, value in fields.items() if value is not None}, declared


def _requirements(declared: list[str], into: Path) -> list[BundledRequirement]:
    """Markers are recorded, never evaluated: whether one applies is the target
    machine's fact, not the building machine's, and guessing it would be the one
    error a bundle cannot afford."""
    present = _present(into)
    collected = []
    for line in declared:
        requirement, _, marker = line.partition(";")
        distribution = _distribution(requirement)
        wheels = sorted(present.get(_normalize(distribution), []))
        collected.append(BundledRequirement(
            requirement=line.strip(), distribution=distribution, wheels=wheels,
            satisfied=bool(wheels), environment_marker=marker.strip() or None,
        ))
    return collected


def _present(into: Path) -> dict[str, list[str]]:
    found: dict[str, list[str]] = {}
    for wheel in sorted(into.glob("*.whl")):
        found.setdefault(_normalize(wheel.name.split("-")[0]), []).append(wheel.name)
    return found


def _distribution(requirement: str) -> str:
    matched = _NAME.match(requirement.strip())
    if matched is None:
        raise ValueError(f"a declared requirement names no distribution: {requirement!r}")
    return matched.group(0)


def _normalize(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def _files(directory: Path) -> list[BundledFile]:
    return [
        BundledFile(name=path.name, sha256=_digest(path), size=path.stat().st_size)
        for path in sorted(directory.iterdir())
        if path.is_file() and not path.is_symlink() and path.name != MANIFEST
    ]


def _digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()
