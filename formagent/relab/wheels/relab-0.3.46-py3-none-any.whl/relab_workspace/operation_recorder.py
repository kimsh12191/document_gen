"""Writing the journal of what was going on, with no way to read it back.

Append-only, like the other two stores, and unlike them it decides nothing. A
study's truth lives in `runs.db` and `sessions.db`; this is `operations.db`, and
it exists so a person watching can see a provider being called, files being
written and a verifier running, instead of watching record kinds go past.

## Why writing and reading are two classes

The layers that run a study -- dispatch, lifecycle, the patch service -- have
something to say and no business knowing what anyone else said. The layer that
shows a timeline needs to read and never writes. Handing both a store with both
methods would leave "nothing that decides reads the journal" as a rule kept by
everyone remembering it.

So a decision module can hold an `OperationRecorder` and physically cannot read
one line of the journal; `OperationStore`, next door, is the only thing that
can, and `tests/contract/test_journal_authority.py` keeps it out of every module
that concludes anything. The invariant survives being forgotten.

## Two properties it must keep

**Nothing reads it to decide.** Lifecycle, readiness, assessment and every
conclusion read the domain stores. If one of them ever read this, a progress
note would have become evidence, and the first disagreement between the two
would leave the record with two answers and no way to choose.

**Losing it costs nothing but the view.** Recording is best-effort and swallows
its own failures: a workspace where this file cannot be opened still runs
studies, still records evidence and still concludes. An observability journal
able to stop an experiment would be a worse thing than no journal, and these
calls are made from inside real work -- mid-patch, mid-verification -- where a
raise would do exactly that.

The sequence here is its own, and means only "the order these were written". It
is not the `RunEvent.sequence` that pins evidence and gates concurrent writes,
which is the whole reason this is a separate file.
"""

import sqlite3
import sys
from collections.abc import Sequence
from contextlib import closing
from pathlib import Path
from threading import Lock
from typing import TypeVar

from relab_core.operations import OperationEvent, OperationState
from relab_workspace.private_state import state_dir

JournalT = TypeVar("JournalT", bound="Journal")


class Journal:
    """Where the file is and what shape it has. Neither reads nor writes."""

    def __init__(self, workspace: Path) -> None:
        root = workspace.resolve(strict=True)
        state = state_dir(root)
        self.path = state / "operations.db"
        if not root.is_dir() or state.is_symlink() or self.path.is_symlink():
            raise ValueError("invalid workspace state location")
        state.mkdir(exist_ok=True)
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("CREATE TABLE IF NOT EXISTS operation_events ("
                       "sequence INTEGER PRIMARY KEY AUTOINCREMENT, "
                       "payload TEXT NOT NULL)")
            db.commit()

    @classmethod
    # `typing.Self` would say this, and arrives in 3.11; this package runs on 3.10.
    def open(cls: type[JournalT], workspace: Path) -> JournalT | None:  # noqa: PYI019
        """This, or nothing at all when the workspace cannot hold a journal.

        A caller that needs one constructs it directly and sees the failure. A
        caller that only wants a study narrated uses this, because the
        alternative is a workspace that cannot be used at all on account of a
        display, and that is exactly the dependency this file promises not to be.
        """
        try:
            return cls(workspace)
        except (OSError, sqlite3.Error, ValueError):
            return None


class OperationRecorder(Journal):
    """Append one record. There is deliberately no way to get one back out."""

    def __init__(self, workspace: Path) -> None:
        super().__init__(workspace)
        self._lock = Lock()
        self._db: sqlite3.Connection | None = None
        # Whether a failed write was said already: once, not on every event.
        self._said_failure = False
        # While held, the connection stays open between operations, and the
        # holder closes it (RL-04). Closed after each operation instead, every
        # one cost about 15 ms on Windows -- connecting, and the checkpoint a
        # last connection does on closing -- against under 1 ms held: a coding
        # loop narrates every read, search and call, twice.
        self.holding = False

    def __call__(self, event: OperationEvent, /) -> None:
        self.append(event)
        if event.state is not OperationState.STARTED and not self.holding:
            self.close()

    def hold(self) -> None:
        """Keep the connection open between operations until `release`."""
        self.holding = True

    def release(self) -> None:
        """Stop holding, and close: nothing keeps the file open after this."""
        self.holding = False
        self.close()

    def append(self, event: OperationEvent) -> None:
        self.append_many([event])

    def append_many(self, events: Sequence[OperationEvent]) -> None:
        """A single best-effort transaction; no journal failure stops the task."""
        with self._lock:
            try:
                if self._db is None:
                    self._db = sqlite3.connect(self.path, check_same_thread=False)
                    self._db.execute("PRAGMA journal_mode=WAL")
                    # A progress journal: a power cut may lose its last lines,
                    # which costs the view and nothing else. Not synced per commit.
                    self._db.execute("PRAGMA synchronous=NORMAL")
                with self._db:
                    for event in events:
                        cursor = self._db.execute(
                            "INSERT INTO operation_events (payload) VALUES (?)",
                            (event.model_dump_json(),))
                        sequence = int(cursor.lastrowid or 0)
                        self._db.execute("UPDATE operation_events SET payload=? WHERE sequence=?",
                                         (event.model_copy(update={"sequence": sequence})
                                          .model_dump_json(), sequence))
            except (OSError, sqlite3.Error) as error:
                self._close()
                if not self._said_failure:
                    # Still never a reason for the work to stop -- but said, once:
                    # a journal that drops every write silently left the chat
                    # showing nothing, and nobody could tell why (0.2.39).
                    self._said_failure = True
                    print(f"[relab] the operations journal could not be written "
                          f"({type(error).__name__}: {error}); progress will not show in "
                          f"the chat, the work goes on", file=sys.stderr, flush=True)

    def _close(self) -> None:
        if self._db is not None:
            try:
                self._db.close()
            except sqlite3.Error:
                pass
            self._db = None

    def close(self) -> None:
        with self._lock:
            self._close()
