"""Append-only research grouping events with optimistic concurrency control."""

import sqlite3
from contextlib import closing
from pathlib import Path

from relab_core.coding.base import utc_now
from relab_core.research import ResearchSession, ResearchSessionEvent
from relab_workspace.locking import session_execution_lock
from relab_workspace.private_state import state_dir


class SessionStore:
    def __init__(self, workspace: Path) -> None:
        root = workspace.resolve(strict=True)
        self.workspace = root
        state = state_dir(root)
        self.path = state / "sessions.db"
        if not root.is_dir() or state.is_symlink() or self.path.is_symlink():
            raise ValueError("invalid research session storage location")
        state.mkdir(exist_ok=True)
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("CREATE TABLE IF NOT EXISTS session_events ("
                       "session_id TEXT, sequence INTEGER, payload TEXT NOT NULL, "
                       "PRIMARY KEY(session_id, sequence))")
            db.commit()

    def session_ids(self) -> list[str]:
        """Every research session in this workspace, ordered so listings are stable."""
        with closing(sqlite3.connect(self.path)) as db:
            rows = db.execute(
                "SELECT DISTINCT session_id FROM session_events ORDER BY session_id").fetchall()
        return [row[0] for row in rows]

    def events(self, session_id: str) -> list[ResearchSessionEvent]:
        with closing(sqlite3.connect(self.path)) as db:
            rows = db.execute("SELECT payload FROM session_events WHERE session_id=? "
                              "ORDER BY sequence", (session_id,)).fetchall()
        return [ResearchSessionEvent.model_validate_json(row[0]) for row in rows]

    def latest(self, session_id: str) -> ResearchSessionEvent:
        events = self.events(session_id)
        if not events:
            raise LookupError(f"research session not found: {session_id}")
        return events[-1]

    def append(self, snapshot: ResearchSession, kind: str, expected_sequence: int) -> None:
        # Hold through commit: checking a busy flag first would leave a race with execute.
        if kind in {"research.plan_recorded", "research.plan_revised",
                    "research.concluded", "research.reopened"}:
            with session_execution_lock(self.workspace, snapshot.session_id):
                self._append(snapshot, kind, expected_sequence)
        else:
            self._append(snapshot, kind, expected_sequence)

    def _append(self, snapshot: ResearchSession, kind: str, expected_sequence: int) -> None:
        with closing(sqlite3.connect(self.path)) as db:
            db.execute("BEGIN IMMEDIATE")
            current = db.execute("SELECT COALESCE(MAX(sequence), 0) FROM session_events "
                                 "WHERE session_id=?", (snapshot.session_id,)).fetchone()[0]
            if current != expected_sequence:
                raise ValueError("research session changed; reload before attaching another run")
            event = ResearchSessionEvent(
                session_id=snapshot.session_id, sequence=current + 1, kind=kind,
                timestamp=utc_now(), snapshot=snapshot,
            )
            db.execute("INSERT INTO session_events VALUES (?, ?, ?)",
                       (snapshot.session_id, event.sequence, event.model_dump_json()))
            db.commit()
