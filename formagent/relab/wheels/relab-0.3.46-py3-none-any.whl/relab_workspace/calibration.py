"""Running a control against a frozen ruler, somewhere that is not the study.

The execution machinery is the arm's, unchanged -- the same sandbox and the
same report channel -- because a calibration measured by different machinery
would produce numbers nobody could compare to an arm's. The *accounting* is not
the arm's at all: nothing here is an attempt, spends a repeat, or produces
evidence about the thing under study.

Reading numbers out of what the ruler printed happens a layer up, where the one
parser every metric in this system comes through lives.

It runs in a directory this module makes and deletes. A control writes a file
into a tree and asks a verifier to measure it, which is exactly what an arm
does, and doing that in the study's own workspace would leave a subject nobody
declared where an arm's subject is supposed to be. The disposable root holds the
frozen ruler's artifacts and the one control subject, and nothing else.

That is also what makes the numbers mean something. If the good and the broken
subject are the only things that differ between two runs of the same verifier in
two identical trees, then a difference in what it printed came from them.
"""

import hashlib
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from relab_core.calibration import ControlReading, MeasurementControlRun
from relab_core.coding.patch import VerificationResult
from relab_core.coding.sandbox import SandboxPolicy, SandboxRequest, SandboxStatus
from relab_core.controls import ControlSubject, MeasurementControl
from relab_execution.sandbox import LocalProcessSandbox, build_sandbox_policy
from relab_workspace.patcher import _read_reported_subjects, _read_verify_report
from relab_workspace.requirement_claims import read_requirement_claims
from relab_workspace.verifier_environment import IMPORT_PATH_ENV_VAR, import_root

_REPORT_ENV_VAR = "AUTOCODE_VERIFY_REPORT"

# A calibration is bounded like a verification is, and for the same reason: an
# instrument that hangs is a finding about the instrument.
CONTROL_TIMEOUT_SECONDS = 300.0


def run_control(
    workspace: Path, artifacts: list[str], argv: list[str],
    control: MeasurementControl, snapshot_id: str, *,
    timeout_seconds: float = CONTROL_TIMEOUT_SECONDS,
    sandbox_policy: SandboxPolicy | None = None,
) -> MeasurementControlRun | None:
    """Measure both of a control's subjects with this ruler.

    The readings come back without metrics: this layer runs things and does not
    read numbers out of them, so the caller parses what the ruler printed. See
    `_measure`.

    `None` when the ruler could not be set up to be asked at all -- an artifact
    that would not copy. That is an unanswered question about the instrument and
    not a finding about it, the same distinction the claim probe keeps.

    Never raises. A calibration that failed is a calibration that did not
    happen, and turning that into an exception would let a question about the
    ruler end a study.
    """
    readings = []
    for subject in (control.good_subject, control.bad_subject):
        reading = _measure(workspace, artifacts, argv, subject,
                           timeout_seconds=timeout_seconds,
                           sandbox_policy=sandbox_policy)
        if reading is None:
            return None
        readings.append(reading)
    return MeasurementControlRun(
        control_id=control.control_id, snapshot_id=snapshot_id,
        good=readings[0], bad=readings[1],
        executed_at=datetime.now(timezone.utc))


def _measure(
    workspace: Path, artifacts: list[str], argv: list[str], subject: ControlSubject, *,
    timeout_seconds: float, sandbox_policy: SandboxPolicy | None,
) -> ControlReading | None:
    """One subject, one run of the ruler, and whatever it printed."""
    content = subject.content.encode("utf-8")
    room = Path(tempfile.mkdtemp(prefix="relab-control-"))
    limitations: list[str] = []
    try:
        for name in artifacts:
            target = room / name
            target.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copyfile(workspace / name, target)
            except OSError:
                return None
        written = room / subject.path
        written.parent.mkdir(parents=True, exist_ok=True)
        try:
            written.write_bytes(content)
        except OSError:
            return None
        report = room / "control-report.json"
        policy = sandbox_policy or build_sandbox_policy()
        policy = policy.model_copy(update={
            "environment_allowlist": [*policy.environment_allowlist, _REPORT_ENV_VAR,
                                      IMPORT_PATH_ENV_VAR]})
        try:
            result = LocalProcessSandbox().run(
                SandboxRequest(id=f"control-{subject.path}", argv=argv,
                               timeout_seconds=timeout_seconds,
                               environment={_REPORT_ENV_VAR: str(report),
                                            **import_root(room)}),
                policy=policy, workspace=room)
        except (OSError, ValueError) as error:
            limitations.append(
                f"the ruler could not be run against this subject: {type(error).__name__}")
            return None
        if result.status is SandboxStatus.TIMED_OUT:
            limitations.append("the ruler did not finish measuring this subject")
        # The metrics are read where metrics are read. This layer may not reach
        # the parser -- judgement is a package it does not depend on -- and one
        # parser that every number in this system comes through is worth more
        # than a second copy here that would drift from it.
        #
        # The report is read by the readers an arm's verification uses, so a
        # count means the same thing on both sides of a comparison.
        counts = _read_verify_report(report)
        claimed = read_requirement_claims(report)
        return ControlReading(
            subject_digest=hashlib.sha256(content).hexdigest(),
            verification=VerificationResult(
                argv=list(argv), exit_code=result.exit_code,
                stdout=result.stdout, stderr=result.stderr,
                timed_out=result.status is SandboxStatus.TIMED_OUT,
                # Never `passed`. A calibration has no verdict to give: whether
                # this ruler is sensitive is read from both subjects together,
                # and a single run of it decides nothing.
                passed=False,
                executed_checks=counts["executed_checks"],
                passed_checks=counts["passed_checks"],
                failed_checks=counts["failed_checks"],
                reported_subjects=_read_reported_subjects(report, room),
                claimed_requirements=claimed,
                measurement_snapshot_id=None),
            limitations=limitations,
            # Read, not judged: whether it declared is a fact about how far the
            # ruler got, and what that means depends on whether it was asked to.
            declared=claimed is not None,
            executed_checks_observed=counts["executed_checks"] is not None)
    finally:
        shutil.rmtree(room, ignore_errors=True)
