"""Bounded explicit target read for model-assisted editing; no repository discovery."""

from pathlib import Path

from relab_core.targets import EditTarget, TargetOperation, unusable_target


def refuse_target(workspace: Path, target: EditTarget) -> str | None:
    """Why this target cannot be written, or None when it can.

    Asked before a session is recorded, so a design that could never execute is
    refused while it is still a proposal. It reads the tree and writes nothing.

    The operation decides what "usable" means, and it is taken from the plan
    rather than from the filesystem. An absent file is a legal `create` and an
    impossible `edit`; a present one is the reverse. Working it out from what is
    there would turn a misspelled path into a new file, silently, which is the
    one outcome worth refusing loudly.
    """
    wrong = unusable_target(target.path)
    if wrong is not None:
        return wrong
    parts = target.path.split("/")
    root = workspace.resolve(strict=True)
    for index in range(1, len(parts) + 1):
        if root.joinpath(*parts[:index]).is_symlink():
            return f"{target.path!r} traverses a symbolic link"
    where = root.joinpath(*parts)
    if target.operation is TargetOperation.CREATE:
        # `exists` follows links and `is_symlink` does not, so a broken link is
        # caught by the second where the first would call the path free.
        if where.exists() or where.is_symlink():
            return f"{target.path!r} is already here, and this arm means to create it"
        return None
    if not where.exists():
        return f"{target.path!r} is not here, and this arm means to edit it"
    if not where.is_file():
        return f"{target.path!r} is not a regular file"
    if not where.resolve(strict=True).is_relative_to(root):
        return f"{target.path!r} leaves the workspace"
    return None


def read_change_source(workspace: Path, target: EditTarget) -> bytes | None:
    """What the tree holds for this target: bytes, or nothing when it is absent.

    An observation, and only that. Whether absence is correct depends on what the
    plan intended, which this function is not the place to decide -- generation
    compares the two and refuses a disagreement. So a target meaning to edit a
    file that is gone reads as `None` here and is refused there, with a sentence
    saying the file was removed after the design was accepted, rather than
    surfacing as a `FileNotFoundError` from a path resolution.

    The path itself was already checked when the `EditTarget` was built.
    """
    parts = target.path.split("/")
    root = workspace.resolve(strict=True)
    if not root.joinpath(*parts).is_file():
        return None
    return read_edit_target(workspace, target.path)


def read_edit_target(workspace: Path, relative: str) -> bytes:
    """The bytes of a file that is expected to be there."""
    # The shape rule lives in core because a proposal is checked against it too,
    # before anything is recorded. Two copies would have drifted, and the copy
    # that mattered was the one nobody reached until a session already existed.
    wrong = unusable_target(relative)
    if wrong is not None:
        raise ValueError(f"generation target {wrong}")
    parts = relative.split("/")
    root = workspace.resolve(strict=True)
    target = root.joinpath(*parts)
    for index in range(1, len(parts) + 1):
        if root.joinpath(*parts[:index]).is_symlink():
            raise ValueError("generation target cannot traverse symbolic links")
    if not target.resolve(strict=True).is_relative_to(root) or not target.is_file():
        raise ValueError("generation target must be a local existing file")
    with target.open("rb") as stream:
        data = stream.read(65537)
    if len(data) > 65536:
        raise ValueError("generation target exceeds 64 KiB")
    text = data.decode("utf-8")
    if "\x00" in text or not text.endswith("\n"):
        raise ValueError("generation requires UTF-8 text with a final newline and no NUL")
    return data
