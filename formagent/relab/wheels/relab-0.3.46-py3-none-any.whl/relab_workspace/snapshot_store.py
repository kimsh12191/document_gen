"""File contents kept under their own digest, so a record can prove itself.

Unlike the operations journal next door, this is evidence: losing it loses a
person's ability to see what an attempt did to a file that no longer holds it.
It lives with the other records, in the workspace that owns them, and it is
written inside the same lock that applies the patch.

Content-addressed, which buys three things at once. The same unchanged file read
by two arms is stored once. A blob that does not hash to the name it is filed
under is not the blob, so nothing has to be trusted to have kept them in order.
And writing the same content twice is not a conflict to resolve -- it is the
same fact arriving again.
"""

import hashlib
import sqlite3
import zlib
from collections.abc import Sequence
from contextlib import closing
from pathlib import Path
from threading import Lock

# Contents are kept compressed (RL-08) when that makes them smaller: source
# text kept whole for every one-line change grew the store to fifty times the
# files it described, and compresses to about a tenth. The digest is always
# of the bytes themselves, so a record names the same content either way, and
# rows written before compression -- `encoding` null -- read as they were.
ZLIB = "zlib"
COMPRESS_FROM = 64
COMPRESS_LEVEL = 6
# No content is larger than this when read back: a row that would inflate
# past it was not written by this store.
MAXIMUM_CONTENT = 64 * 1024 * 1024


def _stored(content: bytes) -> tuple[bytes, str | None]:
    """What a content is kept as: compressed when that is smaller, else itself."""
    if len(content) < COMPRESS_FROM:
        return content, None
    packed = zlib.compress(content, COMPRESS_LEVEL)
    return (packed, ZLIB) if len(packed) < len(content) else (content, None)


def _content(stored: bytes, encoding: str | None) -> bytes | None:
    """A kept content as its bytes; None when it cannot be read back as one."""
    if encoding is None:
        return stored
    if encoding != ZLIB:
        return None
    unpack = zlib.decompressobj()
    try:
        content = unpack.decompress(stored, MAXIMUM_CONTENT)
    except zlib.error:
        return None
    return None if unpack.unconsumed_tail or not unpack.eof else content


class SnapshotStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._initialized = False
        self._lock = Lock()
        # While held, one connection serves every put and get until `release`
        # (a coding leg holds it): connecting and closing for each write cost
        # most of a write's 12 ms on Windows. Commits stay fully synced: this
        # is evidence, unlike the operations journal.
        self.holding = False
        self._db: sqlite3.Connection | None = None
        self._use = Lock()

    def hold(self) -> None:
        """Keep one connection open for puts and gets until `release`."""
        self.holding = True

    def release(self) -> None:
        """Stop holding, and close: nothing keeps the file open after this."""
        with self._use:
            self.holding = False
            if self._db is not None:
                self._db.close()
                self._db = None

    def _connect(self) -> sqlite3.Connection:
        if not self.holding:
            return sqlite3.connect(self.path)
        if self._db is None:
            self._db = sqlite3.connect(self.path, check_same_thread=False)
        return self._db

    def _done(self, db: sqlite3.Connection) -> None:
        if db is not self._db:
            db.close()

    def initialize(self) -> None:
        with self._lock:
            if self._initialized:
                return
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with closing(sqlite3.connect(self.path)) as db:
                db.execute("PRAGMA journal_mode=WAL")
                db.execute("CREATE TABLE IF NOT EXISTS snapshots ("
                           "digest TEXT PRIMARY KEY, content BLOB NOT NULL, encoding TEXT)")
                columns = {row[1] for row in db.execute("PRAGMA table_info(snapshots)")}
                if "encoding" not in columns:
                    # A store from before compression: its rows stay as they are.
                    db.execute("ALTER TABLE snapshots ADD COLUMN encoding TEXT")
                db.commit()
            self._initialized = True

    def put(self, content: bytes) -> str:
        return self.put_many([content])[0]

    def put_many(self, contents: Sequence[bytes]) -> list[str]:
        """Store pre-images together, one transaction, preserving input order."""
        if not contents:
            return []
        digests = [hashlib.sha256(content).hexdigest() for content in contents]
        self.initialize()
        rows = [(digest, *_stored(content)) for digest, content in zip(digests, contents)]
        with self._use:
            db = self._connect()
            try:
                with db:
                    db.executemany("INSERT OR IGNORE INTO snapshots (digest, content, encoding) "
                                   "VALUES (?, ?, ?)", rows)
            finally:
                self._done(db)
        return digests

    def get(self, digest: str) -> bytes | None:
        """The content filed under this digest, or nothing.

        Checked on the way out. A row whose content does not hash to its own key
        cannot have been written by `put`, so returning it would be handing back
        something this store has no account of -- and the caller asked for a
        specific state of a specific file, not for whatever is under that name.
        """
        if not self.path.exists():
            return None
        self.initialize()
        with self._use:
            db = self._connect()
            try:
                row = db.execute(
                    "SELECT content, encoding FROM snapshots WHERE digest = ?", (digest,)).fetchone()
            finally:
                self._done(db)
        if row is None:
            return None
        content = _content(row[0], row[1])
        if content is None:
            return None
        return content if hashlib.sha256(content).hexdigest() == digest else None

    def compact(self) -> dict[str, int]:
        """Compress the rows kept before compression, when that makes them smaller (RL-08).

        Asked for, never run on its own. Every row is checked against its digest
        before it is rewritten, and one that does not match is left as it is;
        nothing is removed. The file is then rewritten to give the space back.
        """
        self.initialize()
        rewritten = before = after = 0
        with self._lock, closing(sqlite3.connect(self.path)) as db:
            with db:
                for digest, stored in db.execute(
                        "SELECT digest, content FROM snapshots WHERE encoding IS NULL").fetchall():
                    if hashlib.sha256(stored).hexdigest() != digest:
                        continue
                    packed, encoding = _stored(stored)
                    if encoding is None:
                        continue
                    db.execute("UPDATE snapshots SET content = ?, encoding = ? WHERE digest = ? "
                               "AND encoding IS NULL", (packed, encoding, digest))
                    rewritten += 1
                    before += len(stored)
                    after += len(packed)
            db.execute("VACUUM")
        return {"rows": rewritten, "bytes_before": before, "bytes_after": after}
