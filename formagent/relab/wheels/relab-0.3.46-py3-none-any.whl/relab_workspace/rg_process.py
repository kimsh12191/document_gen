"""Bounded ripgrep processes, shared by the index and search accelerator."""
import os
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeoutError
from pathlib import Path

MAX_OUTPUT = 4_000_000


def ripgrep() -> str | None:
    named = os.environ.get("RELAB_RG", "").strip()
    return named if named and Path(named).is_file() else shutil.which("rg")


def run_rg(command: list[str], cwd: Path, timeout: float = 20.0) -> bytes | None:
    """Return bounded output, or None so callers use their safe fallback."""
    try:
        with subprocess.Popen(command, cwd=cwd, stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, shell=False) as process:
            assert process.stdout is not None
            with ThreadPoolExecutor(max_workers=1) as pool:
                output = pool.submit(process.stdout.read, MAX_OUTPUT + 1)
                try:
                    data = output.result(timeout=timeout)
                    if len(data) > MAX_OUTPUT:
                        process.kill()
                        return None
                    process.wait(timeout=timeout)
                except (FutureTimeoutError, subprocess.TimeoutExpired):
                    process.kill()
                    process.wait()
                    return None
            return data if process.returncode in (0, 1) else None
    except (OSError, subprocess.SubprocessError):
        return None
